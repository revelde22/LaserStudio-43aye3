# Recuperación del proyecto 43AYE3 Laser

Revisión de 01/10/2026. Base: `43AYE3_COMPLETO_SDXL_ESPANOL_CONTADOR.zip`.
Se recuperaron contexto de conversaciones y archivos disponibles; no se dispone de una exportación literal exhaustiva de todos los hilos. El inventario incluye las versiones encontradas, sin afirmar que cada una haya sido probada o integrada por separado.

| Petición recuperada | Estado en esta entrega |
|---|---|
| Encuadre continuo y recorrido de vectores | Código preservado; requiere validación física |
| Fill, imágenes y parámetros de plumas | Código preservado, envío nativo compatible |
| Tallado imagen/vector, limpieza final | Integrado; limpieza configurable |
| Biblioteca agregar/editar/borrar materiales | Preservada; parche conserva biblioteca personal |
| GPU RTX 5060, CPU como respaldo | Preservado; log aportado confirma inferencia de profundidad en RTX 5060 |
| Mapa de profundidad objetivo en mm | Integrado con muestra medida y comprobación de pluma |
| Relieve artístico, grises/fondo, formato redondo | Preservado |
| Preparación rápida y cancelación | Preservada; prueba Qt confirma cancelación sin emitir órdenes |
| FLUX.2 Klein y prompt español | Cambio solicitado en este hilo: 4B destilado FP8, 4 pasos, 768/512 px, texto/VAE CPU y lowvram |
| Contador de pasadas | Confirmaciones por bloque SDK; nunca se inventa telemetría interna |
| Tiempo estimado y barra | Añadidos y probados con reloj simulado y panel Qt real |
| Parámetros iniciales latón | Referencia oficial G2 1000/70/30; pasadas/hatch de prueba explícitos |
| Manual completo, flujos ilustrados y API/ejemplos | Tres PDF actualizados en Help/Ayuda y F1 |
| Tallado fluido / no marca | Pendiente diagnóstico físico. No se reactivó la cola que fallaba |

## Comprobaciones de esta revisión

Sintaxis de los módulos principales; ETA ponderada y STOP parcial; contador con segmentos y limpieza; cálculo mm y exportación PNG uint16; valores inválidos sin generar salida; conservación de blancos interiores; grafo SDXL; interfaz Qt real con proceso nativo simulado. Se verificó que terminar actualiza contador/ETA/barra y cancelar no genera nuevas órdenes.

No hay acceso a la G2, una RTX 5060, MSVC Windows ni los pesos Klein/OPUS-MT en este entorno. No se certifica emisión ni profundidad física.

## Fuentes revisadas

- https://www.gweikecloud.com/blogs/gweike-g2/setting-parameter-for-gweike-g2
- https://www.gweikecloud.com/products/g2-pro-fiber-laser-engraver
- https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0
- https://huggingface.co/Helsinki-NLP/opus-mt-es-en

La tabla Gweike es para G2 y no una receta completa de tallado calibrado para cada pieza G2 Pro. Se escoge 0,02 mm dentro del rango de intervalos de la tabla; 10 pasadas y cruce a 45° son una propuesta de prueba. No se fija una profundidad física sin medir la muestra.

Última instrucción: usar FLUX.2 Klein para 8 GB. Se aplica al generador; el estimador de profundidad independiente se conserva. Fuentes: https://docs.comfy.org/tutorials/flux/flux-2-klein y https://huggingface.co/black-forest-labs/FLUX.2-klein-4b-fp8 .
