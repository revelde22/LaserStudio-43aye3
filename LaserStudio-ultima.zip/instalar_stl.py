"""Instala "Importar STL como relieve" en 43AYE3 (con copia de seguridad y pruebas).

Que cambia en tu proyecto:
  work/stl_relief.py      (nuevo) lectura de STL, simplificado de malla y de relieve, mapa de profundidad
  work/stl_relief_ui.py   (nuevo) ventana de importacion y colocacion en el lienzo
  work/laser_studio.py    SOLO 2 inserciones: la entrada "Importar STL como relieve" en el menu Archivo y el
                          metodo import_stl (3 lineas). Copia de seguridad: laser_studio.py.bak_stl

Seguridad:
  - Cada edicion de laser_studio.py se busca por texto exacto y debe aparecer UNA sola vez; si no, no toca nada.
  - Comprueba que el resultado compila antes de escribir. Respeta saltos de linea CRLF/LF.
  - Es repetible: si ya esta instalado, no duplica nada.

Uso:
  python instalar_stl.py                   instala y prueba (busca la raiz del proyecto hacia arriba)
  python instalar_stl.py --proyecto RUTA   raiz del proyecto (la carpeta que contiene work\\)
  python instalar_stl.py --solo-tests
  python instalar_stl.py --revertir
"""
import argparse
import hashlib
import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
NUEVOS = {  # nombre: hash SHA-256 del fichero del paquete
    'stl_relief.py': '1f0db3ac5b2a5b990f87d3a32a7b278d2e2d4b1d7cda6a1a78d5a842814b8a67',
    'stl_relief_ui.py': '6e5c9508c34620fa0af91d83c227a603c6af62d5deb32db3546d26710abaef01',
}
TESTS = ('test_stl_relief.py', 'test_stl_ui.py')
DESTINO = 'laser_studio.py'
SUFIJO = '.bak_stl'
EDICIONES = [  # (texto exacto a buscar, texto que lo sustituye; \n se adapta a CRLF)
    ('("Import SVG",self.import_svg,None),',
     '("Import SVG",self.import_svg,None),("Importar STL como relieve",self.import_stl,None),'),
    ('    def export_orzx(self):',
     '    def import_stl(self):\n        from stl_relief_ui import importar_stl\n        importar_stl(self)\n    def export_orzx(self):'),
]
MARCAS = ('self.import_stl,None', 'def import_stl(self)')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def editar_texto(texto):
    """Devuelve (texto nuevo, mensaje de error). Si ya esta instalado devuelve (None, None)."""
    puestas = [m in texto for m in MARCAS]
    if all(puestas):
        return None, None
    if any(puestas):
        return None, 'laser_studio.py tiene solo una parte de la instalacion. Usa --revertir y vuelve a instalar.'
    nl = '\r\n' if '\r\n' in texto else '\n'
    for buscar, poner in EDICIONES:
        buscar, poner = buscar.replace('\n', nl), poner.replace('\n', nl)
        veces = texto.count(buscar)
        if veces != 1:
            return None, (f'No encuentro (o aparece {veces} veces) el texto esperado en laser_studio.py:\n    {buscar.strip()}\n'
                          '  Es otra version del programa. No se ha cambiado nada; envia el archivo para adaptarlo.')
        texto = texto.replace(buscar, poner)
    try:
        compile(texto, DESTINO, 'exec')
    except SyntaxError as error:
        return None, f'El resultado no compila ({error}). No se ha cambiado nada.'
    return texto, None


def aplicar(work):
    destino = work / DESTINO
    if not destino.exists():
        return f'No existe {destino}. ¿Es la raiz del proyecto?'
    for nombre, esperado in NUEVOS.items():
        if sha(AQUI / 'work' / nombre) != esperado:
            return f'El fichero {nombre} del paquete no coincide con su hash esperado; descargalo de nuevo.'
    crudo = destino.read_bytes()
    try:
        texto = crudo.decode('utf-8')
    except UnicodeDecodeError:
        return 'laser_studio.py no es UTF-8; no se toca.'
    nuevo, error = editar_texto(texto)       # se valida todo ANTES de escribir nada
    if error:
        return error
    for nombre in NUEVOS:
        destino_nuevo = work / nombre
        origen = AQUI / 'work' / nombre
        if destino_nuevo.exists() and (origen.resolve() == destino_nuevo.resolve() or sha(destino_nuevo) == sha(origen)):
            print(f'  ya instalado: {nombre}')
            continue
        if destino_nuevo.exists():
            shutil.copy2(destino_nuevo, destino_nuevo.with_name(nombre + '.bak_prev'))
        shutil.copy2(origen, destino_nuevo)
        print(f'  instalado: {nombre}')
    if nuevo is None:
        print(f'  ya instalado: entrada de menu en {DESTINO}')
    else:
        copia = destino.with_name(destino.name + SUFIJO)
        if not copia.exists():
            shutil.copy2(destino, copia)
        destino.write_bytes(nuevo.encode('utf-8'))
        print(f'  editado: {DESTINO}  (copia en {copia.name})')
    return None


def revertir(work):
    hecho = False
    destino = work / DESTINO
    copia = destino.with_name(destino.name + SUFIJO)
    if copia.exists():
        shutil.copy2(copia, destino)
        print(f'  restaurado: {DESTINO}')
        hecho = True
    for nombre, esperado in NUEVOS.items():
        f = work / nombre
        if f.exists() and sha(f) == esperado:
            f.unlink()
            print(f'  eliminado: {nombre}')
            hecho = True
    if not hecho:
        print('  no hay nada que revertir')


def pruebas(raiz):
    carpeta = raiz / 'tests'
    carpeta.mkdir(exist_ok=True)
    for nombre in TESTS:
        origen, copia = AQUI / 'tests' / nombre, carpeta / nombre
        if not (copia.exists() and origen.resolve() == copia.resolve()):   # si el paquete esta en la raiz, ya estan ahi
            shutil.copy2(origen, copia)
    faltan = [m for m in ('pytest', 'numpy', 'PIL', 'PySide6') if importlib.util.find_spec(m) is None]
    if faltan:
        print('Faltan en este Python: ' + ', '.join(faltan))
        print('Instalalos con:  "%s" -m pip install pytest numpy Pillow PySide6' % sys.executable)
        print('(la instalacion ya esta hecha; solo faltan las pruebas)')
        return 4
    print('Ejecutando pruebas...')
    try:
        return subprocess.run([sys.executable, '-m', 'pytest', '-q', *[str(carpeta / n) for n in TESTS]], cwd=str(raiz)).returncode
    except OSError as error:
        print('No se pudo lanzar pytest:', error)
        return 1


def buscar_raiz(explicita):
    if explicita:
        return Path(explicita).resolve()
    for base in [AQUI, *AQUI.parents][:4]:
        if (base / 'work' / DESTINO).exists():
            return base
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--proyecto', help='raiz del proyecto (la carpeta que contiene work\\). Por defecto se busca hacia arriba.')
    parser.add_argument('--solo-tests', action='store_true')
    parser.add_argument('--revertir', action='store_true')
    a = parser.parse_args()
    raiz = buscar_raiz(a.proyecto)
    if raiz is None or not (raiz / 'work' / DESTINO).exists():
        print('No encuentro work\\laser_studio.py. Pon esta carpeta DENTRO del proyecto (junto a ARRANCAR_43AYE3.bat)')
        print('o indica la raiz con:  python instalar_stl.py --proyecto "C:\\ruta\\del\\proyecto"')
        return 2
    print('Proyecto:', raiz)
    if a.revertir:
        revertir(raiz / 'work')
        return 0
    if not a.solo_tests:
        error = aplicar(raiz / 'work')
        if error:
            print('\nERROR:', error)
            return 3
    return pruebas(raiz)


if __name__ == '__main__':
    sys.exit(main())
