@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0work\RECOPILAR_MARCADO.ps1"
pause
