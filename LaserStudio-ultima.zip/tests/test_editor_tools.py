import os
os.environ['QT_QPA_PLATFORM']='offscreen'
import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'work'))
from PySide6.QtWidgets import QApplication,QMessageBox,QPushButton,QDialog,QDialogButtonBox,QTableWidget
from PySide6.QtGui import QPainterPath,QPixmap,QColor
from PySide6.QtCore import QTimer
from laser_studio import Main,GItem,GroupItem,RasterItem
from editor_tools import offset_path,edit_nodes
APP=QApplication.instance() or QApplication([])

class EditorTests(unittest.TestCase):
    def setUp(self):
        self.w=Main();self.history=self.w.editor_history
    def tearDown(self):
        self.w.changed=False
        for timer in self.w.findChildren(QTimer):timer.stop()
        self.w.deleteLater();APP.processEvents()
    def add(self,x=10,y=10):
        p=QPainterPath();p.addRect(0,0,10,10)
        it=GItem(p);self.w.scene.addItem(it);it.setPos(x,y);it.setSelected(True);return it
    def test_history_group_transform_delete_redo_branch(self):
        self.add();self.history.capture();self.w.duplicate();self.history.capture()
        self.w.select_all();self.w.group();self.history.capture()
        self.w.rotate(45);self.history.capture();signature=self.history.states[-1][0]
        self.w.delete();self.history.capture()
        self.history.undo();self.assertEqual(len(self.w.selected()),1)
        self.assertIsInstance(self.w.selected()[0],GroupItem)
        self.assertEqual(self.w.selected()[0].rotation(),45)
        self.assertEqual(self.history.snapshot()[0],signature)
        self.history.redo();self.assertEqual(len(self.w.selected()),0)
        self.history.undo();self.w.rotate(5);self.history.capture()
        self.assertFalse(self.history.redo_action.isEnabled())
    def test_history_raster_and_cut(self):
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/'image.png');pm=QPixmap(20,10);pm.fill(QColor('red'));pm.save(path)
            it=RasterItem(path);self.w.scene.addItem(it);it.setSelected(True)
            self.w.cuts[0].power=42;self.history.capture()
            self.w.delete();self.history.capture();self.history.undo()
            it=self.w.selected()[0];self.assertIsInstance(it,RasterItem)
            self.assertEqual(it.pixmap().width(),20);self.assertEqual(self.w.cuts[0].power,42)
            self.history.redo();self.assertFalse(self.w.selected())
    def test_align_alias_and_mirror_action(self):
        first=self.add(5,6);second=self.add(30,40)
        self.w.align('left');self.assertAlmostEqual(first.sceneBoundingRect().left(),second.sceneBoundingRect().left())
        action=next(a for a in self.w.findChildren(__import__('PySide6.QtGui',fromlist=['QAction']).QAction) if a.text()=='Mirror Horizontal')
        action.trigger();self.assertEqual(first.transform().m11(),-1)
    def test_offset_expansion_erosion_open_rejected(self):
        p=QPainterPath();p.addRect(0,0,10,10)
        self.assertAlmostEqual(offset_path(p,1).boundingRect().width(),12)
        self.assertAlmostEqual(offset_path(p,-1).boundingRect().width(),8)
        p=QPainterPath();p.moveTo(0,0);p.lineTo(10,10)
        with self.assertRaises(ValueError):offset_path(p,1)
    def test_variable_text_and_move_buttons(self):
        dock=self.w.variable_dock
        next(b for b in dock.widget().findChildren(QPushButton) if b.text()=='Insertar texto y avanzar').click()
        item=self.w.selected()[0];self.assertEqual(item.text_meta['text'],'Pieza 0001')
        x=item.x();next(b for b in self.w.move_dock.widget().findChildren(QPushButton) if b.text()=='→').click()
        self.assertEqual(item.x(),x+1)
    def test_node_dialog_applies_local_coordinates(self):
        self.add()
        def change():
            dialog=next(d for d in self.w.findChildren(QDialog) if d.windowTitle().startswith('Editar nodos'))
            table=dialog.findChild(QTableWidget);table.item(1,1).setText('12.5')
            dialog.findChild(QDialogButtonBox).button(QDialogButtonBox.StandardButton.Ok).click()
        QTimer.singleShot(0,change);edit_nodes(self.w)
        self.assertEqual(self.w.selected()[0].path().elementAt(1).x,12.5)
    def test_arrays_support_group_and_images(self):
        from unittest.mock import patch
        self.add();self.w.duplicate();self.w.select_all();self.w.group()
        with patch('laser_studio.QInputDialog.getInt',side_effect=[(2,True),(2,True)]),patch('laser_studio.QInputDialog.getDouble',return_value=(2,True)):
            self.w.grid_array()
        self.assertEqual(len(self.w.selected()),4)
        self.assertTrue(all(isinstance(i,GroupItem) for i in self.w.selected()))
        self.w.scene.clear();self.history.reset()
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/'a.png');pm=QPixmap(10,10);pm.fill(QColor('blue'));pm.save(path)
            it=RasterItem(path);self.w.scene.addItem(it);it.setPos(60,50);it.setSelected(True)
            with patch('laser_studio.QInputDialog.getInt',return_value=(4,True)):
                self.w.circular_array()
            self.assertEqual(len(self.w.selected()),4)
            self.assertTrue(all(isinstance(i,RasterItem) for i in self.w.selected()))
    def test_optimization_persists_priority_and_undo(self):
        from editor_tools import optimization_dialog
        from PySide6.QtWidgets import QSpinBox
        def apply():
            dialog=next(d for d in self.w.findChildren(QDialog) if d.windowTitle()=='Orden de marcado por capas')
            dialog.findChildren(QSpinBox)[0].setValue(20)
            dialog.accept()
        QTimer.singleShot(0,apply);optimization_dialog(self.w)
        self.assertEqual(self.w.cuts[0].priority,20)
        self.history.undo();self.assertEqual(self.w.cuts[0].priority,0)
    def test_csv_text_uses_selected_row_and_advances(self):
        from unittest.mock import patch
        from PySide6.QtWidgets import QLineEdit
        body=self.w.variable_dock.widget()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'datos.csv';path.write_text('nombre;referencia\nAna;A01\nLuis;B02\n',encoding='utf-8')
            with patch('professional_ui.QFileDialog.getOpenFileName',return_value=(str(path),'')):
                next(b for b in body.findChildren(QPushButton) if b.text()=='Cargar CSV UTF-8…').click()
            body.findChildren(QLineEdit)[0].setText('{nombre} {referencia} {n:02d}')
            button=next(b for b in body.findChildren(QPushButton) if b.text()=='Insertar texto y avanzar')
            button.click();self.assertEqual(self.w.selected()[0].text_meta['text'],'Ana A01 01')
            button.click();self.assertEqual(self.w.selected()[0].text_meta['text'],'Luis B02 02')
    def test_save_resets_dirty_and_new_resets_history(self):
        self.add();self.history.capture()
        with tempfile.TemporaryDirectory() as folder:self.assertTrue(self.w._save(str(Path(folder)/'p.43laser')))
        APP.processEvents();self.history.capture();self.assertFalse(self.w.changed)
        self.w.new();self.assertFalse(self.history.undo_action.isEnabled());self.assertFalse(self.w.changed)

if __name__=='__main__':unittest.main()
