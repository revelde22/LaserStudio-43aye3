"""Pruebas de stl_relief.py con verdad analitica. Ejecutar:  python -m pytest tests -q  (desde la carpeta work o la raiz)."""
import struct
import sys
import time
from pathlib import Path

import numpy as np
import pytest

for cand in (Path(__file__).resolve().parents[1] / 'work', Path(__file__).resolve().parents[1]):
    if (cand / 'stl_relief.py').exists():
        sys.path.insert(0, str(cand))
import stl_relief as sr  # noqa: E402


# ------------------------------------------------------------ mallas de referencia

def esfera(radio=10., n_lat=60, n_lon=120, solo_arriba=False):
    """Esfera UV (o hemisferio superior) con triangulos."""
    lat = np.linspace(0 if solo_arriba else -np.pi / 2, np.pi / 2, n_lat + 1)
    lon = np.linspace(0, 2 * np.pi, n_lon + 1)
    la, lo = np.meshgrid(lat, lon, indexing='ij')
    p = np.stack([radio * np.cos(la) * np.cos(lo), radio * np.cos(la) * np.sin(lo), radio * np.sin(la)], axis=-1)
    tri = []
    for i in range(n_lat):
        for j in range(n_lon):
            a, b, c, d = p[i, j], p[i, j + 1], p[i + 1, j + 1], p[i + 1, j]
            tri += [[a, b, c], [a, c, d]]
    return np.array(tri, dtype=np.float32)


def losa(x0, x1, y0, y1, z):
    """Rectangulo horizontal a altura z."""
    a, b, c, d = (x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z)
    return np.array([[a, b, c], [a, c, d]], dtype=np.float32)


def rampa(largo=20., ancho=10., alto=5.):
    """Plano inclinado z = alto * x / largo."""
    a, b, c, d = (0, 0, 0), (largo, 0, alto), (largo, ancho, alto), (0, ancho, 0)
    return np.array([[a, b, c], [a, c, d]], dtype=np.float32)


def cubo(l=10.):
    v = np.array([[x, y, z] for x in (0, l) for y in (0, l) for z in (0, l)], dtype=np.float32)
    caras = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    return np.array([[v[q[0]], v[q[1]], v[q[2]]] for q in caras] + [[v[q[0]], v[q[2]], v[q[3]]] for q in caras], dtype=np.float32)


# ------------------------------------------------------------ lectura / escritura

def test_binary_roundtrip_and_ascii_agree(tmp_path):
    tri = esfera(5, 8, 12)
    b = tmp_path / 'b.stl'
    sr.escribir_stl_binario(b, tri)
    assert np.array_equal(sr.leer_stl(b), tri)
    lineas = ['solid x']
    for t in tri:
        lineas += ['facet normal 0 0 0', 'outer loop'] + [f'vertex {float(v[0])!r} {float(v[1])!r} {float(v[2])!r}' for v in t.astype(float)] + ['endloop', 'endfacet']
    lineas.append('endsolid x')
    a = tmp_path / 'a.stl'
    a.write_text('\n'.join(lineas))
    assert np.allclose(sr.leer_stl(a), tri, atol=1e-5)


def test_binary_that_starts_with_solid_is_still_binary(tmp_path):
    tri = losa(0, 1, 0, 1, 0)
    p = tmp_path / 'c.stl'
    sr.escribir_stl_binario(p, tri)
    datos = bytearray(p.read_bytes())
    datos[:5] = b'solid'
    assert np.array_equal(sr.leer_stl_bytes(bytes(datos)), tri)


@pytest.mark.parametrize('datos', [b'', b'hola', b'solid x\nendsolid x', b'solid x\nvertex 1 2 3\nvertex 1 2\n'])
def test_garbage_is_rejected(datos):
    with pytest.raises(sr.ErrorSTL):
        sr.leer_stl_bytes(datos)


def test_truncated_binary_and_nan_are_rejected(tmp_path):
    p = tmp_path / 't.stl'
    sr.escribir_stl_binario(p, esfera(3, 4, 6))
    with pytest.raises(sr.ErrorSTL):
        sr.leer_stl_bytes(p.read_bytes()[:-20])
    tri = losa(0, 1, 0, 1, 0)
    tri[0, 0, 0] = np.nan
    q = tmp_path / 'n.stl'
    sr.escribir_stl_binario(q, tri)
    with pytest.raises(sr.ErrorSTL, match='no finitas'):
        sr.leer_stl(q)


# ------------------------------------------------------------ rasterizado

def test_ramp_gives_linear_gray_in_the_right_direction():
    r = sr.stl_a_relieve(rampa(), intervalo_mm=.1)
    g = r['gris'].astype(float)
    assert g.shape == (100, 200) and r['mascara'].all()
    assert abs(r['ancho_mm'] - 20) < 1e-9 and abs(r['relieve_mm'] - 5 * (1 - 1 / 200)) < .05   # (altura en centros de pixel)
    esperado = 255 * (np.arange(200) + .5) / 200                       # izquierda baja (negro), derecha alta (blanco)
    assert np.abs(g[50] - esperado).max() <= 3
    assert g[50, 0] < 10 and g[50, -1] > 245


def test_hemisphere_height_matches_analytic_profile():
    R = 10.
    r = sr.stl_a_relieve(esfera(R, 80, 160, solo_arriba=True), intervalo_mm=.1)
    g, hay = r['gris'], r['mascara']
    assert abs(r['ancho_mm'] - 2 * R) < .05 and r['relieve_mm'] > R * .99
    n = g.shape[0]
    yy, xx = np.mgrid[:n, :n]
    rr = np.hypot((xx + .5) - n / 2, (yy + .5) - n / 2) * r['paso_mm']
    dentro = rr < R * .95
    ref = np.sqrt(np.maximum(R ** 2 - rr ** 2, 0)) / R
    assert np.abs(g[dentro] / 255. - ref[dentro]).max() < .02          # coincide con z = sqrt(R^2 - r^2)
    assert g[n // 2, n // 2] >= 253
    assert (g[~hay] == 255).all()                                      # fuera del modelo: blanco


def test_closed_cube_top_view_uses_highest_surface_and_no_cracks():
    r = sr.stl_a_relieve(cubo(10), intervalo_mm=.1)
    assert r['mascara'].all()                                          # sin grietas en la arista compartida
    assert (r['gris'] == 255).all()                                    # la cara superior es plana: todo a la misma altura


def test_shared_edges_leave_no_holes_for_random_fan():
    rng = np.random.default_rng(1)
    ang = np.sort(rng.uniform(0, 2 * np.pi, 40))
    borde = np.stack([10 * np.cos(ang), 10 * np.sin(ang), rng.uniform(0, 3, 40)], axis=1)
    centro = np.array([0, 0, 1.])
    tri = np.array([[centro, borde[i], borde[(i + 1) % 40]] for i in range(40)], dtype=np.float32)
    r = sr.stl_a_relieve(tri, intervalo_mm=.1)
    # Dentro del poligono convexo del abanico no puede haber agujeros. Comprobamos un disco interior seguro.
    n = r['gris'].shape[0]
    yy, xx = np.mgrid[:r['gris'].shape[0], :r['gris'].shape[1]]
    c = (np.hypot((xx + .5) * r['paso_mm'] - 10 - 0, (yy + .5) * r['paso_mm'] - 10) < 4)
    assert r['mascara'][c].all()


@pytest.mark.parametrize('vista,columna_clara', [('superior', 'dcha'), ('inferior', 'izda'), ('trasera', 'izda')])
def test_views_orient_and_mirror_correctly(vista, columna_clara):
    # Rampa que sube con x. Desde arriba: derecha clara. Desde abajo el observador esta del otro lado de z: la zona
    # alta (z grande) queda LEJOS, asi que la clara es la de menor z (izquierda). Desde atras u=-x: izquierda clara.
    if vista == 'trasera':
        tri = rampa()[:, :, [0, 2, 1]].copy()            # intercambia y/z: sube con x a lo largo de y... no: ver abajo
        tri = np.array([[(0, 0, 0), (20, 5, 0), (20, 5, 10)], [(0, 0, 0), (20, 5, 10), (0, 0, 10)]], dtype=np.float32)  # plano vertical, h=y crece con x
    else:
        tri = rampa()
    r = sr.stl_a_relieve(tri, vista=vista, intervalo_mm=.2)
    g = r['gris'][r['gris'].shape[0] // 2].astype(int)
    if columna_clara == 'dcha':
        assert g[-3] > g[2] + 100
    else:
        assert g[2] > g[-3] + 100


def test_front_view_height_is_depth_toward_viewer():
    # Dos placas verticales: una cerca (y=0) y otra lejos (y=10). Desde el frente (observador en -y), la de y=0 es la mas alta (h=-y).
    near = np.array([[(0, 0, 0), (5, 0, 0), (5, 0, 5)], [(0, 0, 0), (5, 0, 5), (0, 0, 5)]], dtype=np.float32)
    far = near + np.array([5, 10, 0], dtype=np.float32)
    r = sr.stl_a_relieve(np.concatenate([near, far]), vista='frontal', intervalo_mm=.1)
    g = r['gris']
    assert g[g.shape[0] // 2, 10] == 255 and g[g.shape[0] // 2, -10] == 0   # izquierda = cercana (blanca), derecha = lejana (negra)


def test_ancho_mm_scales_width_and_relief_together():
    a = sr.stl_a_relieve(esfera(10, 40, 80, True), intervalo_mm=.2)
    b = sr.stl_a_relieve(esfera(10, 40, 80, True), intervalo_mm=.6, ancho_mm=60)
    assert abs(b['ancho_mm'] - 60) < 1e-9 and abs(b['relieve_mm'] / a['relieve_mm'] - 3) < .01


def test_resolution_is_capped_by_max_px():
    r = sr.stl_a_relieve(esfera(50, 30, 60, True), intervalo_mm=.01, max_px=300)
    assert max(r['gris'].shape) <= 300 and r['paso_mm'] > .01


# ------------------------------------------------------------ simplificar la malla

def test_mesh_simplification_hits_target_and_keeps_the_shape():
    tri = esfera(10, 120, 240, True)                                    # 57 600 triangulos
    corto = sr.simplificar_malla(tri, 2000)
    assert 400 < len(corto) <= 2000
    assert np.abs(corto.reshape(-1, 3).max(0) - tri.reshape(-1, 3).max(0)).max() < 1.5     # misma caja
    a = sr.stl_a_relieve(tri, intervalo_mm=.25)['gris'].astype(float)
    b = sr.stl_a_relieve(tri, intervalo_mm=.25, triangulos_max=2000)['gris'].astype(float)
    assert np.corrcoef(a.ravel(), b.ravel())[0, 1] > .97
    assert np.abs(a - b).mean() < 12


def test_simplification_is_noop_below_target_and_monotonic():
    tri = esfera(10, 20, 40, True)
    assert sr.simplificar_malla(tri, len(tri)) is tri or np.array_equal(sr.simplificar_malla(tri, len(tri)), tri)
    tam = [len(sr.simplificar_malla(esfera(10, 100, 200, True), t)) for t in (500, 2000, 8000)]
    assert tam[0] < tam[1] < tam[2] and tam[0] <= 500 and tam[2] <= 8000


def test_simplification_reports_counts_and_rejects_bad_targets():
    tri = esfera(10, 60, 120, True)
    r = sr.stl_a_relieve(tri, intervalo_mm=.5, triangulos_max=1000)
    assert r['triangulos_antes'] == len(tri) and 0 < r['triangulos_despues'] <= 1000
    with pytest.raises(sr.ErrorSTL):
        sr.simplificar_malla(tri, 2)


# ------------------------------------------------------------ simplificar el relieve

def test_depth_fraction_limits_the_darkest_gray():
    tri = esfera(10, 40, 80, True)
    full = sr.stl_a_relieve(tri, intervalo_mm=.25)['gris']
    half = sr.stl_a_relieve(tri, intervalo_mm=.25, profundidad=.5)
    m = half['mascara']
    assert half['gris'][m].min() >= 126 and full[m].min() <= 5
    assert half['gris'][m].max() == 255


def test_levels_posterize_to_at_most_n_values_with_background_white():
    r = sr.stl_a_relieve(esfera(10, 60, 120, True), intervalo_mm=.2, niveles=6)
    valores = np.unique(r['gris'][r['mascara']])
    assert len(valores) <= 6 and len(valores) >= 5
    assert (r['gris'][~r['mascara']] == 255).all()


def test_invert_flips_high_and_low():
    tri = rampa()
    a = sr.stl_a_relieve(tri, intervalo_mm=.2)['gris'].astype(int)
    b = sr.stl_a_relieve(tri, intervalo_mm=.2, invertir=True)['gris'].astype(int)
    assert np.abs(a + b - 255).max() <= 1


def test_smoothing_reduces_roughness_and_does_not_darken_edges():
    rng = np.random.default_rng(0)
    # Placa plana con muescas aleatorias (ruido de malla) rodeada de fondo.
    base = losa(0, 20, 0, 20, 5.)
    teselas = []
    xs = np.linspace(0, 20, 41)
    for i in range(40):
        for j in range(40):
            z = 5 + rng.normal(0, .15)
            teselas += [losa(xs[i], xs[i + 1], xs[j], xs[j + 1], z)[0], losa(xs[i], xs[i + 1], xs[j], xs[j + 1], z)[1]]
    ruidosa = np.array(teselas, dtype=np.float32)
    crudo = sr.stl_a_relieve(ruidosa, intervalo_mm=.1)
    liso = sr.stl_a_relieve(ruidosa, intervalo_mm=.1, suavizado=8)
    m = crudo['mascara']
    assert liso['gris'][m].astype(float).std() < crudo['gris'][m].astype(float).std() / 2
    # Una placa PLANA suavizada no cambia, ni en los bordes (convolucion normalizada).
    plana = sr.stl_a_relieve(base, intervalo_mm=.1, suavizado=8)
    assert (plana['gris'] == 255).all()


def test_smoothing_mask_normalisation_keeps_edge_pixels():
    # Rampa con borde: sin normalizar, los pixeles del borde se mezclarian con el fondo (0) y se oscurecerian.
    h = np.tile(np.linspace(1, 2, 50), (50, 1))
    hay = np.zeros((50, 50), bool)
    hay[10:40, 10:40] = True
    liso = sr.suavizar_relieve(np.where(hay, h, 0.), hay, 6)
    esperado = h[hay].min() - .05, h[hay].max() + .05
    assert liso[hay].min() > esperado[0] and liso[hay].max() < esperado[1]
    assert (liso[~hay] == 0).all()


# ------------------------------------------------------------ errores y rendimiento

@pytest.mark.parametrize('mal', [dict(profundidad=0), dict(profundidad=1.5), dict(niveles=1), dict(niveles=300),
                                 dict(suavizado=-1), dict(suavizado=99), dict(intervalo_mm=0), dict(ancho_mm=-3),
                                 dict(vista='diagonal'), dict(inventado=1)])
def test_invalid_options_are_rejected(mal):
    with pytest.raises(sr.ErrorSTL):
        sr.stl_a_relieve(rampa(), **mal)


def test_flat_in_view_is_reported():
    pared = np.array([[(0, 0, 0), (10, 0, 0), (10, 0, 5)]], dtype=np.float32)
    with pytest.raises(sr.ErrorSTL, match='plano'):
        sr.stl_a_relieve(pared, vista='superior')


def test_input_is_not_modified_and_result_is_deterministic():
    tri = esfera(10, 30, 60, True)
    copia = tri.copy()
    a = sr.stl_a_relieve(tri, intervalo_mm=.2, triangulos_max=800, suavizado=2, niveles=12)
    b = sr.stl_a_relieve(tri, intervalo_mm=.2, triangulos_max=800, suavizado=2, niveles=12)
    assert np.array_equal(tri, copia) and np.array_equal(a['gris'], b['gris'])


def test_big_model_is_fast_enough():
    tri = esfera(30, 300, 600, True)                                   # 360 000 triangulos
    t0 = time.perf_counter()
    r = sr.stl_a_relieve(tri, intervalo_mm=.15, max_px=700, triangulos_max=30000)
    dt = time.perf_counter() - t0
    assert r['triangulos_despues'] <= 30000 and dt < 30, dt
