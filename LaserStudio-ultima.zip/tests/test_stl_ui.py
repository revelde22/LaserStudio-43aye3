"""Integracion de "Importar STL como relieve" con la ventana principal de 43AYE3 (sin pantalla)."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / 'work'))
import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402
from PySide6.QtCore import QTimer  # noqa: E402
from PySide6.QtGui import QAction  # noqa: E402
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox  # noqa: E402

import stl_relief as sr  # noqa: E402
import stl_relief_ui as ui  # noqa: E402
from laser_studio import Main, RasterItem  # noqa: E402

APP = QApplication.instance() or QApplication([])


def hemisferio(R=10., n_lat=40, n_lon=80):
    lat = np.linspace(0, np.pi / 2, n_lat + 1)
    lon = np.linspace(0, 2 * np.pi, n_lon + 1)
    la, lo = np.meshgrid(lat, lon, indexing='ij')
    p = np.stack([R * np.cos(la) * np.cos(lo), R * np.cos(la) * np.sin(lo), R * np.sin(la)], axis=-1)
    tri = []
    for i in range(n_lat):
        for j in range(n_lon):
            a, b, c, d = p[i, j], p[i, j + 1], p[i + 1, j + 1], p[i + 1, j]
            tri += [[a, b, c], [a, c, d]]
    return np.array(tri, dtype=np.float32)


class StlUiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.stl = Path(self.tmp.name) / 'cupula.stl'
        sr.escribir_stl_binario(self.stl, hemisferio())
        self.w = Main()
        self.salida = Path(self.tmp.name) / 'salida'
        self.salida.mkdir()
        patchers = [patch.object(ui, 'carpeta_salida', lambda: self.salida),
                    patch.object(ui.StlReliefDialog, 'exec', lambda s: QDialog.DialogCode.Accepted)]
        for p in patchers:
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self):
        for t in self.w.findChildren(QTimer):
            t.stop()
        self.w.changed = False
        self.w.deleteLater()
        APP.processEvents()
        self.tmp.cleanup()

    def rasters(self):
        return [i for i in self.w.scene.items() if isinstance(i, RasterItem)]

    def test_menu_entry_exists_and_is_wired(self):
        acciones = [a for m in self.w.menuBar().actions() if m.menu() for a in m.menu().actions() if 'STL' in a.text()]
        self.assertEqual(len(acciones), 1)
        self.assertEqual(acciones[0].text().replace('&', ''), 'Importar STL como relieve')
        with patch.object(ui, 'importar_stl') as falso:
            acciones[0].trigger()
        falso.assert_called_once_with(self.w)

    def test_import_places_a_depth_image_with_real_size(self):
        with patch('deep_engraving_dialog.ImageDepthDialog.exec', lambda s: QDialog.DialogCode.Accepted):
            item = ui.importar_stl(self.w, str(self.stl))
        self.assertIsNotNone(item)
        self.assertEqual(self.rasters(), [item])
        png = next(self.salida.glob('*_relieve.png'))
        with Image.open(png) as img:
            self.assertEqual(img.mode, 'L')
            gris = np.asarray(img)
        meta = json.loads(png.with_suffix('.json').read_text(encoding='utf-8'))
        self.assertAlmostEqual(meta['ancho_mm'], 20, delta=.2)
        rect = item.boundingRect()
        ancho_mm = rect.width() * item.transform().m11() * item.scale()
        self.assertAlmostEqual(ancho_mm, meta['ancho_mm'], delta=.05)
        self.assertTrue(item.image_settings['depth_enabled'])
        self.assertEqual(item.image_settings['stl_source'], str(self.stl))
        self.assertEqual(self.w.cuts[item.layer].mode, 'Image')
        self.assertEqual(gris[gris.shape[0] // 2, gris.shape[1] // 2], 255)        # cima del hemisferio = blanco
        json.dumps(item.data43())                                                   # se puede guardar en el proyecto
        # El mapa que llega al tallado (8 bits, via prepare) es exactamente el PNG.
        from laser_image_pipeline import prepare
        with Image.open(prepare(item.original_source, mode='Grayscale', brightness=0, darkness=0, contrast=0,
                                gamma=1., sharpen=0, invert=False)) as procesada:
            leido = np.asarray(procesada.convert('L'))
        self.assertTrue(np.array_equal(leido, gris))

    def test_cancelling_prepare_dialog_adds_nothing(self):
        with patch('deep_engraving_dialog.ImageDepthDialog.exec', lambda s: QDialog.DialogCode.Rejected):
            self.assertIsNone(ui.importar_stl(self.w, str(self.stl)))
        self.assertEqual(self.rasters(), [])

    def test_cancelling_stl_dialog_does_nothing(self):
        with patch.object(ui.StlReliefDialog, 'exec', lambda s: QDialog.DialogCode.Rejected):
            self.assertIsNone(ui.importar_stl(self.w, str(self.stl)))
        self.assertEqual(list(self.salida.iterdir()), [])

    def test_bad_file_shows_message_and_changes_nothing(self):
        malo = Path(self.tmp.name) / 'malo.stl'
        malo.write_bytes(b'esto no es un stl')
        with patch.object(QMessageBox, 'warning') as aviso:
            self.assertIsNone(ui.importar_stl(self.w, str(malo)))
            self.assertIsNone(ui.importar_stl(self.w, str(Path(self.tmp.name) / 'no_existe.stl')))
        self.assertEqual(aviso.call_count, 2)
        self.assertEqual(self.rasters(), [])

    def test_too_big_model_is_scaled_to_the_laser_field(self):
        sr.escribir_stl_binario(self.stl, hemisferio(R=500.))                      # 1000 mm de ancho
        from g2_native_frame import load_calibration
        campo = load_calibration().field_mm
        with patch('deep_engraving_dialog.ImageDepthDialog.exec', lambda s: QDialog.DialogCode.Accepted):
            item = ui.importar_stl(self.w, str(self.stl))
        caja = item.sceneBoundingRect()
        self.assertLessEqual(caja.width(), campo + 1e-6)
        centro = item.mapToScene(item.boundingRect().center())
        self.assertAlmostEqual(centro.x(), campo / 2, delta=1e-6)
        self.assertAlmostEqual(centro.y(), campo / 2, delta=1e-6)

    def test_no_free_layer_is_reported(self):
        for i in range(len(self.w.cuts)):
            r = RasterItem(str(self.salida / 'x.png')) if (self.salida / 'x.png').exists() else None
            if r is None:
                Image.fromarray(np.zeros((4, 4), np.uint8)).save(self.salida / 'x.png')
                r = RasterItem(str(self.salida / 'x.png'))
            r.layer = i
            self.w.scene.addItem(r)
        with patch.object(QMessageBox, 'information') as aviso:
            self.assertIsNone(ui.importar_stl(self.w, str(self.stl)))
        aviso.assert_called_once()

    def test_dialog_caches_simplification_and_maps_options(self):
        d = ui.StlReliefDialog(sr.leer_stl(self.stl), 'x.stl', self.w, campo_mm=100)
        self.addCleanup(d.deleteLater)
        self.assertIsNotNone(d.pix)
        cuenta = []
        real = sr.simplificar_malla
        with patch.object(sr, 'simplificar_malla', lambda t, n: (cuenta.append(n), real(t, n))[1]):
            d.simplificar.setChecked(True)
            d.triangulos_max.setValue(500)
            d.actualizar()
            for vista in ('frontal', 'superior'):
                d.vista.setCurrentIndex(sr.VISTAS.index(vista))
                d.actualizar()
        self.assertEqual(cuenta, [500])                                             # una sola simplificacion
        self.assertIn('→', d.info.text())
        n_antes, n_despues = len(d.triangulos), d._malla.shape[0]
        self.assertTrue(0 < n_despues <= 500 < n_antes)
        d.suavizado.setValue(3); d.niveles.setValue(8); d.profundidad.setValue(60); d.invertir.setChecked(True)
        d.ancho.setValue(40)
        p = d.parametros()
        self.assertEqual((p['suavizado'], p['niveles'], p['invertir'], p['ancho_mm']), (3, 8, True, 40.))
        self.assertAlmostEqual(p['profundidad'], .6)
        r = d.resultado_final()
        self.assertAlmostEqual(r['ancho_mm'], 40, delta=.01)
        d.ancho.setValue(300)
        d.actualizar()
        self.assertIn('campo', d.info.text())                                       # avisa de que supera el campo
        d.niveles.setValue(1)                                                       # 1 no es valido => continuo
        self.assertEqual(d.parametros()['niveles'], 0)


if __name__ == '__main__':
    unittest.main()
