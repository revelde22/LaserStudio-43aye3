import os
os.environ['QT_QPA_PLATFORM']='offscreen'
import sys,unittest,tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'work'))
import numpy as np
from PIL import Image
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QTimer
from laser_studio import Main,RasterItem
from laser_image_pipeline import MODES,prepare,process_array
from image_marking_mode import is_depth_image,apply_image_settings,validate_image_for_marking,raster_grid
from g2_vector_frame import raster_mark_paths
APP=QApplication.instance() or QApplication([])

class ImageMarkingTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=str(Path(self.tmp.name)/'gradient.png')
        self.pixels=np.tile(np.linspace(0,255,80,dtype=np.uint8),(40,1));Image.fromarray(self.pixels).save(self.path)
        self.w=Main();self.item=RasterItem(self.path);self.w.scene.addItem(self.item)
        from PySide6.QtGui import QTransform
        rect=self.item.boundingRect();self.item.setScale(1)
        self.item.setTransform(QTransform().scale(1.6/rect.width(),.8/rect.height()))
        bounds=self.item.sceneBoundingRect();self.item.setPos(10-bounds.left(),10-bounds.top());self.item.setSelected(True)
        cut=self.w.cuts[0];cut.speed=1200;cut.power=50;cut.frequency=30;cut.interval=.05
        self.item.image_settings.update(interval=.05,dpi=508)
    def tearDown(self):
        for t in self.w.findChildren(QTimer):t.stop()
        self.w.changed=False;self.w.deleteLater();APP.processEvents();self.tmp.cleanup()
    def test_all_binary_modes_override_old_depth_flag(self):
        for mode in MODES[1:]:
            with self.subTest(mode=mode):
                old={'mode':mode,'depth_enabled':True,'depth_mm_enabled':True,'depth_passes':150}
                self.assertFalse(is_depth_image(old));self.assertEqual(validate_image_for_marking(old),'raster')
                self.item.image_settings.update(old)
                apply_image_settings(self.item,{'mode':mode,'interval':.05},self.w)
                self.assertFalse(self.item.image_settings['depth_enabled'])
                self.assertFalse(self.item.image_settings['depth_mm_enabled'])
                c=self.w.cuts[0];self.assertEqual((c.speed,c.power,c.frequency,c.interval),(1200,50,30,.05))
    def test_depth_is_explicit_and_grayscale_is_not_auto_depth(self):
        with self.assertRaisesRegex(ValueError,'sin tallado activado'):validate_image_for_marking({'mode':'Grayscale'})
        self.assertEqual(validate_image_for_marking({'mode':'Grayscale','depth_enabled':True}),'depth')
        with self.assertRaisesRegex(ValueError,'desconocido'):validate_image_for_marking({'mode':'unknown'})
    def test_bitmap_paths_match_dither_at_physical_grid(self):
        columns,rows=raster_grid(self.item);self.assertEqual((columns,rows),(32,16))
        for mode in MODES[1:]:
            with self.subTest(mode=mode):
                self.item.image_settings.update(mode=mode,depth_enabled=True)
                expected=process_array(self.path,mode=mode,size=(columns,rows))<128
                observed=np.zeros((rows,columns),dtype=bool)
                with patch('g2_vector_frame._map_logical',side_effect=lambda x,y,c:(x,y)):
                    paths,bounds=raster_mark_paths(self.item)
                for a,b in paths:
                    row=round((a[1]-10)/.05-.5)
                    start=round((min(a[0],b[0])-10)/.05);end=round((max(a[0],b[0])-10)/.05)
                    observed[row,start:end]=True
                np.testing.assert_array_equal(observed,expected)
    def test_reverso_changes_marked_side_without_depth(self):
        self.item.image_settings.update(mode='Threshold',invert=False,depth_enabled=True)
        with patch('g2_vector_frame._map_logical',side_effect=lambda x,y,c:(x,y)):
            normal,_=raster_mark_paths(self.item)
            self.item.image_settings['invert']=True
            reverse,_=raster_mark_paths(self.item)
        self.assertTrue(all(max(a[0],b[0])<=10.8+1e-6 for a,b in normal))
        self.assertTrue(all(min(a[0],b[0])>=10.8-1e-6 for a,b in reverse))
        self.assertFalse(is_depth_image(self.item.image_settings))
    def test_small_source_uses_requested_interval(self):
        Image.new('L',(4,2),0).save(self.path)
        self.item.image_settings.update(mode='Threshold')
        with patch('g2_vector_frame._map_logical',side_effect=lambda x,y,c:(x,y)):
            paths,_=raster_mark_paths(self.item)
        ys=sorted({a[1] for a,b in paths});self.assertEqual(len(ys),16)
        self.assertAlmostEqual(ys[1]-ys[0],.05)
    def test_mark_preflight_shows_raster_parameters_without_depth_dialog(self):
        self.item.image_settings.update(mode='Jarvis',depth_enabled=True,depth_passes=500)
        self.w.cuts[0].mode='Image'
        with patch('production_laser_panel.QMessageBox.question',return_value=QMessageBox.StandardButton.No) as confirm,patch('deep_engraving_dialog.ImageDepthDialog') as depth:
            self.w._production_laser['mark'].clicked.emit()
        depth.assert_not_called();confirm.assert_called_once()
        message=confirm.call_args.args[2]
        for value in ('1200','50%','30 kHz','Jarvis','0.05'):self.assertIn(value,message)
        self.assertNotIn('máximo 500',message)
    def test_pending_render_does_not_overwrite_new_selection(self):
        from PySide6.QtTest import QTest
        requests=[]
        def submit(token,source,kwargs,callback):
            requests.append((token,source,kwargs,callback));return object()
        with patch('image_controller.submit_prepare',side_effect=submit):
            self.w._image_controls['mode'].setCurrentText('Jarvis')
            QTest.qWait(200)
            self.assertTrue(requests)
            token,source,kwargs,callback=requests[-1]
            other=RasterItem(self.path);self.w.scene.addItem(other);self.w.scene.clearSelection();other.setSelected(True)
            before=dict(other.image_settings);pixmap=other.pixmap().cacheKey()
            callback(token,prepare(source,**kwargs),None)
            self.assertEqual(other.image_settings,before)
            self.assertEqual(other.pixmap().cacheKey(),pixmap)
            self.assertEqual(self.item.image_settings['mode'],'Jarvis')
    def test_spacing_control_updates_raster(self):
        self.w._cut_controls['interval'].setValue(.075)
        self.assertEqual(self.item.image_settings['interval'],.075)
        self.assertAlmostEqual(self.item.image_settings['dpi'],25.4/.075)
    def test_sampling_rotation_uses_local_edges(self):
        self.item.setRotation(45)
        self.assertEqual(raster_grid(self.item),(32,16))
    def test_cache_separates_size_and_reverso(self):
        a=prepare(self.path,mode='Jarvis',size=(32,16),invert=False)
        b=prepare(self.path,mode='Jarvis',size=(16,8),invert=False)
        c=prepare(self.path,mode='Jarvis',size=(32,16),invert=True)
        self.assertEqual(len({a,b,c}),3)
        with Image.open(a) as im:self.assertEqual(im.size,(32,16))

if __name__=='__main__':unittest.main()
