@echo off
setlocal
cd /d "%~dp0work"
echo Cierra Laser Studio y ComfyUI antes de ejecutar esta reparacion.
if not exist "AI_RUNTIME\python312\python.exe" (
 echo No se encuentra Python portable. Ejecuta primero ARRANCAR_43AYE3.bat.
 pause
 exit /b 1
)
"AI_RUNTIME\python312\python.exe" -u reparar_gpu.py
if errorlevel 1 (
 echo Error. Revisa work\COMFY_SETUP.log.
 pause
 exit /b 1
)
echo Reparacion finalizada. Abre ARRANCAR_43AYE3.bat.
pause
