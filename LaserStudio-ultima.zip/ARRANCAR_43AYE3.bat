@echo off
call "%~dp0work\ARRANCAR_43AYE3_SEGURO.bat"
