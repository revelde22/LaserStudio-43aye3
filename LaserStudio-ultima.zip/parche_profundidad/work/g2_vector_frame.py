"""Convert one selected QPainterPath into a bounded G2 red outline."""
from __future__ import annotations

import math
from PySide6.QtCore import QPointF
from g2_native_frame import load_calibration, _map_logical


def selected_vector_points(main):
    from laser_studio import GItem
    items = list(main.selected())
    if len(items) != 1 or not isinstance(items[0], GItem):
        raise ValueError('Selecciona exactamente un trazado vectorial (sin imagen).')
    item = items[0]
    path = item.path()
    if path.isEmpty():
        raise ValueError('El trazado seleccionado está vacío.')
    local = []
    i = 0
    while i < path.elementCount():
        e = path.elementAt(i)
        typ = int(e.type.value if hasattr(e.type, 'value') else e.type)
        if typ == 0:  # MoveTo: one continuous subpath for this beta.
            if local:
                raise ValueError('Este vector tiene varios subtrazos. Selecciona uno solo.')
            local.append((float(e.x), float(e.y)))
        elif typ == 1:  # LineTo
            local.append((float(e.x), float(e.y)))
        elif typ == 2:  # CubicTo + two data elements
            if not local or i + 2 >= path.elementCount():
                raise ValueError('Curva vectorial incompleta.')
            a, b = path.elementAt(i + 1), path.elementAt(i + 2)
            x0, y0 = local[-1]
            for step in range(1, 9):
                t = step / 8.0; u = 1.0 - t
                local.append((u**3*x0 + 3*u*u*t*e.x + 3*u*t*t*a.x + t**3*b.x,
                              u**3*y0 + 3*u*u*t*e.y + 3*u*t*t*a.y + t**3*b.y))
            i += 2
        else:
            raise ValueError('Elemento vectorial no admitido.')
        i += 1
    if not 2 <= len(local) <= 128:
        raise ValueError('La beta admite entre 2 y 128 puntos por trazado.')
    c = load_calibration()
    points = []
    for x, y in local:
        scene = item.mapToScene(QPointF(x, y))
        xy = _map_logical(scene.x(), scene.y(), c)
        if not all(math.isfinite(v) and abs(v) <= 55 for v in xy):
            raise ValueError('El vector sale del campo de ±55 mm.')
        if not points or math.dist(points[-1], xy) > 0.001:
            points.append(xy)
    if len(points) < 2:
        raise ValueError('El vector no tiene longitud útil.')
    xs = [p[0] for p in points]; ys = [p[1] for p in points]
    bounds = (min(xs), min(ys), max(xs), max(ys))
    if bounds[2] - bounds[0] > 40 or bounds[3] - bounds[1] > 40:
        raise ValueError('El contorno supera 40 × 40 mm.')
    return points, bounds


def all_vector_paths(main, layer_filter=None):
    """Convert every visible vector and its subpaths to bounded red contours."""
    from laser_studio import GItem
    items = [item for item in reversed(main.scene.items())
             if isinstance(item, GItem) and item.isVisible() and
             (layer_filter is None or (item.layer == layer_filter and main.cuts[item.layer].output))]
    if not items:
        raise ValueError('El diseño no tiene vectores visibles.')
    calibration = load_calibration()
    contours = []
    xs, ys = [], []

    def add_contour(item, local):
        if len(local) < 2:
            return
        points = []
        for x, y in local:
            scene = item.mapToScene(QPointF(x, y))
            xy = _map_logical(scene.x(), scene.y(), calibration)
            if not all(math.isfinite(v) and abs(v) <= 55 for v in xy):
                raise ValueError('Un vector sale del campo de ±55 mm.')
            if not points or math.dist(points[-1], xy) > 0.001:
                points.append(xy)
        if len(points) < 2:
            return
        contours.append(points)
        xs.extend(x for x, _ in points)
        ys.extend(y for _, y in points)

    for item in items:
        path = item.path()
        local = []
        i = 0
        while i < path.elementCount():
            e = path.elementAt(i)
            typ = int(e.type.value if hasattr(e.type, 'value') else e.type)
            if typ == 0:
                add_contour(item, local)
                local = [(float(e.x), float(e.y))]
            elif typ == 1:
                if not local:
                    raise ValueError('Vector con línea sin punto inicial.')
                local.append((float(e.x), float(e.y)))
            elif typ == 2:
                if not local or i + 2 >= path.elementCount():
                    raise ValueError('Curva vectorial incompleta.')
                a, b = path.elementAt(i + 1), path.elementAt(i + 2)
                x0, y0 = local[-1]
                for step in range(1, 5):
                    t = step / 4.0; u = 1.0 - t
                    local.append((u**3*x0 + 3*u*u*t*e.x + 3*u*t*t*a.x + t**3*b.x,
                                  u**3*y0 + 3*u*u*t*e.y + 3*u*t*t*a.y + t**3*b.y))
                i += 2
            else:
                raise ValueError('Elemento vectorial no admitido.')
            i += 1
        add_contour(item, local)
    if not contours:
        raise ValueError('No hay líneas vectoriales útiles en el diseño.')
    bounds = (min(xs), min(ys), max(xs), max(ys))
    return contours, bounds


def layer_mark_paths(main, layer):
    """Build machine paths for a layer, including its actual Fill scan lines."""
    from laser_studio import GItem
    from hatch_engine import horizontal_hatch
    from PySide6.QtGui import QPainterPathStroker

    cut = main.cuts[layer]
    mode = cut.mode
    if mode == 'Line':
        return all_vector_paths(main, layer_filter=layer)
    if mode not in ('Fill', 'Offset Fill'):
        raise ValueError(f'C{layer:02d}: modo {mode} no admitido para marcado vectorial.')

    calibration = load_calibration()
    paths, xs, ys = [], [], []
    items = [it for it in reversed(main.scene.items())
             if isinstance(it, GItem) and it.isVisible() and it.layer == layer]
    for item in items:
        shape = item.mapToScene(item.path())
        if mode == 'Offset Fill' and getattr(cut, 'offset', 0) > 0:
            stroker = QPainterPathStroker()
            stroker.setWidth(2 * float(cut.offset))
            shape = shape.subtracted(stroker.createStroke(shape))
        angles = [float(getattr(cut, 'angle', 0))]
        if getattr(cut, 'cross', False):
            angles.append(angles[0] + 90)
        for angle in angles:
            segments = horizontal_hatch(shape, float(cut.interval), angle)
            # Every scan line is a separate path: the laser must switch off
            # between disjoint islands and between consecutive hatch lines.
            for a, b in segments:
                line = [_map_logical(p.x(), p.y(), calibration) for p in (a, b)]
                if math.dist(*line) < 0.001:
                    continue
                if any(not math.isfinite(v) or abs(v) > 55 for p in line for v in p):
                    raise ValueError('El relleno sale del campo de ±55 mm.')
                paths.append(line)
                xs.extend(p[0] for p in line)
                ys.extend(p[1] for p in line)
    if not paths:
        raise ValueError(f'C{layer:02d}: Fill no produjo líneas. Comprueba que los contornos estén cerrados y el intervalo.')
    bounds = (min(xs), min(ys), max(xs), max(ys))
    return paths, bounds


def backend_batches(paths):
    """Split an unrestricted design into bounded native transactions."""
    batch, points = [], 0
    for path in paths:
        # The native ABI stores each contour length in one bounded record.
        # Duplicate the endpoint so a split does not leave a gap.
        start = 0
        while start < len(path) - 1:
            part = path[start:start + 4096]
            if len(part) < 2:
                break
            if batch and (len(batch) == 2048 or points + len(part) > 65536):
                yield batch
                batch, points = [], 0
            batch.append(part)
            points += len(part)
            start += len(part) - 1
    if batch:
        yield batch


def raster_mark_paths(item):
    """Convert the selected image mode into separated horizontal laser runs."""
    from PIL import Image
    from laser_image_pipeline import prepare

    settings = dict(item.image_settings)
    mode = settings.get('mode', 'Grayscale')
    if mode == 'Grayscale':
        raise ValueError('Para marcar la imagen selecciona Threshold, Jarvis, Stucki, Floyd, Atkinson, Ordered, Newsprint o Halftone.')
    interval = float(settings.get('interval', 0.1))
    if not math.isfinite(interval) or interval <= 0:
        raise ValueError('El intervalo de imagen debe ser mayor que cero.')
    from image_marking_mode import raster_grid, validate_image_for_marking
    validate_image_for_marking(settings)
    columns, rows = raster_grid(item,interval)
    # Resample the continuous image BEFORE dithering. Resizing an already
    # dithered bitmap drops dots and destroys the selected error diffusion.
    source = prepare(item.original_source, size=(columns,rows), **{k: settings[k] for k in
        ('mode', 'brightness', 'darkness', 'contrast', 'gamma', 'sharpen',
         'invert', 'threshold', 'dpi') if k in settings})
    rect = item.boundingRect()
    calibration = load_calibration()
    paths, xs, ys = [], [], []
    with Image.open(source) as original:
        bitmap = original.convert('L')
        pixels = bitmap.load()
        for y in range(rows):
            row_start = len(paths)
            x = 0
            while x < columns:
                while x < columns and pixels[x, y] >= 128:
                    x += 1
                first = x
                while x < columns and pixels[x, y] < 128:
                    x += 1
                if first == x:
                    continue
                line = []
                for u in (first / columns, x / columns):
                    local = QPointF(rect.left() + u * rect.width(),
                                    rect.top() + (y + .5) / rows * rect.height())
                    point = item.mapToScene(local)
                    xy = _map_logical(point.x(), point.y(), calibration)
                    if any(not math.isfinite(v) or abs(v) > 55 for v in xy):
                        raise ValueError('La imagen sale del campo de ±55 mm.')
                    line.append(xy)
                paths.append(line)
                xs.extend(p[0] for p in line)
                ys.extend(p[1] for p in line)
            if y % 2:
                paths[row_start:] = [line[::-1] for line in reversed(paths[row_start:])]
    if not paths:
        raise ValueError('La imagen procesada no contiene píxeles oscuros para marcar.')
    return paths, (min(xs), min(ys), max(xs), max(ys))


def depth_map_paths(item, passes, interval, progress_callback=None):
    """Yield one set of scan runs per depth level, darkest pixels receiving most passes.

    White receives zero passes, black receives all passes. The physical depth is
    material dependent; this is a pass-count map, not a calibrated Z axis.
    """
    from PIL import Image
    from laser_image_pipeline import prepare
    if not 1 <= passes <= 999 or not math.isfinite(interval) or interval <= 0:
        raise ValueError('Mapa de profundidad: pasadas o intervalo no válidos.')
    s = item.image_settings
    source = prepare(item.original_source, mode='Grayscale', **{k: s[k] for k in
        ('brightness','darkness','contrast','gamma','sharpen','invert','threshold','dpi') if k in s})
    rect = item.boundingRect()
    if rect.isEmpty():
        raise ValueError('El mapa de profundidad no tiene tamaño físico.')
    width = math.dist(tuple((item.mapToScene(rect.topLeft()).x(), item.mapToScene(rect.topLeft()).y())),
                      tuple((item.mapToScene(rect.topRight()).x(), item.mapToScene(rect.topRight()).y())))
    height = math.dist(tuple((item.mapToScene(rect.topLeft()).x(), item.mapToScene(rect.topLeft()).y())),
                       tuple((item.mapToScene(rect.bottomLeft()).x(), item.mapToScene(rect.bottomLeft()).y())))
    calibration = load_calibration()
    with Image.open(source) as original:
        columns = min(original.width, max(1, round(width / interval)))
        rows = max(1, round(height / interval)) if s.get('depth_mm_enabled') and s.get('depth_calibration_profile') else min(original.height, max(1, round(height / interval)))
        bitmap = original.convert('L').resize((columns, rows), Image.Resampling.NEAREST)
        import numpy as np
        pixels = np.asarray(bitmap, dtype=np.uint8)
        counts=None
        if s.get('depth_mm_enabled') and s.get('depth_calibration_profile'):
            from depth_calibration import pass_counts,maximum_passes
            profile=s['depth_calibration_profile'];target=float(s['depth_target_mm'])
            passes=maximum_passes(target,profile)
            if s.get('depth_resample','box')=='nearest':
                gray=pixels.astype(float)   # comportamiento anterior (opción de ajuste depth_resample='nearest')
            else:
                # BOX al reducir: promedio por área en vez de un solo píxel por celda (aliasing).
                from depth_resample import resample_depth_gray
                gray=resample_depth_gray(original,columns,rows).astype(float)
            counts=pass_counts((255-gray)/255*target,profile)
        for level in range(1, passes + 1):
            if progress_callback:
                progress_callback(level, passes)
            # Same threshold and runs as the previous pixel-by-pixel implementation.
            threshold = 255 - (level - 1) * 255 / passes
            dark = counts >= level if counts is not None else pixels < threshold
            edges = np.diff(np.pad(dark.astype(np.int8), ((0, 0), (1, 1))), axis=1)
            paths = []
            for y in range(rows):
                if progress_callback and y % 64 == 0:
                    progress_callback(level, passes)
                row_start = len(paths)
                starts = np.flatnonzero(edges[y] == 1)
                ends = np.flatnonzero(edges[y] == -1)
                for start, x in zip(starts.tolist(), ends.tolist()):
                    line = []
                    for u in (start / columns, x / columns):
                        point = item.mapToScene(QPointF(rect.left() + u * rect.width(),
                            rect.top() + (y + .5) / rows * rect.height()))
                        xy = _map_logical(point.x(), point.y(), calibration)
                        if any(not math.isfinite(v) or abs(v) > 55 for v in xy):
                            raise ValueError('El mapa de profundidad sale del campo de ±55 mm.')
                        line.append(xy)
                    paths.append(line)
                if y % 2:
                    paths[row_start:] = [line[::-1] for line in reversed(paths[row_start:])]
            if paths:
                yield level, paths
