"""Measured material response curves, invertible without extrapolation."""
import copy,json,math,uuid
from pathlib import Path
STORE=Path(__file__).resolve().parent/'depth_calibrations.json'
# Redondeo de la curva a pasadas enteras. 'nearest' no tiene sesgo; 'ceil' es el
# comportamiento anterior (siempre hacia más profundidad, hasta +1 pasada por píxel).
ROUNDING='nearest'
ROUNDING_MODES=('nearest','ceil')

def validate_profile(profile):
    p=copy.deepcopy(profile)
    origin=p.get('reference_origin',{})
    if origin.get('source_kind')=='external_reference' and origin.get('locally_measured') is not True:
        raise ValueError('La referencia externa no es una calibración de este equipo. Introduce al menos dos mediciones propias y confirma su origen.')
    if not str(p.get('name','')).strip() or not str(p.get('material','')).strip():
        raise ValueError('Introduce nombre y material de la calibración.')
    points=p.get('points',[])
    if len(points)<2:raise ValueError('Introduce al menos dos muestras medidas, con pasadas y profundidad.')
    checked=[]
    for n,d in points:
        n=float(n);d=float(d)
        if not math.isfinite(n) or n!=int(n) or not 1<=n<=999 or not math.isfinite(d) or d<=0:
            raise ValueError('Cada muestra necesita pasadas enteras 1-999 y profundidad medida positiva y finita.')
        checked.append([int(n),d])
    checked.sort()
    if any(b[0]<=a[0] or b[1]<=a[1] for a,b in zip(checked,checked[1:])):
        raise ValueError('Las pasadas y las profundidades deben aumentar estrictamente; revisa las mediciones.')
    pen=p.get('pen',{})
    for k in ('speed','power','frequency','interval'):
        v=float(pen.get(k,float('nan')))
        if not math.isfinite(v) or v<=0:raise ValueError('La pluma de calibración necesita valores positivos: '+k)
        pen[k]=v
    if pen['power']>100:raise ValueError('Potencia fuera de 0-100%.')
    focus=float(p.get('focus_mm',0))
    if not math.isfinite(focus):raise ValueError('Enfoque no válido.')
    p.update(points=checked,pen=pen,focus_mm=focus,method='measured_piecewise_linear',version=1)
    return p

def load_profiles(path=None):
    target=Path(path or STORE)
    if not target.exists():return []
    try:
        rows=json.loads(target.read_text(encoding='utf-8'))['profiles']
        return [validate_profile(p) for p in rows]
    except (ValueError,KeyError,TypeError) as e:raise ValueError('No se puede leer la biblioteca de calibraciones: '+str(e)) from e

def save_profiles(profiles,path=None):
    target=Path(path or STORE);rows=[validate_profile(p) for p in profiles]
    ids=[p.get('id') for p in rows]
    if len(set(ids))!=len(ids) or any(not i for i in ids):raise ValueError('Identificadores de calibración no válidos.')
    target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_suffix('.tmp');temp.write_text(json.dumps({'version':1,'profiles':rows},indent=2,ensure_ascii=False),encoding='utf-8');temp.replace(target)

def pass_counts(depths,profile,rounding=None):
    import numpy as np
    mode=rounding or ROUNDING
    if mode not in ROUNDING_MODES:raise ValueError('Modo de redondeo no válido: '+str(mode))
    p=validate_profile(profile);values=np.asarray(depths,dtype=float)
    if not np.isfinite(values).all() or (values<0).any():raise ValueError('Profundidades no válidas.')
    maximum=p['points'][-1][1]
    if (values>maximum+1e-10).any():raise ValueError(f'Objetivo fuera de la curva medida: máximo {maximum:g} mm. Mide nuevas muestras; no se extrapola.')
    points=[[0,0]]+p['points'];n,d=np.array(points,dtype=float).T
    fractional=np.interp(np.clip(values,0,maximum),d,n)
    # floor(x+.5) y no np.round: éste redondea 0,5 al par y daría resultados irregulares.
    rounded=np.ceil(fractional-1e-10) if mode=='ceil' else np.floor(fractional+.5)
    counts=rounded.clip(0,999).astype(np.uint16)
    return counts

def maximum_passes(target,profile,rounding=None):
    if not math.isfinite(float(target)) or float(target)<=0:raise ValueError('Objetivo positivo requerido.')
    # Mínimo 1: un objetivo válido siempre necesita al menos una pasada.
    return max(1,int(pass_counts([target],profile,rounding)[0]))

def assert_matching(profile,cut,interval):
    p=validate_profile(profile)
    current=dict(speed=float(cut.speed),power=float(cut.power),frequency=float(cut.frequency),interval=float(interval))
    differences=[f'{k}: muestra {p["pen"][k]:g} / actual {v:g}' for k,v in current.items() if not math.isclose(p['pen'][k],v,rel_tol=1e-8,abs_tol=1e-8)]
    material=str(getattr(cut,'material','')).strip()
    if not material or material.casefold()!=p['material'].strip().casefold():differences.append(f'Material: muestra {p["material"]} / actual {material or "sin asignar"}')
    if differences:raise ValueError('La curva medida no coincide con la pluma/material:\n'+'\n'.join(differences)+'\nRestaura los ajustes medidos o crea otra calibración. No se ha enviado marcado.')
    return p

def export_calibrated(map_path,target,profile,output_dir=None):
    import numpy as np
    from PIL import Image
    p=validate_profile(profile);maximum_passes(target,p)
    with Image.open(map_path) as image:gray=np.asarray(image.convert('L'),dtype=float)
    desired=(255-gray)/255*float(target);counts=pass_counts(desired,p)
    folder=Path(output_dir or Path(map_path).parent);folder.mkdir(parents=True,exist_ok=True)
    out=folder/(Path(map_path).stem+'_'+uuid.uuid4().hex+'_calibrated_mm16.png')
    Image.fromarray(np.round(desired/target*65535).astype(np.uint16)).save(out)
    passes=out.with_name(out.stem.replace('_mm16','_passes16')+'.png');Image.fromarray(counts).save(passes)
    out.with_suffix('.json').write_text(json.dumps({'version':2,'kind':'desired_depth_with_measured_response','unit':'mm','target_max_mm':target,'formula':'depth_mm = pixel_uint16 / 65535 * target_max_mm','pass_map':passes.name,'pass_map_unit':'passes','rounding':ROUNDING,'calibration':p,'physical_result_requires_verification':True},indent=2,ensure_ascii=False),encoding='utf-8')
    return str(out)
