"""Build a bounded height field from semantic masks, never from photo luminance.

White is preserved stock, black is maximum removal. AI geometry is only a
bounded detail guide. Region minima protect black hair; attached eyebrows
follow local face height rather than a global flat plane.
"""
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps

REGIONS = (
    ('Exterior / sin tallar', (255,255,255), 255,255),
    ('Fondo hundido', (32,32,32), 24,40),
    ('Plano posterior / bandera', (255,0,0), 55,90),
    ('Cuerpos / ropa', (0,180,0), 110,155),
    ('Pliegues altos / correas', (0,80,255), 160,180),
    ('Cabezas / pelo / cascos', (255,0,255), 185,205),
    ('Rostros / volumen facial', (0,220,220), 206,220),
    ('Cejas / detalles faciales elevados', (160,80,255), 225,231),
    ('Emblemas / hojas / cinta', (255,160,0), 233,245),
    ('Letras / borde elevado', (255,255,0), 250,255),
)

DISTANCE_METRICS=('l1','euclidean')

def default_settings():
    return dict(version=3, smooth=3., detail=.50, volume=.65, contour=10.,attach_brows=True,distance_metric='euclidean',
                ranges=[[r[2],r[3]] for r in REGIONS], levels=0, reviewed=False)

def region_paths(raw):
    path=Path(raw)
    return path.with_name(path.stem+'_regions.png'),path.with_name(path.stem+'_relief.json')

def validate_settings(settings):
    ranges=np.asarray(settings['ranges'],dtype=float)
    if ranges.shape!=(len(REGIONS),2) or not np.isfinite(ranges).all():
        raise ValueError('Tabla de alturas de regiones no válida.')
    if (ranges<0).any() or (ranges>255).any() or (ranges[:,0]>ranges[:,1]).any():
        raise ValueError('Las alturas deben estar entre 0 y 255; mínimo ≤ máximo.')
    if not np.array_equal(ranges[0],[255,255]):
        raise ValueError('El exterior debe conservarse en blanco (255).')
    for i in range(2,len(REGIONS)):
        if ranges[i,0]<=ranges[i-1,1]:
            raise ValueError('Los intervalos deben subir sin solaparse: fondo → planos → detalles.')
    for key,lo,hi in (('smooth',0,12),('detail',0,1),('contour',1,64)):
        v=float(settings[key])
        if not np.isfinite(v) or not lo<=v<=hi:raise ValueError('Ajuste no válido: '+key)
    if settings.get('distance_metric','l1') not in DISTANCE_METRICS:raise ValueError('Métrica de distancia no válida.')
    levels=int(settings.get('levels',0))
    volume=float(settings.get('volume',.7))
    if not np.isfinite(volume) or not 0<=volume<=1:raise ValueError('Volumen debe estar entre 0 y 1.')
    if not 0<=levels<=256:raise ValueError('Selecciona continuo (0) o de 1 a 256 niveles por región.')
    return ranges

def decode_regions(image):
    """Nearest palette entry; AI colors are not used as height values."""
    rgb=np.asarray(image.convert('RGB'),dtype=np.float32)
    best=np.full(rgb.shape[:2],np.inf,dtype=np.float32)
    labels=np.zeros(best.shape,dtype=np.uint8)
    for i,(_,color,_,_) in enumerate(REGIONS):
        distance=np.sum((rgb-np.asarray(color))**2,axis=2)
        select=distance<best;labels[select]=i;best[select]=distance[select]
    uncertain=float(np.mean(best>65**2))
    return labels,uncertain

def encode_regions(labels):
    labels=np.asarray(labels)
    if labels.ndim!=2 or (labels>=len(REGIONS)).any() or (labels<0).any():
        raise ValueError('Máscara de regiones no válida.')
    return Image.fromarray(np.asarray([r[1] for r in REGIONS],dtype=np.uint8)[labels])

def canonicalize_regions(path):
    with Image.open(path) as image:labels,uncertain=decode_regions(image)
    if not np.any(labels>0):raise ValueError('La IA no ha separado regiones. Importa o dibuja una máscara.')
    encode_regions(labels).save(path)
    return uncertain

def blur(array,sigma):
    """Separable Gaussian in floating point; no extra runtime dependency."""
    if sigma<=0:return np.asarray(array,dtype=np.float32).copy()
    radius=max(1,int(np.ceil(3*sigma)))
    axis=np.arange(-radius,radius+1,dtype=np.float32)
    kernel=np.exp(-axis**2/(2*sigma*sigma));kernel/=kernel.sum()
    result=np.asarray(array,dtype=np.float32)
    for dim in (0,1):
        pads=[(0,0),(0,0)];pads[dim]=(radius,radius)
        padded=np.pad(result,pads,mode='edge');out=np.zeros_like(result)
        for shift,weight in enumerate(kernel):
            slices=[slice(None),slice(None)];slices[dim]=slice(shift,shift+result.shape[dim])
            out+=weight*padded[tuple(slices)]
        result=out
    return result

def _distance_euclidean(mask,limit=None):
    """Exact Euclidean distance to the exterior (outside the image counts as exterior).

    Uses scipy when present. Otherwise a separable NumPy search that is exact up to
    `limit` pixels and saturates at `limit` beyond it."""
    inside=np.pad(np.asarray(mask,dtype=bool),1)
    try:
        from scipy.ndimage import distance_transform_edt
    except ImportError:
        distance_transform_edt=None
    if distance_transform_edt is not None:
        return distance_transform_edt(inside).astype(np.float32)[1:-1,1:-1]
    height,width=inside.shape
    cap=max(height,width) if not limit else int(max(1,min(int(np.ceil(limit)),max(height,width))))
    far=np.float32(4*cap*cap+1)
    base=np.where(inside,far,np.float32(0)).astype(np.float32)
    columns=base.copy()
    for shift in range(1,cap+1):
        cost=np.float32(shift*shift)
        np.minimum(columns[shift:,:],base[:-shift,:]+cost,out=columns[shift:,:])
        np.minimum(columns[:-shift,:],base[shift:,:]+cost,out=columns[:-shift,:])
    both=columns.copy()
    for shift in range(1,cap+1):
        cost=np.float32(shift*shift)
        np.minimum(both[:,shift:],columns[:,:-shift]+cost,out=both[:,shift:])
        np.minimum(both[:,:-shift],columns[:,shift:]+cost,out=both[:,:-shift])
    return np.sqrt(np.minimum(both,np.float32(cap*cap)))[1:-1,1:-1].astype(np.float32)

def distance_inside(mask,metric='l1',limit=None):
    """Distance to the exterior, independent of source pixel intensities.

    metric 'l1' is the legacy diamond-shaped distance; 'euclidean' gives round bevels."""
    if metric=='euclidean':return _distance_euclidean(mask,limit)
    if metric!='l1':raise ValueError('Métrica de distancia no válida.')
    values=np.pad(np.where(mask,1e6,0).astype(np.float32),1)
    for axis in (0,1):
        index=np.arange(values.shape[axis],dtype=np.float32)
        index=index[:,None] if axis==0 else index[None,:]
        values=np.minimum.accumulate(values-index,axis=axis)+index
        rev=np.flip(values,axis=axis)
        values=np.flip(np.minimum.accumulate(rev-index,axis=axis)+index,axis=axis)
    return values[1:-1,1:-1]

def build_height(labels,guide,settings,photo=None):
    ranges=validate_settings(settings)
    labels=np.asarray(labels,dtype=np.uint8);guide=np.asarray(guide,dtype=np.float32)
    if labels.shape!=guide.shape or labels.ndim!=2 or (labels>=len(REGIONS)).any():
        raise ValueError('Mapa y máscara no tienen la misma resolución o etiquetas válidas.')
    if not np.isfinite(guide).all():raise ValueError('Mapa guía no válido.')
    guide=np.clip(guide,0,1)
    height=np.ones(labels.shape,dtype=np.float32)
    if photo is not None:
        photo=np.asarray(photo,dtype=np.float32)
        if photo.shape!=labels.shape:raise ValueError('La imagen de detalle no coincide con la geometría.')

    for i in range(1,len(REGIONS)):
        mask=labels==i
        if not mask.any():continue
        floor,ceiling=ranges[i]/255.
        # Filtering within a mask prevents background from bleeding into heads.
        valid=mask.astype(np.float32)
        support=blur(valid,float(settings['smooth']))
        local=blur(guide*valid,float(settings['smooth']))/np.maximum(support,1e-8)
        # Separate broad shape from small geometric features in the AI guide.
        # This is a bounded height-field approximation, not normal prediction.
        coarse_sigma=max(2.,float(settings['contour'])/2)
        coarse=blur(local*valid,coarse_sigma)/np.maximum(blur(valid,coarse_sigma),1e-8)
        samples=coarse[mask];lo,hi=np.percentile(samples,[2,98])
        shape=np.full_like(local,.5);fine=np.zeros_like(local)
        if hi-lo>1e-5:
            shape=np.clip((coarse-lo)/(hi-lo),0,1)
            fine=np.clip((local-coarse)/(hi-lo),-.5,.5)
        metric=settings.get('distance_metric','l1')
        distance=distance_inside(mask,metric,limit=8*float(settings['contour']))
        dome=1-np.exp(-distance/float(settings['contour']))
        volume=float(settings.get('volume',.7)) if hi-lo>1e-5 else 0.
        amount=.1+.8*((1-volume)*dome+volume*shape)+float(settings['detail'])*.40*fine
        # Fine lighting/pigment modulation only INSIDE each geometric plane.
        # Dark photo details slightly recede, highlights slightly rise, but
        # the region floor/ceiling keeps hair and faces in their proper order.
        if photo is not None:
            local_photo=blur(photo*valid,2.0)/np.maximum(blur(valid,2.0),1e-8)
            broad_photo=blur(photo*valid,12.0)/np.maximum(blur(valid,12.0),1e-8)
            micro=np.clip((local_photo-broad_photo)*2.0,-.38,.38)
            amount+=float(settings.get('shadow_detail',.75)) * micro

        # Aumentar relieve LOCAL de caras: no cambia el orden del resto de planos.
        if i in (6,7):
            strength=float(settings.get('face_depth_strength',100))/100.
            amount=np.clip(.5+(amount-.5)*strength,0,1)
        amount=np.clip(amount,0,1)
        levels=int(settings.get('face_levels',settings.get('levels',0))) if i in (6,7) else int(settings.get('levels',0))
        if levels>1:amount=np.round(amount*(levels-1))/(levels-1)
        elif levels==1:amount=np.ones_like(amount)*0.5
        region=floor+(ceiling-floor)*amount
        height[mask]=np.clip(region[mask],floor,ceiling)
    if settings.get('attach_brows',True) and np.any(labels==7) and np.any(labels==6):
        # Extend adjacent face heights only through eyebrow pixels. Pigment and
        # guide intensity never decide their attachment to the forehead.
        known=labels==6;target=labels==7;base=height.copy()
        for _ in range(min(256,max(labels.shape))):
            total=np.zeros_like(height);count=np.zeros_like(height)
            padded=np.pad(base,1,mode='edge');valid=np.pad(known,1)
            for dy,dx in ((0,1),(2,1),(1,0),(1,2)):
                neighbor=valid[dy:dy+height.shape[0],dx:dx+height.shape[1]]
                total+=padded[dy:dy+height.shape[0],dx:dx+height.shape[1]]*neighbor
                count+=neighbor
            fill=target & ~known & (count>0)
            if not fill.any():break
            base[fill]=total[fill]/count[fill];known[fill]=True
        attached=target & known
        dome=1-np.exp(-distance_inside(target,settings.get('distance_metric','l1'),limit=8*float(settings['contour']))/float(settings['contour']))
        levels=int(settings.get('levels',0))
        if levels>1:dome=np.round(dome*(levels-1))/(levels-1)
        elif levels==1:dome=np.ones_like(dome)*0.5
        thickness=(1.+(ranges[7,1]-ranges[7,0])*dome)/255.
        height[attached]=np.minimum(base[attached]+thickness[attached],ranges[7,1]/255.)
    return height

def build_regional_map(raw,output,settings=None,source=None):
    mask_path,config_path=region_paths(raw)
    if settings is None:
        settings=json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else default_settings()
    with Image.open(mask_path) as image:labels,_=decode_regions(image)
    with Image.open(raw) as image:
        guide=np.asarray(image.convert('L').resize((labels.shape[1],labels.shape[0]),Image.Resampling.BILINEAR),dtype=np.float32)/255.
    photo=None
    if source:
        with Image.open(source) as image:
            gray=ImageOps.exif_transpose(image).convert('L').resize((labels.shape[1],labels.shape[0]),Image.Resampling.LANCZOS)
            photo=np.asarray(gray,dtype=np.float32)/255.
    height=build_height(labels,guide,settings,photo=photo)
    output=Path(output)
    Image.fromarray(np.round(height*255).astype(np.uint8)).save(output)
    precise=output.with_name(output.stem+'_height16.png')
    Image.fromarray(np.round(height*65535).astype(np.uint16)).save(precise)
    config_path.write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8')
    precise.with_suffix('.json').write_text(json.dumps(dict(kind='relative_height_not_measurement',white='highest_preserved_surface',black='deepest_removal',source_mask=str(mask_path),settings=settings),ensure_ascii=False,indent=2),encoding='utf-8')
    return str(output)
