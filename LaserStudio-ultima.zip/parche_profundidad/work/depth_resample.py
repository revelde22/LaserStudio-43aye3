"""Remuestreo del mapa de profundidad a la rejilla de líneas del láser.

El mapa en grises es lineal en profundidad (profundidad = (255 - gris) / 255 * objetivo),
así que promediar grises al reducir equivale a promediar la profundidad de la celda.
Solo depende de Pillow y NumPy; no usa Qt ni el dispositivo.
"""


def resample_depth_gray(image, columns, rows):
    """Devuelve un array float32 (rows, columns) con grises 0..255 (255 = sin tallar).

    - Eje que se REDUCE: promedio por área (BOX). Con NEAREST se tomaba un solo píxel por
      celda y una textura fina producía ruido (aliasing) en las pasadas.
    - Eje que se AMPLÍA: réplica de píxeles (NEAREST), idéntica al comportamiento anterior.
    - Se mantiene en float32: el promedio no se vuelve a cuantizar a 8 bits.
    """
    import numpy as np
    from PIL import Image
    columns = int(columns)
    rows = int(rows)
    if columns < 1 or rows < 1:
        raise ValueError('La rejilla del láser debe tener al menos 1 columna y 1 fila.')
    gray = image.convert('L').convert('F')
    width, height = gray.size
    reduced = (min(columns, width), min(rows, height))
    if reduced != (width, height):
        gray = gray.resize(reduced, Image.Resampling.BOX)
    if gray.size != (columns, rows):
        gray = gray.resize((columns, rows), Image.Resampling.NEAREST)
    return np.asarray(gray, dtype=np.float32)
