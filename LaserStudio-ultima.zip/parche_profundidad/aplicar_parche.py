"""Aplica el parche de profundidad con copia de seguridad y pruebas.

Cambios que instala:
  - depth_calibration.py  redondeo de pasadas al entero más cercano (antes siempre hacia arriba)
  - regional_depth.py     distancia euclídea para los biseles de las regiones (configuraciones nuevas)
  - g2_vector_frame.py    en el modo calibrado en mm, reducir el mapa con promedio por área (BOX)
                          en vez de NEAREST; opción por mapa: depth_resample = 'nearest' (antiguo)
  - depth_resample.py     (nuevo) la función de remuestreo

Qué hace:
  1. Comprueba que cada fichero a sustituir es EXACTAMENTE la versión revisada (hash SHA-256).
     Si lo has modificado, no toca nada.
  2. Guarda una copia *.bak_orig junto a cada fichero y lo sustituye.
  3. Copia los tests a tests/ y ejecuta pytest.

Uso (desde la raíz del proyecto, la carpeta que contiene ARRANCAR_43AYE3.bat):
  python parche_profundidad\\aplicar_parche.py            aplica y prueba
  python parche_profundidad\\aplicar_parche.py --solo-tests
  python parche_profundidad\\aplicar_parche.py --revertir  restaura las copias y quita depth_resample.py
Solo usa la biblioteca estándar; pytest, numpy y Pillow deben estar en el Python que lo ejecute.
"""
import argparse
import hashlib
import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
# nombre: (hash original, hash parcheado)
FICHEROS = {
    'depth_calibration.py': ('e07686cf8f999a10efa887b9e30522d199e29ef550742b0f4740337a0e93f78b',
                             '1af1e7b3f181f9bab0fc0e8b9cf7c42ba10c22c3c0680725e7e0998fa0d67984'),
    'regional_depth.py': ('c5881cd8a06bfd00bcfe3c302a31eacff9b458c6037933ceb756815235923d0d',
                          '32fbea89674025a8cad1869b3e7e93f6014d672f5ea34f4f9f31e402990aa07f'),
    'g2_vector_frame.py': ('468bf502d76f3f67b330829758674dcec4e79d1de101bf8824a7734ce3028caf',
                           'ee80f357d0ff769b424b151463ddc1a5829a15688d0bf3f68cd20a3c2d4a2dc7'),
}
# ficheros que no existían: nombre: hash
NUEVOS = {'depth_resample.py': '0c5395fac984c3394b16482ad9c7b956b94d981961d89ce884f4f398759a07bd'}
TESTS = ('test_depth_precision.py', 'test_depth_resample.py')
SUFIJO = '.bak_orig'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def aplicar(work):
    # Se valida todo primero y se escribe después: nunca queda el parche a medias.
    plan, nuevos = [], []
    for nombre, (original, parcheado) in FICHEROS.items():
        destino = work / nombre
        if not destino.exists():
            return f'No existe {destino}. ¿Estás en la raíz del proyecto?'
        if sha(AQUI / 'work' / nombre) != parcheado:
            return f'El parche {nombre} no coincide con su hash esperado; descárgalo de nuevo.'
        actual = sha(destino)
        if actual == parcheado:
            print(f'  ya aplicado: {nombre}')
        elif actual == original:
            plan.append((nombre, destino))
        else:
            return (f'{nombre} no es la versión revisada (hash distinto): lo has modificado o es otra versión.\n'
                    '  No se ha cambiado nada. Compara a mano con parche_profundidad\\work\\' + nombre)
    for nombre, esperado in NUEVOS.items():
        destino = work / nombre
        if sha(AQUI / 'work' / nombre) != esperado:
            return f'El fichero {nombre} del paquete no coincide con su hash esperado; descárgalo de nuevo.'
        if destino.exists() and sha(destino) != esperado:
            return f'Ya existe {nombre} en el proyecto con otro contenido. No se ha cambiado nada.'
        if not destino.exists():
            nuevos.append((nombre, destino))
        else:
            print(f'  ya aplicado: {nombre}')
    for nombre, destino in nuevos:                 # primero lo nuevo: g2_vector_frame lo importa
        shutil.copy2(AQUI / 'work' / nombre, destino)
        print(f'  añadido: {nombre}')
    for nombre, destino in plan:
        copia = destino.with_name(destino.name + SUFIJO)
        if not copia.exists():
            shutil.copy2(destino, copia)
        shutil.copy2(AQUI / 'work' / nombre, destino)
        print(f'  aplicado: {nombre}  (copia en {copia.name})')
    return None


def revertir(work):
    hecho = False
    for nombre in FICHEROS:
        destino = work / nombre
        copia = destino.with_name(destino.name + SUFIJO)
        if copia.exists():
            shutil.copy2(copia, destino)
            print(f'  restaurado: {nombre}')
            hecho = True
    for nombre, esperado in NUEVOS.items():        # solo se borra si es idéntico al del paquete
        destino = work / nombre
        if destino.exists() and sha(destino) == esperado:
            destino.unlink()
            print(f'  eliminado: {nombre}')
            hecho = True
    if not hecho:
        print('  no hay nada que revertir')


def pruebas(raiz):
    carpeta = raiz / 'tests'
    carpeta.mkdir(exist_ok=True)
    for nombre in TESTS:
        shutil.copy2(AQUI / 'tests' / nombre, carpeta / nombre)
    faltan = [m for m in ('pytest', 'numpy', 'PIL') if importlib.util.find_spec(m) is None]
    if faltan:
        print('Faltan en este Python: ' + ', '.join(faltan))
        print('Instálalos con:  "%s" -m pip install pytest numpy Pillow' % sys.executable)
        print('(el parche ya está aplicado; solo faltan las pruebas)')
        return 4
    print('Ejecutando pruebas...')
    try:
        return subprocess.run([sys.executable, '-m', 'pytest', '-q', *[str(carpeta / n) for n in TESTS]],
                              cwd=str(raiz)).returncode
    except OSError as error:
        print('No se pudo lanzar pytest:', error)
        return 1


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--proyecto', default=str(AQUI.parent), help='raíz del proyecto (por defecto, la carpeta superior)')
    parser.add_argument('--solo-tests', action='store_true')
    parser.add_argument('--revertir', action='store_true')
    argumentos = parser.parse_args()
    raiz = Path(argumentos.proyecto).resolve()
    work = raiz / 'work'
    if not work.is_dir():
        print(f'No encuentro {work}. Ejecuta esto desde la raíz del proyecto.')
        return 2
    if argumentos.revertir:
        revertir(work)
        return 0
    if not argumentos.solo_tests:
        print('Aplicando parche en', work)
        error = aplicar(work)
        if error:
            print('\nERROR:', error)
            return 3
    return pruebas(raiz)


if __name__ == '__main__':
    sys.exit(main())
