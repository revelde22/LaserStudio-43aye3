"""Remuestreo del mapa de profundidad a la rejilla del láser (sin aliasing).

Incluye una prueba de integración que ejecuta g2_vector_frame.depth_map_paths con un
objeto de imagen simulado y reconstruye las pasadas por celda que se enviarían a la
máquina. No necesita la G2; si PySide6 no está instalado se usa un QPointF mínimo.
Ejecutar:  python -m pytest tests/test_depth_resample.py -q
"""
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'work'))

try:
    import PySide6.QtCore  # noqa: F401
except ImportError:                                    # entorno de pruebas sin Qt
    import types
    _pkg, _core = types.ModuleType('PySide6'), types.ModuleType('PySide6.QtCore')

    class _QPointF:
        def __init__(self, x=0., y=0.):
            self._x, self._y = float(x), float(y)

        def x(self):
            return self._x

        def y(self):
            return self._y
    _core.QPointF = _QPointF
    _pkg.QtCore = _core
    sys.modules['PySide6'], sys.modules['PySide6.QtCore'] = _pkg, _core

import depth_calibration as dc  # noqa: E402
from depth_resample import resample_depth_gray  # noqa: E402


# ------------------------------------------------------------- función pura

def legacy_nearest(image, columns, rows):
    return np.asarray(image.convert('L').resize((columns, rows), Image.Resampling.NEAREST), dtype=float)


def random_image(width, height, seed=1):
    return Image.fromarray(np.random.default_rng(seed).integers(0, 256, (height, width), dtype=np.uint8))


@pytest.mark.parametrize('size,grid', [((100, 80), (400, 330)), ((37, 53), (200, 100)), ((64, 64), (64, 64))])
def test_upscale_is_identical_to_previous_nearest(size, grid):
    image = random_image(*size)
    assert np.array_equal(resample_depth_gray(image, *grid), legacy_nearest(image, *grid))


def test_integer_downscale_is_exact_block_mean():
    image = random_image(300, 240)
    expected = np.asarray(image, dtype=float).reshape(80, 3, 100, 3).mean(axis=(1, 3))
    assert np.allclose(resample_depth_gray(image, 100, 80), expected, atol=1e-3)


def test_fine_texture_aliases_with_nearest_but_not_with_box():
    stripes = np.tile(np.array([0, 255, 255], dtype=np.uint8), 400)[None, :].repeat(60, axis=0)   # período 3 px
    image = Image.fromarray(stripes)
    truth = 255 * 2 / 3
    new = resample_depth_gray(image, 400, 60)
    old = legacy_nearest(image, 400, 60)
    assert np.abs(new - truth).max() < 1e-3
    assert np.abs(old - truth).mean() > 80         # NEAREST da 0 o 255: aliasing total


def test_mixed_axes_average_where_reducing_and_replicate_where_enlarging():
    image = random_image(300, 40)
    out = resample_depth_gray(image, 100, 120)     # X se reduce x3, Y se amplía x3
    columns = np.asarray(image, dtype=float).reshape(40, 100, 3).mean(axis=2)
    assert out.shape == (120, 100)
    assert np.allclose(out, np.repeat(columns, 3, axis=0), atol=1e-3)


def test_output_contract():
    out = resample_depth_gray(Image.new('RGBA', (90, 90), (10, 10, 10, 255)), 30, 45)
    assert out.dtype == np.float32 and out.shape == (45, 30)
    assert 0 <= out.min() and out.max() <= 255
    assert np.allclose(resample_depth_gray(Image.new('L', (50, 50), 200), 7, 9), 200)
    for bad in ((0, 5), (5, 0), (-1, 5)):
        with pytest.raises(ValueError):
            resample_depth_gray(Image.new('L', (4, 4)), *bad)


# ------------------------------------------- integración con depth_map_paths

PEN = dict(speed=1000, power=70, frequency=30, interval=.05)
PROFILE = dict(id='t', name='latón', material='Latón', pen=PEN, focus_mm=0.,
               points=[[10, .10], [50, .45], [100, .80]],
               reference_origin=dict(source_kind='local', locally_measured=True))
LEFT, TOP, SIDE, TARGET, INTERVAL = 35., 35., 20., .40, .05      # pieza de 20 x 20 mm


class _Point:
    def __init__(self, x, y):
        self._x, self._y = x, y

    def x(self):
        return self._x

    def y(self):
        return self._y


class _Rect:
    def isEmpty(self):
        return False

    def width(self):
        return SIDE

    def height(self):
        return SIDE

    def left(self):
        return LEFT

    def top(self):
        return TOP

    def topLeft(self):
        return _Point(LEFT, TOP)

    def topRight(self):
        return _Point(LEFT + SIDE, TOP)

    def bottomLeft(self):
        return _Point(LEFT, TOP + SIDE)


class _Item:
    def __init__(self, source, **settings):
        self.original_source = str(source)
        self.image_settings = dict(depth_mm_enabled=True, depth_calibration_profile=PROFILE,
                                   depth_target_mm=TARGET, **settings)

    def boundingRect(self):
        return _Rect()

    def mapToScene(self, point):
        return point


def machine_counts(item, columns, rows):
    """Pasadas por celda que recibiría la máquina, reconstruidas de los trazados generados."""
    from g2_vector_frame import depth_map_paths
    passes = dc.maximum_passes(TARGET, PROFILE)
    counts = np.zeros((rows, columns), dtype=int)
    for _, paths in depth_map_paths(item, passes, INTERVAL):
        for line in paths:
            xs = sorted((line[0][0] + 55, line[-1][0] + 55))              # lógico -> escena (campo 110, sin ajustes)
            row = int((55 - line[0][1] - TOP) / SIDE * rows)
            counts[row, round((xs[0] - LEFT) / SIDE * columns):round((xs[1] - LEFT) / SIDE * columns)] += 1
    return counts


def textured_depth_map(size):
    yy, xx = np.mgrid[:size, :size]
    bowl = 150 + 90 * np.cos(np.hypot(xx - size / 2, yy - size / 2) / (size / 2) * np.pi / 2)
    noise = np.random.default_rng(5).integers(-40, 41, (size, size))
    return np.clip(bowl + noise, 0, 255).astype(np.uint8)


def expected_counts(prepared, columns, rows, how):
    pixels = np.asarray(prepared, dtype=float)
    if how == 'box':
        factor = pixels.shape[0] // rows
        pixels = pixels.reshape(rows, factor, columns, factor).mean(axis=(1, 3))
    else:
        pixels = np.asarray(prepared.resize((columns, rows), Image.Resampling.NEAREST), dtype=float)
    return dc.pass_counts((255 - pixels) / 255 * TARGET, PROFILE).astype(int)


def prepared_image(source):
    from laser_image_pipeline import prepare
    with Image.open(prepare(str(source), mode='Grayscale')) as image:
        return image.convert('L').copy()


@pytest.fixture(scope='module')
def textured_source():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'mapa_1200.png'
        Image.fromarray(textured_depth_map(1200)).save(path)             # 1200 px sobre 400 líneas: se reduce x3
        yield path


def test_default_path_matches_block_mean_and_removes_aliasing_noise(textured_source):
    columns = rows = round(SIDE / INTERVAL)
    prepared = prepared_image(textured_source)
    ideal = expected_counts(prepared, columns, rows, 'box')
    new = machine_counts(_Item(textured_source), columns, rows)
    old = machine_counts(_Item(textured_source, depth_resample='nearest'), columns, rows)
    rms = lambda a: float(np.sqrt(np.mean((a - ideal) ** 2)))
    assert rms(new) < .1                                  # solo diferencias de redondeo en el límite de 0,5
    assert rms(old) > 2                                   # ruido de aliasing del NEAREST, en pasadas
    assert np.abs(new - ideal).max() <= 1


def test_opt_out_reproduces_previous_nearest_behaviour_exactly(textured_source):
    columns = rows = round(SIDE / INTERVAL)
    opted_out = machine_counts(_Item(textured_source, depth_resample='nearest'), columns, rows)
    assert np.array_equal(opted_out, expected_counts(prepared_image(textured_source), columns, rows, 'nearest'))


def test_enlarging_map_is_unchanged_by_the_new_default():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'mapa_100.png'
        Image.fromarray(textured_depth_map(100)).save(path)               # 100 px sobre 400 líneas: se amplía
        default = machine_counts(_Item(path), 100, 400)                   # columnas = min(ancho, 400) = 100
        legacy = machine_counts(_Item(path, depth_resample='nearest'), 100, 400)
    assert np.array_equal(default, legacy)
