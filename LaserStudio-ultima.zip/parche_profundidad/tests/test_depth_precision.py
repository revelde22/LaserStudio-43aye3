"""Pruebas del parche de profundidad: redondeo de pasadas y distancia euclídea.

No necesitan Qt, la G2 ni GPU. Ejecutar:  python -m pytest tests/test_depth_precision.py -q
"""
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'work'))
import depth_calibration as dc  # noqa: E402
import regional_depth as rd  # noqa: E402

PEN = dict(speed=1000, power=70, frequency=30, interval=.02)
POINTS = [[10, .10], [50, .45], [100, .80]]


def profile(points=None):
    return dict(id='t', name='latón', material='Latón', pen=dict(PEN), focus_mm=0.,
                points=[list(p) for p in (points or POINTS)],
                reference_origin=dict(source_kind='local', locally_measured=True))


def fractional(depths, points=None):
    """Oráculo independiente: interpolación directa de la curva medida."""
    pts = np.array([[0, 0]] + list(points or POINTS), dtype=float)
    return np.interp(depths, pts[:, 1], pts[:, 0])


# ---------------------------------------------------------------- pasadas

def test_nearest_has_no_bias_and_ceil_does():
    depths = np.linspace(0, .80, 4001)
    frac = fractional(depths)
    nearest = dc.pass_counts(depths, profile(), 'nearest').astype(float)
    ceil = dc.pass_counts(depths, profile(), 'ceil').astype(float)
    assert abs(np.mean(nearest - frac)) < .02
    assert .4 < np.mean(ceil - frac) < .6          # sesgo anterior: media +0,5 pasadas


def test_default_mode_is_nearest():
    depths = np.random.default_rng(7).uniform(0, .80, 3000)
    assert dc.ROUNDING == 'nearest'
    assert np.array_equal(dc.pass_counts(depths, profile()), dc.pass_counts(depths, profile(), 'nearest'))
    assert not np.array_equal(dc.pass_counts(depths, profile()), dc.pass_counts(depths, profile(), 'ceil'))


def test_round_trip_error_is_at_most_half_a_pass():
    depths = np.linspace(0, .80, 2001)
    err = np.abs(dc.pass_counts(depths, profile()).astype(float) - fractional(depths))
    assert err.max() <= .5 + 1e-9


@pytest.mark.parametrize('mode', dc.ROUNDING_MODES)
def test_counts_are_monotonic(mode):
    counts = dc.pass_counts(np.linspace(0, .80, 3001), profile(), mode).astype(int)
    assert (np.diff(counts) >= 0).all()


def test_ceil_reproduces_previous_behaviour():
    depths = np.random.default_rng(3).uniform(0, .80, 5000)
    legacy = np.ceil(fractional(depths) - 1e-10).clip(0, 999).astype(np.uint16)
    assert np.array_equal(dc.pass_counts(depths, profile(), 'ceil'), legacy)


def test_half_values_round_up_deterministically():
    pts = [[2, .5], [4, 1.]]                      # 4 pasadas/mm: 0,125 mm = 0,5 pasadas; 0,625 mm = 2,5
    assert dc.pass_counts([.125], profile(pts))[0] == 1   # np.round daría 0
    assert dc.pass_counts([.625], profile(pts))[0] == 3   # np.round daría 2


def test_no_extrapolation_beyond_measured_curve():
    with pytest.raises(ValueError, match='fuera de la curva'):
        dc.pass_counts([.80001], profile())
    assert dc.pass_counts([.80], profile())[0] == 100


def test_invalid_rounding_mode_is_rejected():
    with pytest.raises(ValueError):
        dc.pass_counts([.1], profile(), 'floor')


@pytest.mark.parametrize('target', [.05, .1, .3, .45, .62, .8])
def test_maximum_passes_matches_darkest_pixel(target):
    """Igual que g2_vector_frame: gris 0 = objetivo completo, gris 255 = 0 pasadas."""
    gray = np.arange(256, dtype=float)
    counts = dc.pass_counts((255 - gray) / 255 * target, profile())
    assert counts.max() == dc.maximum_passes(target, profile())
    assert counts[255] == 0
    assert (np.diff(counts[::-1].astype(int)) >= 0).all()


def test_tiny_valid_target_needs_at_least_one_pass():
    assert dc.maximum_passes(.0001, profile()) == 1


def test_export_calibrated_records_rounding_and_matches_pass_counts():
    gray = np.tile(np.arange(256, dtype=np.uint8), (8, 1))
    with tempfile.TemporaryDirectory() as tmp:
        source = Path(tmp) / 'mapa.png'
        Image.fromarray(gray).save(source)
        out = Path(dc.export_calibrated(str(source), .60, profile(), Path(tmp) / 'salida'))
        meta = json.loads(out.with_suffix('.json').read_text(encoding='utf-8'))
        assert meta['rounding'] == dc.ROUNDING
        with Image.open(out.parent / meta['pass_map']) as image:
            saved = np.array(image)
    expected = dc.pass_counts((255 - gray.astype(float)) / 255 * .60, profile())
    assert np.array_equal(saved, expected)


# ---------------------------------------------------------------- distancia

def legacy_l1(mask):
    """Copia literal de la implementación original, como referencia."""
    values = np.pad(np.where(mask, 1e6, 0).astype(np.float32), 1)
    for axis in (0, 1):
        index = np.arange(values.shape[axis], dtype=np.float32)
        index = index[:, None] if axis == 0 else index[None, :]
        values = np.minimum.accumulate(values - index, axis=axis) + index
        rev = np.flip(values, axis=axis)
        values = np.flip(np.minimum.accumulate(rev - index, axis=axis) + index, axis=axis)
    return values[1:-1, 1:-1]


def brute_euclid(mask):
    """Oráculo por fuerza bruta; el exterior incluye fuera de la imagen."""
    inside = np.pad(mask, 1)
    outside = np.argwhere(~inside).astype(np.float32)
    points = np.argwhere(inside).astype(np.float32)
    result = np.zeros(inside.shape, np.float32)
    if len(points):
        result[inside] = np.sqrt(((points[:, None] - outside[None]) ** 2).sum(2)).min(1)
    return result[1:-1, 1:-1]


def random_mask(seed, shape=(30, 41)):
    return np.random.default_rng(seed).random(shape) > .35


@pytest.mark.parametrize('seed', range(5))
def test_l1_path_is_unchanged(seed):
    mask = random_mask(seed)
    assert np.array_equal(rd.distance_inside(mask), legacy_l1(mask))
    assert np.array_equal(rd.distance_inside(mask, 'l1'), legacy_l1(mask))


@pytest.mark.parametrize('seed', range(5))
def test_euclidean_matches_brute_force(seed):
    mask = random_mask(seed)
    assert np.abs(rd.distance_inside(mask, 'euclidean') - brute_euclid(mask)).max() < 1e-4


@pytest.mark.parametrize('seed', range(5))
def test_numpy_fallback_matches_brute_force_without_scipy(seed, monkeypatch):
    monkeypatch.setitem(sys.modules, 'scipy.ndimage', None)   # fuerza ImportError
    mask = random_mask(seed)
    assert np.abs(rd.distance_inside(mask, 'euclidean') - brute_euclid(mask)).max() < 1e-4


def test_numpy_fallback_saturates_at_limit(monkeypatch):
    monkeypatch.setitem(sys.modules, 'scipy.ndimage', None)
    mask = np.zeros((60, 60), bool)
    mask[5:55, 5:55] = True
    limited = rd.distance_inside(mask, 'euclidean', limit=7)
    exact = brute_euclid(mask)
    assert limited.max() == 7
    assert np.allclose(limited[exact <= 7], exact[exact <= 7], atol=1e-4)


def test_euclidean_bevel_is_round_and_l1_is_diamond_shaped():
    n, c = 129, 64
    yy, xx = np.mgrid[:n, :n]
    radius = np.hypot(xx - c, yy - c)
    disk = radius <= 60
    ring = (radius >= 39.5) & (radius <= 40.5)

    def spread(metric):
        d = rd.distance_inside(disk, metric)[ring]
        return d.std() / d.mean(), d.max() / d.min()

    l1_std, l1_ratio = spread('l1')
    eu_std, eu_ratio = spread('euclidean')
    assert l1_std > .05 and l1_ratio > 1.2         # artefacto del L1: más profundo en diagonales
    assert eu_std < .03 and eu_ratio < 1.08        # euclídea: casi isótropa


def test_unknown_metric_is_rejected():
    with pytest.raises(ValueError):
        rd.distance_inside(np.ones((4, 4), bool), 'chebyshev')


# ------------------------------------------------------------ build_height

def synthetic_scene(size=96):
    yy, xx = np.mgrid[:size, :size]
    labels = np.zeros((size, size), np.uint8)
    labels[(np.abs(xx - 48) < 40) & (np.abs(yy - 48) < 40)] = 3              # cuerpo
    labels[np.hypot(xx - 48, yy - 48) < 22] = 6                              # rostro
    guide = np.clip(.5 + .3 * np.sin(xx / 9.) * np.cos(yy / 11.), 0, 1).astype(np.float32)
    return labels, guide


def test_legacy_settings_without_metric_build_identical_height():
    labels, guide = synthetic_scene()
    modern = rd.default_settings()
    legacy = {k: v for k, v in modern.items() if k != 'distance_metric'}
    explicit = dict(modern, distance_metric='l1')
    h_legacy = rd.build_height(labels, guide, legacy)
    assert np.array_equal(h_legacy, rd.build_height(labels, guide, explicit))


def test_new_default_is_euclidean_and_stays_inside_region_ranges():
    labels, guide = synthetic_scene()
    settings = rd.default_settings()
    assert settings['distance_metric'] == 'euclidean'
    height = rd.build_height(labels, guide, settings)
    ranges = np.asarray(settings['ranges'], float) / 255.
    for index in (3, 6):
        values = height[labels == index]
        assert values.min() >= ranges[index, 0] - 1e-6
        assert values.max() <= ranges[index, 1] + 1e-6
    assert not np.array_equal(height, rd.build_height(labels, guide, dict(settings, distance_metric='l1')))


def test_validate_settings_metric():
    settings = rd.default_settings()
    rd.validate_settings(settings)
    rd.validate_settings({k: v for k, v in settings.items() if k != 'distance_metric'})
    with pytest.raises(ValueError, match='Métrica'):
        rd.validate_settings(dict(settings, distance_metric='manhattan'))
