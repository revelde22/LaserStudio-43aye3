@echo off
REM Abre la interfaz "Foto a relieve (sin IA)". Tambien puedes arrastrar una foto sobre este .bat.
REM Busca el Python del proyecto 43AYE3 (work\.venv) si esta carpeta esta dentro de el; si no, usa el del sistema.
chcp 65001 >nul
cd /d "%~dp0"

set "PY="
set "PYW="
for %%D in ("%~dp0..\work\.venv\Scripts" "%~dp0..\..\work\.venv\Scripts" "%~dp0work\.venv\Scripts") do (
    if not defined PY if exist "%%~D\python.exe" (
        set "PY=%%~D\python.exe"
        set "PYW=%%~D\pythonw.exe"
    )
)
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 (
        set "PY=python"
        set "PYW=pythonw"
    )
)
if not defined PY (
    echo No encuentro Python. Instala Python 3 o copia esta carpeta dentro del proyecto 43AYE3.
    pause
    exit /b 1
)

"%PY%" -c "import numpy, PIL, PySide6" >nul 2>nul
if errorlevel 1 (
    echo Instalando numpy, Pillow y PySide6 ^(solo la primera vez^)...
    "%PY%" -m pip install numpy Pillow PySide6
    "%PY%" -c "import numpy, PIL, PySide6" >nul 2>nul
    if errorlevel 1 (
        echo No se pudieron instalar las dependencias. Mira los mensajes de arriba.
        pause
        exit /b 1
    )
)

start "" "%PYW%" "%~dp0relieve_foto_gui.py" %*
