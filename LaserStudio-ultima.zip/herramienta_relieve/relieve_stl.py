"""Mapa de relieve (grises, blanco = alto) -> STL binario cerrado. Solo numpy y Pillow.

El solido tiene base plana y paredes; la superficie va de `base_mm` (negro) a `base_mm + relieve_mm` (blanco).
Coordenadas: x a la derecha, y arriba, z arriba. Malla estanca (cada arista la comparten dos caras).
"""
import struct

import numpy as np
from PIL import Image

STL_DEFAULTS = dict(ancho_mm=100., relieve_mm=2., base_mm=1., max_px=400)


def malla_relieve(gris, ancho_mm, relieve_mm, base_mm=1., max_px=400):
    g = np.asarray(gris)
    if g.ndim != 2 or min(g.shape) < 2:
        raise ValueError('El mapa debe ser una imagen en grises de al menos 2 x 2 píxeles.')
    if not (ancho_mm > 0 and relieve_mm > 0 and base_mm > 0):
        raise ValueError('Ancho, altura del relieve y grosor de base deben ser mayores que cero.')
    if max_px < 2:
        raise ValueError('La resolución de la malla debe ser al menos 2 px.')
    h0, w0 = g.shape
    alto_mm = ancho_mm * h0 / w0
    if max(h0, w0) > max_px:
        f = max_px / max(h0, w0)
        g = np.asarray(Image.fromarray(np.clip(g, 0, 255).astype(np.uint8)).resize(
            (max(2, round(w0 * f)), max(2, round(h0 * f))), Image.Resampling.BOX))
    h, w = g.shape
    z = base_mm + np.clip(g.astype(np.float64) / 255., 0, 1) * relieve_mm
    xs, ys = np.linspace(0, ancho_mm, w), np.linspace(alto_mm, 0, h)
    top = np.stack([np.broadcast_to(xs, (h, w)), np.broadcast_to(ys[:, None], (h, w)), z], axis=-1).reshape(-1, 3)
    idx = np.arange(h * w).reshape(h, w)
    a, b, c, d = idx[:-1, :-1].ravel(), idx[:-1, 1:].ravel(), idx[1:, 1:].ravel(), idx[1:, :-1].ravel()
    caras_top = np.concatenate([np.stack([a, d, c], 1), np.stack([a, c, b], 1)])
    perim = np.concatenate([idx[:, 0], idx[-1, 1:], idx[-2::-1, -1], idx[0, -2:0:-1]])     # antihorario visto desde arriba
    n = len(perim)
    suelo_v = top[perim].copy(); suelo_v[:, 2] = 0.
    verts = np.concatenate([top, suelo_v, [[ancho_mm / 2, alto_mm / 2, 0.]]])
    B0 = h * w
    k = np.arange(n); k1 = (k + 1) % n
    pared = np.concatenate([np.stack([perim[k], B0 + k, B0 + k1], 1), np.stack([perim[k], B0 + k1, perim[k1]], 1)])
    suelo = np.stack([np.full(n, B0 + n), B0 + k1, B0 + k], 1)
    return verts, np.concatenate([caras_top, pared, suelo]).astype(np.int64), alto_mm


def escribir_stl(ruta, verts, caras):
    t = verts[caras].astype(np.float32)
    normal = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    largo = np.linalg.norm(normal, axis=1, keepdims=True)
    normal = np.divide(normal, largo, out=np.zeros_like(normal), where=largo > 0)
    reg = np.zeros(len(t), dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]))
    reg['n'], reg['v'] = normal, t
    with open(ruta, 'wb') as f:
        f.write(b'Foto a relieve (sin IA)'.ljust(80, b' '))
        f.write(struct.pack('<I', len(t)))
        f.write(reg.tobytes())


def guardar_stl(gris, ruta, **opciones):
    o = dict(STL_DEFAULTS)
    desconocidas = set(opciones) - set(o)
    if desconocidas:
        raise ValueError(f'Opciones STL desconocidas: {sorted(desconocidas)}')
    o.update(opciones)
    verts, caras, alto_mm = malla_relieve(gris, **o)
    escribir_stl(ruta, verts, caras)
    return dict(ruta=str(ruta), triangulos=int(len(caras)), ancho_mm=float(o['ancho_mm']), alto_mm=float(alto_mm),
                alto_total_mm=float(o['base_mm'] + o['relieve_mm']))
