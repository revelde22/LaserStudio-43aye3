"""Interfaz visual (Qt / PySide6) de relieve_foto: foto -> mapa de relieve sin IA, con vista previa en vivo.

Uso:  python relieve_foto_gui.py [foto]      (o arrastra una foto a la ventana)
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image
from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QImage, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel,
                               QMainWindow, QMessageBox, QPushButton, QScrollArea, QSlider, QSpinBox, QVBoxLayout,
                               QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import relieve_foto as rf  # noqa: E402

LADO_VISTA_PREVIA = 720        # la vista previa se calcula reducida; el resultado final usa la resolución completa

AYUDA = dict(
    volumen='Cuánto de la forma amplia pasa a relieve. 0 = solo detalle fino; 1 = todo el tono de la foto.',
    detalle='Ganancia del detalle fino (pelo, textura, trazos).',
    escala='Tamaño de la "forma amplia" como fracción del lado menor. Mayor = volúmenes más grandes y suaves.',
    bordes='Contraste mínimo que cuenta como borde. Más bajo conserva más bordes; más alto suaviza más.',
    limpieza='Reduce el grano de la foto sin borrar bordes.',
    sombras='Eleva las sombras duras, que en una foto no son huecos reales.',
    luces='Baja las luces quemadas y los brillos.',
    gamma='Curva final. Mayor de 1 oscurece (talla más); menor de 1 aclara.')


class Deslizador(QWidget):
    """Deslizador con valor decimal y etiqueta numérica."""

    def __init__(self, nombre, minimo, maximo, valor, decimales, al_cambiar):
        super().__init__()
        self.minimo, self.maximo, self.decimales = float(minimo), float(maximo), decimales
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 1000)
        self.etiqueta = QLabel()
        self.etiqueta.setMinimumWidth(44)
        fila = QHBoxLayout(self)
        fila.setContentsMargins(0, 0, 0, 0)
        fila.addWidget(self.slider, 1)
        fila.addWidget(self.etiqueta)
        self.setToolTip(AYUDA.get(nombre, ''))
        self.poner(valor)
        self.slider.valueChanged.connect(lambda _: (self._refrescar(), al_cambiar()))

    def valor(self):
        return self.minimo + (self.maximo - self.minimo) * self.slider.value() / 1000.

    def poner(self, valor):
        bloqueado = self.slider.blockSignals(True)
        self.slider.setValue(round((float(valor) - self.minimo) / (self.maximo - self.minimo) * 1000))
        self.slider.blockSignals(bloqueado)
        self._refrescar()

    def _refrescar(self):
        self.etiqueta.setText(f'{self.valor():.{self.decimales}f}')


def pixmap_gris(array):
    datos = np.ascontiguousarray(array, dtype=np.uint8)
    alto, ancho = datos.shape
    return QPixmap.fromImage(QImage(datos.data, ancho, alto, ancho, QImage.Format.Format_Grayscale8).copy())


class Ventana(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Foto a relieve (sin IA)')
        self.resize(1280, 760)
        self.setAcceptDrops(True)
        self.ruta = None
        self.reducida = None
        self.pix_mapa = self.pix_vista = None
        self.temporizador = QTimer(self)
        self.temporizador.setSingleShot(True)
        self.temporizador.setInterval(120)
        self.temporizador.timeout.connect(self.actualizar)

        # ---- controles
        panel = QWidget()
        form = QFormLayout(panel)
        self.abrir_btn = QPushButton('Abrir foto…')
        self.abrir_btn.clicked.connect(self.elegir_foto)
        form.addRow(self.abrir_btn)
        self.preset = QComboBox()
        self.preset.addItems(['(ninguno)'] + sorted(rf.PRESETS))
        self.preset.currentTextChanged.connect(self.aplicar_preset)
        form.addRow('Punto de partida', self.preset)
        self.deslizadores = {}
        for nombre, (lo, hi) in rf.LIMITES.items():
            deslizador = Deslizador(nombre, lo, hi, rf.DEFAULTS[nombre], 3 if nombre in ('escala', 'bordes') else 2,
                                    self.programar)
            self.deslizadores[nombre] = deslizador
            form.addRow(nombre.capitalize(), deslizador)
        self.niveles = QSpinBox()
        self.niveles.setRange(0, 256)
        self.niveles.setSpecialValueText('continuo')
        self.niveles.setToolTip('Terrazas: 0 = continuo; de 2 a 256 = número de alturas distintas.')
        self.niveles.valueChanged.connect(self.programar)
        form.addRow('Niveles', self.niveles)
        self.casillas = {}
        for nombre, texto in (('invertir', 'Invertir (oscuro = alto)'),
                              ('quitar_blanco', 'Quitar fondo blanco del borde'),
                              ('circular', 'Recorte circular'),
                              ('estirar', 'Estirar rango (hondo = negro)')):
            casilla = QCheckBox(texto)
            casilla.toggled.connect(self.programar)
            self.casillas[nombre] = casilla
            form.addRow(casilla)
        self.luz = Deslizador('luz', 0, 360, 315, 0, self.programar)
        self.luz.setToolTip('Dirección de la luz de la vista sombreada (solo afecta a la vista previa y a _vista.png).')
        form.addRow('Luz (vista)', self.luz)
        self.png16 = QCheckBox('Guardar también PNG de 16 bits')
        form.addRow(self.png16)
        self.stl_activo = QCheckBox('Guardar también como modelo STL')
        self.stl_activo.setToolTip('Sólido cerrado (base + paredes). Blanco = parte alta, negro = parte baja.')
        form.addRow(self.stl_activo)
        self.stl = {}
        for nombre, texto, minimo, maximo, valor in (('ancho_mm', 'STL · ancho', .1, 2000, 100.), ('relieve_mm', 'STL · altura del relieve', .01, 500, 2.),
                                                     ('base_mm', 'STL · grosor de base', .01, 500, 1.)):
            caja = QDoubleSpinBox(); caja.setRange(minimo, maximo); caja.setDecimals(2); caja.setSuffix(' mm'); caja.setValue(valor)
            self.stl[nombre] = caja
            form.addRow(texto, caja)
        self.guardar_btn = QPushButton('Guardar mapa de relieve')
        self.guardar_btn.setEnabled(False)
        self.guardar_btn.clicked.connect(lambda: self.guardar())
        form.addRow(self.guardar_btn)
        self.aviso = QLabel('Abre o arrastra una foto.')
        self.aviso.setWordWrap(True)
        form.addRow(self.aviso)
        scroll = QScrollArea()
        scroll.setWidget(panel)
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(380)

        # ---- vistas
        self.lienzo_mapa, self.lienzo_vista = QLabel(), QLabel()
        vistas = QHBoxLayout()
        for titulo, lienzo in (('Mapa (blanco = sin tallar, negro = más hondo)', self.lienzo_mapa),
                               ('Vista sombreada', self.lienzo_vista)):
            lienzo.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lienzo.setMinimumSize(200, 200)
            lienzo.setStyleSheet('background:#222;color:#aaa')
            columna = QVBoxLayout()
            columna.addWidget(QLabel(titulo))
            columna.addWidget(lienzo, 1)
            vistas.addLayout(columna)
        centro = QWidget()
        disposicion = QHBoxLayout(centro)
        disposicion.addWidget(scroll)
        disposicion.addLayout(vistas, 1)
        self.setCentralWidget(centro)

    # ---- parámetros
    def parametros(self):
        p = {nombre: d.valor() for nombre, d in self.deslizadores.items()}
        valor = self.niveles.value()
        p['niveles'] = valor if valor >= 2 else 0
        p.update({nombre: c.isChecked() for nombre, c in self.casillas.items()})
        return p

    def aplicar_preset(self, nombre):
        valores = dict(rf.DEFAULTS)
        valores.update(rf.PRESETS.get(nombre, {}))
        bloqueos = [d.slider.blockSignals(True) for d in self.deslizadores.values()]
        for nombre_param, deslizador in self.deslizadores.items():
            deslizador.poner(valores[nombre_param])
        for d, bloqueo in zip(self.deslizadores.values(), bloqueos):
            d.slider.blockSignals(bloqueo)
        self.niveles.setValue(int(valores['niveles']))
        for nombre_param, casilla in self.casillas.items():
            casilla.setChecked(bool(valores[nombre_param]))
        self.programar()

    # ---- archivos
    def dragEnterEvent(self, evento):
        if evento.mimeData().hasUrls():
            evento.acceptProposedAction()

    def dropEvent(self, evento):
        urls = evento.mimeData().urls()
        if urls:
            self.abrir(urls[0].toLocalFile())

    def elegir_foto(self):
        ruta, _ = QFileDialog.getOpenFileName(self, 'Elegir foto', '', 'Imágenes (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp)')
        if ruta:
            self.abrir(ruta)

    def abrir(self, ruta):
        try:
            with Image.open(ruta) as imagen:
                completa = rf.to_rgba(imagen)
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, 'No se puede abrir', str(error))
            return False
        self.ruta = str(ruta)
        if max(completa.size) > LADO_VISTA_PREVIA:
            factor = LADO_VISTA_PREVIA / max(completa.size)
            completa = completa.resize((max(1, round(completa.width * factor)), max(1, round(completa.height * factor))),
                                       Image.Resampling.LANCZOS)
        self.reducida = completa
        self.setWindowTitle('Foto a relieve (sin IA) · ' + Path(ruta).name)
        self.guardar_btn.setEnabled(True)
        self.actualizar()
        return True

    def guardar(self, carpeta=None, silencioso=False):
        if not self.ruta:
            return None
        parametros = self.parametros()
        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            stl = {k: c.value() for k, c in self.stl.items()} if self.stl_activo.isChecked() else None
            rutas = rf.procesar_archivo(self.ruta, carpeta, png16=self.png16.isChecked(), azimut=self.luz.valor(), stl=stl, **parametros)
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, 'No se pudo guardar', str(error))
            return None
        finally:
            QApplication.restoreOverrideCursor()
        if not silencioso:
            QMessageBox.information(self, 'Guardado', f"Mapa: {rutas['mapa']}\nVista: {rutas['vista']}\n" + (f"STL: {rutas['stl']}\n" if 'stl' in rutas else '') + "\n"
                                    'En 43AYE3 cárgalo como mapa de profundidad (blanco = sin tallar, negro = más hondo).')
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(rutas['mapa']).parent)))
        return rutas

    # ---- cálculo y vista
    def programar(self):
        if self.reducida is not None:
            self.temporizador.start()

    def actualizar(self):
        if self.reducida is None:
            return
        parametros = self.parametros()
        try:
            resultado = rf.foto_a_relieve(self.reducida, max_lado=0, **parametros)
        except ValueError as error:
            self.aviso.setText(str(error))
            return
        self.pix_mapa = pixmap_gris(rf.a_uint8(resultado['height']))
        self.pix_vista = pixmap_gris(rf.vista_sombreada(resultado['height'], self.luz.valor()))
        cobertura = resultado['cobertura']
        self.aviso.setText(f'El punto más hondo llega al {100 * cobertura:.0f} % de la profundidad objetivo'
                           + ('.' if cobertura > .97 else ' (activa «Estirar rango» para llegar al 100 %).')
                           + '\nLa vista previa está reducida; el guardado usa la resolución completa.')
        self.ajustar()

    def ajustar(self):
        for lienzo, pix in ((self.lienzo_mapa, self.pix_mapa), (self.lienzo_vista, self.pix_vista)):
            if pix is not None:
                lienzo.setPixmap(pix.scaled(lienzo.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                            Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, evento):
        super().resizeEvent(evento)
        self.ajustar()


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    app = QApplication.instance() or QApplication(argv)
    ventana = Ventana()
    ventana.show()
    if len(argv) > 1:
        ventana.abrir(argv[1])
    return app.exec()


if __name__ == '__main__':
    sys.exit(main())
