"""Foto -> mapa de relieve para tallado, SIN IA (solo numpy y Pillow).

Convención igual que 43AYE3: BLANCO = sin tallar (lo más alto), NEGRO = lo más profundo.

Cómo funciona (todo clásico y determinista):
  1. La luminosidad de la foto se toma como altura (luz = alto, sombra = hondo).
  2. Se limpia el grano con un filtro guiado, que suaviza sin borrar bordes.
  3. Se separa en BASE (forma amplia, filtro guiado de radio grande) y DETALLE (lo fino).
  4. Se recompone: altura = 0,5 + volumen*(base-0,5) + detalle*gananciaDetalle, y se
     suavizan sombras duras y luces quemadas, que en una foto no son geometría.
  5. Opcional: terrazas (posterizado) y recorte del fondo blanco.

Límite que conviene tener claro: la luminosidad NO es la forma. Sombras proyectadas,
pelo oscuro o piel clara se convierten en relieve falso. Funciona mejor con fotos de
luz frontal y plana. Para volumen real hacen falta datos 3D o una estimación (IA).

Uso:  python relieve_foto.py foto.jpg [--preset retrato|objeto|terrazas] [opciones]
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageOps

DEFAULTS = dict(volumen=.7, detalle=1., escala=.04, bordes=.08, limpieza=.5, sombras=0., luces=0.,
                gamma=1., niveles=0, estirar=False, invertir=False, quitar_blanco=False, circular=False, max_lado=2400)

# Puntos de partida, no recetas: ajústalos mirando la vista sombreada.
PRESETS = {
    'retrato': dict(volumen=.75, detalle=.8, escala=.05, bordes=.06, limpieza=.6, sombras=.3, luces=.2),
    'objeto': dict(volumen=.6, detalle=1.3, escala=.03, bordes=.08, limpieza=.4),
    'terrazas': dict(volumen=.9, detalle=.5, escala=.05, bordes=.07, limpieza=.7, niveles=16),
}

LIMITES = dict(volumen=(0., 1.), detalle=(0., 4.), escala=(.005, .2), bordes=(.01, .5), limpieza=(0., 1.),
               sombras=(0., 1.), luces=(0., 1.), gamma=(.3, 3.))


# ------------------------------------------------------------------ filtros

def box_filter(array, radius):
    """Media sobre ventanas (2r+1)^2 con bordes replicados; coste O(N) con sumas acumuladas."""
    a = np.asarray(array, dtype=np.float64)
    r = int(radius)
    if r <= 0:
        return a.astype(np.float32)
    padded = np.pad(a, ((r + 1, r), (r + 1, r)), mode='edge')
    total = padded.cumsum(axis=0).cumsum(axis=1)
    k = 2 * r + 1
    window = total[k:, k:] - total[:-k, k:] - total[k:, :-k] + total[:-k, :-k]
    return (window / (k * k)).astype(np.float32)


def guided_filter(image, radius, eps):
    """Filtro guiado (He et al.) con la propia imagen como guía: suaviza y conserva bordes.

    Los bordes cuya desviación local supera sqrt(eps) se conservan; el resto se suaviza."""
    i = np.asarray(image, dtype=np.float64)
    mean_i = box_filter(i, radius).astype(np.float64)
    var_i = box_filter(i * i, radius).astype(np.float64) - mean_i * mean_i
    a = var_i / (var_i + eps)
    b = mean_i - a * mean_i
    return (box_filter(a, radius).astype(np.float64) * i + box_filter(b, radius).astype(np.float64)).astype(np.float32)


# ------------------------------------------------------------------ entrada

def to_rgba(image):
    """Imagen Pillow -> RGBA de 8 bits. Los PNG de 16 bits se ESCALAN (convert('L') los recortaría)."""
    image = ImageOps.exif_transpose(image)
    if image.mode in ('I;16', 'I;16L', 'I;16B', 'I'):
        data = np.asarray(image, dtype=np.float64)
        scale = 257. if data.max() > 255 else 1.
        image = Image.fromarray(np.clip(np.round(data / scale), 0, 255).astype(np.uint8))
    return image.convert('RGBA')


def exterior_mask(rgba, quitar_blanco=False, circular=False):
    """True = exterior (no se talla). Transparente, blanco conectado con el borde y/o fuera del círculo."""
    pixels = np.asarray(rgba)
    mask = pixels[:, :, 3] == 0
    if quitar_blanco:
        white = (pixels[:, :, :3] >= 245).all(axis=2) | mask
        padded = ImageOps.expand(Image.fromarray(white.astype('uint8') * 255), border=1, fill=255)
        ImageDraw.floodfill(padded, (0, 0), 128)             # blanco que toca el borde = exterior
        mask = mask | (np.asarray(padded)[1:-1, 1:-1] == 128)  # el blanco interior se conserva
    if circular:
        circle = Image.new('L', rgba.size, 0)
        ImageDraw.Draw(circle).ellipse((0, 0, rgba.width - 1, rgba.height - 1), fill=255)
        mask = mask | (np.asarray(circle) == 0)
    return mask


def validar(params):
    p = dict(DEFAULTS)
    p.update({k: v for k, v in params.items() if v is not None})
    unknown = set(p) - set(DEFAULTS)
    if unknown:
        raise ValueError('Parámetros desconocidos: ' + ', '.join(sorted(unknown)))
    for key, (lo, hi) in LIMITES.items():
        value = float(p[key])
        if not np.isfinite(value) or not lo <= value <= hi:
            raise ValueError(f'{key} debe estar entre {lo:g} y {hi:g}.')
        p[key] = value
    p['niveles'] = int(p['niveles'])
    if p['niveles'] != 0 and not 2 <= p['niveles'] <= 256:
        raise ValueError('niveles debe ser 0 (continuo) o de 2 a 256.')
    p['max_lado'] = int(p['max_lado'])
    if p['max_lado'] != 0 and p['max_lado'] < 64:
        raise ValueError('max_lado debe ser 0 (sin límite) o al menos 64.')
    for key in ('estirar', 'invertir', 'quitar_blanco', 'circular'):
        p[key] = bool(p[key])
    return p


# ------------------------------------------------------------------ núcleo

def curva_tonal(h, sombras, luces):
    """Suaviza sombras duras (lift) y luces quemadas. Monótona para sombras, luces en [0,1]."""
    h = np.asarray(h, dtype=np.float32)
    h = h + sombras * .5 * (1. - h) ** 2          # derivada 1 - sombras*(1-h) >= 0
    h = h - luces * .5 * h ** 2                   # derivada 1 - luces*h >= 0
    return np.clip(h, 0., 1.)


def foto_a_relieve(image, **params):
    """Devuelve dict(height=float32 0..1 con 1 = sin tallar, exterior=bool, params=dict)."""
    p = validar(params)
    rgba = to_rgba(image)
    if p['max_lado'] and max(rgba.size) > p['max_lado']:
        factor = p['max_lado'] / max(rgba.size)
        rgba = rgba.resize((max(1, round(rgba.width * factor)), max(1, round(rgba.height * factor))),
                           Image.Resampling.LANCZOS)
    exterior = exterior_mask(rgba, p['quitar_blanco'], p['circular'])
    inside = ~exterior
    if not inside.any():
        raise ValueError('La imagen solo contiene fondo; no hay nada que tallar.')

    luminance = np.asarray(rgba.convert('L'), dtype=np.float32) / 255.
    if p['invertir']:
        luminance = 1. - luminance
    luminance = np.where(exterior, np.float32(np.median(luminance[inside])), luminance)   # sin saltos en el borde

    if p['limpieza'] > 0:
        # El radio escala con la resolución para que una vista previa reducida se parezca al resultado final.
        luminance = guided_filter(luminance, max(1, round(min(luminance.shape) / 360)), (.01 + .07 * p['limpieza']) ** 2)
    radius = max(2, int(round(p['escala'] * min(luminance.shape))))
    base = guided_filter(luminance, radius, p['bordes'] ** 2)
    detail = np.tanh(4. * (luminance - base)) / 4.          # limita picos sin tocar lo fino

    low, high = np.percentile(base[inside], [1, 99])
    span = max(float(high - low), .05)
    base_n = np.clip((base - low) / span, 0., 1.) if high - low > 1e-4 else np.full_like(base, .5)

    height = .5 + p['volumen'] * (base_n - .5) + p['detalle'] * detail / span
    height = curva_tonal(np.clip(height, 0., 1.), p['sombras'], p['luces'])
    if p['gamma'] != 1.:
        height = height ** p['gamma']
    if p['estirar']:                                   # que el punto más hondo llegue al negro y el más alto al blanco
        low, high = np.percentile(height[inside], [.5, 99.5])
        if high - low > 1e-4:
            height = np.clip((height - low) / (high - low), 0., 1.)
    if p['niveles']:
        height = np.round(height * (p['niveles'] - 1)) / (p['niveles'] - 1)
    height = np.where(exterior, np.float32(1.), height).astype(np.float32)
    return dict(height=height, exterior=exterior, params=p,
                cobertura=float(1. - height[inside].min()))   # fracción de la profundidad objetivo que se alcanza


def a_uint8(height):
    return np.round(np.clip(height, 0, 1) * 255).astype(np.uint8)


def a_uint16(height):
    return np.round(np.clip(height, 0, 1) * 65535).astype(np.uint16)


def vista_sombreada(height, azimut=315., elevacion=50., relieve=.06):
    """Render de sombreado para juzgar el relieve. Luz desde azimut (grados, 0 = arriba, horario)."""
    h = np.asarray(height, dtype=np.float32)
    z = h * float(relieve) * max(h.shape)                      # altura máxima en píxeles
    gy, gx = np.gradient(z)
    az, el = np.radians(azimut), np.radians(elevacion)
    light = np.array([np.cos(el) * np.sin(az), -np.cos(el) * np.cos(az), np.sin(el)], dtype=np.float32)
    shade = (-gx * light[0] - gy * light[1] + light[2]) / np.sqrt(gx * gx + gy * gy + 1.)
    return a_uint8(np.clip(shade, 0, 1))


# ------------------------------------------------------------------ archivos

def procesar_archivo(entrada, salida=None, png16=False, azimut=315., stl=None, **params):
    """stl: None o dict con ancho_mm, relieve_mm, base_mm, max_px para guardar tambien <foto>_relieve.stl."""
    entrada = Path(entrada)
    carpeta = Path(salida) if salida else entrada.parent
    carpeta.mkdir(parents=True, exist_ok=True)
    with Image.open(entrada) as image:
        resultado = foto_a_relieve(image, **params)
    base = carpeta / (entrada.stem + '_relieve')
    rutas = dict(mapa=str(base) + '.png', vista=str(base) + '_vista.png', ajustes=str(base) + '.json',
                 cobertura=resultado['cobertura'])
    Image.fromarray(a_uint8(resultado['height']), 'L').save(rutas['mapa'])
    Image.fromarray(vista_sombreada(resultado['height'], azimut), 'L').save(rutas['vista'])
    if png16:
        rutas['mapa16'] = str(base) + '_16bit.png'
        Image.fromarray(a_uint16(resultado['height'])).save(rutas['mapa16'])
    if stl is not None:
        from relieve_stl import guardar_stl
        info = guardar_stl(a_uint8(resultado['height']), str(base) + '.stl', **stl)
        rutas.update(stl=info['ruta'], stl_info=info)
    Path(rutas['ajustes']).write_text(json.dumps(dict(
        origen=entrada.name, convencion='blanco = sin tallar, negro = mas profundo', ajustes=resultado['params']),
        indent=2, ensure_ascii=False), encoding='utf-8')
    return rutas


def main(argv=None):
    parser = argparse.ArgumentParser(description='Foto -> mapa de relieve para tallado, sin IA.')
    parser.add_argument('foto')
    parser.add_argument('--preset', choices=sorted(PRESETS), help='punto de partida; el resto de opciones lo modifican')
    parser.add_argument('--volumen', type=float, help='0..1  cuánto de la forma amplia pasa a relieve (0,7)')
    parser.add_argument('--detalle', type=float, help='0..4  ganancia del detalle fino (1)')
    parser.add_argument('--escala', type=float, help='0,005..0,2  tamaño de la forma amplia, fracción del lado menor (0,04)')
    parser.add_argument('--bordes', type=float, help='0,01..0,5  contraste mínimo que cuenta como borde (0,08)')
    parser.add_argument('--limpieza', type=float, help='0..1  reducción de grano (0,5)')
    parser.add_argument('--sombras', type=float, help='0..1  eleva las sombras duras (0)')
    parser.add_argument('--luces', type=float, help='0..1  baja las luces quemadas (0)')
    parser.add_argument('--gamma', type=float, help='0,3..3  curva final (1)')
    parser.add_argument('--niveles', type=int, help='0 = continuo, 2..256 = terrazas')
    parser.add_argument('--estirar', action='store_true', default=None,
                        help='ajusta el rango para que el punto más hondo sea negro y el más alto blanco')
    parser.add_argument('--invertir', action='store_true', default=None, help='oscuro = alto')
    parser.add_argument('--quitar-blanco', dest='quitar_blanco', action='store_true', default=None,
                        help='el blanco que toca el borde no se talla')
    parser.add_argument('--circular', action='store_true', default=None, help='recorte circular')
    parser.add_argument('--max-lado', dest='max_lado', type=int, help='reduce si el lado mayor lo supera (2400; 0 = no)')
    parser.add_argument('--png16', action='store_true', help='guarda también PNG de 16 bits (el programa lee 8 bits)')
    parser.add_argument('--luz', type=float, default=315., help='azimut de la luz de la vista previa, grados (315)')
    parser.add_argument('--stl', action='store_true', help='guarda también <foto>_relieve.stl (sólido cerrado, blanco = alto)')
    parser.add_argument('--stl-ancho', dest='stl_ancho', type=float, default=100., help='ancho del STL en mm (100)')
    parser.add_argument('--stl-relieve', dest='stl_relieve', type=float, default=2., help='altura del relieve en mm (2)')
    parser.add_argument('--stl-base', dest='stl_base', type=float, default=1., help='grosor de la base en mm (1)')
    parser.add_argument('--stl-resolucion', dest='stl_resolucion', type=int, default=400, help='lado mayor de la malla en px (400)')
    parser.add_argument('--salida', help='carpeta de salida (por defecto, junto a la foto)')
    args = parser.parse_args(argv)
    params = dict(PRESETS.get(args.preset, {}))
    for key in DEFAULTS:
        value = getattr(args, key, None)
        if value is not None:
            params[key] = value
    try:
        stl = dict(ancho_mm=args.stl_ancho, relieve_mm=args.stl_relieve, base_mm=args.stl_base,
                   max_px=args.stl_resolucion) if args.stl else None
        rutas = procesar_archivo(args.foto, args.salida, png16=args.png16, azimut=args.luz, stl=stl, **params)
    except (OSError, ValueError) as error:
        print('ERROR:', error)
        return 1
    print('Mapa de relieve :', rutas['mapa'])
    print('Vista sombreada :', rutas['vista'])
    if 'stl' in rutas:
        i = rutas['stl_info']
        print(f"Modelo STL      : {rutas['stl']}  ({i['ancho_mm']:g} x {i['alto_mm']:.1f} x {i['alto_total_mm']:g} mm, {i['triangulos']:,} triángulos)")
    print('Blanco = sin tallar, negro = más profundo. Cárgalo como mapa de profundidad en 43AYE3.')
    print(f"El punto más hondo llega al {100 * rutas['cobertura']:.0f} % de la profundidad objetivo"
          + ('.' if rutas['cobertura'] > .97 else ' (usa --estirar para llegar al 100 %).'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
