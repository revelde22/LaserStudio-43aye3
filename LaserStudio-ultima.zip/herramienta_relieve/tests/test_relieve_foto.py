"""Pruebas de relieve_foto.py. Ejecutar:  python -m pytest tests -q   (desde la carpeta herramienta_relieve)."""
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import relieve_foto as rf  # noqa: E402


# ------------------------------------------------------------ utilidades

def gray_image(array):
    return Image.fromarray(np.clip(np.round(np.asarray(array) * 255), 0, 255).astype(np.uint8))


def lit_sphere(n=300, radius=110, noise=.04, background=1., seed=2):
    """Esfera con luz frontal: L = z/R (Lambert), por lo que la luminosidad ES la altura."""
    yy, xx = np.mgrid[:n, :n]
    r = np.hypot(xx - n / 2, yy - n / 2)
    inside = r < radius
    z = np.where(inside, np.sqrt(np.maximum(radius ** 2 - r ** 2, 0)) / radius, 0.)
    lum = np.where(inside, .15 + .8 * z, background)
    lum = lum + np.random.default_rng(seed).normal(0, noise, (n, n)) * inside
    return gray_image(lum), z, inside


# ------------------------------------------------------------ filtros

def brute_box(a, r):
    padded = np.pad(a, r, mode='edge')
    out = np.zeros_like(a, dtype=float)
    for y in range(a.shape[0]):
        for x in range(a.shape[1]):
            out[y, x] = padded[y:y + 2 * r + 1, x:x + 2 * r + 1].mean()
    return out


@pytest.mark.parametrize('radius', [1, 2, 3])
def test_box_filter_matches_brute_force(radius):
    a = np.random.default_rng(radius).random((17, 23))
    assert np.allclose(rf.box_filter(a, radius), brute_box(a, radius), atol=1e-5)
    assert np.array_equal(rf.box_filter(a, 0), a.astype(np.float32))


def test_guided_filter_keeps_constants_and_edges_but_removes_noise():
    assert np.allclose(rf.guided_filter(np.full((40, 40), .3), 3, .01), .3, atol=1e-5)
    rng = np.random.default_rng(0)
    step = np.where(np.arange(120)[None, :] < 60, .2, .8) * np.ones((120, 120))
    noisy = step + rng.normal(0, .02, step.shape)
    guided = rf.guided_filter(noisy, 4, .05 ** 2)
    box = rf.box_filter(noisy, 4)
    flat = (slice(10, 110), slice(10, 40))
    assert guided[flat].std() < noisy[flat].std() / 2                       # menos grano
    row = guided[60]
    width_guided = int(np.sum((row > .3) & (row < .7)))
    width_box = int(np.sum((box[60] > .3) & (box[60] < .7)))
    assert width_guided <= 2 and width_box >= 6                             # el borde sigue nítido


# ------------------------------------------------------------ núcleo

def test_lit_sphere_height_correlates_with_true_height():
    image, z, inside = lit_sphere()
    result = rf.foto_a_relieve(image, quitar_blanco=True)
    mask = ~result['exterior']
    assert abs(mask.sum() - inside.sum()) < .02 * inside.sum()             # recorta el fondo blanco
    assert np.corrcoef(result['height'][mask & inside], z[mask & inside])[0, 1] > .97


def test_cleaning_reduces_grain_without_losing_shape():
    image, z, inside = lit_sphere(noise=.06)
    clean = rf.foto_a_relieve(image, quitar_blanco=True, limpieza=.8, detalle=1)['height']
    raw = rf.foto_a_relieve(image, quitar_blanco=True, limpieza=0, detalle=1)['height']
    ring = (np.hypot(*np.mgrid[:300, :300] - np.array([150, 150])[:, None, None]) < 40)
    assert np.abs(np.diff(clean[ring], axis=0)).mean() < .7 * np.abs(np.diff(raw[ring], axis=0)).mean()


def test_invert_flips_the_relief():
    image, _, inside = lit_sphere()
    a = rf.foto_a_relieve(image, quitar_blanco=True)['height']
    b = rf.foto_a_relieve(image, quitar_blanco=True, invertir=True)['height']
    assert np.corrcoef(a[inside], b[inside])[0, 1] < -.95


def test_exterior_is_white_and_inner_white_is_kept():
    yy, xx = np.mgrid[:200, :200]
    lum = np.where(np.hypot(xx - 100, yy - 100) < 80, .3, 1.)
    lum[np.hypot(xx - 100, yy - 100) < 15] = 1.                              # agujero blanco interior
    result = rf.foto_a_relieve(gray_image(lum), quitar_blanco=True, limpieza=0)
    assert result['exterior'][5, 5] and not result['exterior'][100, 100]
    assert (result['height'][result['exterior']] == 1).all()


def test_levels_posterize_and_stay_monotonic():
    image, _, inside = lit_sphere()
    height = rf.foto_a_relieve(image, quitar_blanco=True, niveles=8)['height']
    assert len(np.unique(np.round(height[inside], 6))) <= 8
    assert set(np.round(np.unique(height) * 7, 5) % 1) <= {0.}


def test_volume_zero_flattens_the_broad_shape():
    image, _, inside = lit_sphere(noise=0)
    flat = rf.foto_a_relieve(image, quitar_blanco=True, volumen=0, detalle=0)['height']
    full = rf.foto_a_relieve(image, quitar_blanco=True, volumen=1, detalle=0)['height']
    assert flat[inside].std() < .05
    assert full[inside].std() > .15


def test_tone_curve_is_monotonic_and_bounded():
    h = np.linspace(0, 1, 2001, dtype=np.float32)
    for sombras in (0, .5, 1):
        for luces in (0, .5, 1):
            out = rf.curva_tonal(h, sombras, luces)
            assert (np.diff(out) >= -1e-6).all() and out.min() >= 0 and out.max() <= 1
    assert rf.curva_tonal(np.array([0.], np.float32), 1, 0)[0] > .4         # las sombras se elevan
    assert rf.curva_tonal(np.array([1.], np.float32), 0, 1)[0] < .6         # las luces bajan


def test_16bit_matches_8bit_and_16bit_input_is_scaled_not_clipped():
    image, _, _ = lit_sphere()
    height = rf.foto_a_relieve(image, quitar_blanco=True)['height']
    assert np.abs(rf.a_uint16(height).astype(float) / 257 - rf.a_uint8(height)).max() <= .51
    ramp = np.tile(np.linspace(0, 65535, 256).astype(np.uint16), (64, 1))
    rgba = rf.to_rgba(Image.fromarray(ramp))
    assert np.asarray(rgba)[0, :, 0][[0, 128, 255]].tolist() == [0, 128, 255]   # no se recorta a 255


def test_deterministic_and_input_not_modified():
    image, _, _ = lit_sphere()
    before = np.asarray(image).copy()
    a = rf.foto_a_relieve(image, quitar_blanco=True, **rf.PRESETS['retrato'])['height']
    b = rf.foto_a_relieve(image, quitar_blanco=True, **rf.PRESETS['retrato'])['height']
    assert np.array_equal(a, b) and np.array_equal(before, np.asarray(image))


@pytest.mark.parametrize('bad', [dict(volumen=1.5), dict(detalle=-1), dict(escala=0), dict(bordes=2),
                                 dict(niveles=1), dict(niveles=300), dict(max_lado=10), dict(gamma=float('nan')),
                                 dict(inventado=1)])
def test_invalid_parameters_are_rejected(bad):
    with pytest.raises(ValueError):
        rf.foto_a_relieve(gray_image(np.ones((50, 50)) * .5), **bad)


def test_only_background_is_rejected():
    with pytest.raises(ValueError, match='solo contiene fondo'):
        rf.foto_a_relieve(Image.new('RGB', (40, 40), 'white'), quitar_blanco=True)


def test_large_images_are_downscaled():
    image = Image.new('L', (900, 600), 128)
    assert rf.foto_a_relieve(image, max_lado=300)['height'].shape == (200, 300)


# ------------------------------------------------------------ vista sombreada

def test_hillshade_is_flat_on_planes_and_lit_from_upper_left():
    plane = np.full((60, 60), .5, np.float32)
    flat = rf.vista_sombreada(plane, elevacion=50)
    assert np.unique(flat).size == 1 and abs(int(flat[0, 0]) - round(np.sin(np.radians(50)) * 255)) <= 1
    n = 200
    yy, xx = np.mgrid[:n, :n]
    r = np.hypot(xx - 100, yy - 100)
    dome = np.where(r < 80, np.sqrt(np.maximum(1 - (r / 80) ** 2, 0)), 0).astype(np.float32)
    shaded = rf.vista_sombreada(dome, azimut=315)
    assert int(shaded[60, 60]) > int(shaded[140, 140]) + 40                   # arriba-izquierda más clara (int: uint8 se desborda)


# ------------------------------------------------------------ archivos y CLI

def test_cli_end_to_end_writes_files():
    image, _, _ = lit_sphere(n=160, radius=60)
    with tempfile.TemporaryDirectory() as tmp:
        source = Path(tmp) / 'foto.png'
        image.save(source)
        assert rf.main([str(source), '--preset', 'retrato', '--quitar-blanco', '--niveles', '12', '--png16']) == 0
        mapa = Path(tmp) / 'foto_relieve.png'
        assert mapa.exists() and (Path(tmp) / 'foto_relieve_vista.png').exists()
        with Image.open(mapa) as saved:
            assert saved.mode == 'L' and saved.size == (160, 160)
        with Image.open(Path(tmp) / 'foto_relieve_16bit.png') as wide:
            assert wide.mode in ('I;16', 'I')
        meta = json.loads((Path(tmp) / 'foto_relieve.json').read_text(encoding='utf-8'))
        assert meta['ajustes']['niveles'] == 12 and meta['ajustes']['sombras'] == rf.PRESETS['retrato']['sombras']
        assert rf.main([str(source), '--volumen', '9']) == 1                    # error -> código 1, sin traza
        assert rf.main([str(Path(tmp) / 'no_existe.png')]) == 1


def test_stretch_uses_the_full_range_and_coverage_reports_it():
    image, _, inside = lit_sphere(noise=0)
    plain = rf.foto_a_relieve(image, quitar_blanco=True, volumen=.3, detalle=0)
    stretched = rf.foto_a_relieve(image, quitar_blanco=True, volumen=.3, detalle=0, estirar=True)
    inner = ~stretched['exterior']
    low, high = np.percentile(stretched['height'][inner], [.5, 99.5])
    assert low < .02 and high > .98
    # Sin estirar, el mínimo es 0,5 + volumen*(0 - 0,5) = 0,35, o sea cobertura 0,65 exacta.
    assert abs(plain['cobertura'] - .65) < .02 and stretched['cobertura'] > .97


def test_result_is_consistent_across_resolutions():
    """La vista previa (reducida) y el resultado final (resolución completa) deben parecerse."""
    big, _, _ = lit_sphere(n=900, radius=330, noise=.03)
    small = big.resize((300, 300), Image.Resampling.LANCZOS)
    full = rf.foto_a_relieve(big, quitar_blanco=True, max_lado=0)['height']
    preview = rf.foto_a_relieve(small, quitar_blanco=True, max_lado=0)['height']
    reduced = np.asarray(Image.fromarray(full).resize((300, 300), Image.Resampling.BOX), dtype=np.float32)
    assert np.corrcoef(reduced.ravel(), preview.ravel())[0, 1] > .99
    assert np.abs(reduced - preview).mean() < .02


# ------------------------------------------------------------ exportar a STL

def leer_stl(ruta):
    datos = Path(ruta).read_bytes()
    import struct
    n = struct.unpack_from('<I', datos, 80)[0]
    assert len(datos) == 84 + 50 * n
    reg = np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')])
    return np.frombuffer(datos, dtype=reg, count=n, offset=84)['v'].astype(float)


def test_stl_is_closed_outward_and_has_requested_size():
    import relieve_stl as rs
    g = np.random.default_rng(3).integers(0, 256, (8, 12)).astype(np.uint8)
    verts, caras, alto = rs.malla_relieve(g, 60., 3., 1.5)
    dirigidas = {}
    for f in caras:
        for p, q in ((f[0], f[1]), (f[1], f[2]), (f[2], f[0])):
            dirigidas[(p, q)] = dirigidas.get((p, q), 0) + 1
    assert all(v == 1 for v in dirigidas.values()) and all((q, p) in dirigidas for p, q in dirigidas)
    a, b, c = verts[caras[:, 0]], verts[caras[:, 1]], verts[caras[:, 2]]
    assert np.einsum('ij,ij->i', a, np.cross(b, c)).sum() / 6 > 0                     # normales hacia fuera
    assert abs(alto - 60 * 8 / 12) < 1e-9 and verts[:, 0].max() == 60 and verts[:, 2].max() == pytest.approx(1.5 + 3 * float(g.max()) / 255)
    # blanco alto, negro bajo, fila 0 arriba
    g2 = np.full((6, 6), 128, np.uint8); g2[0, 0] = 255; g2[5, 5] = 0
    v2, _, _ = rs.malla_relieve(g2, 10., 2., 1.)
    assert v2[0][2] == pytest.approx(3.) and v2[0][1] == pytest.approx(10.) and v2[35][2] == pytest.approx(1.)


def test_stl_volume_matches_trapezoid_of_the_ramp():
    import relieve_stl as rs
    g = np.tile(np.linspace(0, 255, 41).round().astype(np.uint8), (20, 1))
    verts, caras, alto = rs.malla_relieve(g, 40., 5., 1.)
    a, b, c = verts[caras[:, 0]], verts[caras[:, 1]], verts[caras[:, 2]]
    z = 1 + 5 * g[0].astype(float) / 255.
    esperado = alto * float(np.sum((z[1:] + z[:-1]) / 2 * (40 / 40)))
    assert abs(np.einsum('ij,ij->i', a, np.cross(b, c)).sum() / 6 - esperado) < 1e-9 * esperado


@pytest.mark.parametrize('mal', [dict(ancho_mm=0), dict(relieve_mm=-1), dict(base_mm=0), dict(max_px=1), dict(inventado=2)])
def test_stl_rejects_bad_options(mal, tmp_path):
    import relieve_stl as rs
    with pytest.raises(ValueError):
        rs.guardar_stl(np.zeros((10, 10), np.uint8), tmp_path / 'x.stl', **mal)


def test_cli_writes_stl_that_matches_the_png_map(tmp_path):
    image, _, _ = lit_sphere(n=120, radius=45)
    foto = tmp_path / 'foto.png'
    image.save(foto)
    assert rf.main([str(foto), '--quitar-blanco', '--stl', '--stl-ancho', '50', '--stl-relieve', '4', '--stl-base', '2',
                    '--stl-resolucion', '120']) == 0
    tri = leer_stl(tmp_path / 'foto_relieve.stl')
    pts = tri.reshape(-1, 3)
    mapa = np.asarray(Image.open(tmp_path / 'foto_relieve.png')).astype(float)
    assert pts[:, 0].max() == pytest.approx(50, abs=1e-4) and pts[:, 2].min() == 0
    assert pts[:, 2].max() == pytest.approx(2 + 4 * mapa.max() / 255, abs=1e-4)           # base 2 + relieve 4 * gris/255
    # z de cada vertice superior = 2 + 4*gris/255: el centro de la esfera (mas claro) esta mas alto que su borde
    centro = pts[(np.abs(pts[:, 0] - 25) < .5) & (np.abs(pts[:, 1] - 25) < .5), 2].max()
    borde = pts[(np.abs(pts[:, 0] - 25) < .5) & (pts[:, 1] > 7.5) & (pts[:, 1] < 8.5), 2].max()   # cerca del borde de la esfera (fuera es fondo blanco = alto)
    assert centro > borde and centro == pytest.approx(2 + 4 * mapa[58:63, 58:63].max() / 255, abs=.02)
    assert rf.main([str(foto), '--stl', '--stl-ancho', '0']) == 1                       # error limpio
    assert not (tmp_path / 'foto_relieve.stl').read_bytes() == b''


def test_without_stl_flag_no_stl_is_written(tmp_path):
    image, _, _ = lit_sphere(n=80, radius=30)
    foto = tmp_path / 'f.png'
    image.save(foto)
    assert rf.main([str(foto)]) == 0 and not (tmp_path / 'f_relieve.stl').exists()
