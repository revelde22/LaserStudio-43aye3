"""Prueba de humo de la interfaz Qt, sin pantalla (QT_QPA_PLATFORM=offscreen). Se omite si no hay PySide6."""
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
pytest.importorskip('PySide6')
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication  # noqa: E402

import relieve_foto as rf  # noqa: E402
import relieve_foto_gui as gui  # noqa: E402

APP = QApplication.instance() or QApplication([])


def photo(path, n=900):
    yy, xx = np.mgrid[:n, :n]
    r = np.hypot(xx - n / 2, yy - n / 2)
    lum = np.where(r < n * .35, .2 + .7 * np.sqrt(np.maximum(1 - (r / (n * .35)) ** 2, 0)), 1.)
    Image.fromarray(np.clip(lum * 255, 0, 255).astype(np.uint8)).save(path)


@pytest.fixture()
def window():
    w = gui.Ventana()
    yield w
    w.temporizador.stop()
    w.deleteLater()


def test_open_preview_and_save_follow_the_controls(window):
    with tempfile.TemporaryDirectory() as tmp:
        source = Path(tmp) / 'foto.png'
        photo(source)
        assert window.abrir(str(source))
        assert max(window.reducida.size) == gui.LADO_VISTA_PREVIA              # la vista previa va reducida
        assert not window.pix_mapa.isNull() and not window.pix_vista.isNull()

        window.preset.setCurrentText('terrazas')                                # aplica valores y niveles
        assert window.niveles.value() == rf.PRESETS['terrazas']['niveles']
        assert abs(window.deslizadores['volumen'].valor() - rf.PRESETS['terrazas']['volumen']) < .002
        window.casillas['quitar_blanco'].setChecked(True)
        window.casillas['estirar'].setChecked(True)
        window.actualizar()
        assert 'profundidad objetivo' in window.aviso.text()

        params = window.parametros()
        assert params['niveles'] == 16 and params['quitar_blanco'] and params['estirar']
        out = Path(tmp) / 'salida'
        rutas = window.guardar(str(out), silencioso=True)
        with Image.open(rutas['mapa']) as saved:
            assert saved.mode == 'L' and saved.size == (900, 900)               # resolución completa, no la reducida
        expected = rf.a_uint8(rf.foto_a_relieve(Image.open(source), **params)['height'])
        assert np.array_equal(np.asarray(Image.open(rutas['mapa'])), expected)  # = lo que haría la línea de comandos


def test_sliders_map_to_declared_ranges(window):
    for name, (lo, hi) in rf.LIMITES.items():
        slider = window.deslizadores[name]
        slider.poner(lo)
        assert abs(slider.valor() - lo) < 1e-9
        slider.poner(hi)
        assert abs(slider.valor() - hi) < 1e-9


def test_bad_file_does_not_crash(window, monkeypatch):
    monkeypatch.setattr(gui.QMessageBox, 'warning', lambda *a, **k: None)
    assert window.abrir('/ruta/que/no/existe.png') is False


def test_save_with_stl_checkbox_writes_the_model(window):
    with tempfile.TemporaryDirectory() as tmp:
        source = Path(tmp) / 'foto.png'
        photo(source, 300)
        assert window.abrir(str(source))
        rutas = window.guardar(str(Path(tmp) / 'a'), silencioso=True)
        assert 'stl' not in rutas                                              # sin marcar, no hay STL
        window.stl_activo.setChecked(True)
        window.stl['ancho_mm'].setValue(80); window.stl['relieve_mm'].setValue(3); window.stl['base_mm'].setValue(1.5)
        rutas = window.guardar(str(Path(tmp) / 'b'), silencioso=True)
        info = rutas['stl_info']
        assert Path(rutas['stl']).exists() and info['ancho_mm'] == 80 and abs(info['alto_total_mm'] - 4.5) < 1e-9
