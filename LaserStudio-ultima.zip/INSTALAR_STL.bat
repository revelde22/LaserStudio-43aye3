@echo off
REM Instala "Importar STL como relieve" en 43AYE3. Deja esta carpeta dentro del proyecto.
REM   INSTALAR_STL.bat                       instala y prueba
REM   INSTALAR_STL.bat --revertir             deshace
REM   INSTALAR_STL.bat --proyecto "C:\ruta"    si no encuentra el proyecto
chcp 65001 >nul
cd /d "%~dp0"

set "PY="
for %%D in ("%~dp0..\work\.venv\Scripts" "%~dp0..\..\work\.venv\Scripts" "%~dp0..\..\..\work\.venv\Scripts") do (
    if not defined PY if exist "%%~D\python.exe" set "PY=%%~D\python.exe"
)
if not defined PY (
    where python >nul 2>nul
    if errorlevel 1 (
        echo No encuentro Python. Instala Python o coloca esta carpeta dentro del proyecto 43AYE3.
        pause
        exit /b 1
    )
    set "PY=python"
)
echo Usando: %PY%
echo.

"%PY%" "%~dp0instalar_stl.py" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo TODO CORRECTO.) else (echo Terminado con codigo %RC%. Lee los mensajes de arriba.)
pause
exit /b %RC%
