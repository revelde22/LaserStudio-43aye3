
from dataclasses import dataclass,field
from typing import Any

def _vector_image(path):
    """Rasteriza un vector para la vista de modo Image; no envia comandos."""
    from PySide6.QtGui import QImage,QPainter,QColor,QPen,QBrush
    import tempfile,hashlib
    from pathlib import Path
    r=path.boundingRect();scale=10.0
    width=max(1,min(3000,round(r.width()*scale)))
    height=max(1,min(3000,round(r.height()*scale)))
    img=QImage(width,height,QImage.Format.Format_ARGB32);img.fill(QColor("white"))
    painter=QPainter(img);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.scale(width/max(.001,r.width()),height/max(.001,r.height()))
    painter.translate(-r.left(),-r.top());painter.setPen(QPen(QColor("black"),0));painter.setBrush(QBrush(QColor("black")))
    painter.drawPath(path);painter.end()
    key=hashlib.sha1(str([(path.elementAt(i).x,path.elementAt(i).y) for i in range(path.elementCount())]).encode()).hexdigest()
    filename=Path(tempfile.gettempdir())/("43aye3_vector_image_"+key+".png")
    img.save(str(filename));return str(filename),r

def _raster_geometry(item,cut):
    """Geometria de Line/Fill/Offset Fill desde pixels oscuros del raster."""
    import cv2,numpy as np
    from PIL import Image
    from PySide6.QtCore import QPointF
    from PySide6.QtGui import QPainterPath
    source=item.preview_path if __import__('pathlib').Path(item.preview_path).exists() else item.original_source
    pixels=np.asarray(Image.open(source).convert("L"))
    h,w=pixels.shape
    if max(h,w)>1600:
        factor=1600/max(h,w)
        pixels=cv2.resize(pixels,(max(1,round(w*factor)),max(1,round(h*factor))),interpolation=cv2.INTER_AREA)
        h,w=pixels.shape
    limit=int(item.image_settings.get("threshold",128))
    mask=np.where(pixels<limit,255,0).astype(np.uint8)
    br=item.boundingRect()
    def scene(x,y):return item.mapToScene(QPointF(br.left()+x*br.width()/max(1,w),br.top()+y*br.height()/max(1,h)))
    if cut.mode=="Offset Fill" and cut.offset>0:
        px_per_mm=w/max(.001,item.sceneBoundingRect().width())
        radius=max(1,min(100,round(cut.offset*px_per_mm)))
        k=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+1,radius*2+1))
        mask=cv2.erode(mask,k)
    if cut.mode=="Line":
        contours,_=cv2.findContours(mask,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        path=QPainterPath()
        for contour in contours:
            if len(contour)<3:continue
            first=scene(float(contour[0][0][0]),float(contour[0][0][1]));path.moveTo(first)
            for point in contour[1:]:path.lineTo(scene(float(point[0][0]),float(point[0][1])))
            path.closeSubpath()
        return path
    spacing=max(1,round(max(.001,cut.interval)*h/max(.001,item.sceneBoundingRect().height())))
    lines=[]
    for y in range(0,h,spacing):
        row=mask[y]>0
        edges=np.diff(np.pad(row.astype(np.int8),(1,1)))
        for a,b in zip(np.flatnonzero(edges==1),np.flatnonzero(edges==-1)):
            if b>a:lines.append((scene(float(a),float(y)),scene(float(b),float(y))))
    return lines

@dataclass
class JobOperation:
    kind:str
    layer:int
    geometry:Any
    speed:float
    power:float
    frequency:float
    passes:int=1
    interval:float|None=None

@dataclass
class LaserJob:
    operations:list[JobOperation]=field(default_factory=list)
    bounds:tuple[float,float,float,float]=(0,0,0,0)
    warnings:list[str]=field(default_factory=list)

def from_scene(main,selected_only=False,use_cache=False):
    from laser_studio import GItem,RasterItem,GroupItem
    if selected_only:
        def leaves(item):
            if isinstance(item,GroupItem):
                for child in item.members():yield from leaves(child)
            else:yield item
        items=[leaf for selected in main.selected() for leaf in leaves(selected)]
    else:items=list(reversed(main.scene.items()))
    ops=[];bounds=None;warnings=[]
    cache=getattr(main,"_preview_geometry_cache",None) if use_cache else None
    for it in items:
        if not isinstance(it,(GItem,RasterItem)):continue
        layer=getattr(it,"layer",0);cut=main.cuts[layer]
        if not getattr(cut,"output",True):continue
        r=it.sceneBoundingRect()
        bounds=r if bounds is None else bounds.united(r)
        signature=None
        if cache is not None and isinstance(it,GItem):
            t=it.sceneTransform()
            signature=(layer,getattr(it,"_path_revision",0),t.m11(),t.m12(),t.m21(),t.m22(),t.dx(),t.dy(),
                       cut.mode,cut.speed,cut.power,cut.frequency,cut.passes,cut.interval,cut.angle,cut.cross,cut.offset)
            hit=cache.get(id(it))
            if hit is not None and hit[0] is it and hit[1]==signature:
                ops.extend(hit[2]);warnings.extend(hit[3]);continue
        before_ops=len(ops);before_warnings=len(warnings)
        if isinstance(it,GItem):
            sp=it.mapToScene(it.path())
            if cut.mode in ("Fill","Offset Fill"):
                from hatch_engine import horizontal_hatch
                if cut.mode=="Offset Fill" and getattr(cut,"offset",0)>0:
                    from PySide6.QtGui import QPainterPathStroker
                    stroke=QPainterPathStroker();stroke.setWidth(2*cut.offset)
                    sp=sp.subtracted(stroke.createStroke(sp))
                try:
                    hatch=horizontal_hatch(sp,getattr(cut,"interval",.1),getattr(cut,"angle",0.0))
                    hatch2=horizontal_hatch(sp,getattr(cut,"interval",.1),getattr(cut,"angle",0.0)+90) if hatch and getattr(cut,"cross",False) else None
                except ValueError as exc:
                    warnings.append(f"C{layer:02d}: {exc}. Se muestra el contorno hasta ajustar Fill.")
                    ops.append(JobOperation("Line",layer,it.mapToScene(it.path()),cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes))
                    continue
                if not hatch:
                    warnings.append(f"C{layer:02d}: {cut.mode} sin superficie interior; se muestra el contorno. Revisa si el dibujo esta cerrado o reduce el margen/intervalo.")
                    ops.append(JobOperation("Line",layer,it.mapToScene(it.path()),cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes))
                else:
                    ops.append(JobOperation(cut.mode,layer,hatch,cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,getattr(cut,"interval",.1)))
                if hatch2:
                    ops.append(JobOperation(cut.mode,layer,hatch2,cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,getattr(cut,"interval",.1)))
            elif cut.mode=="Image":
                preview,rect=_vector_image(sp)
                ops.append(JobOperation("Image",layer,{"preview":preview,"rect":(rect.x(),rect.y(),rect.width(),rect.height()),"settings":{"mode":"Vector raster"}},cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,cut.interval))
            else:
                ops.append(JobOperation(cut.mode,layer,sp,cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,getattr(cut,"interval",None)))
        else:
            if cut.mode in ("Line","Fill","Offset Fill"):
                geometry=_raster_geometry(it,cut)
                if geometry:
                    ops.append(JobOperation(cut.mode,layer,geometry,cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,cut.interval))
                else:
                    warnings.append(f"C{layer:02d}: {cut.mode} no encontro pixeles oscuros; se muestra la imagen. Ajusta Threshold/Invert o el margen.")
                    ops.append(JobOperation("Image",layer,{"preview":it.preview_path,"source":it.original_source,"rect":(r.x(),r.y(),r.width(),r.height()),"settings":dict(it.image_settings)},cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,it.image_settings.get("interval")))
            else:
                ops.append(JobOperation("Image",layer,{"preview":it.preview_path,"source":it.original_source,"rect":(r.x(),r.y(),r.width(),r.height()),
                    "settings":dict(it.image_settings)},cut.speed,cut.power,getattr(cut,"frequency",30),cut.passes,it.image_settings.get("interval")))
        if signature is not None:
            if len(cache)>512:cache.clear()
            cache[id(it)]=(it,signature,ops[before_ops:],warnings[before_warnings:])
    b=(bounds.x(),bounds.y(),bounds.width(),bounds.height()) if bounds else (0,0,0,0)
    return LaserJob(ops,b,warnings)
