from comfy_setup import ensure_cuda_runtime, ensure_depth, say
if __name__ == '__main__':
    try:
        ensure_cuda_runtime()
        python = ensure_depth()
        say('Reparación terminada. Entorno de profundidad: '+str(python))
    except Exception as exc:
        say('ERROR de reparación GPU: '+str(exc))
        raise SystemExit(1)
