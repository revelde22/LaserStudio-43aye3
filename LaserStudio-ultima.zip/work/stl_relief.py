"""STL -> mapa de relieve para tallado (43AYE3). Solo numpy + Pillow, sin IA.

Convencion de 43AYE3: BLANCO = sin tallar, NEGRO = mas profundo.
Aqui la parte mas ALTA del modelo (la que mira al laser) queda blanca y la mas baja, negra.

Pasos: leer STL (binario o ASCII) -> simplificar malla (agrupado de vertices) -> proyectar en la vista
elegida con un z-buffer -> simplificar el relieve (suavizado, niveles, profundidad) -> uint8.
"""
import re
import struct
from pathlib import Path

import numpy as np

VISTAS = ('superior', 'inferior', 'frontal', 'trasera', 'izquierda', 'derecha')
MAX_TRIANGULOS = 5_000_000


class ErrorSTL(ValueError):
    """Archivo STL ilegible o parametros no validos."""


# ------------------------------------------------------------------ lectura

def leer_stl(ruta):
    """Devuelve un array (n, 3, 3) float32 con los triangulos. Acepta STL binario y ASCII."""
    datos = Path(ruta).read_bytes()
    return leer_stl_bytes(datos)


def leer_stl_bytes(datos):
    if len(datos) >= 84:
        n = struct.unpack_from('<I', datos, 80)[0]
        if len(datos) == 84 + 50 * n:                      # tamano exacto => binario (aunque empiece por "solid")
            if n == 0:
                raise ErrorSTL('El STL no contiene triangulos.')
            if n > MAX_TRIANGULOS:
                raise ErrorSTL(f'El STL tiene {n} triangulos; el maximo admitido es {MAX_TRIANGULOS}.')
            registro = np.dtype([('normal', '<f4', 3), ('v', '<f4', (3, 3)), ('attr', '<u2')])
            triangulos = np.frombuffer(datos, dtype=registro, count=n, offset=84)['v'].astype(np.float32)
            return _validar(triangulos)
    texto = datos.decode('utf-8', errors='ignore')
    if 'vertex' not in texto:
        raise ErrorSTL('No parece un STL: ni binario con tamano coherente ni ASCII con vertices.')
    numeros = re.findall(r'vertex\s+(\S+)\s+(\S+)\s+(\S+)', texto)
    if len(numeros) % 3 or not numeros:
        raise ErrorSTL('STL ASCII incompleto: el numero de vertices no es multiplo de 3.')
    try:
        arr = np.array(numeros, dtype=np.float64)
    except ValueError as error:
        raise ErrorSTL(f'STL ASCII con numeros invalidos: {error}') from None
    return _validar(arr.reshape(-1, 3, 3).astype(np.float32))


def _validar(triangulos):
    if not np.isfinite(triangulos).all():
        raise ErrorSTL('El STL contiene coordenadas no finitas (NaN o infinito).')
    return np.ascontiguousarray(triangulos, dtype=np.float32)


def escribir_stl_binario(ruta, triangulos):
    """Utilidad (y para tests): escribe un STL binario."""
    t = np.asarray(triangulos, dtype=np.float32).reshape(-1, 3, 3)
    n = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    largo = np.linalg.norm(n, axis=1, keepdims=True)
    n = np.divide(n, largo, out=np.zeros_like(n), where=largo > 0)
    registro = np.zeros(len(t), dtype=np.dtype([('normal', '<f4', 3), ('v', '<f4', (3, 3)), ('attr', '<u2')]))
    registro['normal'], registro['v'] = n, t
    with open(ruta, 'wb') as f:
        f.write(b'43AYE3 stl'.ljust(80, b' '))
        f.write(struct.pack('<I', len(t)))
        f.write(registro.tobytes())


# ------------------------------------------------------------------ simplificar malla

def _agrupar(vertices, minimo, celda):
    """Agrupa vertices en celdas cubicas; devuelve (indice de grupo por vertice, centroides)."""
    celdas = np.floor((vertices - minimo) / celda).astype(np.int64)
    dims = celdas.max(axis=0) + 1
    clave = (celdas[:, 0] * dims[1] + celdas[:, 1]) * dims[2] + celdas[:, 2]
    _, inverso = np.unique(clave, return_inverse=True)
    inverso = inverso.reshape(-1)
    cuenta = np.bincount(inverso).astype(np.float64)
    centroides = np.stack([np.bincount(inverso, weights=vertices[:, k].astype(np.float64)) / cuenta for k in range(3)], axis=1)
    return inverso, centroides


def _triangulos_agrupados(triangulos, minimo, celda):
    vertices = triangulos.reshape(-1, 3)
    inverso, centroides = _agrupar(vertices, minimo, celda)
    idx = inverso.reshape(-1, 3)
    valido = (idx[:, 0] != idx[:, 1]) & (idx[:, 1] != idx[:, 2]) & (idx[:, 0] != idx[:, 2])
    idx = idx[valido]
    if len(idx):
        _, unicos = np.unique(np.sort(idx, axis=1), axis=0, return_index=True)
        idx = idx[np.sort(unicos)]
    return centroides[idx].astype(np.float32)


def simplificar_malla(triangulos, objetivo):
    """Reduce la malla a ~`objetivo` triangulos por agrupado de vertices en una rejilla 3D.

    Busca la celda mas pequena que deja como mucho `objetivo` triangulos. Si la malla ya cumple, no la toca.
    Los vertices de cada celda se funden en su centroide y se descartan los triangulos degenerados.
    """
    triangulos = np.asarray(triangulos, dtype=np.float32)
    objetivo = int(objetivo)
    if objetivo < 4:
        raise ErrorSTL('El objetivo de triangulos debe ser al menos 4.')
    if len(triangulos) <= objetivo:
        return triangulos
    vertices = triangulos.reshape(-1, 3)
    minimo = vertices.min(axis=0)
    extension = float((vertices.max(axis=0) - minimo).max())
    if extension <= 0:
        raise ErrorSTL('El modelo no tiene volumen (todos los puntos coinciden).')
    bajo, alto = extension / 8192., extension          # alto: todo en una celda => 0 triangulos
    mejor = None
    for _ in range(18):
        celda = (bajo * alto) ** .5                     # busqueda logaritmica
        resultado = _triangulos_agrupados(triangulos, minimo, celda)
        if len(resultado) <= objetivo:
            mejor, alto = resultado, celda
        else:
            bajo = celda
    if mejor is None or len(mejor) == 0:
        mejor = _triangulos_agrupados(triangulos, minimo, alto)
    if len(mejor) == 0:
        raise ErrorSTL('La simplificacion elimino todo el modelo; sube el numero de triangulos.')
    return mejor


# ------------------------------------------------------------------ vistas y rasterizado

def orientar(triangulos, vista):
    """Transforma a (u, v, h): u hacia la derecha, v hacia arriba, h hacia el observador."""
    if vista not in VISTAS:
        raise ErrorSTL(f'Vista desconocida: {vista!r}. Opciones: {", ".join(VISTAS)}.')
    x, y, z = triangulos[..., 0], triangulos[..., 1], triangulos[..., 2]
    u, v, h = {'superior': (x, y, z), 'inferior': (x, -y, -z), 'frontal': (x, z, -y),
               'trasera': (-x, z, y), 'izquierda': (-y, z, -x), 'derecha': (y, z, x)}[vista]
    return np.stack([u, v, h], axis=-1).astype(np.float64)


def rasterizar(tri_uvh, ancho_px, alto_px, umin, vmax, paso):
    """z-buffer ortografico: devuelve (altura, hay) con la h maxima por pixel. paso = mm por pixel."""
    altura = np.full((alto_px, ancho_px), -np.inf)
    px = (tri_uvh[..., 0] - umin) / paso                      # columnas en pixeles
    py = (vmax - tri_uvh[..., 1]) / paso                      # filas (v hacia arriba => fila 0 = arriba)
    h = tri_uvh[..., 2]
    area = (px[:, 1] - px[:, 0]) * (py[:, 2] - py[:, 0]) - (px[:, 2] - px[:, 0]) * (py[:, 1] - py[:, 0])
    x0 = np.clip(np.floor(px.min(axis=1) - .5).astype(np.int64), 0, ancho_px - 1)
    x1 = np.clip(np.ceil(px.max(axis=1) - .5).astype(np.int64), 0, ancho_px - 1)
    y0 = np.clip(np.floor(py.min(axis=1) - .5).astype(np.int64), 0, alto_px - 1)
    y1 = np.clip(np.ceil(py.max(axis=1) - .5).astype(np.int64), 0, alto_px - 1)
    for i in np.flatnonzero(np.abs(area) > 1e-12):
        xs = np.arange(x0[i], x1[i] + 1) + .5
        ys = (np.arange(y0[i], y1[i] + 1) + .5)[:, None]
        ax, ay = px[i, 0], py[i, 0]
        w1 = ((xs - ax) * (py[i, 2] - ay) - (px[i, 2] - ax) * (ys - ay)) / area[i]
        w2 = ((px[i, 1] - ax) * (ys - ay) - (xs - ax) * (py[i, 1] - ay)) / area[i]
        w0 = 1. - w1 - w2
        dentro = (w0 >= -1e-9) & (w1 >= -1e-9) & (w2 >= -1e-9)
        if not dentro.any():
            continue
        valor = np.where(dentro, w0 * h[i, 0] + w1 * h[i, 1] + w2 * h[i, 2], -np.inf)
        region = altura[y0[i]:y1[i] + 1, x0[i]:x1[i] + 1]
        np.maximum(region, valor, out=region)
    return altura, np.isfinite(altura)


# ------------------------------------------------------------------ simplificar relieve

def _desenfoque(a, radio):
    """Desenfoque gaussiano separable; radio en pixeles (sigma = radio/2)."""
    radio = int(radio)
    if radio <= 0:
        return a
    sigma = max(radio / 2., .5)
    k = np.exp(-.5 * (np.arange(-radio, radio + 1) / sigma) ** 2)
    k /= k.sum()
    for eje in (0, 1):
        p = np.pad(a, [(radio, radio) if e == eje else (0, 0) for e in (0, 1)], mode='edge')
        salida = np.zeros_like(a, dtype=np.float64)
        for j, peso in enumerate(k):
            salida += peso * (p[j:j + a.shape[0]] if eje == 0 else p[:, j:j + a.shape[1]])
        a = salida
    return a


def suavizar_relieve(altura, hay, radio):
    """Suaviza SOLO dentro del modelo (convolucion normalizada): el borde no se mezcla con el fondo."""
    if radio <= 0:
        return altura
    m = hay.astype(np.float64)
    num = _desenfoque(np.where(hay, altura, 0.), radio)
    den = _desenfoque(m, radio)
    return np.where(hay, num / np.maximum(den, 1e-12), 0.)


def cuantizar(t, niveles):
    """t en [0,1] -> `niveles` alturas distintas (2..256)."""
    if niveles < 2:
        return t
    return np.round(t * (niveles - 1)) / (niveles - 1)


# ------------------------------------------------------------------ tuberia completa

DEFAULTS = dict(vista='superior', ancho_mm=0., intervalo_mm=.1, max_px=1600, triangulos_max=0, suavizado=0, niveles=0,
                profundidad=1., invertir=False)


def stl_a_relieve(triangulos, **opciones):
    """STL (triangulos) -> mapa de relieve uint8 (blanco = sin tallar).

    vista         superior|inferior|frontal|trasera|izquierda|derecha
    ancho_mm      ancho final del modelo (0 = tamano original del STL); escala TAMBIEN la altura
    intervalo_mm  tamano de pixel deseado; se agranda si el mapa pasaria de `max_px`
    triangulos_max  simplifica la malla a este numero (0 = no simplificar)
    suavizado     radio en pixeles del suavizado del relieve (0 = nada)
    niveles       alturas distintas (0 = continuo, 2..256)
    profundidad   fraccion (0..1] del rango de grises que ocupa el relieve; 1 = hasta negro puro
    invertir      el punto mas ALTO pasa a ser el mas hondo
    """
    o = dict(DEFAULTS)
    desconocidas = set(opciones) - set(o)
    if desconocidas:
        raise ErrorSTL(f'Opciones desconocidas: {sorted(desconocidas)}')
    o.update(opciones)
    if not (0 < o['profundidad'] <= 1):
        raise ErrorSTL('profundidad debe estar en (0, 1].')
    if o['niveles'] not in (0,) and not (2 <= o['niveles'] <= 256):
        raise ErrorSTL('niveles debe ser 0 (continuo) o de 2 a 256.')
    if o['suavizado'] < 0 or o['suavizado'] > 60:
        raise ErrorSTL('suavizado debe estar entre 0 y 60 pixeles.')
    if o['intervalo_mm'] <= 0 or o['max_px'] < 16:
        raise ErrorSTL('intervalo_mm debe ser > 0 y max_px >= 16.')
    if o['ancho_mm'] < 0:
        raise ErrorSTL('ancho_mm no puede ser negativo.')

    antes = len(triangulos)
    if o['triangulos_max']:
        triangulos = simplificar_malla(triangulos, o['triangulos_max'])
    uvh = orientar(np.asarray(triangulos), o['vista'])
    umin, umax = uvh[..., 0].min(), uvh[..., 0].max()
    vmin, vmax = uvh[..., 1].min(), uvh[..., 1].max()
    ancho0, alto0 = umax - umin, vmax - vmin
    if ancho0 <= 0 or alto0 <= 0:
        raise ErrorSTL('El modelo es plano en esta vista; prueba otra vista.')
    escala = o['ancho_mm'] / ancho0 if o['ancho_mm'] else 1.
    uvh = uvh * escala
    umin, umax, vmin, vmax = umin * escala, umax * escala, vmin * escala, vmax * escala
    ancho_mm, alto_mm = umax - umin, vmax - vmin
    paso = max(o['intervalo_mm'], max(ancho_mm, alto_mm) / o['max_px'])
    ancho_px, alto_px = max(1, int(np.ceil(ancho_mm / paso))), max(1, int(np.ceil(alto_mm / paso)))
    altura, hay = rasterizar(uvh, ancho_px, alto_px, umin, vmax, paso)
    if not hay.any():
        raise ErrorSTL('No se pudo proyectar ningun pixel; el modelo es demasiado fino para esta resolucion.')
    hmin, hmax = float(altura[hay].min()), float(altura[hay].max())
    relieve_mm = hmax - hmin
    altura = np.where(hay, altura, hmin)
    altura = suavizar_relieve(altura, hay, o['suavizado'])
    if relieve_mm > 1e-12:
        t = np.clip((altura - hmin) / relieve_mm, 0, 1)          # 1 = mas alto
    else:
        t = np.ones_like(altura)                                  # modelo plano en altura: todo igual
    t = cuantizar(t, o['niveles'])
    if o['invertir']:
        t = 1. - t
    gris = 1. - (1. - t) * o['profundidad']                       # t=1 -> blanco; t=0 -> 1-profundidad
    gris = np.where(hay, gris, 1.)                                # fuera del modelo: blanco (sin tallar)
    img = np.clip(np.round(gris * 255), 0, 255).astype(np.uint8)
    return dict(gris=img, mascara=hay, ancho_mm=float(ancho_mm), alto_mm=float(alto_mm), relieve_mm=float(relieve_mm),
                paso_mm=float(paso), triangulos_antes=int(antes), triangulos_despues=int(len(triangulos)),
                tamano_px=(ancho_px, alto_px))


def guardar_png(resultado, ruta):
    from PIL import Image
    Image.fromarray(resultado['gris'], 'L').save(ruta)
    return ruta
