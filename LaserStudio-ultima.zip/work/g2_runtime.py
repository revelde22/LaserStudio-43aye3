from __future__ import annotations
from pathlib import Path

APP = Path(__file__).resolve().parent
RUNTIME = APP / 'G2_RUNTIME'
REQUIRED = ('SeaMark.dll','SeaDraw.dll','SeaBase.dll','libcodebar.dll','LPCodeAddin.dll')

def discover():
    if RUNTIME.is_dir() and all((RUNTIME / n).exists() for n in REQUIRED):
        return RUNTIME
    return None

def diagnostic():
    lines=[f'Runtime G2 nativo: {RUNTIME}']
    for n in REQUIRED + ('crypto3.dll','crypto5.0.dll','crypto6.0.dll','config/LmcPar.cfg','config/BslCAD.cfg','Plug/markcfg0'):
        p=RUNTIME / n
        lines.append(f'{n}: ' + ('OK' if p.exists() else 'NO'))
    lines.append('GLASER_EXE_USED=NO')
    return '\n'.join(lines)
