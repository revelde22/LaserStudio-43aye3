# Estado vigente: recuperación SDXL / español / contador / ETA

- Base más reciente recuperada: SDXL_ESPANOL_CONTADOR, 01/10/2026.
- Se recibió el fallo «NO MARCA» después de revisiones anteriores. El envío actual es compatible por bloque. La causa física aún no se ha identificado; usar RECOPILAR_MARCADO.bat.
- La sesión única experimental no está activa; no se afirma que el marcado ya sea fluido.
- Encuadre continuo hasta STOP conservado. Pendiente verificar trayectoria y luz roja en la G2.
- Profundidad en mm es objetivo desde una muestra medida. Cambiar pluma o intervalo requiere revisar la calibración.
- ETA aproximada por trayectorias y bloques. El SDK no informa progreso interno de repeticiones.
- Los modelos Klein/OPUS-MT se preparan en Windows. No se han ejecutado aquí con la RTX 5060.
- Los binarios propios se compilan en Windows; no se incluyen nuevas compilaciones nativas.
- Los PDF contienen revisión actual y referencia anterior; prevalece la revisión actual.

- Cambio posterior autorizado: FLUX.2 Klein 4B destilado FP8, texto/VAE CPU y resolución 768/512 para 8 GB.
