"""Functional document tools. These functions never send hardware commands."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QPainterPathStroker
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QTableWidget,QTableWidgetItem,
    QDialogButtonBox,QMessageBox,QInputDialog,QFormLayout,QSpinBox)


def offset_path(path, distance):
    if not distance:return path
    for polygon in path.toSubpathPolygons():
        if len(polygon)<4 or polygon[0] != polygon[-1]:
            raise ValueError('El contorno desplazado necesita formas cerradas.')
    stroker=QPainterPathStroker();stroker.setWidth(abs(distance)*2)
    stroker.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    border=stroker.createStroke(path)
    return path.united(border) if distance>0 else path.subtracted(border)


def offset_selected(w):
    from laser_studio import GItem
    selected=w.selected()
    if not selected or any(not isinstance(i,GItem) for i in selected):
        return QMessageBox.information(w,'Contorno desplazado','Selecciona vectores cerrados sin agrupar.')
    distance,ok=QInputDialog.getDouble(w,'Contorno desplazado','Distancia en mm: positiva exterior, negativa interior',.25,-100,100,3)
    if not ok or not distance:return
    try:
        paths=[offset_path(i.mapToScene(i.path()),distance) for i in selected]
        if any(p.isEmpty() for p in paths):raise ValueError('La distancia elimina una forma. Reduce el desplazamiento.')
    except ValueError as exc:return QMessageBox.warning(w,'Contorno desplazado',str(exc))
    w.scene.clearSelection()
    for original,path in zip(selected,paths):
        item=GItem(path,'offset');w.scene.addItem(item)
        layer=w.active_layer;w.active_layer=original.layer;w.apply_layer(item);w.active_layer=layer
        item.setSelected(True)
    w.changed=True;w.schedule_preview()


def edit_nodes(w):
    from laser_studio import GItem
    xs=w.selected()
    if len(xs)!=1 or not isinstance(xs[0],GItem):
        return QMessageBox.information(w,'Editar nodos','Selecciona un único vector. Desagrupa si es necesario.')
    item=xs[0];path=item.path()
    d=QDialog(w);d.setWindowTitle('Editar nodos · coordenadas locales en mm');d.resize(580,500)
    layout=QVBoxLayout(d);table=QTableWidget(path.elementCount(),3)
    table.setHorizontalHeaderLabels(['Tipo','X local (mm)','Y local (mm)'])
    names=['Inicio','Línea','Control curva','Dato curva']
    for n in range(path.elementCount()):
        e=path.elementAt(n);kind=e.type.value
        label=QTableWidgetItem(names[kind]);label.setFlags(label.flags() & ~Qt.ItemFlag.ItemIsEditable);table.setItem(n,0,label)
        table.setItem(n,1,QTableWidgetItem(f'{e.x:.6f}'));table.setItem(n,2,QTableWidgetItem(f'{e.y:.6f}'))
    layout.addWidget(table)
    bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);layout.addWidget(bb)
    bb.rejected.connect(d.reject)
    def apply():
        import math
        try:
            coords=[(float(table.item(n,1).text().replace(',','.')),float(table.item(n,2).text().replace(',','.'))) for n in range(table.rowCount())]
            if any(not math.isfinite(v) or abs(v)>100000 for row in coords for v in row):raise ValueError()
        except ValueError:return QMessageBox.warning(d,'Nodos','Introduce coordenadas finitas entre -100000 y 100000 mm.')
        for n,(x,y) in enumerate(coords):path.setElementPositionAt(n,x,y)
        item.setPath(path);item.update_handles();w.changed=True;w.schedule_preview();d.accept()
    bb.accepted.connect(apply);d.exec()


def optimization_dialog(w):
    d=QDialog(w);d.setWindowTitle('Orden de marcado por capas');form=QFormLayout(d)
    values=[]
    for c in w.cuts:
        spin=QSpinBox();spin.setRange(0,100000);spin.setValue(c.priority);values.append(spin)
        form.addRow(f'C{c.i:02d} · prioridad (menor primero)',spin)
    bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
    form.addRow(bb);bb.accepted.connect(d.accept);bb.rejected.connect(d.reject)
    if d.exec():
        for c,spin in zip(w.cuts,values):c.priority=spin.value()
        w.changed=True;w.schedule_preview()
