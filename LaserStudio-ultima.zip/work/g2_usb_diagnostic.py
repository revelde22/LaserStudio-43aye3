"""Comprobacion Windows PnP solamente. No abre el dispositivo ni carga DLL vendor."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess
import sys

REPORT = Path(__file__).resolve().parent / "G2_USB_DIAGNOSTICO.txt"
ID = re.compile(r"VID_04B4&PID_1004", re.I)
PS = r'''$ErrorActionPreference='Stop'; @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -match 'VID_04B4&PID_1004' } | Select-Object Name,Status,PNPDeviceID,Manufacturer,Service) | ConvertTo-Json -Compress'''


def classify(entries):
    if isinstance(entries, dict):
        entries = [entries]
    if not isinstance(entries, list):
        entries = []
    matches = [e for e in entries if isinstance(e, dict) and ID.search(str(e.get("PNPDeviceID", "")))]
    present = [e for e in matches if str(e.get("Status", "")).strip().upper() == "OK"]
    return matches, present


def diagnose(runner=subprocess.run, platform=os.name):
    lines = ["43AYE3 G2 USB - DIAGNOSTICO WINDOWS SIN EMISION", "EXPECTED_USB_ID=VID_04B4&PID_1004", "DEVICE_OPENED=NO", "LASER_COMMANDS_SENT=NO"]
    if platform != "nt":
        lines.append("RESULT=WINDOWS_REQUIRED")
        return 2, lines
    try:
        run = runner(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", PS], capture_output=True, text=True, errors="replace", timeout=20)
        if run.returncode:
            raise RuntimeError(f"PowerShell RC={run.returncode}: {run.stderr.strip()[:300]}")
        data = json.loads(run.stdout) if run.stdout.strip() else []
        matches, present = classify(data)
        lines += [f"PNP_MATCH_COUNT={len(matches)}", f"PNP_STATUS_OK_COUNT={len(present)}"]
        for n, entry in enumerate(matches):
            for key in ("Name", "Status", "PNPDeviceID", "Manufacturer", "Service"):
                lines.append(f"PNP_{n}_{key.upper()}={str(entry.get(key, '')).replace(chr(10), ' ')[:300]}")
        lines += ["USB_PNP_READY=" + ("YES" if present else "NO"), "RESULT=" + ("PNP_READY" if present else "PNP_NOT_READY")]
        return (0 if present else 3), lines
    except (OSError, subprocess.TimeoutExpired, RuntimeError, ValueError) as exc:
        lines += [f"DIAGNOSTIC_ERROR={exc}", "USB_PNP_READY=UNKNOWN", "RESULT=DIAGNOSTIC_FAILED"]
        return 4, lines


def main():
    code, lines = diagnose()
    output = "\n".join(lines) + "\n"
    REPORT.write_text(output, encoding="utf-8")
    print(output, end="")
    return code


if __name__ == "__main__":
    sys.exit(main())
