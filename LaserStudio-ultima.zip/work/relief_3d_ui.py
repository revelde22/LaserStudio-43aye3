"""Portable software mesh viewer: no OpenGL driver required."""
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt,QPointF,QTimer
from PySide6.QtGui import QPainter,QColor,QPolygonF
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QWidget,
    QLabel,QSlider,QDoubleSpinBox,QSpinBox,QPushButton,QFileDialog,QMessageBox)
from relief_geometry import load_height,mesh

class ReliefView(QWidget):
    def __init__(self,height,parent=None):
        super().__init__(parent);self.heightfield=height;self.setMinimumSize(500,360)
        self.yaw=0.;self.tilt=40.;self.light_angle=315.;self.exaggeration=5.
        self.width_mm=35.;self.height_mm=35.;self.relief_mm=.2;self.base_mm=1.
    def paintEvent(self,event):
        painter=QPainter(self);painter.fillRect(self.rect(),QColor('#20242b'))
        # Sampling only affects the preview. Export uses its own resolution.
        vertices,faces=mesh(self.heightfield,self.width_mm,self.height_mm,self.relief_mm*self.exaggeration,self.base_mm)
        vertices-=np.array([self.width_mm/2,self.height_mm/2,0],dtype=np.float32)
        yaw=np.deg2rad(self.yaw);tilt=np.deg2rad(self.tilt)
        rotate_z=np.array([[np.cos(yaw),-np.sin(yaw),0],[np.sin(yaw),np.cos(yaw),0],[0,0,1]])
        rotate_x=np.array([[1,0,0],[0,np.cos(tilt),-np.sin(tilt)],[0,np.sin(tilt),np.cos(tilt)]])
        points=vertices@(rotate_x@rotate_z).T;triangles=points[faces]
        normals=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
        normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-12)
        # Smooth lighting on the height surface; keep base edges geometrically sharp.
        dy,dx=np.gradient(self.heightfield*self.relief_mm*self.exaggeration,self.height_mm/(self.heightfield.shape[0]-1),self.width_mm/(self.heightfield.shape[1]-1))
        vertex_normals=np.stack([-dx,dy,np.ones_like(dx)],axis=-1).reshape(-1,3)
        vertex_normals/=np.linalg.norm(vertex_normals,axis=1,keepdims=True)
        vertex_normals=vertex_normals@(rotate_x@rotate_z).T
        top_count=2*(self.heightfield.shape[0]-1)*(self.heightfield.shape[1]-1)
        lighting_normals=normals.copy();lighting_normals[:top_count]=vertex_normals[faces[:top_count]].mean(axis=1)
        lighting_normals/=np.maximum(np.linalg.norm(lighting_normals,axis=1,keepdims=True),1e-12)
        angle=np.deg2rad(self.light_angle);light=np.array([.65*np.cos(angle),.65*np.sin(angle),.76]);light/=np.linalg.norm(light)
        brightness=.28+.72*np.maximum(0,lighting_normals@light)
        extent=np.ptp(points[:,:2],axis=0);scale=.9*min(self.width()/max(extent[0],1e-6),self.height()/max(extent[1],1e-6))
        projected=points[:,:2]*scale;projected[:,1]*=-1
        projected+=np.array([self.width()/2,self.height()/2])-np.mean([projected.min(axis=0),projected.max(axis=0)],axis=0)
        for face in np.argsort(triangles[:,:,2].mean(axis=1)):
            if normals[face,2]<=0:continue
            tone=int(235*brightness[face]);color=QColor(tone,tone,int(tone*.97))
            painter.setPen(color);painter.setBrush(color)
            painter.drawPolygon(QPolygonF([QPointF(float(x),float(y)) for x,y in projected[faces[face]]]))
        painter.setPen(QColor('white'));painter.drawText(12,22,'Vista 3D · la luz y la exageración solo cambian la previsualización')

class Relief3DDialog(QDialog):
    def __init__(self,path,width_mm,height_mm,relief_mm,parent=None):
        super().__init__(parent);self.path=path;self.job=None;self.setWindowTitle('Vista 3D del relieve');self.resize(820,680)
        layout=QVBoxLayout(self)
        note=QLabel('Vista 3D sencilla del relieve. Negro = más profundidad y blanco = menos. Esta ventana sirve para revisar el volumen antes de tallar.');note.setWordWrap(True);layout.addWidget(note)
        self.view=ReliefView(load_height(path,96));layout.addWidget(self.view,1)
        controls=QHBoxLayout();layout.addLayout(controls);left=QFormLayout();right=QFormLayout();controls.addLayout(left);controls.addLayout(right)
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.timeout.connect(self.update_view)
        self.sliders={}
        for title,key,lo,hi,value in [('Giro','yaw',-180,180,0),('Inclinación','tilt',0,80,40),('Dirección de luz','light_angle',0,360,315),('Exageración visual ×','exaggeration',1,100,10)]:
            slider=QSlider(Qt.Orientation.Horizontal);slider.setRange(lo,hi);slider.setValue(value);left.addRow(title,slider);self.sliders[key]=slider;slider.valueChanged.connect(self.schedule_view)
        self.fields={}
        for title,key,value,lo,hi in [('Ancho mm','width_mm',width_mm,1,1000),('Alto mm','height_mm',height_mm,1,1000),('Relieve máximo mm','relief_mm',relief_mm,.001,100),('Base STL mm','base_mm',1.,.01,100)]:
            field=QDoubleSpinBox();field.setRange(lo,hi);field.setDecimals(3);field.setValue(value);right.addRow(title,field);self.fields[key]=field;field.valueChanged.connect(self.schedule_view)
        self.resolution=QSpinBox();self.resolution.setRange(32,1024);self.resolution.setValue(512);right.addRow('Resolución máxima STL',self.resolution)
        self.status=QLabel('Comprueba el relieve girando la pieza. La profundidad final del láser depende del material y de las pasadas.');self.status.setWordWrap(True);layout.addWidget(self.status)
        row=QHBoxLayout();layout.addLayout(row)
        self.export_btn=QPushButton('Exportar STL…');self.export_btn.clicked.connect(self.export_stl);row.addWidget(self.export_btn)
        height_btn=QPushButton('Guardar mapa de alturas…');height_btn.clicked.connect(self.export_height);row.addWidget(height_btn)
        close=QPushButton('Cerrar');close.clicked.connect(self.reject);row.addWidget(close)
        self.update_view()
    def schedule_view(self,*args):self.timer.start(60)
    def update_view(self):
        for key,control in {**self.sliders,**self.fields}.items():setattr(self.view,key,control.value())
        self.view.update()
    def export_height(self):
        path,_=QFileDialog.getSaveFileName(self,'Mapa geométrico sin iluminación','relieve_alturas.png','PNG (*.png)')
        if path:
            try:
                from PIL import Image
                with Image.open(self.path) as image:image.save(path)
                self.status.setText('Mapa de alturas guardado: '+path)
            except Exception as exc:QMessageBox.warning(self,'Exportar mapa',str(exc))
    def export_stl(self):
        if self.job:return
        path,_=QFileDialog.getSaveFileName(self,'Exportar relieve cerrado','relieve.stl','STL (*.stl)')
        if not path:return
        from depth_preview_worker import PreviewWorker
        options=dict(task='export_stl',height_path=self.path,output=path,resolution=self.resolution.value(),**{key:field.value() for key,field in self.fields.items()})
        self.job=PreviewWorker(options,self);self.export_btn.setEnabled(False);self.status.setText('Construyendo STL en segundo plano…')
        self.job.result.connect(lambda result:self.status.setText('STL guardado: '+result['stl']+' · '+str(result['triangles'])+' triángulos · unidades mm.'))
        self.job.failed.connect(lambda error:self.status.setText('No se pudo exportar: '+error))
        self.job.finished.connect(self.export_finished);self.job.start()
    def export_finished(self):
        job=self.job;self.job=None;self.export_btn.setEnabled(True)
        if job:job.deleteLater()
    def done(self,result):
        if self.job:
            self.job.stop();self.job.wait(1500)
        super().done(result)
