from pathlib import Path
import struct,hashlib,re,json,subprocess,os
TARGETS=["SeaMark.dll","SeaBase.dll","SeaDraw.dll"]
INTEREST=("DoMark","DoMarkSyn","EmergenyStop","EnableInfiniteRedlightOut","EnableRedlightInfiniteOut","CloseAutoRedLight","GetLaserState","GetAllDevices","GetDeviceByID","GetLmcParByDev","AddLinesToFile","AddPointToFile","FillEntity","CheckCardRegisteStatusBeforeMark")
def pe_machine(path):
    b=Path(path).read_bytes()
    if b[:2]!=b"MZ":return None
    pe=struct.unpack_from("<I",b,0x3c)[0]
    if b[pe:pe+4]!=b"PE\0\0":return None
    machine=struct.unpack_from("<H",b,pe+4)[0]
    return {0x14c:"x86",0x8664:"x64"}.get(machine,hex(machine))
def printable_strings(path,minlen=5):
    b=Path(path).read_bytes()
    return [m.decode("latin1","ignore") for m in re.findall(rb"[\x20-\x7e]{%d,}"%minlen,b)]
def inspect(base="."):
    out={"host_bits":struct.calcsize("P")*8,"files":{}}
    base=Path(base)
    # El paquete limpio consulta los DLL de la instalación oficial sin copiarlos.
    if not all((base/n).exists() for n in TARGETS):
        vendor=Path(os.environ.get("G2PRO_VENDOR_DIR") or Path(os.environ.get("USERPROFILE",""))/"Documents"/"G2PRO")
        if all((vendor/n).exists() for n in TARGETS):base=vendor
    for n in TARGETS:
        p=Path(base)/n
        if not p.exists():continue
        ss=printable_strings(p);hits=sorted({x for x in ss for k in INTEREST if k in x})
        out["files"][n]={"machine":pe_machine(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"interesting_exports_or_symbols":hits[:120]}
    return out
def windows_pnp():
    if os.name!="nt":return []
    # SeaMark.dll comprueba 04B4:1004 antes de abrir USB. El INF incluye otros
    # modelos Cypress: el nombre genérico no identifica el G2 conectado.
    ps='$ErrorActionPreference="SilentlyContinue"; Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -match "VID_04B4&PID_1004" -and $_.Status -eq "OK" } | Select-Object Name,Status,PNPDeviceID,Manufacturer | ConvertTo-Json -Compress'
    cp=subprocess.run(["powershell","-NoProfile","-Command",ps],text=True,capture_output=True)
    try:
        x=json.loads(cp.stdout) if cp.stdout.strip() else []
        return x if isinstance(x,list) else [x]
    except:return []  # La consulta fallida nunca cuenta como dispositivo detectado.
if __name__=="__main__":
    r=inspect(Path(__file__).parent);r["pnp"]=windows_pnp();print(json.dumps(r,indent=2,ensure_ascii=False))
