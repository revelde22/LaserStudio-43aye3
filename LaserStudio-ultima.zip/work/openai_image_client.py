"""OpenAI Images API over fixed-host HTTPS; no SDK or ComfyUI required."""
import base64,http.client,io,json,math,uuid
from pathlib import Path
MODELS=('gpt-image-2.5-flare','gpt-image-2.5-sunburst','gpt-image-2','gpt-image-1.5','gpt-image-1-mini')
QUALITIES=('low','medium','high')
SIZES=('1024x1024','1536x1024','1024x1536')
def image_prompt(options):
 text=str(options['prompt']).strip()
 if not text:raise ValueError('Escribe una descripción.')
 if options.get('purpose')=='depth_regions':
  from regional_depth import REGIONS
  palette='; '.join(f'{i}: {name} = RGB{color}' for i,(name,color,_,_) in enumerate(REGIONS))
  return text+'\nCreate an exactly aligned semantic segmentation MASK of the reference, not an illustration or depth map. Preserve every silhouette, location, letter, facial feature and object boundary. Fill each region with ONE EXACT SOLID RGB color from this palette: '+palette+'. No shading, antialiasing, outlines, gradients, textures, or original pigment. Classify by geometry and occlusion order, NEVER by source color. Clothes and black neckties/scarves are body or raised-cloth regions, not background. Hair and helmets are head regions. Eyebrows are raised facial-detail regions ABOVE the forehead, not dark recesses; classify visible hair on top of the forehead as raised facial detail too. Facial skin and lips are face regions, irrespective of source shadows. Goggle lenses are part of the helmet/head, never background. All flag stripes belong to the same posterior plane. Camouflage does not change class. Letter glyphs and rims use the raised-letter color regardless of original ink. Outside the design alone uses white. Do not invent objects. Return ONLY the mask at identical composition and aspect ratio.'
 if options.get('purpose')=='depth':
  levels=int(options.get('plane_levels',0))
  instruction='\nInfer the three-dimensional shapes and occlusion order of the subject, then build a bas-relief REMOVAL-depth map. Preserve composition and contours. Ignore original pigment, brightness, albedo, patterns, texture, highlights and cast shadows when assigning depth. Black clothing is not deeper because it is black; white skin is not higher because it is white. Surfaces on the same geometric plane must have the same depth even if their colors differ. Foreground protruding surfaces require LESS removal (lighter); recessed and occluded surfaces require MORE removal (darker). Pure white means zero removal; black means deepest removal. Do not copy or desaturate the reference photograph. No rendered lighting, shadows, labels or decorative borders. This is an inferred relative bas-relief, not measured geometry or millimeters.'
  if levels:instruction+=f' Use {levels} discrete uniformly spaced grayscale depth levels for geometric planes. Flat areas must be uniform; do not add photographic shading. Do not assign a separate depth level to a color boundary without a geometric boundary.'
  else:instruction+=' Gray interpolates geometric depth smoothly, independently of the reference colors. Preserve broad rounded anatomical volume and fine geometric detail separately: forehead, cheeks, nose, chin, curved helmets, hair strands and cloth folds. Use diffuse source shading only as a clue to surface orientation; distinguish it from pigment and cast shadows. Reconstruct the continuous curved surface that would create those shades under lighting, never bake the shades into height. Do not flatten curved faces into constant planes. Eyebrows and hair must sit on the forehead surface with small raised thickness. No terracing.'
  if options.get('refine_from'):
   instruction+=' Image 1 is the original design; image 2 is the existing geometric height guide. Improve that height guide according to the requested correction. Preserve exact pixel alignment, contours, lettering and object positions. Do not redraw the artwork or render a shaded sculpture. Keep the current heights outside the requested region. Requested correction: '+str(options.get('correction',''))
   if int(options.get('correction_region',-1))>=0:
    from regional_depth import REGIONS
    instruction+=' The editable region is: '+REGIONS[int(options['correction_region'])][0]+'.'
  return text+instruction
 hints='Black and white engraving stencil, crisp black contours on pure white, no gradients.' if options['style'].startswith('Blanco') else 'Monochrome grayscale engraving artwork, white background, clear tones.'
 text+='\n'+hints+' Complete centered subject, no watermark.'
 if options.get('circular'):text+=' Circular medallion, all details inside the circle, generous white margin.'
 return text

def build_request(options):
 model=options.get('model',MODELS[0]);quality=options.get('quality','medium');size=options.get('api_size','1024x1024')
 if model not in MODELS or quality not in QUALITIES or size not in SIZES:raise ValueError('Modelo, calidad o tamaño OpenAI no compatibles con este cliente.')
 values=dict(model=model,prompt=image_prompt(options),n=1,size=size,quality=quality,output_format='png')
 references=[p for p in [options.get('reference'),*options.get('additional_references',[])] if p]
 if not references:return '/v1/images/generations',json.dumps(values,ensure_ascii=False).encode('utf-8'),'application/json'
 if model=='gpt-image-1.5':values['input_fidelity']='high'
 from PIL import Image,ImageOps
 boundary='43aye3_'+uuid.uuid4().hex;parts=[]
 for name,value in values.items():
  parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))
 for index,reference in enumerate(references):
  with Image.open(reference) as source:
   image=ImageOps.exif_transpose(source).convert('RGB');stream=io.BytesIO();image.save(stream,format='PNG');data=stream.getvalue()
  if len(data)>=50*1024*1024:raise ValueError('La referencia convertida supera 50 MB. Reduce su tamaño.')
  parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="image[]"; filename="reference_{index+1}.png"\r\nContent-Type: image/png\r\n\r\n').encode()+data+b'\r\n')
 parts.append(f'--{boundary}--\r\n'.encode());return '/v1/images/edits',b''.join(parts),'multipart/form-data; boundary='+boundary

def generate_image(options,api_key,connection_factory=http.client.HTTPSConnection):
 key=api_key.strip()
 if not key or any(c.isspace() for c in key):raise ValueError('Introduce una clave API válida, sin espacios.')
 route,body,content_type=build_request(options)
 connection=connection_factory('api.openai.com',timeout=180)
 try:
  # No automatic retry: a timeout may occur after the service accepts a paid request.
  connection.request('POST',route,body=body,headers={'Authorization':'Bearer '+key,'Content-Type':content_type})
  response=connection.getresponse();raw=response.read()
  try:result=json.loads(raw)
  except ValueError:raise RuntimeError('OpenAI devolvió una respuesta no válida. No se reintenta automáticamente.')
  if response.status>=300:
   messages={401:'Clave API incorrecta o revocada.',403:'El proyecto no tiene acceso al modelo; comprueba permisos y verificación de organización.',429:'Límite de uso o cuota de la API; comprueba facturación y límites.',400:'Solicitud rechazada; revisa modelo, referencia y descripción.'}
   detail=str(result.get('error',{}).get('message','')).replace(key,'[clave omitida]')[:500]
   raise RuntimeError(f'OpenAI HTTP {response.status}: '+messages.get(response.status,'Error del servicio.')+' '+detail)
  encoded=result.get('data',[{}])[0].get('b64_json') if result.get('data') else None
  if not encoded:raise RuntimeError('OpenAI terminó sin devolver una imagen base64.')
  image=base64.b64decode(encoded,validate=True)
  from PIL import Image
  with Image.open(io.BytesIO(image)) as check:check.verify()
  return image,result.get('usage')
 except (TimeoutError,OSError) as exc:
  raise RuntimeError('Se interrumpió la conexión con OpenAI. No se reintenta para evitar duplicar solicitudes. Revisa el uso de tu API antes de repetir.') from exc
 finally:connection.close()

def create_design(options,api_key,output_dir,notify=lambda message:None,connection_factory=http.client.HTTPSConnection):
 width=float(options['width_mm']);height=width if options.get('circular') else float(options['height_mm'])
 if not all(math.isfinite(x) and x>0 for x in (width,height)):raise ValueError('Dimensiones físicas no válidas.')
 notify('Enviando descripción'+(' y referencia' if options.get('reference') else '')+' a OpenAI…')
 data,usage=generate_image(options,api_key,connection_factory)
 notify('Preparando el diseño para grabado…')
 from comfy_design_client import prepare_artwork
 folder=Path(output_dir);folder.mkdir(parents=True,exist_ok=True);path=folder/('openai_'+uuid.uuid4().hex+'.png')
 prepare_artwork(data,path,options['style'],width,height,options.get('circular',False),options.get('border',True))
 metadata={k:options.get(k) for k in ('prompt','language','style','model','quality','api_size','reference','circular','border')}
 metadata.update(provider='openai',width_mm=width,height_mm=height,usage=usage,depth_kind='artwork_not_physical_measurement')
 path.with_suffix('.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
 return str(path)


def create_depth_map(options,api_key,output_dir,notify=lambda message:None,connection_factory=http.client.HTTPSConnection):
 options=dict(options,purpose='depth')
 if not options.get('reference'):raise ValueError('Selecciona una imagen de referencia para el mapa.')
 from PIL import Image
 regional=bool(options.get('geometric_regions'))
 refining=bool(options.get('refine_from'))
 if refining:
  if not Path(options['refine_from']).is_file():raise ValueError('Falta la guía que quieres corregir.')
  if not str(options.get('correction','')).strip():raise ValueError('Describe qué zona o forma debe corregir ChatGPT.')
  if regional and not options.get('region_mask'):raise ValueError('La corrección por regiones necesita la máscara existente.')
  options['additional_references']=[options['refine_from']]
 folder=Path(output_dir);folder.mkdir(parents=True,exist_ok=True)
 token=uuid.uuid4().hex
 path=folder/('raw_openai_'+token+'.png')
 region_usage=None;uncertain=0.;request_count=1
 if regional:
  from regional_depth import region_paths,default_settings,canonicalize_regions
  import shutil
  mask_path,config_path=region_paths(path)
  saved=options.get('region_mask')
  if saved and Path(saved).exists():
   shutil.copyfile(saved,mask_path)
   previous=options.get('region_config')
   settings=json.loads(Path(previous).read_text(encoding='utf-8')) if previous and Path(previous).exists() else default_settings()
  else:
   notify('Paso 1/2: separando objetos por geometría, sin colores ni sombras…')
   mask_options=dict(options,purpose='depth_regions',prompt='Segment the original composition into bas-relief height regions.')
   region_data,region_usage=generate_image(mask_options,api_key,connection_factory)
   request_count+=1
   with Image.open(io.BytesIO(region_data)) as segmented:segmented.convert('RGB').save(mask_path)
   uncertain=canonicalize_regions(mask_path)
   settings=default_settings()
  settings['reviewed']=bool(settings.get('reviewed',False))
  config_path.write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8')
  options['plane_levels']=0
 if refining and int(options.get('correction_region',-1))>=0:
  from regional_depth import decode_regions,REGIONS
  import numpy as np
  region=int(options['correction_region'])
  if not regional or not 0<=region<len(REGIONS):raise ValueError('Región de corrección no válida.')
  with Image.open(mask_path) as mask:labels,_=decode_regions(mask)
  if not np.any(labels==region):raise ValueError('Esa región no existe en la máscara. Píntala o selecciona otra antes de corregir.')
 notify('Corrigiendo la guía con la imagen original y el mapa actual (1 solicitud API)…' if refining else ('Paso 2/2: estimando volumen continuo y detalle por región…' if regional else 'Enviando referencia a OpenAI para estimar relieve relativo…'))
 data,usage=generate_image(options,api_key,connection_factory)
 from PIL import Image
 # The raw guide is retained separately from region masks and generated heights.
 with Image.open(io.BytesIO(data)) as image:
  guide=image.convert('L')
  if refining:
   import numpy as np
   with Image.open(options['refine_from']) as previous:old=previous.convert('L')
   guide=guide.resize(old.size,Image.Resampling.BILINEAR)
   region=int(options.get('correction_region',-1))
   if region>=0:
    from regional_depth import decode_regions
    with Image.open(mask_path) as mask:labels,_=decode_regions(mask.resize(old.size,Image.Resampling.NEAREST))
    corrected=np.asarray(guide);retained=np.array(old);retained[labels==region]=corrected[labels==region]
    guide=Image.fromarray(retained)
  guide.save(path)
 metadata={k:options.get(k) for k in ('prompt','model','quality','api_size','reference','plane_levels')}
 metadata.update(provider='openai',purpose='depth',usage=usage,region_usage=region_usage,geometric_regions=regional,uncertain_region_color_fraction=uncertain,depth_kind='relative_depth_not_measurement',refined_from=options.get('refine_from'),correction=options.get('correction'),correction_region=options.get('correction_region'),api_request_count=request_count)
 path.with_suffix('.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
 return str(path)
