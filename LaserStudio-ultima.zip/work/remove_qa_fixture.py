"""Remove only the exact non-executable QA placeholder from an older release."""
from pathlib import Path

def remove_fixture(base=None):
 path=Path(base or Path(__file__).resolve().parent)/'BSL_SDK/43AYE3_G2_SDK/43AYE3_SDK_SELFTEST.exe'
 marker=b'QA stub, removed after test'
 if path.exists() and path.stat().st_size==len(marker) and path.read_bytes()==marker:
  path.unlink();return True
 return False

if __name__=='__main__':
 if remove_fixture():print('Archivo de prueba retirado. El arranque recompilara el SDK necesario.')
