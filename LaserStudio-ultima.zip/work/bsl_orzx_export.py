"""Compatibilidad histórica: la exportación ORZX es ahora 100% nativa G2.
No busca, copia ni ejecuta GLaser/BSLAppSimple.
"""
from g2_native_orzx import NativeOrzxError, export_job as _native_export

class OrzxExportError(NativeOrzxError):
    pass

def export_job(main, filename, sdk_dir=None, selected_only=False):
    try:
        out, job, log = _native_export(main, filename, selected_only=selected_only)
        return out, "G2_RUNTIME/SeaBase.dll + SeaDraw.dll", job
    except NativeOrzxError as exc:
        raise OrzxExportError(str(exc)) from exc
