import sys, json, traceback
from laser_image_pipeline import prepare

def main():
    try:
        source=sys.argv[1]
        kwargs=json.loads(sys.argv[2])
        out=prepare(source,**kwargs)
        print(json.dumps({'ok':True,'out':out},ensure_ascii=False))
        return 0
    except Exception as exc:
        print(json.dumps({'ok':False,'error':str(exc),'trace':traceback.format_exc()},ensure_ascii=False))
        return 2
if __name__=='__main__':
    raise SystemExit(main())
