"""Offline Spanish prompts; translation uses CPU, leaving CUDA for ComfyUI."""
import json, os, subprocess, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
TARGET = BASE / 'AI_RUNTIME/models/opus_mt_es_en'

def translator_ready():
    try:
        saved = json.loads((TARGET / 'READY.json').read_text(encoding='utf-8'))
        python = BASE / 'AI_RUNTIME/comfy_venv/Scripts/python.exe'
        return saved.get('version') == 1 and saved.get('python') == str(python) and all(
            (TARGET / name).is_file() for name in ('config.json', 'tokenizer_config.json',
            'source.spm', 'target.spm', 'vocab.json', 'pytorch_model.bin'))
    except (OSError, ValueError):
        return False

def translate_prompt(prompt, notify=lambda message: None, cancelled=lambda: False):
    if cancelled():raise RuntimeError('Generación cancelada.')
    python = BASE / 'AI_RUNTIME/comfy_venv/Scripts/python.exe'
    if not python.exists() or not translator_ready():
        raise RuntimeError('Falta el traductor español. Pulsa Conectar / instalar lo que falte.')
    from comfy_setup import runtime_env
    notify('Traduciendo el prompt español localmente…')
    process = subprocess.Popen([str(python), str(Path(__file__).resolve()), '--translate'],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding='utf-8', env=runtime_env(),
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    try:
        payload = json.dumps({'prompt': prompt}, ensure_ascii=False)
        import time
        deadline = time.monotonic() + 180
        while True:
            if cancelled():raise RuntimeError('Traducción cancelada.')
            if time.monotonic() > deadline:raise RuntimeError('El traductor no respondió en 180 segundos. Consulta el registro IA.')
            try:
                output, errors = process.communicate(input=payload, timeout=.25)
                break
            except subprocess.TimeoutExpired:
                payload = None
        if process.returncode:raise RuntimeError('Falló la traducción española: ' + errors[-1800:])
        translated = json.loads(output)['prompt'].strip()
        if not translated:raise RuntimeError('El traductor devolvió un texto vacío.')
        notify('Prompt traducido: ' + translated)
        return translated
    finally:
        if process.poll() is None:process.kill();process.communicate()

def local_translation(prompt):
    import torch
    from transformers import MarianMTModel, MarianTokenizer
    torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
    tokenizer = MarianTokenizer.from_pretrained(str(TARGET), local_files_only=True)
    model = MarianMTModel.from_pretrained(str(TARGET), local_files_only=True).to('cpu').eval()
    tokens = tokenizer.encode(prompt, add_special_tokens=False)
    texts = []
    # Bound each input without silently truncating a long description.
    with torch.inference_mode():
        for offset in range(0, len(tokens), 240):
            chunk = tokenizer.decode(tokens[offset:offset + 240], skip_special_tokens=True)
            inputs = tokenizer(chunk, return_tensors='pt', truncation=False)
            outputs = model.generate(**inputs, max_new_tokens=480, num_beams=4)
            texts.append(tokenizer.decode(outputs[0], skip_special_tokens=True))
    return ' '.join(texts)

if __name__ == '__main__':
    try:
        request = json.load(sys.stdin)
        print(json.dumps({'prompt': local_translation(request['prompt'])}, ensure_ascii=False))
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
