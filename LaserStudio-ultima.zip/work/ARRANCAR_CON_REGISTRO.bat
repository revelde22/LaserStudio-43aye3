@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo 43AYE3 - arranque con registro de cierre
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" startup_safe.py
) else (
  echo No existe el entorno del editor. Ejecuta ARRANCAR_43AYE3.bat primero.
)
echo.
echo Registro: %~dp0CIERRE_43AYE3.log
echo Preparacion: %~dp0COMPROBACION_EDITOR.log
pause
