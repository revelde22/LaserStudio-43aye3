import json,sys
from pathlib import Path
from PySide6.QtCore import Qt,QProcess,Signal
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QListWidget,QListWidgetItem,QPushButton,QHBoxLayout,QPlainTextEdit,QProgressBar
from model_downloads import CATALOG,installed
class ModelManagerDialog(QDialog):
 completed=Signal()
 def __init__(self,parent=None):
  super().__init__(parent);self.setWindowTitle('Descargar otros modelos');self.resize(630,450);self.buffer='';self.failed=False
  layout=QVBoxLayout(self);note=QLabel('Marca los modelos que quieras descargar. FLUX.2 Klein 4B FP8 sigue siendo el modelo principal. Estos modelos usan el mismo servidor local con descarga de memoria. El consumo real de VRAM debe comprobarse en tu equipo.');note.setWordWrap(True);layout.addWidget(note)
  self.list=QListWidget();layout.addWidget(self.list)
  for key,row in CATALOG.items():
   item=QListWidgetItem(f'{row[0]} · {row[5]/1e9:.2f} GB · '+('archivo presente' if installed(key) else 'pendiente'));item.setData(Qt.ItemDataRole.UserRole,key);item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable);item.setCheckState(Qt.CheckState.Unchecked);self.list.addItem(item)
  self.progress=QProgressBar();layout.addWidget(self.progress);self.log=QPlainTextEdit();self.log.setReadOnly(True);layout.addWidget(self.log)
  row=QHBoxLayout();layout.addLayout(row);self.download=QPushButton('Descargar seleccionados');self.cancel=QPushButton('Cancelar descarga');self.cancel.setEnabled(False);row.addWidget(self.download);row.addWidget(self.cancel)
  self.process=QProcess(self);self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels);self.process.readyReadStandardOutput.connect(self.read);self.process.finished.connect(self.finished);self.process.errorOccurred.connect(self.error)
  self.download.clicked.connect(self.start);self.cancel.clicked.connect(self.stop)
 def running(self):return self.process.state()!=QProcess.ProcessState.NotRunning
 def start(self):
  keys=[self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count()) if self.list.item(i).checkState()==Qt.CheckState.Checked]
  if not keys:self.log.appendPlainText('Selecciona al menos un modelo.');return
  self.failed=False;self.buffer='';self.progress.setValue(0);self.download.setEnabled(False);self.list.setEnabled(False);self.cancel.setEnabled(True)
  self.process.start(sys.executable,['-u',str(Path(__file__).with_name('model_downloads.py')),*keys])
 def read(self):
  self.buffer+=bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace')
  while '\n' in self.buffer:
   line,self.buffer=self.buffer.split('\n',1)
   try:
    data=json.loads(line);self.log.appendPlainText(data.get('message',''))
    if 'percent' in data:self.progress.setValue(data['percent'])
   except ValueError:self.log.appendPlainText(line)
 def error(self,error):
  self.log.appendPlainText(self.process.errorString())
  if not self.running():self.finished(1)
 def finished(self,code,*args):
  self.read();self.download.setEnabled(True);self.list.setEnabled(True);self.cancel.setEnabled(False)
  self.log.appendPlainText('Descarga terminada. Modelos disponibles actualizados.' if code==0 and not self.failed else 'Descarga cancelada o fallida; puedes reintentar.')
  self.completed.emit()
 def stop(self):
  self.failed=True
  if self.running():self.process.kill();self.process.waitForFinished(3000)
 def reject(self):self.stop();super().reject()
 def closeEvent(self,event):self.stop();event.accept()
