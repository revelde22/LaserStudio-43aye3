"""Official FLUX.2 Klein 4B distilled FP8 graph, memory profile for 8GB GPUs."""
MODEL='flux-2-klein-4b-fp8.safetensors'
TEXT_ENCODER='qwen_3_4b.safetensors'
VAE='flux2-vae.safetensors'
REQUIRED_NODES=('UNETLoader','CLIPLoader','VAELoader','EmptyFlux2LatentImage','Flux2Scheduler','CFGGuider','SamplerCustomAdvanced','KSamplerSelect','RandomNoise','ConditioningZeroOut','ReferenceLatent','VAEDecodeTiled')
FILES=(
 ('diffusion_models',MODEL,'black-forest-labs/FLUX.2-klein-4b-fp8',MODEL),
 ('text_encoders',TEXT_ENCODER,'Comfy-Org/z_image_turbo','split_files/text_encoders/'+TEXT_ENCODER),
 ('vae',VAE,'Comfy-Org/flux2-dev','split_files/vae/'+VAE),
)

def graph(prompt,width,height,steps=4,reference=None,seed=0):
    # Matches the core nodes/links of Comfy-Org's distilled reference graph.
    nodes={
      '1':{'class_type':'UNETLoader','inputs':{'unet_name':MODEL,'weight_dtype':'default'}},
      '2':{'class_type':'CLIPLoader','inputs':{'clip_name':TEXT_ENCODER,'type':'flux2','device':'cpu'}},
      '3':{'class_type':'VAELoader','inputs':{'vae_name':VAE}},
      '4':{'class_type':'CLIPTextEncode','inputs':{'text':prompt,'clip':['2',0]}},
      '5':{'class_type':'ConditioningZeroOut','inputs':{'conditioning':['4',0]}},
      '6':{'class_type':'EmptyFlux2LatentImage','inputs':{'width':width,'height':height,'batch_size':1}},
      '7':{'class_type':'RandomNoise','inputs':{'noise_seed':seed}},
      '8':{'class_type':'KSamplerSelect','inputs':{'sampler_name':'euler'}},
      '9':{'class_type':'Flux2Scheduler','inputs':{'steps':steps,'width':width,'height':height}},
      '10':{'class_type':'CFGGuider','inputs':{'model':['1',0],'positive':['4',0],'negative':['5',0],'cfg':1.0}},
      '11':{'class_type':'SamplerCustomAdvanced','inputs':{'noise':['7',0],'guider':['10',0],'sampler':['8',0],'sigmas':['9',0],'latent_image':['6',0]}},
      '12':{'class_type':'VAEDecodeTiled','inputs':{'samples':['11',0],'vae':['3',0],'tile_size':256,'overlap':32}},
      '13':{'class_type':'SaveImage','inputs':{'images':['12',0],'filename_prefix':'43AYE3_klein'}}}
    if reference:
        nodes['14']={'class_type':'LoadImage','inputs':{'image':reference}}
        nodes['15']={'class_type':'ImageScale','inputs':{'image':['14',0],'upscale_method':'lanczos','width':width,'height':height,'crop':'disabled'}}
        nodes['16']={'class_type':'VAEEncode','inputs':{'pixels':['15',0],'vae':['3',0]}}
        nodes['17']={'class_type':'ReferenceLatent','inputs':{'conditioning':['4',0],'latent':['16',0]}}
        nodes['18']={'class_type':'ReferenceLatent','inputs':{'conditioning':['5',0],'latent':['16',0]}}
        nodes['10']['inputs'].update(positive=['17',0],negative=['18',0])
    return nodes
