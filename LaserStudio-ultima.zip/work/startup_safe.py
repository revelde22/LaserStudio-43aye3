"""Capture startup/Qt exceptions and native crashes without losing diagnostics."""
import datetime,faulthandler,json,os,platform,runpy,sys,traceback
from pathlib import Path

BASE=Path(__file__).resolve().parent
LOG=BASE/'CIERRE_43AYE3.log'

class Tee:
    def __init__(self,console,file):self.console=console;self.file=file
    def write(self,text):
        self.file.write(text);self.file.flush()
        if self.console:
            try:self.console.write(text);self.console.flush()
            except (OSError,UnicodeError):pass
        return len(text)
    def flush(self):
        self.file.flush()
        if self.console:self.console.flush()
    def isatty(self):return False
    @property
    def encoding(self):return 'utf-8'

def main():
    os.chdir(BASE)
    log=LOG.open('a',encoding='utf-8',errors='replace',buffering=1)
    out,err=sys.stdout,sys.stderr;previous_hook=sys.excepthook
    sys.stdout=Tee(out,log);sys.stderr=Tee(err,log)
    faulthandler.enable(file=log,all_threads=True)
    print('\n=== ARRANQUE '+datetime.datetime.now().isoformat(timespec='seconds')+' ===')
    print('Python:',sys.executable,sys.version.split()[0],platform.machine())
    print('Sistema:',platform.platform())
    print('Carpeta:',BASE)
    handling=False
    def hook(kind,value,tb):
        nonlocal handling
        traceback.print_exception(kind,value,tb)
        if handling:return
        handling=True
        try:
            from PySide6.QtWidgets import QApplication,QMessageBox
            from PySide6.QtCore import QThread
            app=QApplication.instance()
            if app and QThread.currentThread()==app.thread():
                box=QMessageBox(QMessageBox.Icon.Warning,'43AYE3 · error registrado',
                    'Se ha registrado un error. La ventana sigue abierta si el fallo es recuperable.\n\n'
                    +str(value)[:500]+'\n\nRegistro: '+str(LOG))
                box.setDetailedText(''.join(traceback.format_exception(kind,value,tb)))
                box.exec()
        finally:handling=False
    sys.excepthook=hook
    try:
        # Compile first so a partial/incorrect extraction produces a clear log.
        names=['laser_studio.py','depth_map_ui.py','depth_map_tools.py',
               'regional_depth.py','regional_depth_ui.py','openai_image_client.py',
               'depth_preview_cli.py','depth_preview_worker.py','relief_geometry.py','relief_3d_ui.py','right_accordion.py']
        for name in names:
            path=BASE/name
            if not path.exists():raise FileNotFoundError('Falta '+name+'. Extrae la actualización completa en la carpeta correcta.')
            compile(path.read_bytes(),str(path),'exec')
        import PySide6
        print('PySide6:',PySide6.__version__)
        print('Iniciando ventana principal…')
        runpy.run_path(str(BASE/'laser_studio.py'),run_name='__main__')
        print('La ventana principal terminó sin código de error.')
        return 0
    except SystemExit as exc:
        code=exc.code if isinstance(exc.code,int) else (0 if exc.code is None else 1)
        print('Código de salida:',code)
        return code
    except BaseException:
        traceback.print_exc()
        print('\nERROR DE ARRANQUE. Copia el registro:',LOG)
        return 1
    finally:
        faulthandler.disable();sys.excepthook=previous_hook
        sys.stdout=out;sys.stderr=err;log.close()

if __name__=='__main__':sys.exit(main())
