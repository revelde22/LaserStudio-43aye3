@echo off
setlocal
cd /d "%~dp0"
set "PY=py -3"
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
echo ============================================================
echo   43AYE3 - ACELERACION JARVIS / STUCKI / ATKINSON
 echo ============================================================
%PY% -c "import numba" >nul 2>&1
if %errorlevel%==0 (
  echo Numba ya esta instalado. No hay que hacer nada.
  pause
  exit /b 0
)
echo Instalando Numba en el entorno de 43AYE3...
%PY% -m pip install "numba>=0.60"
if errorlevel 1 (
  echo.
  echo AVISO: no se pudo instalar Numba. El programa seguira funcionando
  echo y procesara las imagenes en segundo plano para no bloquear la interfaz.
) else (
  echo.
  echo OK: aceleracion instalada.
)
pause
endlocal
