from PySide6.QtCore import Qt
from PySide6.QtWidgets import QToolBar,QStatusBar,QDockWidget

def install_classic_layout(w):
    w.setWindowTitle("43AYE3 Laser Studio Pro")
    w.setDockNestingEnabled(True)
    w.setStyleSheet("""
    QMainWindow,QWidget{background:#f3f3f3;color:#202020;font-size:9pt}
    QMenuBar,QMenu,QToolBar{background:#f7f7f7;color:#202020}
    QToolBar{spacing:2px;border:0}
    QDockWidget{font-weight:600}
    QDockWidget::title{background:#e8e8e8;padding:5px;border:1px solid #c8c8c8}
    QPushButton,QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit{background:white;color:#202020;border:1px solid #aaa;padding:3px}
    QTableWidget,QTreeWidget{background:white;color:#202020;gridline-color:#ccc}
    QTabBar::tab{background:#e4e4e4;padding:5px 9px;border:1px solid #bbb}
    QTabBar::tab:selected{background:white}
    """)

    # Original text-based tool rail (no copied proprietary icons/assets).
    left=QToolBar("Creation / Modifier",w);left.setOrientation(Qt.Orientation.Vertical);left.setMovable(True)
    w.addToolBar(Qt.ToolBarArea.LeftToolBarArea,left)
    left.hide()  # base Create toolbar is authoritative; avoid duplicate controls
    actions=[
      ("Select",lambda:w.tool("select")),("Line",lambda:w.tool("line")),
      ("Rectangle",lambda:w.tool("rect")),("Ellipse",lambda:w.tool("ellipse")),
      ("Delete",w.delete),("Duplicate",w.duplicate),("Preview",w.preview)]
    for name,fn in actions:left.addAction(name,fn)

    # Qt-native tabbed right-side docks: one visible panel at a time, maximizing workspace.
    docks=[]
    for attr in ("layers_dock","laser_dock","shape_dock","move_dock","library_dock","variable_dock","image_scale_dock","material_test_dock"):
        d=getattr(w,attr,None)
        if isinstance(d,QDockWidget):
            d.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable|
                          QDockWidget.DockWidgetFeature.DockWidgetMovable|
                          QDockWidget.DockWidgetFeature.DockWidgetFloatable)
            w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d)
            docks.append(d)
    if docks:
        base=docks[0]
        for d in docks[1:]:w.tabifyDockWidget(base,d)
        base.raise_()
        try:w.resizeDocks([base],[330],Qt.Orientation.Horizontal)
        except Exception:pass

    st=QStatusBar(w);st.showMessage("Ready · 110 × 110 mm · Gweike G2 Pro profile · backend not armed")
    w.setStatusBar(st)
