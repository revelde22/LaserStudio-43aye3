"""Local, idempotent ComfyUI installation in this release's work folder."""
import argparse,json,os,shutil,subprocess,sys,time,zipfile,struct,uuid
from pathlib import Path
from urllib.request import Request,urlopen
BASE=Path(__file__).resolve().parent
STATE=BASE/'AI_RUNTIME'
CONFIG=STATE/'comfy_config.json'
from flux_klein import MODEL
PROFILE='klein4b-fp8-cpu-enc-vae-768-v1'
MODEL_URL='https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors'
APP_PACKAGES={'PySide6':'PySide6','PIL':'Pillow','numpy':'numpy','cv2':'opencv-python','svgpathtools':'svgpathtools','shapely':'shapely'}

def runtime_env():
    env=os.environ.copy()
    for name,folder in {'PIP_CACHE_DIR':'cache/pip','HF_HOME':'cache/huggingface','TORCH_HOME':'cache/torch','CUDA_CACHE_PATH':'cache/cuda','TEMP':'tmp','TMP':'tmp'}.items():
        path=STATE/folder;path.mkdir(parents=True,exist_ok=True);env[name]=str(path)
    env['PYTHONUNBUFFERED']='1';return env

def say(message):
    print(message,flush=True)
    with (BASE/'COMFY_SETUP.log').open('a',encoding='utf-8') as log:log.write(message+'\n')

def run(command):
    say('Ejecutando: '+' '.join(map(str,command)))
    subprocess.run(list(map(str,command)),check=True,env=runtime_env())

def download(url,target):
    target=Path(target);target.parent.mkdir(parents=True,exist_ok=True);part=target.with_suffix(target.suffix+'.part')
    say('Descargando '+target.name)
    try:
        with urlopen(Request(url,headers={'User-Agent':'43AYE3-Laser-Studio'}),timeout=90) as response,part.open('wb') as output:
            size=int(response.headers.get('Content-Length',0));count=0;last=time.monotonic()
            while True:
                block=response.read(1024*1024)
                if not block:break
                output.write(block);count+=len(block)
                if time.monotonic()-last>5:
                    say(f'{target.name}: {count/1024**2:.0f} MB'+(f' de {size/1024**2:.0f} MB' if size else ''));last=time.monotonic()
            if size and count!=size:raise RuntimeError('Descarga incompleta: '+target.name)
        part.replace(target)
    except Exception:
        part.unlink(missing_ok=True);raise

def models_at(url):
    with urlopen(url+'/object_info',timeout=10) as response:info=json.load(response)
    from flux_klein import REQUIRED_NODES,TEXT_ENCODER,VAE
    if not all(name in info for name in REQUIRED_NODES):return []
    unets=info['UNETLoader']['input']['required']['unet_name'][0]
    encoders=info['CLIPLoader']['input']['required']['clip_name'][0]
    vaes=info['VAELoader']['input']['required']['vae_name'][0]
    return [MODEL] if MODEL in unets and TEXT_ENCODER in encoders and VAE in vaes else []


def ensure_venv(folder):
    python=folder/'Scripts/python.exe'
    config=folder/'pyvenv.cfg'
    if python.exists() and config.exists():
        home=next((line.split('=',1)[1].strip() for line in config.read_text().splitlines() if line.startswith('home =')),None)
        if home and os.path.normcase(str(Path(home)))!=os.path.normcase(str(Path(sys.base_prefix))):
            say('Recreando entorno local: '+folder.name);shutil.rmtree(folder)
    if not python.exists():run([sys.executable,'-m','venv',folder])
    return python

def ensure_app():
    python=ensure_venv(BASE/'.venv')
    missing=[]
    for module,package in APP_PACKAGES.items():
        if subprocess.run([str(python),'-c',f'import {module}'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:missing.append(package)
    if missing:run([python,'-m','pip','install',*missing])
    return python

def compatible_gpu(python):
    code="import torch; assert torch.cuda.is_available(); x=torch.ones((2,2),device='cuda'); y=x@x; torch.cuda.synchronize(); print(torch.cuda.get_device_name(0))"
    result=subprocess.run([str(python),'-c',code],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=runtime_env())
    if result.returncode:say('CUDA: comprobación fallida: '+result.stdout.strip()[-2500:])
    else:say('CUDA: comprobación correcta: '+result.stdout.strip())
    return result.returncode==0

def nvidia_present():
    command=shutil.which('nvidia-smi')
    if not command:
        candidate=Path(os.environ.get('SystemRoot','C:/Windows'))/'System32/nvidia-smi.exe'
        if candidate.exists():command=str(candidate)
    if not command:return False
    try:
        result=subprocess.run([command,'--query-gpu=name','--format=csv,noheader'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=15)
        if result.returncode==0 and result.stdout.strip():
            say('NVIDIA detectada: '+result.stdout.strip());return True
    except (OSError,subprocess.TimeoutExpired) as exc:say('No se pudo comprobar NVIDIA: '+str(exc))
    return False

def ensure_cuda_runtime():
    python=ensure_venv(STATE/'comfy_venv')
    if not compatible_gpu(python):
        say('Preparando PyTorch CUDA 12.8 en el entorno local; puede tardar en la primera instalación.')
        run([python,'-m','pip','install','--upgrade','--force-reinstall','torch','torchvision','torchaudio','--index-url','https://download.pytorch.org/whl/cu128'])
    if not compatible_gpu(python):raise RuntimeError('El entorno CUDA no supera la prueba real. Consulta COMFY_SETUP.log para ver el error.')
    return python

def valid_model(path,minimum_bytes=1024**3):
    try:
        size=path.stat().st_size
        if size<minimum_bytes:return False
        with path.open('rb') as handle:
            n=struct.unpack('<Q',handle.read(8))[0]
            if not 0<n<20*1024**2:return False
            headers=json.loads(handle.read(n))
        return max(value['data_offsets'][1] for key,value in headers.items() if key!='__metadata__')+8+n==size
    except Exception:return False

def ensure_model(root):
    from flux_klein import FILES
    # File sizes and LFS SHA256 from official model repositories, 01/10/2026.
    revisions=(
      ('5b4408e59397a4a37ccb46afe426d8ed86379441',4070624520,'97ed34fe0567e436200f2faee3939b88f2b5d99f8af2a4dc16532c4245c0ccb6'),
      ('6fc90a3b1b653e935a0d175e260736de25b84df5',8044982048,'6c671498573ac2f7a5501502ccce8d2b08ea6ca2f661c458e708f36b36edfc5a'),
      ('ed33133cd56476eac818c0943b6f9419b3e4a3a1',336213556,'d64f3a68e1cc4f9f4e29b6e0da38a0204fe9a49f2d4053f0ec1fa1ca02f9c4b5'))
    for (folder,name,repo,remote),(revision,size,sha) in zip(FILES,revisions):
        path=root/'models'/folder/name
        if not valid_model(path,1024*1024) or path.stat().st_size!=size:
            download(f'https://huggingface.co/{repo}/resolve/{revision}/{remote}',path)
            import hashlib
            with path.open('rb') as handle:digest=hashlib.file_digest(handle,'sha256').hexdigest()
            if digest!=sha:
                path.unlink(missing_ok=True)
                raise RuntimeError('El archivo no coincide con la fuente oficial: '+name)
        if not valid_model(path,1024*1024) or path.stat().st_size!=size:
            raise RuntimeError('Modelo incompleto: '+name)
    say('FLUX.2 Klein 4B FP8 preparado; Qwen en CPU, VAE en CPU, perfil 8 GB.')


def ensure_comfy_source(root):
    marker=root/'.43aye3_klein_source'
    if (root/'main.py').exists() and marker.exists():return
    say('Actualizando el código gestionado de ComfyUI para FLUX.2 Klein; modelos conservados.')
    archive=STATE/'comfy_klein_source.zip'
    download('https://github.com/Comfy-Org/ComfyUI/archive/refs/heads/master.zip',archive)
    temporary=STATE/('klein_source_'+uuid.uuid4().hex)
    try:
        with zipfile.ZipFile(archive) as z:z.extractall(temporary)
        source=temporary/'ComfyUI-master'
        if not (source/'main.py').exists():raise RuntimeError('Código ComfyUI no válido.')
        protected={'models','user','input','output','custom_nodes'}
        for name in protected:(root/name).mkdir(parents=True,exist_ok=True)
        for item in source.iterdir():
            if item.name in protected:continue
            target=root/item.name
            if item.is_dir():shutil.copytree(item,target,dirs_exist_ok=True)
            else:target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(item,target)
        marker.write_text(PROFILE,encoding='utf-8')
    finally:
        shutil.rmtree(temporary,ignore_errors=True);archive.unlink(missing_ok=True)


def ensure_translator(python):
    from prompt_spanish import translator_ready
    if translator_ready():
        check=subprocess.run([str(python),'-c','from transformers import MarianMTModel, MarianTokenizer; import sentencepiece, sacremoses'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=runtime_env())
        if check.returncode==0:return
    say('Preparando traducción local español → inglés (unos 315 MB).')
    run([python,'-m','pip','install','transformers>=4.45,<5','sentencepiece','sacremoses'])
    target=STATE/'models/opus_mt_es_en'
    files=('config.json','generation_config.json','tokenizer_config.json','source.spm','target.spm','vocab.json','pytorch_model.bin')
    for name in files:
        path=target/name
        minimum=300_000_000 if name=='pytorch_model.bin' else 10
        if not path.exists() or path.stat().st_size<minimum:
            download('https://huggingface.co/Helsinki-NLP/opus-mt-es-en/resolve/c96e2c5/'+name,path)
    # A real local load/inference verifies both files and dependencies before readiness.
    result=subprocess.run([str(python),str(BASE/'prompt_spanish.py'),'--translate'],
        input=json.dumps({'prompt':'Un águila con las alas abiertas.'}),text=True,encoding='utf-8',
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=runtime_env(),timeout=180)
    if result.returncode:raise RuntimeError('No se pudo preparar el traductor: '+result.stderr[-2000:])
    if not json.loads(result.stdout).get('prompt'):raise RuntimeError('El traductor no produjo texto.')
    (target/'READY.json').write_text(json.dumps({'python':str(python),'version':1}),encoding='utf-8')
    say('Traducción española comprobada y lista.')

def ensure_comfy(owner=None,prepare_only=False):
    STATE.mkdir(parents=True,exist_ok=True)
    root=STATE/'ComfyUI';python=STATE/'comfy_venv/Scripts/python.exe'
    if owner and CONFIG.exists():
        saved=json.loads(CONFIG.read_text(encoding='utf-8'))
        if saved.get('owner')==owner and saved.get('supervisor_pid'):
            try:
                if saved.get('profile')==PROFILE and MODEL in models_at(saved['url']):
                    ensure_translator(python);say('IA local ya preparada y activa.');return
            except Exception:pass
            stop_file=saved.get('stop_file')
            if stop_file and Path(stop_file).name==stop_file:
                (STATE/stop_file).touch()
                time.sleep(.5)
    ensure_comfy_source(root)
    python=ensure_cuda_runtime()
    run([python,'-m','pip','install','-r',root/'requirements.txt'])
    ensure_model(root)
    ensure_translator(python)
    if prepare_only:say('Dependencias IA preparadas en work/AI_RUNTIME.');return
    if not owner:raise RuntimeError('El servidor IA requiere el proceso propietario de Laser Studio.')
    # A free port for our own server avoids connecting to a different ComfyUI.
    import socket
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    url=f'http://127.0.0.1:{port}';token=uuid.uuid4().hex
    stop_path=STATE/f'stop_{token}.flag'
    config={'profile':PROFILE,'root':'ComfyUI','python':'comfy_venv/Scripts/python.exe','url':url,'owner':owner,'stop_file':stop_path.name,'token':token}
    log=(BASE/'COMFY_SERVER.log').open('ab')
    command=[sys.executable,str(BASE/'comfy_server_supervisor.py'),'--owner',str(owner),'--port',str(port),'--token',token]
    process=subprocess.Popen(command,cwd=str(BASE),stdout=log,stderr=subprocess.STDOUT,env=runtime_env(),
                             creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));log.close()
    config['supervisor_pid']=process.pid
    temporary=CONFIG.with_suffix('.tmp');temporary.write_text(json.dumps(config,indent=2),encoding='utf-8');temporary.replace(CONFIG)
    start=time.monotonic()
    while time.monotonic()-start<240:
        try:
            if MODEL in models_at(url):say('IA lista: '+url+' · modelo '+MODEL);return
        except Exception:pass
        if process.poll() is not None:raise RuntimeError('ComfyUI no pudo iniciar. Revisa COMFY_SERVER.log.')
        time.sleep(1)
    stop_path.touch();raise RuntimeError('ComfyUI no respondió. Revisa COMFY_SERVER.log y reintenta.')

def ensure_depth():
    # Reuse the CUDA runtime already installed for ComfyUI; do not download
    # a second copy of GPU PyTorch into the depth-only environment.
    gpu_python=STATE/'comfy_venv/Scripts/python.exe'
    if nvidia_present():
        try:gpu_python=ensure_cuda_runtime()
        except Exception as exc:say('Profundidad: no se pudo preparar CUDA; alternativa CPU. '+str(exc))
    if gpu_python.exists() and compatible_gpu(gpu_python):
        try:
            check=subprocess.run([str(gpu_python),'-c','from transformers import AutoImageProcessor, AutoModelForDepthEstimation; import PIL, safetensors'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if check.returncode:
                run([gpu_python,'-m','pip','install','transformers>=4.45,<5','Pillow','safetensors'])
            say('Profundidad: utilizando el entorno CUDA de ComfyUI.')
            return ensure_depth_model(gpu_python)
        except Exception as exc:
            say('Profundidad: GPU pendiente; utilizando CPU. '+str(exc))
    say('Profundidad: utilizando CPU porque no hay un entorno CUDA operativo. Consulta COMFY_SETUP.log.')
    return ensure_depth_cpu()

def ensure_depth_cpu():
    python=ensure_venv(STATE/'depth_venv')
    check=subprocess.run([str(python),'-c','import torch, transformers; from transformers import AutoImageProcessor, AutoModelForDepthEstimation'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    if check.returncode:
        run([python,'-m','pip','install','torch','torchvision','--index-url','https://download.pytorch.org/whl/cpu'])
        run([python,'-m','pip','install','transformers>=4.45,<5','Pillow','safetensors'])
    return ensure_depth_model(python)

def ensure_depth_model(python):
    target=STATE/'models/depth_anything_v2_small'
    base='https://huggingface.co/depth-anything/Depth-Anything-V2-Small-hf/resolve/main/'
    for filename in ('config.json','preprocessor_config.json','model.safetensors'):
        path=target/filename
        valid=valid_model(path,1024*1024) if filename.endswith('.safetensors') else path.exists()
        if not valid:download(base+filename,path)
    if not valid_model(target/'model.safetensors',1024*1024):raise RuntimeError('El modelo de profundidad está incompleto.')
    say('Modelo de profundidad IA preparado en work/AI_RUNTIME.')
    return python

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--comfy-only',action='store_true');parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--owner',type=int);args=parser.parse_args()
    if os.name!='nt':raise RuntimeError('La instalación automática está preparada para Windows.')
    if not args.comfy_only:ensure_app()
    if not args.prepare_only:
        ensure_comfy(owner=args.owner)
        try:ensure_depth()
        except Exception as e:say('Mapa de profundidad pendiente de preparar: '+str(e))
if __name__=='__main__':
    try:main()
    except Exception as e:say('ERROR: '+str(e));sys.exit(1)
