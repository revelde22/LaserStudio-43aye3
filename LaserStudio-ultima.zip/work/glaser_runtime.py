def ensure_runtime(*args, **kwargs):
    raise RuntimeError('GLaser está desactivado. 43AYE3 usa G2_RUNTIME y ORZX NATIVO.')
