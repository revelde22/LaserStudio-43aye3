"""Key received through stdin only, never argv, config, sidecar or logs."""
import json,sys
from pathlib import Path
from openai_image_client import create_design,create_depth_map
def emit(**event):print(json.dumps(event,ensure_ascii=False),flush=True)
def main():
 key=''
 try:
  payload=json.load(sys.stdin);key=payload.pop('api_key','');options=payload['options']
  depth=options.get('purpose')=='depth'
  path=(create_depth_map if depth else create_design)(options,key,Path(__file__).resolve().parent/('DEPTH_MAPS' if depth else 'AI_DESIGNS'),lambda message:emit(status=message));emit(result=path)
 except Exception as exc:
  message=str(exc)
  if key:message=message.replace(key,'[clave omitida]')
  emit(error=message);return 1
 return 0
if __name__=='__main__':sys.exit(main())
