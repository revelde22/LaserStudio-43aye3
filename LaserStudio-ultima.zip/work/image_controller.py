
from pathlib import Path
from PySide6.QtCore import Qt,QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QDockWidget,QWidget,QFormLayout,QHBoxLayout,QDoubleSpinBox,
 QSlider,QComboBox,QCheckBox,QPushButton,QLabel,QGroupBox,QVBoxLayout,QMessageBox,QScrollArea)
from laser_image_pipeline import prepare,interval_from_dpi,MODES,acceleration_name
from image_async import submit_prepare
from image_marking_mode import apply_image_settings, raster_grid
from image_display_utils import load_display_pixmap, replace_pixmap_keep_scene_bounds

def install_image_controller(w):
    from laser_studio import RasterItem

    # Hide inherited duplicate image docks. One panel = one source of truth.
    for name in ("image_scale_dock","live_image_dock"):
        d=getattr(w,name,None)
        if d:d.hide()

    dock=QDockWidget("Image / Scale",w)
    outer=QWidget();v=QVBoxLayout(outer)

    sizebox=QGroupBox("Size / Position");sf=QFormLayout(sizebox)
    def ds(lo=-10000,hi=10000,dec=3):
        x=QDoubleSpinBox();x.setRange(lo,hi);x.setDecimals(dec);x.setSuffix(" mm");return x
    xpos=ds();ypos=ds();width=ds(0.01,10000);height=ds(0.01,10000)
    lock=QCheckBox("Keep aspect ratio");lock.setChecked(True)
    sf.addRow("X",xpos);sf.addRow("Y",ypos);sf.addRow("Width",width);sf.addRow("Height",height);sf.addRow(lock)
    v.addWidget(sizebox)

    imgbox=QGroupBox("Image processing — live");f=QFormLayout(imgbox)
    mode=QComboBox();mode.addItems(MODES)
    def sl(lo,hi,val):
        x=QSlider(Qt.Orientation.Horizontal);x.setRange(lo,hi);x.setValue(val);x.setTracking(True);return x
    brightness=sl(-100,100,0);darkness=sl(0,100,0);contrast=sl(-100,100,0)
    gamma=sl(10,300,100);sharpen=sl(0,100,0);threshold=sl(0,255,128)
    dpi=QDoubleSpinBox();dpi.setRange(25,5000);dpi.setDecimals(0);dpi.setValue(254);dpi.setSuffix(" DPI")
    interval=QDoubleSpinBox();interval.setRange(0.005,1.000);interval.setDecimals(4);interval.setSingleStep(0.005);interval.setValue(0.1000);interval.setSuffix(" mm")
    invert=QCheckBox("Reverso · invertir blanco y negro (negativo)")
    invert_button=QPushButton("Invertir colores de la imagen")
    invert_button.setToolTip("Cambia blanco por negro en la imagen seleccionada; vuelve a pulsar para restaurarla")
    status=QLabel("Select one image");status.setWordWrap(True)
    slider_labels={}
    def slider_row(q,fmt=lambda v:str(v)):
        box=QWidget();h=QHBoxLayout(box);h.setContentsMargins(0,0,0,0);h.addWidget(q,1)
        lab=QLabel(fmt(q.value()));lab.setMinimumWidth(44);h.addWidget(lab);slider_labels[q]=lab
        q.valueChanged.connect(lambda v,q=q,lab=lab,fmt=fmt:lab.setText(fmt(v)))
        return box
    rows=[("Mode",mode),("Brightness",slider_row(brightness)),("Darkness",slider_row(darkness)),
          ("Contrast",slider_row(contrast)),("Gamma",slider_row(gamma,lambda v:f"{v/100:.2f}")),
          ("Sharpen",slider_row(sharpen)),("Threshold",slider_row(threshold)),
          ("Resolution",dpi),("Line interval",interval)]
    for n,q in rows:f.addRow(n,q)
    f.addRow(invert);f.addRow(invert_button)
    reset=QPushButton("Reset image")
    export_img=QPushButton("EXPORTAR IMAGEN PROCESADA")
    export_img.setToolTip("Exporta la imagen tal como se ve ahora (Jarvis, Stucki, Atkinson, Floyd, etc.) sin usar GLaser ni SDK BSL")
    f.addRow(reset);f.addRow(export_img);f.addRow(status);v.addWidget(imgbox)
    scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QScrollArea.Shape.NoFrame);scroll.setWidget(outer)
    dock.setWidget(scroll);dock.setMinimumWidth(300);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,dock);w.image_dock=dock
    if getattr(w,"layers_dock",None):w.tabifyDockWidget(w.layers_dock,dock)
    dock.raise_()

    busy={"v":False}; timer=QTimer(w);timer.setSingleShot(True);timer.setInterval(140)
    render_seq={"n":0}; render_tasks={}; render_requests={}

    active={"item":None}
    def current():
        try:
            xs=[x for x in w.scene.selectedItems() if isinstance(x,RasterItem)]
            if len(xs)==1:
                active["item"]=xs[0]
                return xs[0]
            # If the image lost selection while the user is working in the dock,
            # keep editing the last active raster.
            it=active.get("item")
            if it is not None and it.scene() is w.scene:
                return it
            # LightBurn-like convenience: when the document contains exactly one
            # image, Image controls target it even if selection is temporarily 0.
            rasters=[x for x in w.scene.items() if isinstance(x,RasterItem)]
            if len(rasters)==1:
                active["item"]=rasters[0]
                return rasters[0]
        except RuntimeError:
            return None
        return None

    def scene_mm(it):
        r=it.sceneBoundingRect()
        return r.x(),r.y(),r.width(),r.height()

    def load_selection():
        try:
            it=current()
            busy["v"]=True
            if it:
                x,y,ww,hh=scene_mm(it);xpos.setValue(x);ypos.setValue(y);width.setValue(ww);height.setValue(hh)
                st=getattr(it,"image_settings",{})
                mode.setCurrentText(st.get("mode","Grayscale"));brightness.setValue(st.get("brightness",0));darkness.setValue(st.get("darkness",0))
                contrast.setValue(st.get("contrast",0));gamma.setValue(round(st.get("gamma",1)*100));sharpen.setValue(st.get("sharpen",0))
                threshold.setValue(st.get("threshold",128));dpi.setValue(st.get("dpi",254));interval.setValue(st.get("interval",interval_from_dpi(dpi.value())))
                invert.setChecked(st.get("invert",False));status.setText(Path(it.original_source).name)
            else:
                status.setText("Select an image to edit")
        except RuntimeError:
            return
        finally:
            busy["v"]=False

    def apply_geometry(*_):
        if busy["v"]:return
        it=current()
        if not it:return
        br=it.boundingRect()
        if br.width()<=0 or br.height()<=0:return
        # independent X/Y transform; preserve rotation and position without cumulative scaling.
        targetw=max(.01,width.value()); targeth=max(.01,height.value())
        if lock.isChecked():
            ratio=br.width()/br.height()
            sender=w.sender()
            if sender is width:
                busy["v"]=True;height.setValue(targetw/ratio);targeth=height.value();busy["v"]=False
            elif sender is height:
                busy["v"]=True;width.setValue(targeth*ratio);targetw=width.value();busy["v"]=False
        from PySide6.QtGui import QTransform
        # Canonical transform: do not combine the legacy item scale with the new matrix.
        # Otherwise a 0.625 legacy scale turns requested 42 mm into 26.25 mm.
        it.setScale(1.0)
        tr=QTransform();tr.scale(targetw/br.width(),targeth/br.height());it.setTransform(tr,False)
        r=it.sceneBoundingRect();it.moveBy(xpos.value()-r.x(),ypos.value()-r.y())
        it.update_handles()
        if hasattr(w,"changed"):w.changed=True
        if hasattr(w,"hruler"):w.hruler.update();w.vruler.update()

    def sync_settings(source="ui"):
        it=current()
        if not it:return
        if source=="dpi":
            busy["v"]=True;interval.setValue(interval_from_dpi(dpi.value()));busy["v"]=False
        elif source=="interval":
            busy["v"]=True;dpi.setValue(25.4/max(.0001,interval.value()));busy["v"]=False
        mm=interval.value();dpiv=dpi.value()
        apply_image_settings(it,{"mode":mode.currentText(),"brightness":brightness.value(),"darkness":darkness.value(),
          "contrast":contrast.value(),"gamma":gamma.value()/100.0,"sharpen":sharpen.value(),"threshold":threshold.value(),
          "invert":invert.isChecked(),"interval":mm,"dpi":dpiv},w)

    def schedule(*_,source="ui"):
        if busy["v"]:return
        sync_settings(source)
        # Debounce rapid slider/mode changes. The old code rendered synchronously
        # on every mouse tick, which made Jarvis/Stucki/Atkinson look frozen.
        timer.start()

    def _finish_render(token,out,error):
        render_tasks.pop(token,None)
        request=render_requests.pop(token,None)
        if token!=render_seq["n"] or request is None:return
        it,requested=request
        try:
            if it.scene() is not w.scene:return
        except RuntimeError:return
        if any(it.image_settings.get(k)!=v for k,v in requested.items() if k!="size"):return
        if tuple(requested["size"])!=raster_grid(it):return
        if error:
            status.setText("ERROR: "+str(error));return
        try:
            pm=load_display_pixmap(out,2048)
            replace_pixmap_keep_scene_bounds(it,pm)
            mm=float(it.image_settings["interval"]);dpiv=requested["dpi"];it.preview_path=out
            if current() is it:status.setText(f"LIVE IMAGE: {Path(it.original_source).name} · {requested['mode']} · {acceleration_name()} · {dpiv:.0f} DPI · {mm:.4f} mm")
            if hasattr(w,"view"):w.view.viewport().update()
            if hasattr(w,"changed"):w.changed=True
            if hasattr(w,"schedule_preview"):w.schedule_preview()
        except Exception as e:status.setText("ERROR: "+str(e))

    def render():
        it=current()
        if not it:return
        source=it.original_source;dpiv=dpi.value()
        kwargs={"mode":mode.currentText(),"brightness":brightness.value(),"darkness":darkness.value(),"contrast":contrast.value(),
                "gamma":gamma.value()/100.0,"sharpen":sharpen.value(),"invert":invert.isChecked(),"threshold":threshold.value(),"dpi":dpiv}
        try:kwargs["size"]=raster_grid(it)
        except ValueError as exc:
            status.setText("ERROR: "+str(exc));return
        render_seq["n"]+=1;token=render_seq["n"]
        render_requests.clear();render_requests[token]=(it,dict(kwargs))
        status.setText(f"Procesando {mode.currentText()} en proceso separado… ({acceleration_name()})")
        task=submit_prepare(token,source,kwargs,_finish_render);render_tasks[token]=task

    timer.timeout.connect(render)
    w.scene.selectionChanged.connect(load_selection)
    for q in (xpos,ypos,width,height):q.valueChanged.connect(apply_geometry)
    # Mode changes render immediately so Jarvis/Stucki/etc. are visibly applied at once.
    mode.currentTextChanged.connect(lambda *_:schedule())
    for q in (brightness,darkness,contrast,gamma,sharpen,threshold):
        q.valueChanged.connect(schedule)
    dpi.valueChanged.connect(lambda *_:schedule(source="dpi"))
    interval.valueChanged.connect(lambda *_:schedule(source="interval"))
    invert.toggled.connect(lambda *_:schedule())
    def toggle_invert():
        if current() is None:
            QMessageBox.information(w,"Invertir imagen","Selecciona primero una imagen importada.")
            return
        dock.show();dock.raise_();invert.setChecked(not invert.isChecked())
    invert_button.clicked.connect(toggle_invert)
    w.invert_selected_image=toggle_invert
    def export_current_image():
        it=current()
        if it is None:
            QMessageBox.information(w,"Exportar imagen","Selecciona primero una imagen importada.")
            return
        try:
            it.setSelected(True)
        except Exception:
            pass
        from image_export_native import ImageExportDialog
        ImageExportDialog(w, default_area="SELECCION", default_preset="GRABADO").exec()
    export_img.clicked.connect(export_current_image)
    w.export_current_image=export_current_image
    reset.clicked.connect(lambda:(brightness.setValue(0),darkness.setValue(0),contrast.setValue(0),gamma.setValue(100),
                                  sharpen.setValue(0),threshold.setValue(128),dpi.setValue(254),interval.setValue(.1),invert.setChecked(False),
                                  mode.setCurrentText("Grayscale"),schedule()))
    w._image_controls={"mode":mode,"brightness":brightness,"darkness":darkness,"contrast":contrast,"gamma":gamma,"invert":invert,
                       "sharpen":sharpen,"threshold":threshold,"dpi":dpi,"interval":interval,"x":xpos,"y":ypos,"w":width,"h":height,"export":export_img}
    w._image_render_now=render
    w._image_sync_settings=sync_settings
    w._image_load_selection=load_selection
    w._image_timer=timer
    load_selection()
