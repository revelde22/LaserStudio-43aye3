
from PySide6.QtCore import Qt,QPointF
from PySide6.QtGui import QAction,QBrush,QColor,QPen,QTransform
from PySide6.QtWidgets import (QDockWidget,QWidget,QVBoxLayout,QHBoxLayout,QTableWidget,QTableWidgetItem,
 QHeaderView,QPushButton,QComboBox,QDoubleSpinBox,QSpinBox,QCheckBox,QFormLayout,QGroupBox,QMessageBox,
 QMenu,QAbstractItemView)

def install_functional_controls(w):
    from laser_studio import GItem,RasterItem,COLORS

    # --- selection actions ---
    edit=next((a.menu() for a in w.menuBar().actions() if a.text().replace("&","")=="Edit"),None)
    if edit:
        edit.addSeparator()
        a=edit.addAction("Delete Selected");a.triggered.connect(w.delete)
        a=edit.addAction("Duplicate Selected");a.triggered.connect(w.duplicate)

    # --- arrange operations actually wired ---
    arr=next((a.menu() for a in w.menuBar().actions() if a.text().replace("&","")=="Arrange"),None)
    if arr:
        arr.addSeparator()
        def call_first(names,*args):
            for name in names:
                fn=getattr(w,name,None)
                if callable(fn): return fn(*args)
        controls=[
          ("Mirror Horizontal",lambda:w.flip(True)),
          ("Mirror Vertical",lambda:w.flip(False)),
          ("Rotate 90°",lambda:call_first(("rotate_sel","rotate"),90)),
          ("Align Left",lambda:call_first(("align",),"left")),
          ("Align Right",lambda:call_first(("align",),"right")),
          ("Align Top",lambda:call_first(("align",),"top")),
          ("Align Bottom",lambda:call_first(("align",),"bottom")),
          ("Center Horizontally",lambda:call_first(("align",),"h")),
          ("Center Vertically",lambda:call_first(("align",),"v"))]
        for label,fn in controls: arr.addAction(label,fn)

    # --- filled/wireframe toggle ---
    state={"filled":True}
    def apply_view():
        for it in w.scene.items():
            if isinstance(it,GItem):
                cut=w.cuts[getattr(it,"layer",0)]
                if state["filled"] and cut.mode in ("Fill","Offset Fill"):
                    it.setBrush(QBrush(QColor(COLORS[it.layer%len(COLORS)])))
                else: it.setBrush(Qt.BrushStyle.NoBrush)
    def toggle_filled():
        state["filled"]=not state["filled"];apply_view()
        w.statusBar().showMessage("View: "+("Filled" if state["filled"] else "Wireframe"))
    view=next((a.menu() for a in w.menuBar().actions() if a.text().replace("&","") in ("View","Window")),None)
    if view:
        a=view.addAction("Toggle Wireframe / Filled");a.setShortcut("Alt+W");a.triggered.connect(toggle_filled)

    # --- replace old Cuts/Layers dock with functional table ---
    old=getattr(w,"layers_dock",None)
    if old: old.hide()
    dock=QDockWidget("Cuts / Layers",w);box=QWidget();v=QVBoxLayout(box)
    table=QTableWidget(16,6);table.setHorizontalHeaderLabels(["#","Mode","Speed","Power","Output","Show"])
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    table.horizontalHeader().setStretchLastSection(True)
    for r in range(16):
        c=w.cuts[r]
        item=QTableWidgetItem(f"C{r:02d}");item.setForeground(QBrush(QColor(COLORS[r])));table.setItem(r,0,item)
        table.setItem(r,1,QTableWidgetItem(c.mode));table.setItem(r,2,QTableWidgetItem(str(c.speed)));table.setItem(r,3,QTableWidgetItem(str(c.power)))
        for col,val in ((4,True),(5,True)):
            x=QTableWidgetItem();x.setFlags(x.flags()|Qt.ItemFlag.ItemIsUserCheckable);x.setCheckState(Qt.CheckState.Checked if val else Qt.CheckState.Unchecked);table.setItem(r,col,x)
    v.addWidget(table)
    w._cuts_table=table
    quick=QGroupBox("Cut Info");f=QFormLayout(quick)
    mode=QComboBox();mode.addItems(["Line","Fill","Offset Fill","Image"])
    speed=QDoubleSpinBox();speed.setRange(.001,100000);speed.setSuffix(" mm/s")
    power=QDoubleSpinBox();power.setRange(0,100);power.setSuffix(" %")
    frequency=QDoubleSpinBox();frequency.setRange(1,4000);frequency.setDecimals(1);frequency.setSuffix(" kHz")
    passes=QSpinBox();passes.setRange(1,1000)
    interval=QDoubleSpinBox();interval.setRange(.001,10);interval.setDecimals(4);interval.setSuffix(" mm")
    offset=QDoubleSpinBox();offset.setRange(0,10);offset.setDecimals(3);offset.setValue(.15);offset.setSuffix(" mm")
    f.addRow("Mode",mode);f.addRow("Speed",speed);f.addRow("Power",power);f.addRow("Frequency (kHz)",frequency);f.addRow("Pass Count",passes);f.addRow("Interval",interval);f.addRow("Offset inset",offset)
    v.addWidget(quick);dock.setWidget(box);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,dock);w.layers_dock=dock

    updating={"v":False}
    def sync_row_controls(r):
        if r<0:return
        updating["v"]=True;c=w.cuts[r]
        mode.setCurrentText(c.mode);speed.setValue(c.speed);power.setValue(c.power);frequency.setValue(getattr(c,"frequency",30.0));passes.setValue(c.passes);interval.setValue(c.interval);offset.setValue(c.offset)
        updating["v"]=False
    w._sync_cut_controls=sync_row_controls
    w._cut_controls={"mode":mode,"interval":interval,"offset":offset,"speed":speed,"power":power}
    def loadrow(r):
        if r<0:return
        w.set_layer(r,assign_selection=False)
    def savequick():
        if updating["v"]:return
        r=table.currentRow()
        if r<0:return
        c=w.cuts[r];c.mode=mode.currentText();c.speed=speed.value();c.power=power.value();c.frequency=frequency.value();c.passes=passes.value();c.interval=interval.value();c.offset=offset.value()
        for item in w.scene.items():
            if isinstance(item,RasterItem) and item.layer==r:
                item.image_settings['interval']=c.interval
                item.image_settings['dpi']=25.4/c.interval
        if hasattr(w,'_image_load_selection'):w._image_load_selection()
        table.item(r,1).setText(c.mode);table.item(r,2).setText(str(c.speed));table.item(r,3).setText(str(c.power));apply_view()
        from material_test_matrix import refresh_labels
        refresh_labels(w,r)
        w.changed=True;w.schedule_preview()
    table.currentCellChanged.connect(lambda r,*_:loadrow(r))
    table.cellDoubleClicked.connect(lambda r,c:w.edit_cut(r))
    for q in (mode,speed,power,frequency,passes,interval,offset):
        (q.currentTextChanged if isinstance(q,QComboBox) else q.valueChanged).connect(savequick)

    def cellchanged(r,c):
        if c==4:w.cuts[r].output=(table.item(r,c).checkState()==Qt.CheckState.Checked)
        elif c==5:
            vis=(table.item(r,c).checkState()==Qt.CheckState.Checked)
            w.cuts[r].show=vis
            for it in w.scene.items():
                if isinstance(it,(GItem,RasterItem)) and getattr(it,"layer",-1)==r:it.setVisible(vis)
        w.changed=True;w.schedule_preview()
    table.cellChanged.connect(cellchanged)
    table.selectRow(0);loadrow(0)

    # layer right click actions
    def ctx(pos):
        r=table.rowAt(pos.y())
        if r<0:return
        m=QMenu(table);sel=m.addAction("Select all shapes in layer");hide=m.addAction("Hide this layer");only=m.addAction("Show only this layer")
        a=m.exec(table.viewport().mapToGlobal(pos))
        if a==sel:
            w.scene.clearSelection()
            for it in w.scene.items():
                if isinstance(it,(GItem,RasterItem)) and getattr(it,"layer",-1)==r:it.setSelected(True)
        elif a==hide:
            table.item(r,5).setCheckState(Qt.CheckState.Unchecked)
        elif a==only:
            for rr in range(table.rowCount()):table.item(rr,5).setCheckState(Qt.CheckState.Checked if rr==r else Qt.CheckState.Unchecked)
    table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);table.customContextMenuRequested.connect(ctx)

    # tabify all right docks again with the new Cuts/Layers.
    docks=[dock]
    for attr in ("laser_dock","shape_dock","move_dock","library_dock","variable_dock","image_scale_dock","material_test_dock"):
        d=getattr(w,attr,None)
        if isinstance(d,QDockWidget):docks.append(d)
    for d in docks[1:]:w.tabifyDockWidget(dock,d)
    dock.raise_()
