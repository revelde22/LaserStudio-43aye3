from __future__ import annotations
import json, math, os, subprocess, tempfile
from pathlib import Path
from dataclasses import dataclass, asdict

APP = Path(__file__).resolve().parent
CFG = APP / 'g2_frame_calibration.json'

@dataclass
class Calibration:
    field_mm: float = 110.0
    scale_x: float = 1.0
    scale_y: float = 1.0
    offset_x_mm: float = 0.0
    offset_y_mm: float = 0.0
    invert_x: bool = False
    invert_y: bool = False
    swap_xy: bool = False
    # GLaser's observed ~3 cm red square used 65 point commands per cycle.
    # Keep the same density for the offline/native path preparation.
    edge_points: int = 65
    repeats: int = 2
    delay_ms: int = 80


def load_calibration() -> Calibration:
    try:
        d=json.loads(CFG.read_text(encoding='utf-8'))
        c=Calibration(**{k:v for k,v in d.items() if k in Calibration.__annotations__})
        return c
    except Exception:
        return Calibration()


def save_calibration(c: Calibration):
    CFG.write_text(json.dumps(asdict(c),indent=2,ensure_ascii=False),encoding='utf-8')


def _scene_items(main):
    try:
        selected=list(main.selected())
    except Exception:
        selected=[]
    if selected:
        return selected, True
    try:
        from laser_studio import GItem, RasterItem
        items=[it for it in main.scene.items() if isinstance(it,(GItem,RasterItem)) and it.isVisible()]
    except Exception:
        items=[]
    return items, False


def frame_bounds(main):
    items, selected = _scene_items(main)
    if not items:
        raise ValueError('No hay objetos para encuadrar.')
    rect=None
    for it in items:
        r=it.sceneBoundingRect()
        if r.isEmpty():
            continue
        rect=r if rect is None else rect.united(r)
    if rect is None or rect.isEmpty():
        raise ValueError('La geometría no tiene un área válida.')
    vals=(rect.left(),rect.top(),rect.right(),rect.bottom())
    if not all(math.isfinite(float(v)) for v in vals):
        raise ValueError('Los límites del dibujo no son válidos.')
    return rect, selected


def mark_probe_center(main):
    """Return the machine center for a selected line or design, including zero-height lines."""
    items, _ = _scene_items(main)
    if not items:
        raise ValueError('Selecciona una línea o un diseño para situar la sonda.')
    limits=[]
    for item in items:
        r=item.sceneBoundingRect()
        vals=tuple(float(v) for v in (r.left(),r.top(),r.right(),r.bottom()))
        if all(math.isfinite(v) for v in vals):
            limits.append(vals)
    if not limits:
        raise ValueError('La selección no tiene coordenadas válidas.')
    x=(min(v[0] for v in limits)+max(v[2] for v in limits))/2
    y=(min(v[1] for v in limits)+max(v[3] for v in limits))/2
    return _map_logical(x,y,load_calibration())


def _map_logical(x_mm,y_mm,c:Calibration):
    f=float(c.field_mm)
    # Lienzo 43AYE3: 0..field, origen arriba-izquierda.
    # GotoPosforSDK trabaja en coordenadas logicas de maquina (mm), centradas en 0,0.
    x=(float(x_mm)-f/2.0)*float(c.scale_x)+float(c.offset_x_mm)
    y=(f/2.0-float(y_mm))*float(c.scale_y)+float(c.offset_y_mm)
    if c.swap_xy: x,y=y,x
    if c.invert_x: x=-x
    if c.invert_y: y=-y
    # No recortar silenciosamente: una calibración fuera de campo debe corregirse.
    if abs(x)>75.0 or abs(y)>75.0:
        raise ValueError('El encuadre sale del margen lógico de seguridad ±75 mm. Revisa la calibración.')
    return x,y

def make_rect_path(rect,c:Calibration):
    f=float(c.field_mm)
    l=max(0.0,min(f,float(rect.left())))
    t=max(0.0,min(f,float(rect.top())))
    r=max(0.0,min(f,float(rect.right())))
    b=max(0.0,min(f,float(rect.bottom())))
    if r<=l or b<=t:
        raise ValueError('El encuadre tiene tamaño cero.')
    n=max(4,min(128,int(c.edge_points)))
    pts=[]
    def edge(x1,y1,x2,y2):
        for i in range(n):
            q=i/float(n)
            pts.append(_map_logical(x1+(x2-x1)*q,y1+(y2-y1)*q,c))
    edge(l,t,r,t); edge(r,t,r,b); edge(r,b,l,b); edge(l,b,l,t)
    pts.append(_map_logical(l,t,c))
    return pts,(l,t,r,b)


def write_path(main):
    c=load_calibration(); rect,selected=frame_bounds(main); pts,bounds=make_rect_path(rect,c)
    temp=APP/'NATIVE_G2_FRAME_PATH.txt'
    with temp.open('w',encoding='ascii',newline='\n') as fh:
        fh.write(f'# repeats={max(1,min(50,int(c.repeats)))} delay_ms={max(1,min(1000,int(c.delay_ms)))}\n')
        for x,y in pts: fh.write(f'{x:.3f} {y:.3f}\n')
    return temp,c,bounds,selected


def _build(base=APP, timeout=120):
    bat=Path(base)/'COMPILAR_DIAGNOSTICO_G2.bat'
    p=subprocess.run(['cmd.exe','/d','/c',str(bat)],cwd=str(base),capture_output=True,text=True,timeout=timeout,
                     creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return p.returncode==0,(p.stdout+'\n'+p.stderr)


def start_frame(main,vendor_dir):
    path,c,bounds,selected=write_path(main)
    exe=APP/'native_bridge_x86'/'43aye3_g2_native_frame_x86.exe'
    src=APP/'native_bridge_x86'/'device_frame_native_x86.cpp'
    if (not exe.exists()) or (src.exists() and src.stat().st_mtime>exe.stat().st_mtime):
        ok,log=_build()
        if not ok or not exe.exists():
            raise RuntimeError('No se pudo compilar el encuadre nativo x86.\n'+log[-3000:])
    env=os.environ.copy(); env['G2PRO_VENDOR_DIR']=str(vendor_dir); env['AYE_SDK_DLL']=str(APP/'BSL_SDK'/'43AYE3_G2_SDK'/'43AYE3_BSL_COMPAT.dll')
    env['G2_FRAME_REPEATS']=str(max(1,min(50,int(c.repeats))))
    env['G2_FRAME_DELAY_MS']=str(max(1,min(1000,int(c.delay_ms))))
    proc=subprocess.Popen([str(exe),str(path)],cwd=str(APP),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                          text=True,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return proc,c,bounds,selected
