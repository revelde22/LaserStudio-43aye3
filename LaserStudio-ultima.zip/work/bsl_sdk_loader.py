from __future__ import annotations

"""Detector automatico del BSLAPP-SDK 5.x.

No depende del nombre de la DLL. Lee la tabla PE de exports de cada DLL de
BSL_SDK y selecciona la que expone la API publica documentada BSL_*.
No carga/ejecuta la DLL durante la deteccion.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import struct
from typing import Iterable

APP = Path(__file__).resolve().parent
SDKDIR = APP / "BSL_SDK"

REQUIRED_EXPORTS = (
    "BSL_NewFile",
    "BSL_SaveEntLibToFile",
    "BSL_AddLinesToFile2",
    "BSL_SetPenParam",
)
OPTIONAL_EXPORTS = (
    "BSL_AddBmpToFile",
    "BSL_GetPenParam",
    "BSL_UnLoadDataFile",
    "BSL_LoadDataFile",
    "BSL_DrawFileInImg",
    "BSL_InitInstance",
    "BSL_ExitInstance",
    "BSL_GetAllDevices",
    "BSL_AppendFileToDevice",
    "BSL_RedLightMark",
    "BSL_RedLightMarkByEnt2",
    "BSL_StopMark",
    "BSL_EmergenyStop",
    "BSL_MarkByDeviceId",
    "BSL_MarkSelectedFile",
    "BSL_MarkLines2",
    "BSL_MarkLinesX",
)

@dataclass
class DllCandidate:
    path: str
    machine: str
    bits: int
    exports: list[str]
    required_present: list[str]
    required_missing: list[str]
    optional_present: list[str]
    score: int

    @property
    def ready(self) -> bool:
        return not self.required_missing


def _u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def _u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def _cstr(data: bytes, off: int) -> str:
    if off < 0 or off >= len(data):
        return ""
    end = data.find(b"\x00", off)
    if end < 0:
        end = min(len(data), off + 512)
    return data[off:end].decode("ascii", errors="ignore")


def _parse_exports(path: Path) -> tuple[str, int, set[str]]:
    data = path.read_bytes()
    if len(data) < 0x100 or data[:2] != b"MZ":
        raise ValueError("no es PE/MZ")
    pe = _u32(data, 0x3C)
    if pe + 0x100 > len(data) or data[pe:pe+4] != b"PE\x00\x00":
        raise ValueError("cabecera PE invalida")
    machine_val = _u16(data, pe + 4)
    machine = {0x14C: "x86", 0x8664: "x64", 0x1C0: "ARM", 0xAA64: "ARM64"}.get(machine_val, f"0x{machine_val:04X}")
    nsec = _u16(data, pe + 6)
    opt_size = _u16(data, pe + 20)
    opt = pe + 24
    magic = _u16(data, opt)
    if magic == 0x10B:
        bits = 32
        dd = opt + 96
    elif magic == 0x20B:
        bits = 64
        dd = opt + 112
    else:
        raise ValueError("optional header desconocido")
    export_rva = _u32(data, dd)
    export_size = _u32(data, dd + 4)
    sec_base = opt + opt_size
    sections = []
    for i in range(nsec):
        s = sec_base + i * 40
        if s + 40 > len(data):
            break
        vsize = _u32(data, s + 8)
        va = _u32(data, s + 12)
        raw_size = _u32(data, s + 16)
        raw_ptr = _u32(data, s + 20)
        sections.append((va, max(vsize, raw_size), raw_ptr, raw_size))

    def rva_to_off(rva: int) -> int:
        if rva == 0:
            return -1
        for va, span, raw, raw_size in sections:
            if va <= rva < va + span:
                d = rva - va
                if d >= raw_size and raw_size:
                    return -1
                return raw + d
        # Header RVAs may map 1:1.
        if 0 <= rva < len(data):
            return rva
        return -1

    exports: set[str] = set()
    if not export_rva or not export_size:
        return machine, bits, exports
    eoff = rva_to_off(export_rva)
    if eoff < 0 or eoff + 40 > len(data):
        return machine, bits, exports
    n_names = _u32(data, eoff + 24)
    names_rva = _u32(data, eoff + 32)
    names_off = rva_to_off(names_rva)
    if names_off < 0:
        return machine, bits, exports
    n_names = min(n_names, 100000)
    for i in range(n_names):
        poff = names_off + i * 4
        if poff + 4 > len(data):
            break
        name_rva = _u32(data, poff)
        noff = rva_to_off(name_rva)
        if noff >= 0:
            name = _cstr(data, noff)
            if name:
                exports.add(name)
    return machine, bits, exports


def _declared_43aye3_exports() -> set[str]:
    """Lee los exports declarados por nuestro propio SDK desde su .def.

    El parser PE es deliberadamente conservador y algunas DLL x86 creadas por
    MSVC pueden no aparecer como candidatas aunque la tabla de exports sea
    valida. Para *nuestro* SDK podemos usar el .def que se compila junto a la
    DLL como segunda fuente de verdad; el bridge x86 vuelve a validar los
    exports reales con GetProcAddress antes de usarlos.
    """
    out: set[str] = set()
    try:
        defs = list(SDKDIR.rglob("43AYE3_BSL_COMPAT.def"))
        if not defs:
            return out
        in_exports = False
        for raw in defs[0].read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith(";"):
                continue
            if line.upper() == "EXPORTS":
                in_exports = True
                continue
            if not in_exports:
                continue
            name = line.split("=", 1)[0].strip().split()[0] if line else ""
            if name:
                out.add(name)
    except Exception:
        pass
    return out


def inspect_dll(path: Path) -> DllCandidate | None:
    try:
        machine, bits, exports = _parse_exports(path)
    except Exception:
        return None
    # Normaliza decoracion C x86 por si una compilacion de respaldo no usa .def.
    # MSVC puede exportar _BSL_Foo/_AYE_Foo; para deteccion los tratamos como
    # BSL_Foo/AYE_Foo. El helper x86 vuelve a validar los nombres reales.
    norm = set(exports)
    for name in list(exports):
        if name.startswith("_BSL_") or name.startswith("_AYE_"):
            norm.add(name[1:])
    exports = norm
    # Nuestro SDK 43AYE3 se compila con un .def explicito. Si el parser PE
    # conservador no ve los nombres, incorpora los nombres declarados.
    if path.name.lower() == "43aye3_bsl_compat.dll":
        exports = set(exports) | _declared_43aye3_exports()
    req_p = [n for n in REQUIRED_EXPORTS if n in exports]
    req_m = [n for n in REQUIRED_EXPORTS if n not in exports]
    opt_p = [n for n in OPTIONAL_EXPORTS if n in exports]
    # Prioriza API completa, x86 (nuestro bridge es x86), imagen y control fisico.
    score = len(req_p) * 100 + len(opt_p) * 5 + (25 if bits == 32 else 0)
    return DllCandidate(
        path=str(path.resolve()), machine=machine, bits=bits,
        exports=sorted(exports), required_present=req_p,
        required_missing=req_m, optional_present=opt_p, score=score,
    )


def scan_sdk(root: Path | str = SDKDIR) -> list[DllCandidate]:
    root = Path(root)
    if not root.exists():
        return []
    out: list[DllCandidate] = []
    for p in sorted(root.rglob("*.dll"), key=lambda x: str(x).lower()):
        # The in-house frame/control bridge mirrors BSL export names but its
        # ORZX implementation delegates to SeaDraw::SaveOrz and is unverified.
        # It must never qualify as the vendor's BSLAPP-SDK for file export.
        if p.name.casefold() == "43aye3_bsl_compat.dll":
            continue
        c = inspect_dll(p)
        if c is not None and (c.required_present or any(x.startswith("BSL_") for x in c.exports)):
            out.append(c)
    out.sort(key=lambda c: (c.ready, c.bits == 32, c.score), reverse=True)
    return out


def detect_sdk_dll(root: Path | str = SDKDIR, require_x86: bool = True) -> DllCandidate:
    candidates = scan_sdk(root)
    if not candidates:
        raise RuntimeError(
            "Falta la DLL oficial BSLAPP-SDK 5.x para guardar ORZX. "
            "43AYE3_BSL_COMPAT.dll sirve para conexión y encuadre, pero su guardado "
            "SeaDraw::SaveOrz no está validado. Copia el SDK oficial x86 completo "
            "(DLL, MarkAPI.h y dependencias) dentro de BSL_SDK."
        )
    ready = [c for c in candidates if c.ready and (not require_x86 or c.bits == 32)]
    if ready:
        return ready[0]
    complete_wrong_arch = [c for c in candidates if c.ready]
    if complete_wrong_arch and require_x86:
        c = complete_wrong_arch[0]
        raise RuntimeError(
            f"He encontrado la API BSL completa, pero es {c.machine}/{c.bits}-bit: {c.path}. "
            "El puente actual de tu G2 es x86 y necesita la DLL SDK de 32 bits."
        )
    c = candidates[0]
    missing = ", ".join(c.required_missing) or "ninguno"
    raise RuntimeError(
        "He encontrado una DLL BSL, pero no contiene la API ORZX completa.\n"
        f"DLL: {c.path}\nArquitectura: {c.machine}/{c.bits}-bit\n"
        f"Faltan: {missing}"
    )


def report(root: Path | str = SDKDIR) -> str:
    root = Path(root)
    lines = [f"BSL_SDK_DIR={root.resolve()}"]
    dlls = list(root.rglob("*.dll")) if root.exists() else []
    lines.append(f"DLL_COUNT={len(dlls)}")
    candidates = scan_sdk(root)
    lines.append(f"BSL_CANDIDATE_COUNT={len(candidates)}")
    if not candidates:
        lines.append("SDK_AUTO_DETECT=NOT_FOUND")
        lines.append("COPIA_EL_PAQUETE_COMPLETO_EN_BSL_SDK=YES")
        return "\n".join(lines)
    for i, c in enumerate(candidates[:12], 1):
        lines.append(f"CANDIDATE_{i}_PATH={c.path}")
        lines.append(f"CANDIDATE_{i}_ARCH={c.machine}/{c.bits}")
        lines.append(f"CANDIDATE_{i}_REQUIRED={','.join(c.required_present) or 'NONE'}")
        lines.append(f"CANDIDATE_{i}_MISSING={','.join(c.required_missing) or 'NONE'}")
        lines.append(f"CANDIDATE_{i}_OPTIONAL={','.join(c.optional_present) or 'NONE'}")
    try:
        best = detect_sdk_dll(root)
        lines.append("SDK_AUTO_DETECT=PASS")
        lines.append(f"SDK_SELECTED_DLL={best.path}")
        lines.append(f"SDK_SELECTED_ARCH={best.machine}/{best.bits}")
        lines.append(f"SDK_IMAGE_API={'YES' if 'BSL_AddBmpToFile' in best.exports else 'NO'}")
        lines.append(f"SDK_FRAME_API={'YES' if ('BSL_RedLightMark' in best.exports or 'BSL_RedLightMarkByEnt2' in best.exports) else 'NO'}")
        lines.append(f"SDK_STOP_API={'YES' if 'BSL_StopMark' in best.exports else 'NO'}")
        lines.append(f"SDK_MARK_API={'YES' if ('BSL_MarkByDeviceId' in best.exports or 'BSL_MarkSelectedFile' in best.exports) else 'NO'}")
    except Exception as e:
        lines.append("SDK_AUTO_DETECT=INVALID")
        lines.append("SDK_AUTO_DETECT_ERROR=" + str(e).replace("\n", " | "))
    return "\n".join(lines)


def write_manifest(path: Path, candidate: DllCandidate) -> None:
    payload = asdict(candidate)
    payload["ready"] = candidate.ready
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    print(report())
