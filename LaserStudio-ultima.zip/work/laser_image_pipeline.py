from pathlib import Path
import tempfile, hashlib, math, os
from PIL import Image, ImageOps, ImageFilter
import numpy as np

MODES=["Grayscale","Threshold","Floyd-Steinberg","Jarvis","Stucki","Atkinson","Ordered","Newsprint","Halftone"]

KERNELS={
"Floyd-Steinberg":[(1,0,7/16),(-1,1,3/16),(0,1,5/16),(1,1,1/16)],
"Jarvis":[(1,0,7/48),(2,0,5/48),(-2,1,3/48),(-1,1,5/48),(0,1,7/48),(1,1,5/48),(2,1,3/48),(-2,2,1/48),(-1,2,3/48),(0,2,5/48),(1,2,3/48),(2,2,1/48)],
"Stucki":[(1,0,8/42),(2,0,4/42),(-2,1,2/42),(-1,1,4/42),(0,1,8/42),(1,1,4/42),(2,1,2/42),(-2,2,1/42),(-1,2,2/42),(0,2,4/42),(1,2,2/42),(2,2,1/42)],
"Atkinson":[(1,0,1/8),(2,0,1/8),(-1,1,1/8),(0,1,1/8),(1,1,1/8),(0,2,1/8)]
}
BAYER=np.array([[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]],dtype=np.float32)

# Fast path. Numba is optional: if unavailable the UI still stays responsive
# because image processing is dispatched to a worker thread by image_async.py.
try:
    from numba import njit
    NUMBA_AVAILABLE=True
except Exception:
    njit=None
    NUMBA_AVAILABLE=False

if NUMBA_AVAILABLE:
    @njit(cache=True, nogil=True)
    def _diffuse_numba(a, dxs, dys, weights):
        x=a.astype(np.float32).copy()
        h,w=x.shape
        for y in range(h):
            rev=(y & 1)==1
            if rev:
                xx0=w-1; stop=-1; step=-1
            else:
                xx0=0; stop=w; step=1
            while xx0 != stop:
                old=x[y,xx0]
                new=255.0 if old>=128.0 else 0.0
                x[y,xx0]=new
                err=old-new
                for i in range(weights.shape[0]):
                    dx=dxs[i]
                    if rev: dx=-dx
                    xx=xx0+dx; yy=y+dys[i]
                    if 0<=xx<w and 0<=yy<h:
                        v=x[yy,xx]+err*weights[i]
                        if v<0.0: v=0.0
                        elif v>255.0: v=255.0
                        x[yy,xx]=v
                xx0+=step
        return x.astype(np.uint8)
else:
    _diffuse_numba=None

def _kernel_arrays(kernel):
    return (np.asarray([k[0] for k in kernel],dtype=np.int64),
            np.asarray([k[1] for k in kernel],dtype=np.int64),
            np.asarray([k[2] for k in kernel],dtype=np.float32))

_KERNEL_ARRAYS={name:_kernel_arrays(k) for name,k in KERNELS.items()}

def _diffuse_python(a,kernel):
    x=a.astype(np.float32).copy();h,w=x.shape
    for y in range(h):
        rev=(y&1)==1; xs=range(w-1,-1,-1) if rev else range(w)
        for xx0 in xs:
            old=float(x[y,xx0]);new=255.0 if old>=128 else 0.0;x[y,xx0]=new;err=old-new
            for dx,dy,f in kernel:
                dx=-dx if rev else dx;xx=xx0+dx;yy=y+dy
                if 0<=xx<w and 0<=yy<h:
                    v=x[yy,xx]+err*f
                    x[yy,xx]=0 if v<0 else (255 if v>255 else v)
    return x.astype(np.uint8)

def diffuse(a,kernel,mode_name=None):
    # Pillow's Floyd-Steinberg implementation is C-fast even without numba.
    if mode_name=="Floyd-Steinberg" and not NUMBA_AVAILABLE:
        return np.asarray(Image.fromarray(a,"L").convert("1",dither=Image.Dither.FLOYDSTEINBERG).convert("L"),dtype=np.uint8)
    if NUMBA_AVAILABLE:
        dxs,dys,weights=_KERNEL_ARRAYS.get(mode_name,_kernel_arrays(kernel))
        return _diffuse_numba(a,dxs,dys,weights)
    return _diffuse_python(a,kernel)

def _clustered_halftone(a,cell):
    # Vectorized clustered-dot screen. Avoids a Python loop per cell.
    h,w=a.shape
    ph=(-h)%cell; pw=(-w)%cell
    ap=np.pad(a,((0,ph),(0,pw)),mode="edge") if (ph or pw) else a
    H,W=ap.shape; ny=H//cell; nx=W//cell
    means=ap.reshape(ny,cell,nx,cell).mean(axis=(1,3))
    darkness=1.0-means/255.0
    radius=darkness*(cell*.72)
    yy,xx=np.ogrid[:cell,:cell]
    dist=np.sqrt((xx-(cell-1)/2.0)**2+(yy-(cell-1)/2.0)**2)
    mask=(dist[None,:,None,:] <= radius[:,None,:,None])
    out=np.where(mask,0,255).astype(np.uint8).transpose(0,1,2,3).reshape(H,W)
    return out[:h,:w]

def process_array(source,mode="Grayscale",brightness=0,darkness=0,contrast=0,gamma=1.0,sharpen=0,invert=False,threshold=128,size=None):
    im=Image.open(source).convert("L")
    if size is not None:
        im=im.resize(tuple(map(int,size)),Image.Resampling.LANCZOS)
    a=np.asarray(im,dtype=np.float32)
    a=np.clip(a + brightness*1.6 - darkness*1.6,0,255)
    a=np.clip((a-127.5)*(1+contrast/100.0)+127.5,0,255)
    a=255*np.power(a/255.0,1/max(.05,float(gamma)))
    im=Image.fromarray(a.astype(np.uint8),"L")
    if sharpen: im=im.filter(ImageFilter.UnsharpMask(radius=1.2,percent=int(sharpen*3),threshold=2))
    if invert: im=ImageOps.invert(im)
    a=np.asarray(im,dtype=np.uint8)
    if mode=="Threshold": return np.where(a>=threshold,255,0).astype(np.uint8)
    if mode in KERNELS:return diffuse(a,KERNELS[mode],mode)
    if mode=="Ordered":
        yy,xx=np.indices(a.shape);t=(BAYER[yy%4,xx%4]+.5)/16*255
        return np.where(a>t,255,0).astype(np.uint8)
    if mode in ("Newsprint","Halftone"):
        return _clustered_halftone(a,6 if mode=="Newsprint" else 8)
    return a

def prepare(source,mode="Grayscale",brightness=0,darkness=0,contrast=0,gamma=1.0,sharpen=0,invert=False,threshold=128,dpi=254,size=None):
    src=Path(source)
    try: mtime=src.stat().st_mtime_ns
    except Exception: mtime=0
    sig=f"{src}|{mtime}|{mode}|{brightness}|{darkness}|{contrast}|{gamma}|{sharpen}|{invert}|{threshold}|{dpi}|{size}|grid3"
    fn=Path(tempfile.gettempdir())/("43aye3_"+hashlib.sha1(sig.encode()).hexdigest()+".png")
    # Cache prevents recomputing Jarvis/Stucki/etc. when the user returns to a prior setting.
    if fn.exists() and fn.stat().st_size>0:
        return str(fn)
    a=process_array(source,mode,brightness,darkness,contrast,gamma,sharpen,invert,threshold,size)
    tmp=fn.with_name(fn.name+f".{os.getpid()}.tmp.png")
    Image.fromarray(a,"L").save(tmp,dpi=(float(dpi),float(dpi)))
    try:
        os.replace(tmp,fn)
    except Exception:
        if not fn.exists(): raise
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
    return str(fn)

def interval_from_dpi(dpi):return 25.4/max(1,float(dpi))

def acceleration_name():
    return "NUMBA" if NUMBA_AVAILABLE else "BACKGROUND-PYTHON"
