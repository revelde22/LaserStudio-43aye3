#pragma once
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef AYE_API
# ifdef AYE_BUILD_DLL
#  define AYE_API __declspec(dllexport)
# else
#  define AYE_API __declspec(dllimport)
# endif
#endif

struct AYE_PointD { double x; double y; };
struct AYE_DeviceInfo {
    int connected;
    int valid_devices;
    int device_no;
    int device_type;
    int usb_speed_type;
};

// Capabilities verified for this exact pinned x86 vendor runtime.
// These bits describe implemented API routes, not a current device connection.
#define AYE_CAP_DEVICE_CONNECT       0x00000001u
#define AYE_CAP_DEVICE_STOP          0x00000002u
#define AYE_CAP_MARKER_ASSOCIATION   0x00000004u
#define AYE_CAP_RED_POINT_MOVEMENT   0x00000008u
#define AYE_CAP_DOCUMENT_EDIT        0x00000010u
#define AYE_CAP_VISIBLE_RED_FRAME    0x00000020u
#define AYE_CAP_LASER_MARKING        0x00000040u

// Return convention: 0 = OK, negative = error.
AYE_API int __cdecl AYE_GetVersion(wchar_t* outText, int cch);
AYE_API int __cdecl AYE_GetLastError(wchar_t* outText, int cch);
AYE_API int __cdecl AYE_GetCapabilities(unsigned int* outFlags);
AYE_API int __cdecl AYE_DeviceConnect(void);
AYE_API int __cdecl AYE_DeviceGetInfo(AYE_DeviceInfo* info);
AYE_API int __cdecl AYE_Stop(void);
AYE_API int __cdecl AYE_ProbeMarker(void);
// Read-only native geometry preparation. Requires AYE_ProbeMarker and a
// document created with BSL_NewFile/BSL_AddLinesToFile2. No USB commands.
AYE_API int __cdecl AYE_ProbeRedPaths(int mode, int* pathCount);
// Experimental physical probe using GLaser's CMarkMgr::DoMark red control.
AYE_API int __cdecl AYE_TestRedViaDoMark(void);
AYE_API int __cdecl AYE_TestRedOutlineViaDoMark(void);
// Keeps the native red call active until STOP or parent exit.
AYE_API int __cdecl AYE_RunRedBoxContinuous(HANDLE stopEvent, HANDLE parent);
AYE_API int __cdecl AYE_RunRedVectorContinuous(HANDLE stopEvent, HANDLE parent);
AYE_API int __cdecl AYE_FramePolyline(const AYE_PointD* pts, int count, int repeats, int delayMs);
AYE_API int __cdecl AYE_DeviceClose(void);
AYE_API int __cdecl AYE_MarkLines(const AYE_PointD* pts, int count, int pen);
// Mark all vector shapes in the active in-memory document, pen 0 only.
AYE_API int __cdecl AYE_MarkVectorDesign(HANDLE parent);

// Compatibility exports used by 43AYE3 Laser Studio's BSL bridge.
AYE_API int __cdecl BSL_NewFile(wchar_t* filePath);
AYE_API int __cdecl BSL_SaveEntLibToFile(wchar_t* filePath);
AYE_API int __cdecl BSL_UnLoadDataFile(wchar_t* filePath);
AYE_API int __cdecl BSL_AddLinesToFile2(wchar_t* filePath, void* pointsXYFloat, int lineCount, int* pointCounts, wchar_t* entityName, int pen);
AYE_API int __cdecl BSL_AddBmpToFile(wchar_t* filePath, wchar_t* imagePath, wchar_t* entityName, double widthMm, double heightMm, double centerX, double centerY, double rotationDeg, int pen);
AYE_API int __cdecl BSL_GetPenParam(wchar_t* filePath, unsigned int pen, int* loops, double* speed, double* power, double* current, int* frequencyHz, int* qPulse, int* startTc, int* laserOffTc, int* endTc, int* polygonTc, double* jumpSpeed, int* jumpPosTc, int* jumpDistTc, double* endComp, bool* pulsePoint, int* pulseCount, float* pulseTime);
AYE_API int __cdecl BSL_SetPenParam(wchar_t* filePath, unsigned int pen, int loops, double speed, double power, double current, int frequencyHz, int qPulse, int startTc, int laserOffTc, int endTc, int polygonTc, double jumpSpeed, int jumpPosTc, int jumpDistTc, double endComp, bool pulsePoint, int pulseCount, float pulseTime);

#ifdef __cplusplus
}
#endif
