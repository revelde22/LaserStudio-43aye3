"""Offline verifier for an isolated GLaser red-frame transaction.

Reads a USBPcap file, finds the SEA-LASER EP2 session made only of family
0x41 batches, and verifies the observed 530+530+98 cycle pattern byte-for-byte.
It never opens USB and never transmits a packet.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from analyze_g2_red_pcap import records
from g2_red_packet_codec import decode_batch, encode_batch


def analyze(path: Path):
    rows = list(records(path))
    if not rows:
        raise ValueError("Empty capture")
    t0 = rows[0][0]
    devices = {}
    for t, bus, dev, ep, transfer, info, payload, _ in rows:
        if ep == 0x80 and info == 1 and len(payload) >= 12 and payload[:2] == b"\x12\x01":
            devices[(bus, dev)] = (int.from_bytes(payload[8:10], "little"),
                                   int.from_bytes(payload[10:12], "little"))
    laser = {k for k, vp in devices.items() if vp == (0x04B4, 0x1004)}
    if not laser:
        raise ValueError("No SEA-LASER 04b4:1004 descriptor")
    packets = []
    for t, bus, dev, ep, transfer, info, payload, _ in rows:
        if ((bus, dev) in laser and ep == 2 and transfer == 3 and info == 0
                and payload.startswith(b"\xfe\xff") and len(payload) >= 26):
            try:
                commands = decode_batch(payload)
            except ValueError:
                continue
            if all(len(c.encode()) == 18 for c in commands):
                packets.append((t - t0, payload, len(commands)))
    if not packets:
        raise ValueError("No decodable family 0x41 batches")
    active = [p for p in packets if p[2] > 1]
    groups = []
    for item in active:
        if not groups or item[0] - groups[-1][-1][0] > 0.2:
            groups.append([])
        groups[-1].append(item)
    group = max(groups, key=len)
    roundtrip = all(encode_batch(decode_batch(payload)) == payload for _, payload, _ in group)
    sizes = Counter(len(payload) for _, payload, _ in group)
    commands = sum(n for _, _, n in group)
    cycle = [len(payload) for _, payload, _ in group[:3]]
    cycles = len(group) // 3 if cycle == [530, 530, 98] else None
    return {
        "input": path.name,
        "sea_laser_bus_device": sorted(map(list, laser)),
        "start_seconds": round(group[0][0], 3),
        "end_seconds": round(group[-1][0], 3),
        "packet_count": len(group),
        "packet_sizes": dict(sizes),
        "cycle_pattern": cycle,
        "cycles": cycles,
        "position_commands": commands,
        "exact_batch_roundtrip": roundtrip,
        "read_only": True,
        "transmission_attempted": False,
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("pcap", type=Path)
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    text = json.dumps(analyze(args.pcap), indent=2) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
