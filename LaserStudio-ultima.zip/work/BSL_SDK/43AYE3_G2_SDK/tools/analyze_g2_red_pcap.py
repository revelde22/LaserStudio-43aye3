"""Read-only USBPcap analyzer for G2 red-outline captures.

This program never opens a USB device or emits a machine command. It extracts
outgoing point batches from the SEA-LASER (VID 04b4, PID 1004) capture and
groups identical consecutive outline cycles, including their closed geometry.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
from g2_red_packet_codec import decode_batch, encode_batch


def records(path: Path):
    with path.open("rb") as f:
        global_header = f.read(24)
        if len(global_header) != 24 or struct.unpack_from("<I", global_header)[0] != 0xA1B2C3D4:
            raise ValueError("Expected a little-endian USBPcap .pcap file")
        if struct.unpack_from("<I", global_header, 20)[0] != 249:
            raise ValueError("Expected USBPcap link type 249")
        while header := f.read(16):
            if len(header) != 16:
                raise ValueError("Truncated pcap record")
            sec, usec, captured, _ = struct.unpack("<IIII", header)
            raw = f.read(captured)
            if len(raw) != captured or captured < 27:
                raise ValueError("Truncated USBPcap packet")
            length, _, status, function, info, bus, device, endpoint, transfer, data_length = struct.unpack_from(
                "<HQIHBHHBBI", raw
            )
            if length > captured:
                raise ValueError("Invalid USBPcap header length")
            yield sec + usec / 1_000_000, bus, device, endpoint, transfer, info, raw[length:], data_length


def batch_points(payload: bytes):
    if (len(payload) < 8 or payload[:6] != b"\xfe\xff" + len(payload).to_bytes(2, "big") + b"\x01\x00"
            or payload[-2:] != b"\x00\x43" or (len(payload) - 8) % 18):
        return None
    chunks = [payload[6 + n:6 + n + 18] for n in range(0, len(payload) - 8, 18)]
    if not chunks or any(c[:4] != b"\x02\x41\x12\x00" for c in chunks):
        return None
    return [(int.from_bytes(c[8:11], "big"), int.from_bytes(c[11:14], "big")) for c in chunks]


def analyze(path: Path):
    all_records = list(records(path))
    starts = []
    for i, (t, bus, device, endpoint, transfer, info, payload, _) in enumerate(all_records):
        if endpoint == 0x80 and info == 1 and len(payload) >= 12 and payload[:2] == b"\x12\x01":
            vid, pid = struct.unpack_from("<HH", payload, 8)
            if (vid, pid) == (0x04B4, 0x1004):
                starts.append((i, bus, device))
    if not starts:
        raise ValueError("No SEA-LASER device descriptor (04b4:1004) found")
    device_keys = {(bus, device) for _, bus, device in starts}
    exact_roundtrips = Counter()
    for _, bus, device, endpoint, transfer, info, payload, _ in all_records:
        if (bus, device) in device_keys and endpoint == 2 and transfer == 3 and info == 0 \
                and len(payload) in (26, 134, 368, 530):
            if encode_batch(decode_batch(payload)) != payload:
                raise ValueError("EP2 byte-for-byte round trip failed")
            exact_roundtrips[len(payload)] += 1
    out = []
    for t, bus, device, endpoint, transfer, info, payload, _ in all_records:
        if (bus, device) not in device_keys or endpoint != 2 or transfer != 3 or info != 0:
            continue
        pts = batch_points(payload)
        # A single 26-byte command at the end parks the mirrors at the
        # neutral position. It is not part of the closed outline.
        if pts is not None and len(pts) >= 2:
            out.append((t, hashlib.sha256(payload).hexdigest()[:16], len(payload), pts))
    # Each GLaser frame cycle begins with a packet containing a non-zero
    # start-move field. Subsequent cycles zero it while repeating the shape.
    sessions = []
    session = []
    for item in out:
        if session and item[0] - session[-1][0] > 1.0:
            sessions.append(session)
            session = []
        session.append(item)
    if session:
        sessions.append(session)
    results = []
    for group in sessions:
        counts = Counter((size, digest) for _, digest, size, _ in group)
        # Repeated body packets are the canonical geometry; the first packet
        # may have different starting control bytes with the same coordinates.
        unique = []
        for _, digest, size, pts in group:
            if pts not in [x[2] for x in unique]:
                unique.append((digest, size, pts))
        points = [point for _, _, batch in unique for point in batch]
        xs, ys = zip(*points)
        results.append({
            "start_seconds": round(group[0][0] - all_records[0][0], 3),
            "end_seconds": round(group[-1][0] - all_records[0][0], 3),
            "packets": len(group),
            "batch_sizes": dict(Counter(size for _, _, size, _ in group)),
            "bounds_units": [min(xs), min(ys), max(xs), max(ys)],
            "closed": points[0] == points[-1],
            "unique_points": len(points),
            "batch_hash_counts": {f"{size}:{digest}": n for (size, digest), n in counts.items()},
        })
    square = next((g for g, result in zip(sessions, results)
                   if result["unique_points"] == 65 and result["closed"]), None)
    if square is None:
        raise ValueError("No closed 65-point GLaser square in capture")
    first, last = square[0][0], square[-1][0]
    # Read the complete red-light transaction around the square. This is an
    # offline consistency check, never a command emitter or safety guarantee.
    traffic = [(t, ep, p) for t, bus, dev, ep, transfer, info, p, _ in all_records
               if (bus, dev) in device_keys and info == 0 and transfer == 3
               and first - 0.2 <= t <= last + 0.1 and ep in (2, 6) and p]
    special6 = [(round(t - first, 4), p.hex()) for t, ep, p in traffic
                if ep == 6 and p[6:8] != b"\xaa\x05"]
    controls2 = [(round(t - first, 4), p.hex()) for t, ep, p in traffic
                 if ep == 2 and len(p) == 20]
    parks = [(round(t - first, 4), p.hex()) for t, ep, p in traffic
             if ep == 2 and len(p) == 26]
    sizes = [size for _, _, size, _ in square]
    complete = sum(sizes[i:i + 3] == [530, 530, 134] for i in range(0, len(sizes) - 2, 3))
    first_packet = next(p for t, ep, p in traffic if ep == 2 and len(p) == 530 and t >= first)
    checks = {
        "70_complete_square_cycles": complete == 70,
        "one_incomplete_cycle_at_stop": sizes[210:] == [530, 530],
        "red_control_start_observed": [p[1] for p in special6[:3]] == [
            "feff00148100aa180000000000000000000000c2",
            "feff00148100aa100001000000000000000000ba",
            "feff00148100aa100003000000000000000000ba"],
        "two_ep2_setup_commands": [p[1] for p in controls2] == [
            "feff0014010002210a00ffffffff000000000023",
            "feff001401000212060001000000000000000014"],
        "neutral_park_observed": len(parks) == 1 and "00800000800000" in parks[0][1],
        "stop_control_observed": [p[1] for p in special6[-2:]] == [
            "feff00148100aa180000000000000000000000c2",
            "feff00148100aa100001000000000000000000ba"],
        "first_move_differs_from_loop": first_packet[10:14] !=
            next(p for t, ep, p in traffic if ep == 2 and len(p) == 530 and t > first + 0.02)[10:14],
    }
    return {"input": path.name, "sea_laser_bus_device": sorted(map(list, device_keys)),
            "exact_ep2_packet_roundtrips": dict(exact_roundtrips),
            "outline_sessions": results,
            "square_transaction": {"packet_sizes": dict(Counter(sizes)),
                                   "complete_cycles": complete,
                                   "control_ep6": special6,
                                   "setup_ep2": controls2,
                                   "park_ep2": parks,
                                   "checks": checks,
                                   "offline_reference_valid": all(checks.values())}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pcap", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(analyze(args.pcap), indent=2)
    if args.output:
        args.output.write_text(result + "\n", encoding="utf-8")
    else:
        print(result)
