"""Read-only integrity check for the exact SeaMark.dll studied for red framing.

This does not initialize SeaMark or open the G2. Matching signatures establish
the code path, not safety of executing it with user-generated geometry.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct


SIGNATURES = {
    "MarkPathsSDK_entry": (0x2FD10, bytes.fromhex("55 8b ec 6a ff")),
    "GetRedPaths_entry": (0x4BC60, bytes.fromhex("55 8b ec 6a ff")),
    "SendMarkData_mode_switch": (0x47F14, bytes.fromhex("83 bd 74 ff ff ff 14")),
    "red_mode_branch": (0x4B521, bytes.fromhex("83 3a 14")),
}


def inspect(path: Path) -> dict:
    data = path.read_bytes()
    if data[:2] != b"MZ":
        raise ValueError("Not a PE DLL")
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe:pe + 4] != b"PE\0\0":
        raise ValueError("Invalid PE header")
    count, timestamp, opt_size = (struct.unpack_from("<H", data, pe + 6)[0],
                                  struct.unpack_from("<I", data, pe + 8)[0],
                                  struct.unpack_from("<H", data, pe + 20)[0])
    section_offset = pe + 24 + opt_size
    sections = []
    for i in range(count):
        base = section_offset + 40 * i
        name = data[base:base + 8].rstrip(b"\0").decode("ascii", "replace")
        virtual_size, rva, raw_size, raw_offset = struct.unpack_from("<IIII", data, base + 8)
        sections.append((name, rva, max(virtual_size, raw_size), raw_offset, raw_size))

    def at(rva: int, size: int) -> bytes:
        for _, start, extent, offset, raw_size in sections:
            if start <= rva and rva + size <= start + extent and rva + size <= start + raw_size:
                return data[offset + rva - start:offset + rva - start + size]
        raise ValueError(f"Unmapped RVA {rva:#x}")

    checks = {name: at(rva, len(expected)) == expected
              for name, (rva, expected) in SIGNATURES.items()}
    # SendMarkData subtracts 10 from the control mode before indexing its
    # switch table. Mode 0x14 therefore selects table entry 10. The selected
    # branch calls CDataMarker's virtual slot +0x134. In this exact build that
    # slot resolves to FlatMark, shared with marking preparation.
    mode20_branch = at(0x48310 + (0x14 - 10), 1)[0]
    flat_mark_va = struct.unpack("<I", at(0x8B29C + 0x134, 4))[0]
    mark_account_va = struct.unpack("<I", at(0x8B29C + 0x90, 4))[0]
    mark_continuous_va = struct.unpack("<I", at(0x8B29C + 0x94, 4))[0]
    pinned = len(data) == 744448 and timestamp == 0x6655B439
    return {"file": path.name, "sha256": hashlib.sha256(data).hexdigest(),
            "size": len(data), "pe_timestamp": f"{timestamp:08X}",
            "exact_build": pinned, "code_signatures": checks,
            "mode_0x14_switch_branch": mode20_branch,
            "mode_0x14_virtual_target": f"{flat_mark_va:08X}",
            "flat_mark_subpaths": [f"{mark_account_va:08X}", f"{mark_continuous_va:08X}"],
            "shared_flat_mark_path": (mode20_branch == 0 and flat_mark_va == 0x100485F0
                                      and mark_account_va == 0x1004A9E0
                                      and mark_continuous_va == 0x1004AFB0),
            "static_route_matches": pinned and all(checks.values())
                                    and mode20_branch == 0 and flat_mark_va == 0x100485F0
                                    and mark_account_va == 0x1004A9E0
                                    and mark_continuous_va == 0x1004AFB0,
            "device_access": False, "red_only_emission_proven": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("seamark_dll", type=Path)
    args = parser.parse_args()
    print(json.dumps(inspect(args.seamark_dll), indent=2))
