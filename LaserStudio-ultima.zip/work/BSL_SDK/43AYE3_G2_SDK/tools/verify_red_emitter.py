"""Compare USBPcap captures of a candidate emitter with a proven GLaser red frame.

Read-only. A passing trace still requires visual confirmation, and this tool
never transmits to the laser.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import struct

from analyze_g2_red_pcap import records, batch_points

RED_SETUP = {
    bytes.fromhex("feff0014010002210a00ffffffff000000000023"),
    bytes.fromhex("feff001401000212060001000000000000000014"),
}
RED_CTRL = {
    bytes.fromhex("feff00148100aa180000000000000000000000c2"),
    bytes.fromhex("feff00148100aa100001000000000000000000ba"),
    bytes.fromhex("feff00148100aa100003000000000000000000ba"),
}

def inspect(path: Path) -> dict:
    rows = list(records(path))
    devices = set()
    for _, bus, dev, ep, _, info, data, _ in rows:
        if ep == 0x80 and info == 1 and len(data) >= 12 and data[:2] == b"\x12\x01":
            if struct.unpack_from("<HH", data, 8) == (0x04B4, 0x1004):
                devices.add((bus, dev))
    if not devices:
        raise ValueError(f"{path}: no aparece SEA-LASER 04b4:1004; captura USBPcap incompleta")
    ep2, ep6 = [], []
    for t, bus, dev, ep, transfer, info, data, _ in rows:
        if (bus, dev) not in devices or transfer != 3 or info != 0 or not data:
            continue
        if ep == 2: ep2.append((t, data))
        elif ep == 6 and data[6:8] != b"\xaa\x05": ep6.append((t, data))
    setups = [p for _, p in ep2 if p in RED_SETUP]
    outlines = [(t, p, batch_points(p)) for t, p in ep2 if batch_points(p) is not None and len(p) > 26]
    parks = [p for _, p in ep2 if len(p) == 26 and batch_points(p) is not None]
    other = [p for _, p in ep2 if p not in RED_SETUP and
             not (batch_points(p) is not None and len(p) >= 26)]
    ctrl_other = [p for _, p in ep6 if p not in RED_CTRL]
    coords = [xy for _, _, points in outlines for xy in points]
    red_only = (len(setups) == 2 and set(setups) == RED_SETUP and len(outlines) >= 3
                and not other and not ctrl_other and len(parks) <= 1)
    return {
        "file": path.name, "devices": sorted(map(list, devices)),
        "ep2_packets": len(ep2), "setup": len(setups),
        "outline_batches": len(outlines), "outline_points": len(coords),
        "park_packets": len(parks), "other_ep2": [p.hex() for p in other[:10]],
        "other_ep6": [p.hex() for p in ctrl_other[:10]],
        "ep2_sizes": dict(Counter(map(lambda item: len(item[1]), ep2))),
        "bbox_dac": ([min(x for x, _ in coords), min(y for _, y in coords),
                      max(x for x, _ in coords), max(y for _, y in coords)] if coords else None),
        "red_only_transport_observed": red_only,
    }

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("reference", type=Path)
    ap.add_argument("candidate", type=Path)
    args = ap.parse_args()
    a, b = inspect(args.reference), inspect(args.candidate)
    comparison = {
        "reference": a, "candidate": b,
        "candidate_matches_red_only_transport": a["red_only_transport_observed"]
            and b["red_only_transport_observed"],
    }
    print(json.dumps(comparison, ensure_ascii=False, indent=2))
    raise SystemExit(0 if comparison["candidate_matches_red_only_transport"] else 2)

if __name__ == "__main__": main()
