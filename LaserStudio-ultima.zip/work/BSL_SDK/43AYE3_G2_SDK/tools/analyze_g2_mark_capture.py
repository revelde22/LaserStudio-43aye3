"""Read-only comparison of GLaser red framing and marking traffic.

USBPcap capture only: this tool never opens a USB device and never sends a
packet. It separates observed EP2 command families. Family 0x41 carries
position batches; family 0x46 is interleaved with 0x41 during the observed
marking runs and is reported as an opaque companion family.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import struct

from analyze_g2_red_pcap import records


def point_commands(packet: bytes, family: int):
    magic = bytes((0x02, family, 0x12, 0x00))
    return [packet[o:o + 18] for o in range(6, len(packet) - 2, 18)
            if packet[o:o + 4] == magic]


def analyze(path: Path):
    all_records = list(records(path))
    t0 = all_records[0][0]
    devices = {}
    for i, (t, bus, dev, ep, transfer, info, payload, _) in enumerate(all_records):
        if ep == 0x80 and info == 1 and len(payload) >= 12 and payload[:2] == b"\x12\x01":
            vid, pid = struct.unpack_from("<HH", payload, 8)
            devices[(bus, dev)] = (vid, pid)
    laser_keys = {key for key, vp in devices.items() if vp == (0x04B4, 0x1004)}
    if not laser_keys:
        raise ValueError("No SEA-LASER 04b4:1004 descriptor")
    traffic = []
    for t, bus, dev, ep, transfer, info, payload, _ in all_records:
        if ((bus, dev) in laser_keys and ep == 2 and transfer == 3 and info == 0
                and payload.startswith(b"\xfe\xff") and len(payload) >= 20):
            families = tuple(sorted(set(
                payload[o + 1]
                for o in range(6, len(payload) - 2, 18)
                if payload[o:o + 4] in (
                    b"\x02\x41\x12\x00",
                    b"\x02\x46\x12\x00",
                    b"\x02\x42\x12\x00",
                )
            )))
            if families:
                traffic.append((t - t0, payload, families))
    sessions = []
    for item in traffic:
        if not sessions or item[0] - sessions[-1][-1][0] > 0.5:
            sessions.append([])
        sessions[-1].append(item)
    out = []
    for group in sessions:
        pts = []
        companion_commands = Counter()
        for _, packet, _ in group:
            for command in point_commands(packet, 0x41):
                pts.append((int.from_bytes(command[8:11], "big"),
                            int.from_bytes(command[11:14], "big")))
            for command in point_commands(packet, 0x46):
                companion_commands[command.hex()] += 1
        families = Counter(f"0x{family:02x}" for _, _, fs in group for family in fs)
        item = {"start_seconds": round(group[0][0], 3),
                "end_seconds": round(group[-1][0], 3),
                "packets": len(group), "families": dict(families),
                "packet_sizes": dict(Counter(len(packet) for _, packet, _ in group)),
                "red_position_points": len(pts)}
        if pts:
            item["red_family_bounds_units"] = [min(x for x, _ in pts), min(y for _, y in pts),
                                                max(x for x, _ in pts), max(y for _, y in pts)]
        if companion_commands:
            item["companion_0x46_commands"] = [
                {"command_hex": command, "count": count}
                for command, count in companion_commands.most_common(5)
            ]
        item["classification"] = ("red_frame_candidate"
                                   if set(families) == {"0x41"} else
                                   "marking_candidate_with_companion_family"
                                   if "0x46" in families else "other")
        out.append(item)
    return {"input": path.name, "sea_laser_bus_device": sorted(map(list, laser_keys)),
            "sessions": out,
            "read_only": True,
            "marking_semantics_proven": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pcap", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(analyze(args.pcap), indent=2)
    if args.output:
        args.output.write_text(result + "\n", encoding="utf-8")
    else:
        print(result)
