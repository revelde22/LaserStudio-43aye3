"""Clasifica por sesion la trayectoria roja capturada con USBPcap.

No abre dispositivos. El resultado describe comandos observados de GLaser;
no autoriza transmitirlos desde otra aplicacion.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import struct

from analyze_g2_red_pcap import records
from g2_red_packet_codec import decode_batch, encode_batch


START_21 = bytes.fromhex("feff0014010002210a00ffffffff000000000023")
START_12 = bytes.fromhex("feff001401000212060001000000000000000014")


def classify(points):
    unique = list(dict.fromkeys(points))
    xs = [p[0] for p in unique]
    ys = [p[1] for p in unique]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    if x0 == x1 or y0 == y1:
        return "degenerate", None
    radii = [math.hypot((x - (x0+x1)/2)/(x1-x0),
                        (y - (y0+y1)/2)/(y1-y0)) for x,y in unique]
    spread = max(radii) - min(radii)
    if len(unique) >= 64 and spread <= 0.015:
        shape = "circle_outline"
    elif len(unique) >= 8 and all(
        min((x-x0)/(x1-x0), (x1-x)/(x1-x0),
            (y-y0)/(y1-y0), (y1-y)/(y1-y0)) < 0.04 for x,y in unique):
        shape = "rectangle_outline"
    else:
        shape = "other_outline"
    return shape, {"unique_coordinates":len(unique),"bbox_dac":[x0,y0,x1,y1],
                   "normalized_radius_min":round(min(radii),6),
                   "normalized_radius_max":round(max(radii),6)}


def verify(path):
    rows=list(records(path))
    devices={(bus,dev) for _,bus,dev,ep,_,info,p,_ in rows
             if ep==0x80 and info==1 and len(p)>=12 and p[:2]==b"\x12\x01"
             and struct.unpack_from("<HH",p,8)==(0x04b4,0x1004)}
    if not devices:
        raise ValueError("No se encontro SEA-LASER 04b4:1004")
    sessions=[];current={}
    for t,bus,dev,ep,transfer,info,p,_ in rows:
        if (bus,dev) not in devices or transfer!=3 or info!=0:
            continue
        if ep==2 and p==START_21:
            current={"start":t,"setup":[p],"packets":0,"other":Counter(),
                     "points":[],"ep6":[]}
            sessions.append(current)
        elif current and ep==2:
            if p==START_12:
                current["setup"].append(p)
            else:
                try:
                    cmds=decode_batch(p)
                    if encode_batch(cmds)!=p:raise ValueError("roundtrip")
                    if len(cmds)>1:
                        current["packets"]+=1
                        current["points"].extend((c.x,c.y) for c in cmds)
                except ValueError:
                    current["other"][p[6:8].hex() if len(p)>=8 else p.hex()]+=1
        elif current and ep==6 and p[6:8]!=b"\xaa\x05":
            current["ep6"].append(p.hex())
    out=[]
    for s in sessions:
        shape,metrics=classify(s["points"]) if s["points"] else ("none",None)
        out.append({"shape":shape,"geometry":metrics,"batches":s["packets"],
                    "setup_exact":s["setup"]==[START_21,START_12],
                    "other_ep2_families":dict(s["other"]),
                    "red_only_observed":s["setup"]==[START_21,START_12]
                    and s["packets"]>0 and not s["other"],
                    "ep6_controls":s["ep6"]})
    return {"file":path.name,"device":sorted(map(list,devices)),"sessions":out,
            "read_only":True,"transmission_attempted":False}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pcap",type=Path)
    args=parser.parse_args()
    print(json.dumps(verify(args.pcap),indent=2))
