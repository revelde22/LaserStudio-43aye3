"""Read-only comparison of two USBPcap red-light sessions from GLaser.

Run on a rectangle capture and an L-shaped outline capture. No USB access.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import struct

from analyze_g2_red_pcap import records
from g2_red_packet_codec import decode_batch, encode_batch


STARTS = {
    bytes.fromhex("feff0014010002210a00ffffffff000000000023"),
    bytes.fromhex("feff001401000212060001000000000000000014"),
}


def inspect(path: Path) -> dict:
    rows = list(records(path))
    devices = set()
    for _, bus, dev, endpoint, _, info, payload, _ in rows:
        if endpoint == 0x80 and info == 1 and len(payload) >= 12 and payload[:2] == b"\x12\x01":
            if struct.unpack_from("<HH", payload, 8) == (0x04B4, 0x1004):
                devices.add((bus, dev))
    if not devices:
        raise ValueError("No se encontro descriptor SEA-LASER 04b4:1004")
    batches, other, setup = [], Counter(), Counter()
    sessions = []
    current = None
    setup_order = [bytes.fromhex("feff0014010002210a00ffffffff000000000023"),
                   bytes.fromhex("feff001401000212060001000000000000000014")]
    for t, bus, dev, endpoint, transfer, info, payload, _ in rows:
        if (bus, dev) not in devices or endpoint != 2 or transfer != 3 or info != 0 or not payload:
            continue
        if payload in STARTS:
            setup[payload.hex()] += 1
            if payload == setup_order[0]:
                current = {"setup": [payload.hex()], "batches": 0, "other": Counter()}
                sessions.append(current)
            elif current is not None:
                current["setup"].append(payload.hex())
            continue
        try:
            commands = decode_batch(payload)
            if encode_batch(commands) != payload:
                raise ValueError("Batch no reproduce sus bytes")
            batches.append((t, commands))
            if current is not None:
                current["batches"] += 1
        except ValueError:
            family = payload[6:8].hex() if len(payload) >= 8 else payload.hex()
            other[family] += 1
            if current is not None:
                current["other"][family] += 1
    if not batches:
        raise ValueError("No se encontraron lotes de trayectoria roja")
    # The park command has one point at (0x800000, 0x800000); exclude it.
    drawable = [(t, c) for t, c in batches if len(c) > 1]
    if not drawable:
        raise ValueError("Solo se encontro estacionamiento; no hay trayectoria")
    coords = [(c.x, c.y) for _, group in drawable for c in group]
    unique = set(coords)
    xs, ys = zip(*unique)
    return {
        "file": path.name,
        "device": sorted(map(list, devices)),
        "setup": dict(setup),
        "other_ep2_families": dict(other),
        "batches": len(drawable),
        "points_total": len(coords),
        "unique_coordinates": len(unique),
        "bbox_dac": [min(xs), min(ys), max(xs), max(ys)],
        "unique_x": len(set(xs)),
        "unique_y": len(set(ys)),
        "first_24_coordinates": coords[:24],
        "sessions": [{"setup": s["setup"], "batches": s["batches"],
                      "other_ep2_families": dict(s["other"]),
                      "red_only_observed": s["setup"] == [x.hex() for x in setup_order]
                      and s["batches"] > 0 and not s["other"]} for s in sessions],
        "red_only_observed": not other and bool(sessions) and all(
            s["setup"] == [x.hex() for x in setup_order] and s["batches"] > 0
            and not s["other"] for s in sessions),
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("rectangulo", type=Path)
    p.add_argument("contorno_l", type=Path)
    args = p.parse_args()
    a, b = inspect(args.rectangulo), inspect(args.contorno_l)
    print(json.dumps({"rectangulo": a, "contorno_l": b,
                      "different_geometry": (a["unique_coordinates"], a["unique_x"], a["unique_y"])
                      != (b["unique_coordinates"], b["unique_x"], b["unique_y"]),
                      "both_red_only_observed": a["red_only_observed"] and b["red_only_observed"]}, indent=2))


if __name__ == "__main__":
    main()
