"""PASS/FAIL gate for a physical GLaser red-frame capture.

This is a read-only USBPcap checker. PASS means the capture has a recognized
continuous-batch shape (test3, test5, or a long uniform batch stream); it does
not authorize replay or prove fibre exclusion.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from analyze_g2_frame_transaction import analyze


def verify(path: Path):
    result = analyze(path)
    sizes = result["packet_sizes"]
    uniform_candidate = len(sizes) == 1 and result["packet_count"] >= 10
    known_test3 = result["cycle_pattern"] == [530, 530, 98]
    # test5: valid 20 mm red-frame capture using alternating 530/260-byte
    # EP2 batches. The batch size is an encoding detail, not a new protocol.
    known_test5 = result["cycle_pattern"] == [530, 260, 530] and set(sizes) == {530, 260}
    checks = {
        "sea_laser_found": result["sea_laser_bus_device"] == [[2, 4]],
        "recognized_continuous_batch_shape": known_test3 or known_test5 or uniform_candidate,
        "minimum_batches": result["packet_count"] >= 10,
        "exact_batch_roundtrip": result["exact_batch_roundtrip"] is True,
        "read_only": result["read_only"] is True,
        "no_transmission": result["transmission_attempted"] is False,
    }
    result["checks"] = checks
    result["result"] = "PASS" if all(checks.values()) else "FAIL"
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("pcap", type=Path)
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    text = json.dumps(verify(args.pcap), indent=2) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
