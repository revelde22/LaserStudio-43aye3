"""Offline codec for observed GLaser red-outline EP2 batches.

No USB, SeaMark, or device access. Unknown fields remain opaque and must not
be treated as proof that a future transmission cannot activate the fibre.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PointCommand:
    control: bytes  # Four observed bytes: timing/move flags, semantics incomplete.
    x: int  # Observed 24-bit big-endian galvo coordinate.
    y: int
    tail: bytes  # Four observed zero bytes; preserved exactly.

    def encode(self) -> bytes:
        if len(self.control) != 4 or len(self.tail) != 4:
            raise ValueError("A point command has four control and four tail bytes")
        if not (0 <= self.x < 1 << 24 and 0 <= self.y < 1 << 24):
            raise ValueError("Coordinate exceeds 24 bits")
        return (b"\x02\x41\x12\x00" + self.control
                + self.x.to_bytes(3, "big") + self.y.to_bytes(3, "big") + self.tail)


def decode_batch(packet: bytes) -> tuple[PointCommand, ...]:
    if (len(packet) < 26 or len(packet) > 530 or (len(packet) - 8) % 18
            or packet[:2] != b"\xfe\xff"
            or int.from_bytes(packet[2:4], "big") != len(packet)
            or packet[4:6] != b"\x01\x00" or packet[-2:] != b"\x00\x43"):
        raise ValueError("Not an observed EP2 point batch")
    commands = []
    for offset in range(6, len(packet) - 2, 18):
        raw = packet[offset:offset + 18]
        if raw[:4] != b"\x02\x41\x12\x00" or raw[14:] != b"\x00" * 4:
            raise ValueError("Unexpected point command or nonzero reserved field")
        commands.append(PointCommand(raw[4:8], int.from_bytes(raw[8:11], "big"),
                                     int.from_bytes(raw[11:14], "big"), raw[14:18]))
    return tuple(commands)


def encode_batch(commands: tuple[PointCommand, ...]) -> bytes:
    if not (1 <= len(commands) <= 29):
        raise ValueError("Observed batches contain 1 to 29 commands")
    body = b"".join(c.encode() for c in commands)
    size = 8 + len(body)
    return b"\xfe\xff" + size.to_bytes(2, "big") + b"\x01\x00" + body + b"\x00\x43"
