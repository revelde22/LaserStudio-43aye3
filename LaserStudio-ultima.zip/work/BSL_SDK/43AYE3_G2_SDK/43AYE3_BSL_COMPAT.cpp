#include <windows.h>
#include <wincodec.h>
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <atomic>
#include <algorithm>
#include <cwctype>
#include <cstdarg>
#define AYE_BUILD_DLL 1
#include "43AYE3_BSL_COMPAT.h"

#pragma comment(lib,"ole32.lib")
#pragma comment(lib,"windowscodecs.lib")


// 43AYE3 G2 SDK compatibility layer for the exact Gweike G2 runtime supplied
// by the user. It does NOT contain or redistribute vendor code. It dynamically
// calls the original Sea*.dll files present next to the application.
//
// SDK 3.3: physically confirmed square mark; multi-vector route remains beta.
// Vendor binaries are version-pinned. ORZX remains with the official BSLAPP-SDK.

static HMODULE g_self = nullptr;
static std::mutex g_lock;
static std::atomic_bool g_cancel_frame{false};
static std::wstring g_lastError;

static const int AYE_OK = 0;
static const int AYE_E_ARG = -1;
static const int AYE_E_RUNTIME = -2;
static const int AYE_E_VERSION = -3;
static const int AYE_E_SYMBOL = -4;
static const int AYE_E_VENDOR = -5;
static const int AYE_E_FILE = -6;
static const int AYE_E_STATE = -7;
static const int AYE_E_EXCEPTION = -8;
static const int AYE_E_MARK_LOCKED = -30;

static void seterr(const wchar_t* s){ g_lastError = s ? s : L""; }
static void seterrf(const wchar_t* fmt, ...){
    wchar_t b[2048] = {0}; va_list ap; va_start(ap,fmt); _vsnwprintf_s(b,_countof(b),_TRUNCATE,fmt,ap); va_end(ap); g_lastError=b;
}
static std::wstring dirname_of(std::wstring p){ size_t n=p.find_last_of(L"\\/"); return n==std::wstring::npos?L".":p.substr(0,n); }
static std::wstring joinp(const std::wstring&a,const std::wstring&b){ if(a.empty())return b; wchar_t c=a.back(); return a+((c==L'\\'||c==L'/')?L"":L"\\")+b; }
static bool file_exists(const std::wstring&p){ DWORD a=GetFileAttributesW(p.c_str()); return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY); }
static bool dir_exists(const std::wstring&p){ DWORD a=GetFileAttributesW(p.c_str()); return a!=INVALID_FILE_ATTRIBUTES && (a&FILE_ATTRIBUTE_DIRECTORY); }

static std::wstring module_dir(){
    wchar_t b[32768]={0}; DWORD n=GetModuleFileNameW(g_self,b,_countof(b)); if(n&&n<_countof(b))return dirname_of(b); return L".";
}
static std::wstring vendor_dir(){
    wchar_t b[32768]={0}; DWORD n=GetEnvironmentVariableW(L"G2PRO_VENDOR_DIR",b,_countof(b));
    if(n&&n<_countof(b)&&dir_exists(b)) return b;
    std::wstring d=module_dir(); if(file_exists(joinp(d,L"SeaMark.dll"))) return d;
    // Self-test lives in BSL_SDK\43AYE3_G2_SDK; vendor DLLs live two levels up
    // in G2_RUNTIME. Resolve this before depending on the caller's cwd.
    std::wstring bundled=joinp(d,L"..\\..\\G2_RUNTIME");
    if(file_exists(joinp(bundled,L"SeaMark.dll")))return bundled;
    wchar_t cwd[32768]={0}; n=GetCurrentDirectoryW(_countof(cwd),cwd); if(n&&file_exists(joinp(cwd,L"SeaMark.dll")))return cwd;
    return d;
}

static bool pe_signature(const std::wstring& path, ULONGLONG& size, DWORD& timestamp){
    WIN32_FILE_ATTRIBUTE_DATA fad={}; if(!GetFileAttributesExW(path.c_str(),GetFileExInfoStandard,&fad)) return false;
    size=((ULONGLONG)fad.nFileSizeHigh<<32)|fad.nFileSizeLow;
    HANDLE h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE)return false; IMAGE_DOS_HEADER dos={};DWORD got=0;bool ok=false;
    if(ReadFile(h,&dos,sizeof(dos),&got,nullptr)&&got==sizeof(dos)&&dos.e_magic==IMAGE_DOS_SIGNATURE){
        SetFilePointer(h,dos.e_lfanew,nullptr,FILE_BEGIN); DWORD sig=0;IMAGE_FILE_HEADER fh={};
        if(ReadFile(h,&sig,sizeof(sig),&got,nullptr)&&got==sizeof(sig)&&sig==IMAGE_NT_SIGNATURE&&ReadFile(h,&fh,sizeof(fh),&got,nullptr)&&got==sizeof(fh)){timestamp=fh.TimeDateStamp;ok=true;}
    }
    CloseHandle(h); return ok;
}

struct VendorApi {
    HMODULE base=nullptr, draw=nullptr, mark=nullptr;
    bool ready=false;

    typedef void (__stdcall *InitDllFn)();
    typedef void* (__cdecl *CreateObjectFn)();
    typedef int (__thiscall *DocNewFn)(void*);
    typedef void (__thiscall *DocAddShapeFn)(void*,void*);
    typedef int (__thiscall *ShapeSetPenFn)(void*,unsigned char);
    typedef void (__thiscall *ShapeSetDocViewFn)(void*,void*,void*);
    typedef void (__thiscall *ShapeUpdatePropsFn)(void*);
    struct POINTF2{float x,y;}; struct stPolylinePos{int nIndex;POINTF2 pt;};
    typedef void (__thiscall *PolyAddDelFn)(void*,int,stPolylinePos);

    InitDllFn initBase=nullptr, initDraw=nullptr;
    CreateObjectFn createDoc=nullptr, createPoly=nullptr;
    DocNewFn newDoc=nullptr; DocAddShapeFn addShape=nullptr;
    ShapeSetPenFn setPen=nullptr; ShapeSetDocViewFn setDocView=nullptr;
    ShapeUpdatePropsFn updateProps=nullptr; PolyAddDelFn addDel=nullptr;

    // Device symbols.
    typedef void (__thiscall *MarkCtorFn)(void*);
    typedef void (__thiscall *MarkDtorFn)(void*);
    typedef void (__thiscall *SetParamFn)(void*,void*);
    typedef int (__thiscall *InitDevicesFn)(void*,int&);
    typedef int (__thiscall *CloseAllFn)(void*);
    typedef bool (__thiscall *LoadSeaParFn)(void*,HINSTANCE);
    typedef bool (__thiscall *UnloadSeaParFn)(void*);
    typedef void (__thiscall *GetValidFn)(void*,int&);
    typedef void* (__thiscall *GetFirstAdaptorFn)(void*);
    typedef bool (__thiscall *AdaptorIsValidFn)(void*,int);
    typedef int (__thiscall *GetDevNoFn)(void*);
    typedef int (__thiscall *GetDevTypeFn)(void*);
    typedef int (__thiscall *GetUsbSpeedFn)(void*);
    typedef void (__thiscall *StopFn)(void*,int);
    typedef void* (__thiscall *CreateMarkerSimpleFn)(void*,void*,int);
    typedef void* (__thiscall *GetCtlDataFn)(void*);
    typedef bool (__thiscall *CreateMarkerAdaptorFn)(void*,void*,void*,void*);
    typedef bool (__thiscall *CreateMarkerByIndexFn)(void*,int,void*,void*);
    typedef void (__thiscall *SetMarkerFn)(void*,void*);
    typedef void* (__thiscall *GetMarkerFn)(void*);
    typedef void* (__thiscall *GetAdaptorFn)(void*);
    typedef void* (__thiscall *GetParamFn)(void*);
    typedef void* (__thiscall *GetLmcParFn)(void*);
    typedef bool (__thiscall *GotoPosFn)(void*,double,double);

    MarkCtorFn markCtor=nullptr; MarkDtorFn markDtor=nullptr; SetParamFn setParam=nullptr;
    InitDevicesFn initDevices=nullptr; CloseAllFn closeAll=nullptr; LoadSeaParFn loadSeaPar=nullptr; UnloadSeaParFn unloadSeaPar=nullptr; GetValidFn getValid=nullptr;
    GetFirstAdaptorFn getFirstAdaptor=nullptr; AdaptorIsValidFn adaptorIsValid=nullptr;
    GetDevNoFn getDevNo=nullptr; GetDevTypeFn getDevType=nullptr; GetUsbSpeedFn getUsbSpeed=nullptr;
    StopFn stop=nullptr; CreateMarkerSimpleFn createMarkerSimple=nullptr; GetCtlDataFn getCtlData=nullptr; CreateMarkerAdaptorFn createMarkerAdaptor=nullptr; CreateMarkerByIndexFn createMarkerByIndex=nullptr; SetMarkerFn setMarker=nullptr;
    GetMarkerFn getMarker=nullptr; GetAdaptorFn getAdaptor=nullptr; GetParamFn getParam=nullptr;
    GetLmcParFn getLmcPar=nullptr; GotoPosFn gotoPos=nullptr;
};
static VendorApi V;

static HMODULE load_local(const std::wstring&d,const wchar_t*n){ return LoadLibraryExW(joinp(d,n).c_str(),nullptr,LOAD_WITH_ALTERED_SEARCH_PATH); }

static int ensure_vendor(){
    if(V.ready)return 0;
    std::wstring d=vendor_dir();
    ULONGLONG bs=0,ds=0,ms=0; DWORD bt=0,dt=0,mt=0;
    bool bok=pe_signature(joinp(d,L"SeaBase.dll"),bs,bt), dok=pe_signature(joinp(d,L"SeaDraw.dll"),ds,dt), mok=pe_signature(joinp(d,L"SeaMark.dll"),ms,mt);
    if(!bok||!dok||!mok){seterrf(L"No encuentro SeaBase/SeaDraw/SeaMark en %s",d.c_str());return AYE_E_RUNTIME;}
    if(bs!=1271808ULL||bt!=0x6655B3C3UL||ds!=1851392ULL||dt!=0x6655B3E4UL||ms!=744448ULL||mt!=0x6655B439UL){
        seterrf(L"Runtime G2 distinto del validado. SeaBase=%llu/%08X SeaDraw=%llu/%08X SeaMark=%llu/%08X",bs,bt,ds,dt,ms,mt);return AYE_E_VERSION;
    }
    SetDllDirectoryW(d.c_str()); SetCurrentDirectoryW(d.c_str());
    const wchar_t* deps[]={L"libcodebar.dll",L"LPCodeAddin.dll",L"crypto3.dll",L"crypto5.0.dll",L"crypto6.0.dll"}; for(auto n:deps) if(file_exists(joinp(d,n))) load_local(d,n);
    V.base=load_local(d,L"SeaBase.dll");V.draw=load_local(d,L"SeaDraw.dll");V.mark=load_local(d,L"SeaMark.dll");
    if(!V.base||!V.draw||!V.mark){seterrf(L"LoadLibrary Sea*.dll fallo: %lu",GetLastError());return AYE_E_RUNTIME;}
#define GP(M,N,T) V.N=(T)GetProcAddress(V.M,#N)
    V.initBase=(VendorApi::InitDllFn)GetProcAddress(V.base,"_InitSeaBaseDLL@0");
    V.initDraw=(VendorApi::InitDllFn)GetProcAddress(V.draw,"_InitSeaDrawDLL@0");
    V.createDoc=(VendorApi::CreateObjectFn)GetProcAddress(V.base,"?CreateObject@CBaseDoc@@SGPAVCObject@@XZ");
    V.newDoc=(VendorApi::DocNewFn)GetProcAddress(V.base,"?OnNewDocument@CBaseDoc@@UAEHXZ");
    V.addShape=(VendorApi::DocAddShapeFn)GetProcAddress(V.base,"?AddNewShape@CBaseDoc@@UAEXPAVCBaseShape@@@Z");
    V.setPen=(VendorApi::ShapeSetPenFn)GetProcAddress(V.base,"?SetPen@CBaseShape@@UAEHE@Z");
    V.setDocView=(VendorApi::ShapeSetDocViewFn)GetProcAddress(V.base,"?SetDocView@CBaseShape@@UAEXPAVCBaseDoc@@PAVCBaseView@@@Z");
    V.updateProps=(VendorApi::ShapeUpdatePropsFn)GetProcAddress(V.base,"?UpdatePropsValue@CBaseShape@@UAEXXZ");
    V.createPoly=(VendorApi::CreateObjectFn)GetProcAddress(V.draw,"?CreateObject@CPolyLine@@SGPAVCObject@@XZ");
    V.addDel=(VendorApi::PolyAddDelFn)GetProcAddress(V.draw,"?AddDelPoint@CPolyLine@@QAEXHUstPolylinePos@@@Z");

    V.markCtor=(VendorApi::MarkCtorFn)GetProcAddress(V.mark,"??0CMarkMgr@@QAE@XZ");
    V.markDtor=(VendorApi::MarkDtorFn)GetProcAddress(V.mark,"??1CMarkMgr@@UAE@XZ");
    V.setParam=(VendorApi::SetParamFn)GetProcAddress(V.base,"?SetParam@CBaseMarkMgr@@UAEXPAVCParaMgr@@@Z");
    V.initDevices=(VendorApi::InitDevicesFn)GetProcAddress(V.mark,"?InitDevices@CMarkMgr@@UAEHAAH@Z");
    V.closeAll=(VendorApi::CloseAllFn)GetProcAddress(V.mark,"?CloseAllDevice@CMarkMgr@@UAEHXZ");
    V.loadSeaPar=(VendorApi::LoadSeaParFn)GetProcAddress(V.mark,"?loadSeaPar@CMarkMgr@@QAE_NPAUHINSTANCE__@@@Z");
    V.unloadSeaPar=(VendorApi::UnloadSeaParFn)GetProcAddress(V.mark,"?unloadSeaPar@CMarkMgr@@QAE_NXZ");
    V.getValid=(VendorApi::GetValidFn)GetProcAddress(V.mark,"?GetValidDevCount@CMarkMgr@@QAEXAAH@Z");
    V.getFirstAdaptor=(VendorApi::GetFirstAdaptorFn)GetProcAddress(V.mark,"?GetFirstAdaptor@CMarkMgr@@UAEPAVCMarkAdaptor@@XZ");
    V.adaptorIsValid=(VendorApi::AdaptorIsValidFn)GetProcAddress(V.mark,"?IsValid@CMarkAdaptor@@UAE_NH@Z");
    V.getDevNo=(VendorApi::GetDevNoFn)GetProcAddress(V.mark,"?GetDevNo@CMarkAdaptor@@UAEHXZ");
    V.getDevType=(VendorApi::GetDevTypeFn)GetProcAddress(V.mark,"?GetDevType@CMarkAdaptor@@UAEHXZ");
    V.getUsbSpeed=(VendorApi::GetUsbSpeedFn)GetProcAddress(V.mark,"?GetUsbSpeedType@CMarkMgr@@UAEHXZ");
    V.stop=(VendorApi::StopFn)GetProcAddress(V.mark,"?StopMark@CMarkAdaptor@@UAEXH@Z");
    V.createMarkerSimple=(VendorApi::CreateMarkerSimpleFn)GetProcAddress(V.mark,"?CreateMarker@CMarkMgr@@UAEPAVCDataMarker@@PAVCParaMgr@@W4MARKTYPE@@@Z");
    V.getCtlData=(VendorApi::GetCtlDataFn)GetProcAddress(V.mark,"?GetCtlData@CDataMarker@@UAEPAUtagMarkCtlData@@XZ");
    V.createMarkerAdaptor=(VendorApi::CreateMarkerAdaptorFn)GetProcAddress(V.mark,"?CreateMarker@CMarkMgr@@UAE_NPAVCMarkAdaptor@@QAUtagMarkCtlData@@PAX@Z");
    V.createMarkerByIndex=(VendorApi::CreateMarkerByIndexFn)GetProcAddress(V.mark,"?CreateMarker@CMarkMgr@@UAE_NHQAUtagMarkCtlData@@PAX@Z");
    V.setMarker=(VendorApi::SetMarkerFn)GetProcAddress(V.mark,"?SetMarker@CMarkAdaptor@@UAEXPAVCDataMarker@@@Z");
    V.getMarker=(VendorApi::GetMarkerFn)GetProcAddress(V.mark,"?GetMarker@CMarkAdaptor@@UAEPAVCDataMarker@@XZ");
    V.getAdaptor=(VendorApi::GetAdaptorFn)GetProcAddress(V.mark,"?GetAdaptor@CDataMarker@@UAEPAVCMarkAdaptor@@XZ");
    V.getParam=(VendorApi::GetParamFn)GetProcAddress(V.mark,"?GetParam@CDataMarker@@UAEPAVCParaMgr@@XZ");
    V.getLmcPar=(VendorApi::GetLmcParFn)GetProcAddress(V.mark,"?GetLmcPar@CDataMarker@@UAEPAUtagLmcPar@@XZ");
    V.gotoPos=(VendorApi::GotoPosFn)GetProcAddress(V.mark,"?GotoPosforSDK@CDataMarker@@QAE_NNN@Z");
#undef GP
    if(!V.createDoc||!V.newDoc||!V.addShape||!V.setPen||!V.setDocView||!V.createPoly||!V.addDel||
       !V.markCtor||!V.markDtor||!V.setParam||!V.initDevices||!V.closeAll||!V.loadSeaPar||!V.unloadSeaPar||!V.getValid||!V.getFirstAdaptor||!V.adaptorIsValid||!V.stop||
       !V.createMarkerSimple||!V.getCtlData||!V.createMarkerAdaptor||!V.createMarkerByIndex||!V.setMarker||!V.getMarker||!V.getAdaptor||!V.getParam||!V.getLmcPar||!V.gotoPos){
        seterr(L"Faltan símbolos necesarios en Sea*.dll.");return AYE_E_SYMBOL;
    }
    if(V.initBase)V.initBase(); if(V.initDraw)V.initDraw();
    V.ready=true; seterr(L""); return 0;
}

static bool readable_ptr(const void* p,SIZE_T bytes){
    if(!p||!bytes)return false; MEMORY_BASIC_INFORMATION m={}; if(!VirtualQuery(p,&m,sizeof(m)))return false;
    if(m.State!=MEM_COMMIT||(m.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false; uintptr_t a=(uintptr_t)p,b=a+bytes,e=(uintptr_t)m.BaseAddress+m.RegionSize; return b>=a&&b<=e;
}

struct PenState { int loops=1; double speed=1000,power=20,current=0; int frequencyHz=30000,qPulse=0,startTc=0,laserOffTc=0,endTc=0,polygonTc=0; double jumpSpeed=4000; int jumpPosTc=0,jumpDistTc=0; double endComp=0; bool pulsePoint=false; int pulseCount=0; float pulseTime=0; };
struct Job { void* doc=nullptr; std::wstring file; std::vector<void*> shapes; PenState pens[256]; bool penTouched[256]={false}; };
static std::map<std::wstring,Job*> g_jobs;
static Job* g_activeJob=nullptr;
static std::wstring keypath(const wchar_t* p){ if(!p)return L""; wchar_t full[32768]={0}; DWORD n=GetFullPathNameW(p,_countof(full),full,nullptr); std::wstring s=(n&&n<_countof(full))?full:p; std::transform(s.begin(),s.end(),s.begin(),[](wchar_t c){return (wchar_t)towlower(c);}); return s; }

static Job* getjob(const wchar_t* p){ auto it=g_jobs.find(keypath(p)); return it==g_jobs.end()?nullptr:it->second; }

static int apply_pen_to_vendor(Job* j,unsigned pen,const PenState&s){
    if(!j||!j->doc||pen>=256)return AYE_E_ARG;
    BYTE* v=(BYTE*)j->doc+0x278; BYTE* firstA=*(BYTE**)(v+4),*lastA=*(BYTE**)(v+8); BYTE* firstB=*(BYTE**)(v+0),*lastB=*(BYTE**)(v+4); BYTE* first=nullptr,*last=nullptr;
    auto good=[](BYTE*a,BYTE*b)->bool{if(!a||!b||b<a)return false;SIZE_T n=(SIZE_T)(b-a);return n%216==0&&n/216>=1&&n/216<=256;};
    if(good(firstA,lastA)){first=firstA;last=lastA;}else if(good(firstB,lastB)){first=firstB;last=lastB;}else{seterr(L"Vector tagPenPar inválido.");return AYE_E_STATE;}
    SIZE_T count=(SIZE_T)(last-first)/216; if(pen>=count||!readable_ptr(first,count*216)){seterr(L"tagPenPar fuera de rango.");return AYE_E_STATE;}
    BYTE* e=first+(SIZE_T)pen*216; int on=1,loops=std::max(1,s.loops),speed=std::max(1,(int)std::lround(s.speed)),power=std::max(0,std::min(100,(int)std::lround(s.power))); float fk=(float)(s.frequencyHz/1000.0);
    memcpy(e+0,&on,4); memcpy(e+36,&loops,4); memcpy(e+40,&speed,4); memcpy(e+44,&power,4); memcpy(e+56,&fk,4); return 0;
}

// No STL objects in these wrappers: safe to protect with SEH in MSVC x86.
static int safe_newdoc(void* doc){ __try{return V.newDoc(doc);}__except(EXCEPTION_EXECUTE_HANDLER){return -999;} }
static int safe_add_point(void* pl,int idx,float x,float y){ __try{VendorApi::stPolylinePos sp;sp.nIndex=idx;sp.pt.x=x;sp.pt.y=y;V.addDel(pl,1,sp);return 1;}__except(EXCEPTION_EXECUTE_HANDLER){return 0;} }
static int safe_attach_shape(void* pl,void*doc,int pen){ __try{V.setPen(pl,(unsigned char)std::max(0,std::min(255,pen)));V.setDocView(pl,doc,nullptr);if(V.updateProps)V.updateProps(pl);V.addShape(doc,pl);return 1;}__except(EXCEPTION_EXECUTE_HANDLER){return 0;} }
static int aye_seh_capture(EXCEPTION_POINTERS*ep,DWORD*code,void**addr){if(code)*code=(ep&&ep->ExceptionRecord)?ep->ExceptionRecord->ExceptionCode:0xE0000001;if(addr)*addr=(ep&&ep->ExceptionRecord)?ep->ExceptionRecord->ExceptionAddress:nullptr;return EXCEPTION_EXECUTE_HANDLER;}
// ORZX serialization requires the official BSLAPP-SDK. The SeaDraw private
// SaveOrz entry point is deliberately never called by this compatibility DLL.

static int add_poly(Job*j,const std::vector<std::pair<float,float>>&pts,int pen){
    if(!j||pts.size()<2)return AYE_E_ARG; void* pl=V.createPoly(); if(!pl){seterr(L"CPolyLine::CreateObject devolvió NULL.");return AYE_E_VENDOR;}
    for(size_t i=0;i<pts.size();++i)if(!safe_add_point(pl,(int)i,pts[i].first,pts[i].second)){seterr(L"Excepción en CPolyLine::AddDelPoint.");return AYE_E_EXCEPTION;}
    if(!safe_attach_shape(pl,j->doc,pen)){seterr(L"Excepción al enlazar CPolyLine al CBaseDoc.");return AYE_E_EXCEPTION;}
    j->shapes.push_back(pl); return 0;
}

struct PointFCompat{float x,y;};

AYE_API int __cdecl BSL_NewFile(wchar_t* filePath){
    std::lock_guard<std::mutex> lk(g_lock); if(!filePath||!*filePath)return AYE_E_ARG; int rc=ensure_vendor();if(rc)return rc;
    std::wstring k=keypath(filePath); auto old=g_jobs.find(k);if(old!=g_jobs.end()){if(g_activeJob==old->second)g_activeJob=nullptr;delete old->second;g_jobs.erase(old);} void* doc=V.createDoc();if(!doc){seterr(L"No se pudo crear CBaseDoc.");return AYE_E_VENDOR;}
    int nr=safe_newdoc(doc);if(nr!=1){seterrf(L"CBaseDoc::OnNewDocument devolvió %d.",nr);return AYE_E_VENDOR;}
    Job*j=new Job();j->doc=doc;j->file=filePath;g_jobs[k]=j;g_activeJob=j;seterr(L"");return 0;
}

AYE_API int __cdecl BSL_SetPenParam(wchar_t* filePath,unsigned int pen,int loops,double speed,double power,double current,int frequencyHz,int qPulse,int startTc,int laserOffTc,int endTc,int polygonTc,double jumpSpeed,int jumpPosTc,int jumpDistTc,double endComp,bool pulsePoint,int pulseCount,float pulseTime){
    std::lock_guard<std::mutex> lk(g_lock); Job*j=getjob(filePath);if(!j||pen>=256)return AYE_E_STATE;PenState&s=j->pens[pen];s.loops=loops;s.speed=speed;s.power=power;s.current=current;s.frequencyHz=frequencyHz;s.qPulse=qPulse;s.startTc=startTc;s.laserOffTc=laserOffTc;s.endTc=endTc;s.polygonTc=polygonTc;s.jumpSpeed=jumpSpeed;s.jumpPosTc=jumpPosTc;s.jumpDistTc=jumpDistTc;s.endComp=endComp;s.pulsePoint=pulsePoint;s.pulseCount=pulseCount;s.pulseTime=pulseTime;j->penTouched[pen]=true;return apply_pen_to_vendor(j,pen,s);
}

AYE_API int __cdecl BSL_GetPenParam(wchar_t* filePath,unsigned int pen,int*loops,double*speed,double*power,double*current,int*frequencyHz,int*qPulse,int*startTc,int*laserOffTc,int*endTc,int*polygonTc,double*jumpSpeed,int*jumpPosTc,int*jumpDistTc,double*endComp,bool*pulsePoint,int*pulseCount,float*pulseTime){
    std::lock_guard<std::mutex> lk(g_lock);Job*j=getjob(filePath);if(!j||pen>=256)return AYE_E_STATE;const PenState&s=j->pens[pen];if(loops)*loops=s.loops;if(speed)*speed=s.speed;if(power)*power=s.power;if(current)*current=s.current;if(frequencyHz)*frequencyHz=s.frequencyHz;if(qPulse)*qPulse=s.qPulse;if(startTc)*startTc=s.startTc;if(laserOffTc)*laserOffTc=s.laserOffTc;if(endTc)*endTc=s.endTc;if(polygonTc)*polygonTc=s.polygonTc;if(jumpSpeed)*jumpSpeed=s.jumpSpeed;if(jumpPosTc)*jumpPosTc=s.jumpPosTc;if(jumpDistTc)*jumpDistTc=s.jumpDistTc;if(endComp)*endComp=s.endComp;if(pulsePoint)*pulsePoint=s.pulsePoint;if(pulseCount)*pulseCount=s.pulseCount;if(pulseTime)*pulseTime=s.pulseTime;return 0;
}

AYE_API int __cdecl BSL_AddLinesToFile2(wchar_t* filePath,void* pointsXYFloat,int lineCount,int*pointCounts,wchar_t*,int pen){
    std::lock_guard<std::mutex> lk(g_lock);Job*j=getjob(filePath);if(!j||!pointsXYFloat||lineCount<=0||!pointCounts)return AYE_E_ARG;PointFCompat*p=(PointFCompat*)pointsXYFloat;size_t off=0;
    for(int l=0;l<lineCount;++l){int n=pointCounts[l];if(n<2||n>10000000)return AYE_E_ARG;std::vector<std::pair<float,float>> pts;pts.reserve((size_t)n);for(int i=0;i<n;++i){float x=p[off+i].x,y=p[off+i].y;if(!_finite(x)||!_finite(y))return AYE_E_ARG;pts.emplace_back(x,y);}off+=(size_t)n;int rc=add_poly(j,pts,pen);if(rc)return rc;}return 0;
}

static int load_wic_bgra(const wchar_t*path,UINT&w,UINT&h,std::vector<BYTE>&pixels){
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);bool uninit=SUCCEEDED(ci);IWICImagingFactory*f=nullptr;IWICBitmapDecoder*d=nullptr;IWICBitmapFrameDecode*fr=nullptr;IWICFormatConverter*c=nullptr;int rc=AYE_E_FILE;
    if(SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&f)))&&SUCCEEDED(f->CreateDecoderFromFilename(path,nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&d))&&SUCCEEDED(d->GetFrame(0,&fr))&&SUCCEEDED(f->CreateFormatConverter(&c))&&SUCCEEDED(c->Initialize(fr,GUID_WICPixelFormat32bppBGRA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom))&&SUCCEEDED(c->GetSize(&w,&h))&&w&&h){UINT stride=w*4;pixels.resize((size_t)stride*h);if(SUCCEEDED(c->CopyPixels(nullptr,stride,(UINT)pixels.size(),pixels.data())))rc=0;}
    if(c)c->Release();if(fr)fr->Release();if(d)d->Release();if(f)f->Release();if(uninit)CoUninitialize();return rc;
}

AYE_API int __cdecl BSL_AddBmpToFile(wchar_t*filePath,wchar_t*imagePath,wchar_t*,double widthMm,double heightMm,double centerX,double centerY,double rotationDeg,int pen){
    std::lock_guard<std::mutex> lk(g_lock);Job*j=getjob(filePath);if(!j||!imagePath||widthMm<=0||heightMm<=0)return AYE_E_ARG;UINT iw=0,ih=0;std::vector<BYTE> px;int rc=load_wic_bgra(imagePath,iw,ih,px);if(rc){seterrf(L"No pude leer imagen: %s",imagePath);return rc;}
    int maxAxis=2400;wchar_t eb[32]={0};DWORD en=GetEnvironmentVariableW(L"AYE_RASTER_MAX_AXIS",eb,_countof(eb));if(en)maxAxis=std::max(256,_wtoi(eb));UINT step=std::max<UINT>(1,(std::max(iw,ih)+maxAxis-1)/maxAxis);
    int threshold=128;en=GetEnvironmentVariableW(L"AYE_RASTER_THRESHOLD",eb,_countof(eb));if(en)threshold=std::max(0,std::min(255,_wtoi(eb)));
    double rad=rotationDeg*3.14159265358979323846/180.0,cs=cos(rad),sn=sin(rad);auto mappt=[&](double u,double v){double lx=(u-0.5)*widthMm,ly=(v-0.5)*heightMm;return std::pair<float,float>((float)(centerX+lx*cs-ly*sn),(float)(centerY+lx*sn+ly*cs));};
    size_t runs=0;for(UINT y=0;y<ih;y+=step){UINT x=0;while(x<iw){auto dark=[&](UINT xx)->bool{const BYTE*b=&px[((size_t)y*iw+xx)*4];int lum=(int)(0.114*b[0]+0.587*b[1]+0.299*b[2]);return b[3]>16&&lum<threshold;};while(x<iw&&!dark(x))x+=step;if(x>=iw)break;UINT s=x;while(x<iw&&dark(x))x+=step;UINT e=std::min(iw,x);double u0=(double)s/iw,u1=(double)e/iw,v=((double)y+0.5*step)/ih;auto a=mappt(u0,v),b=mappt(u1,v);std::vector<std::pair<float,float>> line={a,b};rc=add_poly(j,line,pen);if(rc)return rc;if(++runs>1000000){seterr(L"Imagen demasiado compleja (>1.000.000 trazos raster).");return AYE_E_STATE;}}}
    if(!runs){seterr(L"La imagen no contiene píxeles oscuros con el umbral actual.");return AYE_E_STATE;}return 0;
}

AYE_API int __cdecl BSL_SaveEntLibToFile(wchar_t*filePath){
    (void)filePath;
    seterr(L"ORZX requiere la DLL oficial BSLAPP-SDK 5.x; 43AYE3_BSL_COMPAT no implementa guardado.");
    return AYE_E_STATE;
}

AYE_API int __cdecl BSL_UnLoadDataFile(wchar_t*filePath){std::lock_guard<std::mutex>lk(g_lock);auto it=g_jobs.find(keypath(filePath));if(it!=g_jobs.end()){if(g_activeJob==it->second)g_activeJob=nullptr;delete it->second;g_jobs.erase(it);}return 0;}

// -------- Device / framing layer --------
struct DevCtx{void*pm=nullptr;void*mm=nullptr;void*adaptor=nullptr;void*marker=nullptr;void*ctl=nullptr;void (__cdecl *ctlFree)(void*)=nullptr;int initRc=0,initRef=0,valid=0,isvalid=0;bool markCtor=false,seaParLoaded=false,closed=true;};
static DevCtx D;

struct ConnectResult{int phase,rc,ref,valid,isvalid,loaded,configEntries;void*pm;void*adaptor;DWORD seh;void*addr;};
static int connect_filter(EXCEPTION_POINTERS*ep,ConnectResult*r){if(r){r->seh=(ep&&ep->ExceptionRecord)?ep->ExceptionRecord->ExceptionCode:0xE0000001;r->addr=(ep&&ep->ExceptionRecord)?ep->ExceptionRecord->ExceptionAddress:nullptr;}return EXCEPTION_EXECUTE_HANDLER;}
static ConnectResult connect_protected(void*mm,HINSTANCE module,VendorApi::MarkCtorFn ctor,VendorApi::LoadSeaParFn load,VendorApi::InitDevicesFn init,VendorApi::GetValidFn gv,VendorApi::GetFirstAdaptorFn ga,VendorApi::AdaptorIsValidFn iv){
    ConnectResult r={};
    __try{
        r.phase=1;ctor(mm);
        r.phase=2;r.loaded=load(mm,module)?1:0;
        r.phase=3;r.pm=*(void**)((BYTE*)mm+0x08);
        if(r.pm){BYTE*first=*(BYTE**)((BYTE*)r.pm+0x36C),*last=*(BYTE**)((BYTE*)r.pm+0x370);
            if(first&&last&&(uintptr_t)last>(uintptr_t)first&&((uintptr_t)last-(uintptr_t)first)%0x22A0==0)
                r.configEntries=(int)(((uintptr_t)last-(uintptr_t)first)/0x22A0);}
        if(r.loaded&&r.pm&&r.configEntries>0){
            r.phase=4;r.rc=init(mm,r.ref);
            r.phase=5;gv(mm,r.valid);
            r.phase=6;r.adaptor=ga(mm);if(r.adaptor)r.isvalid=iv(r.adaptor,1)?1:0;
        }
        r.phase=7;
    }__except(connect_filter(GetExceptionInformation(),&r)){}
    return r;
}

static int connect_locked(){
    int vr=ensure_vendor();if(vr)return vr;if(D.mm&&D.adaptor&&D.isvalid==1)return 0;
    if(D.mm){seterr(L"Estado de dispositivo inconsistente; reinicia la aplicacion.");return AYE_E_STATE;}
    D.mm=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,0x320);
    if(!D.mm){seterr(L"Sin memoria para CMarkMgr.");return AYE_E_STATE;}
    ConnectResult r=connect_protected(D.mm,(HINSTANCE)V.mark,V.markCtor,V.loadSeaPar,V.initDevices,V.getValid,V.getFirstAdaptor,V.adaptorIsValid);
    D.markCtor=r.phase>=1;D.seaParLoaded=r.pm!=nullptr;D.pm=r.pm;D.initRc=r.rc;D.initRef=r.ref;D.valid=r.valid;D.adaptor=r.adaptor;D.isvalid=r.isvalid;D.closed=false;
    if(r.seh){seterrf(L"Excepcion cargando configuracion G2 fase %d: 0x%08X en %p",r.phase,r.seh,r.addr);return AYE_E_EXCEPTION;}
    if(!r.loaded||!D.pm||r.configEntries!=1){seterrf(L"Configuracion G2 no lista. loadSeaPar=%d Param=%p Entradas=%d",r.loaded,D.pm,r.configEntries);return AYE_E_STATE;}
    if(!(D.initRc==1&&D.initRef>0&&D.valid==1&&D.adaptor&&D.isvalid==1)){seterrf(L"G2 no lista. Init=%d Ref=%d Valid=%d IsValid=%d",D.initRc,D.initRef,D.valid,D.isvalid);return AYE_E_STATE;}
    seterr(L"");return 0;
}

static int ensure_marker_locked(){
    int rc=connect_locked();if(rc)return rc;if(D.marker)return 0;
    // The native control route in AYE_ProbeMarker has passed on the user's G2.
    // AYE_FramePolyline can move the red point after that probe. Without it,
    // the older CreateMarker(CParaMgr*, MARKTYPE) path is unverified and may
    // dereference an empty CParaMgr+0x36C vector. Do not use that path.
    BYTE* first=*(BYTE**)((BYTE*)D.pm+0x36C);
    BYTE* last=*(BYTE**)((BYTE*)D.pm+0x370);
    if(!first||!last||(uintptr_t)last<=(uintptr_t)first||
       ((uintptr_t)last-(uintptr_t)first)%0x22A0!=0||
       !readable_ptr(first,0x22A0)){
        seterr(L"ENCUADRE BLOQUEADO: CParaMgr no tiene configuracion de marcador (vector +0x36C vacio). Conexion USB correcta, inicializacion de parametros pendiente. No se llamo a CreateMarker ni se activo el laser.");
        return AYE_E_STATE;
    }
    // The older CreateMarker(CParaMgr*, MARKTYPE) bridge has not been
    // physically validated. A populated vector alone does not establish its
    // ABI or the correctness of red-light calibration.
    seterr(L"ENCUADRE BLOQUEADO: parametros presentes, pero la ABI de CreateMarker y la calibracion de luz roja aun no estan validadas. No se emitio ningun comando de movimiento.");
    return AYE_E_STATE;
#if 0 // Re-enable only after the exact vendor call chain is validated.
    __try{D.marker=V.createMarkerSimple(D.mm,D.pm,0);if(!D.marker){seterr(L"CreateMarker(CParaMgr*,MARKTYPE) devolvió NULL.");return AYE_E_VENDOR;}
        // Exact SeaMark build: CDataMarker+0x0C is its CMarkAdaptor pointer.
        *(void**)((BYTE*)D.marker+0x0C)=D.adaptor;V.setMarker(D.adaptor,D.marker);
        void*back=V.getAdaptor(D.marker);void*param=V.getParam(D.marker);void*lmc=V.getLmcPar(D.marker);void*fromAdaptor=V.getMarker(D.adaptor);
        if(back!=D.adaptor||param!=D.pm||!lmc||fromAdaptor!=D.marker){seterrf(L"Marker incompleto. Back=%p Param=%p Lmc=%p AdaptorMarker=%p",back,param,lmc,fromAdaptor);return AYE_E_STATE;}
    }__except(EXCEPTION_EXECUTE_HANDLER){seterrf(L"Excepción creando CDataMarker: 0x%08X",GetExceptionCode());return AYE_E_EXCEPTION;}return 0;
#endif
}

AYE_API int __cdecl AYE_GetVersion(wchar_t*outText,int cch){if(!outText||cch<=0)return AYE_E_ARG;wcsncpy_s(outText,cch,L"43AYE3 Laser Studio G2 V1 / Sea* 2024-05-28",_TRUNCATE);return 0;}
AYE_API int __cdecl AYE_GetLastError(wchar_t*outText,int cch){if(!outText||cch<=0)return AYE_E_ARG;std::lock_guard<std::mutex>lk(g_lock);wcsncpy_s(outText,cch,g_lastError.c_str(),_TRUNCATE);return 0;}
AYE_API int __cdecl AYE_GetCapabilities(unsigned int*outFlags){
    if(!outFlags)return AYE_E_ARG;
    *outFlags=AYE_CAP_DEVICE_CONNECT|AYE_CAP_DEVICE_STOP|
              AYE_CAP_MARKER_ASSOCIATION|AYE_CAP_RED_POINT_MOVEMENT|
              AYE_CAP_DOCUMENT_EDIT;
    // Multiple vector shapes and per-layer parameter combinations require final physical validation.
    return 0;
}
AYE_API int __cdecl AYE_DeviceConnect(){std::lock_guard<std::mutex>lk(g_lock);return connect_locked();}
AYE_API int __cdecl AYE_DeviceGetInfo(AYE_DeviceInfo*info){if(!info)return AYE_E_ARG;std::lock_guard<std::mutex>lk(g_lock);int rc=connect_locked();if(rc)return rc;info->connected=1;info->valid_devices=D.valid;info->device_no=V.getDevNo?V.getDevNo(D.adaptor):0;info->device_type=V.getDevType?V.getDevType(D.adaptor):308;info->usb_speed_type=V.getUsbSpeed?V.getUsbSpeed(D.mm):-1;return 0;}
static int protected_stop_call(){
    __try { V.stop(D.adaptor,1); return 0; }
    __except(EXCEPTION_EXECUTE_HANDLER) { seterrf(L"Excepción en STOP: 0x%08X",GetExceptionCode()); return AYE_E_EXCEPTION; }
}

static int protected_frame_call(const AYE_PointD*pts,int count,int repeats,int delayMs){
    __try {
        V.stop(D.adaptor,1);
        for(int r=0;r<repeats;++r){
            for(int i=0;i<count;++i){
                if(g_cancel_frame.load(std::memory_order_acquire)){
                    V.stop(D.adaptor,1);
                    seterr(L"Recorrido de punto rojo cancelado por STOP.");
                    return AYE_E_STATE;
                }
                double x=pts[i].x,y=pts[i].y;
                if(!_finite(x)||!_finite(y)||fabs(x)>80.0||fabs(y)>80.0){seterr(L"Punto de encuadre fuera del rango lógico ±80 mm.");V.stop(D.adaptor,1);return AYE_E_ARG;}
                if(!V.gotoPos(D.marker,x,y)){seterrf(L"GotoPosforSDK devolvió false en punto %d (%.3f, %.3f).",i,x,y);V.stop(D.adaptor,1);return AYE_E_VENDOR;}
                // STOP can request cancellation while this thread owns g_lock.
                // Keep its response bounded by a short sleep slice.
                for(int elapsed=0;elapsed<delayMs;){
                    if(g_cancel_frame.load(std::memory_order_acquire)){
                        V.stop(D.adaptor,1);
                        seterr(L"Recorrido de punto rojo cancelado por STOP.");
                        return AYE_E_STATE;
                    }
                    int slice=std::min(10,delayMs-elapsed);
                    Sleep((DWORD)slice);
                    elapsed+=slice;
                }
            }
        }
        V.stop(D.adaptor,1); return 0;
    }
    __except(EXCEPTION_EXECUTE_HANDLER) { seterrf(L"Excepción en encuadre: 0x%08X",GetExceptionCode()); return AYE_E_EXCEPTION; }
}

static void protected_close_vendor(){
    __try {
        if(D.adaptor&&V.stop)V.stop(D.adaptor,1);
        if(D.mm&&V.closeAll)V.closeAll(D.mm);
        if(D.mm&&D.seaParLoaded&&V.unloadSeaPar)V.unloadSeaPar(D.mm);
        if(D.markCtor&&V.markDtor)V.markDtor(D.mm);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}

AYE_API int __cdecl AYE_Stop(){
    g_cancel_frame.store(true,std::memory_order_release);
    std::lock_guard<std::mutex>lk(g_lock);
    int rc=connect_locked();
    if(!rc)rc=protected_stop_call();
    g_cancel_frame.store(false,std::memory_order_release);
    return rc;
}

AYE_API int __cdecl AYE_FramePolyline(const AYE_PointD*pts,int count,int repeats,int delayMs){
    if(!pts||count<2)return AYE_E_ARG;repeats=std::max(1,std::min(50,repeats));delayMs=std::max(1,std::min(1000,delayMs));
    std::lock_guard<std::mutex>lk(g_lock);
    if(g_cancel_frame.load(std::memory_order_acquire)){
        seterr(L"STOP pendiente; no se inicia recorrido de punto rojo.");
        return AYE_E_STATE;
    }
    int rc=ensure_marker_locked();if(rc)return rc;
    if(g_cancel_frame.load(std::memory_order_acquire)){
        seterr(L"STOP pendiente; no se inicia recorrido de punto rojo.");
        return AYE_E_STATE;
    }
    rc=protected_frame_call(pts,count,repeats,delayMs);
    if(rc==0)seterr(L"Comandos de posicion enviados y STOP ejecutado. Confirmacion visual pendiente.");
    return rc;
}

AYE_API int __cdecl AYE_DeviceClose(){
    g_cancel_frame.store(true,std::memory_order_release);
    std::lock_guard<std::mutex>lk(g_lock);if(!D.mm&&!D.pm){g_cancel_frame.store(false,std::memory_order_release);return 0;}protected_close_vendor();
    if(D.ctl&&D.ctlFree)D.ctlFree(D.ctl);
    if(D.mm)HeapFree(GetProcessHeap(),0,D.mm);D=DevCtx();g_cancel_frame.store(false,std::memory_order_release);return 0;
}

static int marker_probe_protected(DWORD*seh,void**addr,void**marker){
    *seh=0;*addr=nullptr;*marker=nullptr;
    __try{*marker=V.createMarkerSimple(D.mm,D.pm,0);return *marker?0:AYE_E_VENDOR;}
    __except(aye_seh_capture(GetExceptionInformation(),seh,addr)){return AYE_E_EXCEPTION;}
}
struct MarkerLinks {void*adaptor;void*param;void*lmc;void*adaptorMarker;DWORD seh;void*addr;};
static MarkerLinks read_marker_links_protected(void*marker){
    MarkerLinks r={};
    __try {
        r.adaptor=V.getAdaptor(marker);
        r.param=V.getParam(marker);
        r.lmc=V.getLmcPar(marker);
        r.adaptorMarker=V.getMarker(D.adaptor);
    } __except(aye_seh_capture(GetExceptionInformation(),&r.seh,&r.addr)) {}
    return r;
}
struct NativeCtlResult {int initialized;int associated;DWORD seh;void*addr;};
static NativeCtlResult native_ctl_protected(void*ctl,void*initializer){
    NativeCtlResult r={};
    __try {
        // SeaMark's own 0x70-byte initializer uses ESI, as in its
        // CMarkMgr red-light caller. Exact PE build checked by ensure_vendor.
        __asm {
            mov esi, ctl
            call initializer
        }
        r.initialized=1;
        // The original red-light caller passes index 0, the initialized
        // control object, and NULL. No GotoPos, Frame or Mark call here.
        r.associated=V.createMarkerByIndex(D.mm,0,ctl,nullptr)?1:0;
    } __except(aye_seh_capture(GetExceptionInformation(),&r.seh,&r.addr)) {}
    return r;
}
static void* get_marker_protected(DWORD*seh,void**addr){
    *seh=0;*addr=nullptr;
    __try {return V.getMarker(D.adaptor);}
    __except(aye_seh_capture(GetExceptionInformation(),seh,addr)){return nullptr;}
}
static void* get_ctl_protected(void*marker,DWORD*seh,void**addr){
    *seh=0;*addr=nullptr;
    __try {return V.getCtlData(marker);}
    __except(aye_seh_capture(GetExceptionInformation(),seh,addr)){return nullptr;}
}
AYE_API int __cdecl AYE_ProbeMarker(){
    std::lock_guard<std::mutex>lk(g_lock);int rc=connect_locked();if(rc)return rc;
    if(D.ctl){seterr(L"Prueba nativa ya ejecutada en esta conexion.");return AYE_E_STATE;}
    BYTE*initializer=(BYTE*)V.mark+0x73EE0;
    static const BYTE signature[]={0x8D,0x4E,0x60,0xE8,0x38,0x23,0xFD,0xFF};
    if(!readable_ptr(initializer,sizeof(signature))||memcmp(initializer,signature,sizeof(signature))){seterr(L"Inicializador nativo de tagMarkCtlData no coincide con el runtime validado.");return AYE_E_VERSION;}
    // Use the exact new/delete imports used at SeaMark+0x30D5D/0x30DDC.
    // They are ordinal imports from MFC100U in this pinned SeaMark build.
    if(!readable_ptr((BYTE*)V.mark+0x88BEC,sizeof(void*))||!readable_ptr((BYTE*)V.mark+0x88C00,sizeof(void*))){seterr(L"Tabla de asignacion nativa no legible.");return AYE_E_VERSION;}
    typedef void* (__cdecl *VendorNewFn)(size_t);
    VendorNewFn alloc=*(VendorNewFn*)((BYTE*)V.mark+0x88BEC);
    D.ctlFree=*(void (__cdecl **)(void*))((BYTE*)V.mark+0x88C00);
    if(!alloc||!D.ctlFree){seterr(L"No se encontro el asignador nativo usado por SeaMark.");return AYE_E_RUNTIME;}
    D.ctl=alloc(0x70);
    if(!D.ctl){seterr(L"No se pudo reservar tagMarkCtlData nativo.");return AYE_E_STATE;}
    memset(D.ctl,0,0x70);
    NativeCtlResult result=native_ctl_protected(D.ctl,initializer);
    DWORD markerSeh=0;void*markerAddr=nullptr;
    void*marker=get_marker_protected(&markerSeh,&markerAddr);
    MarkerLinks links={};
    if(marker&&!markerSeh)links=read_marker_links_protected(marker);
    void*ctlBack=nullptr;DWORD ctlSeh=0;void*ctlAddr=nullptr;
    if(marker&&!markerSeh&&!links.seh)ctlBack=get_ctl_protected(marker,&ctlSeh,&ctlAddr);
    D.marker=marker;
    seterrf(L"NativeCtl=%p Initialized=%d Associated=%d AssocSEH=0x%08X Addr=%p AdaptorMarker=%p MarkerSEH=0x%08X Addr=%p Back=%p ExpectedAdaptor=%p Param=%p ExpectedParam=%p Lmc=%p CtlBack=%p CtlSEH=0x%08X Addr=%p LinkSEH=0x%08X. Sin orden de trayectoria ni marcado.",
            D.ctl,result.initialized,result.associated,result.seh,result.addr,marker,markerSeh,markerAddr,links.adaptor,D.adaptor,links.param,D.pm,links.lmc,ctlBack,ctlSeh,ctlAddr,links.seh);
    if(result.seh||markerSeh||links.seh||ctlSeh)return AYE_E_EXCEPTION;
    return result.initialized&&result.associated&&marker&&links.adaptor==D.adaptor&&links.param==D.pm&&links.lmc?0:AYE_E_STATE;
}

// Three pointers are the exact std::vector layout used by this SeaMark build.
// The output vector stores 24-byte tagPathData objects, per SeaMark+0x4D580.
struct VendorVector3 { BYTE* first; BYTE* last; BYTE* capacity; };
struct RedPathProbeResult { int ok,count; DWORD seh; void* addr; };
static RedPathProbeResult prepare_red_paths_protected(void* marker,void* lmc,
        VendorVector3* shapes,void* selected,int mode){
    RedPathProbeResult r={};
    typedef void (__thiscall *VectorCtor)(void*);
    typedef void (__thiscall *VectorDtor)(void*);
    typedef bool (__thiscall *GetRedPathsFn)(void*,const void*,void*,void*,bool);
    VectorCtor ctor=(VectorCtor)((BYTE*)V.mark+0x4D4F0);
    VectorDtor dtor=(VectorDtor)((BYTE*)V.mark+0x4D520);
    GetRedPathsFn get=(GetRedPathsFn)GetProcAddress(V.mark,
        "?GetRedPaths@CDataMarker@@UAE_NABV?$vector@PAVCBaseShape@@V?$allocator@PAVCBaseShape@@@std@@@std@@PAVCBaseShape@@AAV?$vector@UtagPathData@@V?$allocator@UtagPathData@@@std@@@3@_N@Z");
    if(!get||!readable_ptr((void*)ctor,5)||!readable_ptr((void*)dtor,5))return r;
    int* redMode=(int*)((BYTE*)lmc+0x21F0);
    int previous=*redMode;
    VendorVector3 output={};bool constructed=false;
    __try {
        *redMode=mode;
        ctor(&output);constructed=true;
        r.ok=get(marker,shapes,selected,&output,false)?1:0;
        if(output.first&&output.last&&output.last>=output.first&&
           (output.last-output.first)%24==0&&readable_ptr(output.first,
           (SIZE_T)(output.last-output.first))){
            r.count=(int)((output.last-output.first)/24);
        }
        if(constructed)dtor(&output);
        *redMode=previous;
    } __except(aye_seh_capture(GetExceptionInformation(),&r.seh,&r.addr)) {
        // Restore the mode even after an exception. We deliberately avoid a
        // second vendor call on the damaged vector in the exception handler.
        __try {*redMode=previous;} __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    return r;
}

AYE_API int __cdecl AYE_ProbeRedPaths(int mode,int*pathCount){
    if(!pathCount||!(mode==3||mode==4))return AYE_E_ARG;
    *pathCount=0;
    std::lock_guard<std::mutex>lk(g_lock);
    if(!D.marker||!g_activeJob||g_activeJob->shapes.empty()){
        seterr(L"Primero crea un documento con lineas y ejecuta AYE_ProbeMarker.");
        return AYE_E_STATE;
    }
    void*lmc=V.getLmcPar(D.marker);
    if(!lmc||!readable_ptr((BYTE*)lmc+0x21F0,4)){
        seterr(L"tagLmcPar no legible.");return AYE_E_STATE;
    }
    auto&v=g_activeJob->shapes;
    VendorVector3 shapes={(BYTE*)v.data(),(BYTE*)(v.data()+v.size()),
                          (BYTE*)(v.data()+v.size())};
    RedPathProbeResult r=prepare_red_paths_protected(D.marker,lmc,&shapes,
                                                     v.front(),mode);
    *pathCount=r.count;
    seterrf(L"GetRedPaths modo=%d resultado=%d rutas=%d SEH=0x%08X en %p. Solo geometria; no se envio USB.",
            mode,r.ok,r.count,r.seh,r.addr);
    if(r.seh)return AYE_E_EXCEPTION;
    return r.ok&&r.count>0?0:AYE_E_VENDOR;
}

// Layouts from SeaMark's tagDevDocs (20 bytes) and its per-document 36-byte
// entries. Their vectors contain native shape pointers and native pen data.
struct NativeDocEntry36 {
    void*doc;
    VendorVector3 shapes;
    int reserved;
    VendorVector3 pens;
    int reserved2;
};
struct NativeDevDocs20 {void*deviceIdCString;VendorVector3 docs;int reserved;};
static_assert(sizeof(NativeDocEntry36)==36,"G2 x86 doc entry ABI");
static_assert(sizeof(NativeDevDocs20)==20,"G2 x86 device docs ABI");
struct NativeDoMarkResult {int called,stop,devIdReady;DWORD seh;void*addr;};
static DWORD WINAPI domark_stop_watchdog(LPVOID adaptor){
    Sleep(1000);
    __try {if(adaptor&&V.stop)V.stop(adaptor,1);}
    __except(EXCEPTION_EXECUTE_HANDLER) {}
    return 0;
}
struct ContinuousRedWatchdog {void* adaptor;HANDLE cancel,stopEvent,parent;};
static DWORD WINAPI domark_continuous_watchdog(LPVOID arg){
    auto*ctx=(ContinuousRedWatchdog*)arg;
    HANDLE handles[]={ctx->cancel,ctx->stopEvent,ctx->parent};
    // A frame runs until STOP or the owning UI exits. A fixed ten minute
    // watchdog interrupted a healthy frame and restarted it mid contour.
    DWORD outcome=WaitForMultipleObjects(3,handles,FALSE,INFINITE);
    if(outcome==WAIT_OBJECT_0)return 0; // DoMark returned normally.
    seterrf(L"Red watchdog: stop o salida del programa; evento=%lu.",outcome);
    __try {if(ctx->adaptor&&V.stop)V.stop(ctx->adaptor,1);}
    __except(EXCEPTION_EXECUTE_HANDLER) {}
    return 0;
}
static NativeDoMarkResult call_red_domark_protected(void*adaptor,
        VendorVector3*devDocs,void*ctl,HANDLE stopEvent=nullptr,HANDLE parent=nullptr){
    NativeDoMarkResult r={};
    typedef bool (__thiscall *DoMarkFn)(void*,const void*,void*,void*,bool);
    DoMarkFn doMark=(DoMarkFn)GetProcAddress(V.mark,
        "?DoMark@CMarkMgr@@UAE_NABV?$vector@UtagDevDocs@@V?$allocator@UtagDevDocs@@@std@@@std@@QAUtagMarkCtlData@@PAX_N@Z");
    if(!doMark)return r;
    HANDLE cancel=nullptr;
    ContinuousRedWatchdog ctx={adaptor,nullptr,stopEvent,parent};
    if(stopEvent&&parent){
        cancel=CreateEventW(nullptr,TRUE,FALSE,nullptr);
        if(!cancel)return r;
        ctx.cancel=cancel;
    }
    HANDLE watchdog=CreateThread(nullptr,0,cancel?domark_continuous_watchdog:domark_stop_watchdog,
                                 cancel?(void*)&ctx:adaptor,0,nullptr);
    if(!watchdog){if(cancel)CloseHandle(cancel);return r;}
    __try {r.called=doMark(D.mm,devDocs,ctl,nullptr,true)?1:0;}
    __except(aye_seh_capture(GetExceptionInformation(),&r.seh,&r.addr)) {}
    if(cancel)SetEvent(cancel);
    WaitForSingleObject(watchdog,INFINITE);CloseHandle(watchdog);
    if(cancel)CloseHandle(cancel);
    // DoMark can return after a single contour even though the caller asked
    // for continuous red framing. Stopping the adaptor here extinguishes the
    // red light before the next contour can start. Keep the session alive
    // between natural returns; the watchdog handles the explicit STOP event.
    bool continueRed=cancel && r.called &&
        WaitForSingleObject(stopEvent,0)==WAIT_TIMEOUT &&
        WaitForSingleObject(parent,0)==WAIT_TIMEOUT;
    if(!continueRed){
        __try {V.stop(adaptor,1);r.stop=1;}
        __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    return r;
}
typedef void* (__thiscall *GetDevIdNativeFn)(void*,void*);
static int get_dev_id_protected(GetDevIdNativeFn fn,void*adaptor,
        void**out,DWORD*seh,void**addr){
    __try {return fn(adaptor,out)?1:0;}
    __except(aye_seh_capture(GetExceptionInformation(),seh,addr)){return 0;}
}
static int red_via_domark(int redMode,HANDLE stopEvent=nullptr,HANDLE parent=nullptr){
    if(redMode!=3&&redMode!=4)return AYE_E_ARG;
    if((stopEvent==nullptr)!=(parent==nullptr))return AYE_E_ARG;
    std::lock_guard<std::mutex>lk(g_lock);
    if(!D.marker||!D.ctl||!D.adaptor||!g_activeJob||
       !g_activeJob->doc||g_activeJob->shapes.empty()||g_activeJob->shapes.size()>2048){
        seterr(L"Falta documento con 1-2048 contornos o marcador G2.");return AYE_E_STATE;}
    GetDevIdNativeFn getId=(GetDevIdNativeFn)GetProcAddress(V.mark,
        "?GetDevId@CMarkAdaptor@@UAE?AV?$CStringT@_WV?$StrTraitMFC_DLL@_WV?$ChTraitsCRT@_W@ATL@@@@@ATL@@XZ");
    if(!getId){seterr(L"GetDevId no disponible.");return AYE_E_SYMBOL;}
    auto& shapes=g_activeJob->shapes;
    BYTE*doc=(BYTE*)g_activeJob->doc;
    BYTE*penVector=doc+0x278;
    BYTE*a=*(BYTE**)(penVector+4),*b=*(BYTE**)(penVector+8);
    BYTE*c=*(BYTE**)(penVector),*d=*(BYTE**)(penVector+4);
    auto valid=[](BYTE*lo,BYTE*hi)->bool{return lo&&hi&&hi>lo&&
        (SIZE_T)(hi-lo)%216==0&&(SIZE_T)(hi-lo)/216<=256;};
    BYTE*penStart=valid(a,b)?a:(valid(c,d)?c:nullptr);
    BYTE*penEnd=valid(a,b)?b:(valid(c,d)?d:nullptr);
    if(!penStart||!readable_ptr(penStart,216)){
        seterr(L"Vector nativo de plumas no valido.");return AYE_E_STATE;}
    void* lmc=V.getLmcPar(D.marker);
    if(!lmc||!readable_ptr((BYTE*)lmc+0x21F0,4)||!readable_ptr(D.ctl,0x70)){
        seterr(L"Control rojo nativo incompleto.");return AYE_E_STATE;}
    BYTE* shapeFirst=(BYTE*)shapes.data();
    NativeDocEntry36 entry={};
    // tagDocShape+0 is a UTF-16 document identifier, not CBaseDoc*.
    entry.doc=(void*)g_activeJob->file.c_str();
    BYTE*shapeLast=shapeFirst+shapes.size()*sizeof(void*);
    entry.shapes={shapeFirst,shapeLast,shapeLast};
    entry.pens={penStart,penEnd,penEnd};
    void* devIdCString=nullptr;DWORD idSeh=0;void*idAddr=nullptr;
    get_dev_id_protected(getId,D.adaptor,&devIdCString,&idSeh,&idAddr);
    if(idSeh||!devIdCString||!readable_ptr(devIdCString,2)){
        seterrf(L"GetDevId invalido. SEH=0x%08X at=%p",idSeh,idAddr);
        return idSeh?AYE_E_EXCEPTION:AYE_E_STATE;
    }
    NativeDevDocs20 item={};item.deviceIdCString=devIdCString;
    item.docs={(BYTE*)&entry,(BYTE*)&entry+sizeof(entry),(BYTE*)&entry+sizeof(entry)};
    VendorVector3 deviceDocs={(BYTE*)&item,(BYTE*)&item+sizeof(item),(BYTE*)&item+sizeof(item)};
    // The manager's DoMark checks CMarkAdaptor+0x24 for document shapes.
    // Our standalone probe has no GLaser UI to populate that vector.
    VendorVector3*attached=(VendorVector3*)((BYTE*)D.adaptor+0x24);
    if(!readable_ptr(attached,sizeof(*attached))){
        seterr(L"Vector de documentos del adaptador no legible.");return AYE_E_STATE;}
    VendorVector3 previous=*attached;
    if(previous.first!=previous.last){
        seterr(L"El adaptador ya contiene documentos; no se reemplazan.");return AYE_E_STATE;}
    *attached=item.docs;
    // MarkUI.dll 0x100265dd: ctl=&UI+0x2e0. At 0x100266ef..0x10026706
    // it writes +0x1c=1, +0x0c=1, +0x00=0x14; +0x30=0 just before DoMark.
    // Keep a copy so this experimental call cannot persist UI-only flags.
    int oldCtl=*(int*)D.ctl,oldMode=*(int*)((BYTE*)lmc+0x21F0);
    int oldC=*(int*)((BYTE*)D.ctl+0x0c);
    int old1C=*(int*)((BYTE*)D.ctl+0x1c);
    int old30=*(int*)((BYTE*)D.ctl+0x30);
    *(int*)D.ctl=0x14;
    *(int*)((BYTE*)D.ctl+0x0c)=1;
    *(int*)((BYTE*)D.ctl+0x1c)=1;
    *(int*)((BYTE*)D.ctl+0x30)=0;
    *(int*)((BYTE*)lmc+0x21F0)=redMode;
    NativeDoMarkResult r=call_red_domark_protected(D.adaptor,&deviceDocs,D.ctl,stopEvent,parent);
    *attached=previous;
    *(int*)D.ctl=oldCtl;
    *(int*)((BYTE*)D.ctl+0x0c)=oldC;
    *(int*)((BYTE*)D.ctl+0x1c)=old1C;
    *(int*)((BYTE*)D.ctl+0x30)=old30;
    *(int*)((BYTE*)lmc+0x21F0)=oldMode;
    seterrf(L"DoMark rojo: devId=1 call=%d stop=%d SEH=0x%08X at=%p. El PASS de llamada NO valida el USB: captura obligatoria.",
            r.called,r.stop,r.seh,r.addr);
    if(r.seh)return AYE_E_EXCEPTION;
    return r.called&&(stopEvent||r.stop)?0:AYE_E_VENDOR;
}
AYE_API int __cdecl AYE_TestRedViaDoMark(){return red_via_domark(3);}
AYE_API int __cdecl AYE_TestRedOutlineViaDoMark(){return red_via_domark(4);}
AYE_API int __cdecl AYE_RunRedBoxContinuous(HANDLE stopEvent,HANDLE parent){return red_via_domark(3,stopEvent,parent);}
AYE_API int __cdecl AYE_RunRedVectorContinuous(HANDLE stopEvent,HANDLE parent){return red_via_domark(4,stopEvent,parent);}

// The exported CMarkMgr::MarkLines has five arguments: device-id wchar_t*,
// vector<tagPOINTF> const&, tagMarkCtlData*, tagPenPar&, tagLmcPar&.
// Keep this probe separate from the UI until a physical mark verifies the ABI.
struct MarkLineWatchdog { HANDLE done; void* adaptor; };
static DWORD WINAPI mark_line_watchdog(LPVOID arg){
    MarkLineWatchdog* w=(MarkLineWatchdog*)arg;
    if(WaitForSingleObject(w->done,2000)==WAIT_TIMEOUT){
        __try { if(w->adaptor&&V.stop)V.stop(w->adaptor,1); }
        __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    return 0;
}
struct MarkLineResult {int called,stopped; DWORD seh;void*addr;};
static MarkLineResult call_mark_lines_protected(const wchar_t*id,VendorVector3*points,
                                                void*ctl,void*pen,void*lmc){
    MarkLineResult r={};
    typedef bool (__thiscall *MarkLinesFn)(void*,wchar_t*,const void*,void*,void*,void*);
    MarkLinesFn fn=(MarkLinesFn)GetProcAddress(V.mark,
        "?MarkLines@CMarkMgr@@UAE_NPA_WABV?$vector@UtagPOINTF@@V?$allocator@UtagPOINTF@@@std@@@std@@QAUtagMarkCtlData@@AAUtagPenPar@@AAUtagLmcPar@@@Z");
    if(!fn)return r;
    HANDLE done=CreateEventW(nullptr,TRUE,FALSE,nullptr);
    if(!done)return r;
    MarkLineWatchdog ctx={done,D.adaptor};
    HANDLE thread=CreateThread(nullptr,0,mark_line_watchdog,&ctx,0,nullptr);
    if(!thread){CloseHandle(done);return r;}
    __try {r.called=fn(D.mm,(wchar_t*)id,points,ctl,pen,lmc)?1:0;}
    __except(aye_seh_capture(GetExceptionInformation(),&r.seh,&r.addr)) {}
    SetEvent(done);WaitForSingleObject(thread,INFINITE);CloseHandle(thread);CloseHandle(done);
    __try {V.stop(D.adaptor,1);r.stopped=1;}
    __except(EXCEPTION_EXECUTE_HANDLER) {}
    return r;
}
// MarkUI.dll RVA 0x203DF calls CMarkMgr vtable+0x68 (MarkPathsSDK), with
// device ID, path vector, control, pen and LMC. This probe is separate from
// the physically validated red DoMark route above.
struct MarkPathsResult {int paths,prepared,called,stopped,interrupted; DWORD seh;void*addr;};
struct MarkWatch {void*adaptor;HANDLE finished;HANDLE requested;HANDLE parent;DWORD timeout;volatile LONG interrupted;};
static DWORD WINAPI mark_paths_watchdog(LPVOID arg){
    MarkWatch*w=(MarkWatch*)arg;
    HANDLE events[3]={w->finished,w->requested,w->parent};
    DWORD count=w->parent?3:(w->requested?2:1);
    DWORD result=WaitForMultipleObjects(count,events,FALSE,w->timeout);
    if(result==WAIT_OBJECT_0)return 0;
    InterlockedExchange(&w->interrupted,1);
    __try {if(w->adaptor&&V.stop)V.stop(w->adaptor,1);}
    __except(EXCEPTION_EXECUTE_HANDLER) {}
    return 0;
}
static MarkPathsResult call_mark_paths_protected(void*marker,void*lmc,
        VendorVector3*shapes,void*selected,const wchar_t*id,void*ctl,void*pen,
        int expectedPaths=1,HANDLE stopEvent=nullptr,DWORD timeoutMs=5000,HANDLE parent=nullptr){
    MarkPathsResult r={}; VendorVector3 paths={};bool constructed=false;
    typedef void (__thiscall *VectorCtor)(void*);
    typedef void (__thiscall *VectorDtor)(void*);
    typedef bool (__thiscall *GetRedPathsFn)(void*,const void*,void*,void*,bool);
    typedef bool (__thiscall *MarkPathsSDKFn)(void*,wchar_t*,const void*,void*,void*,void*);
    VectorCtor ctor=(VectorCtor)((BYTE*)V.mark+0x4D4F0);
    VectorDtor dtor=(VectorDtor)((BYTE*)V.mark+0x4D520);
    GetRedPathsFn get=(GetRedPathsFn)GetProcAddress(V.mark,
        "?GetRedPaths@CDataMarker@@UAE_NABV?$vector@PAVCBaseShape@@V?$allocator@PAVCBaseShape@@@std@@@std@@PAVCBaseShape@@AAV?$vector@UtagPathData@@V?$allocator@UtagPathData@@@std@@@3@_N@Z");
    MarkPathsSDKFn mark=(MarkPathsSDKFn)GetProcAddress(V.mark,
        "?MarkPathsSDK@CMarkMgr@@UAE_NPA_WABV?$vector@UtagPathData@@V?$allocator@UtagPathData@@@std@@@std@@QAUtagMarkCtlData@@AAUtagPenPar@@AAUtagLmcPar@@@Z");
    if(!get||!mark)return r;
    int*mode=(int*)((BYTE*)lmc+0x21F0),previous=*mode;
    __try {
        ctor(&paths);constructed=true;
        *mode=4;
        r.prepared=get(marker,shapes,selected,&paths,false)?1:0;
        *mode=0;
        if(paths.first&&paths.last&&paths.last>paths.first&&
           (paths.last-paths.first)%24==0)
            r.paths=(int)((paths.last-paths.first)/24);
        if(r.prepared&&r.paths==expectedPaths&&readable_ptr(paths.first,24)){
            HANDLE finished=CreateEventW(nullptr,TRUE,FALSE,nullptr);
            MarkWatch watch={D.adaptor,finished,stopEvent,parent,timeoutMs,0};
            HANDLE watchdog=finished?CreateThread(nullptr,0,mark_paths_watchdog,&watch,0,nullptr):nullptr;
            if(watchdog){
                r.called=mark(D.mm,(wchar_t*)id,&paths,ctl,pen,lmc)?1:0;
                SetEvent(finished);
                WaitForSingleObject(watchdog,INFINITE);CloseHandle(watchdog);
                r.interrupted=watch.interrupted?1:0;
            }
            if(finished)CloseHandle(finished);
        }
        if(D.adaptor&&V.stop){V.stop(D.adaptor,1);r.stopped=1;}
        if(constructed)dtor(&paths);
        *mode=previous;
    } __except(aye_seh_capture(GetExceptionInformation(),&r.seh,&r.addr)) {
        __try {*mode=previous;if(D.adaptor&&V.stop)V.stop(D.adaptor,1);}
        __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    return r;
}
static int mark_square_paths_probe(const AYE_PointD*pts){
    if(!pts)return AYE_E_ARG;
    const double x=pts[0].x,y=pts[0].y,eps=0.02;
    const double expected[5][2]={{x,y},{x+20,y},{x+20,y+20},{x,y+20},{x,y}};
    for(int i=0;i<5;i++)if(!_finite(pts[i].x)||!_finite(pts[i].y)||
        fabs(pts[i].x-expected[i][0])>eps||fabs(pts[i].y-expected[i][1])>eps||
        fabs(pts[i].x)>45||fabs(pts[i].y)>45)return AYE_E_ARG;
    std::lock_guard<std::mutex> lk(g_lock);
    if(!D.marker||!D.ctl||!D.adaptor||!D.mm||!g_activeJob||
       !g_activeJob->doc||g_activeJob->shapes.size()!=1){
        seterr(L"Sonda MarkPathsSDK: falta cuadrado o conexión G2.");return AYE_E_STATE;}
    BYTE*pv=(BYTE*)g_activeJob->doc+0x278;
    if(!readable_ptr(pv,12))return AYE_E_STATE;
    BYTE*first=*(BYTE**)pv,*end=*(BYTE**)(pv+4);
    if(!first||!end||end<first||(SIZE_T)(end-first)<216||
       (SIZE_T)(end-first)%216||!readable_ptr(first,216))return AYE_E_STATE;
    BYTE nativePen[216];memcpy(nativePen,first,216);
    int one=1,speed=1500,power=25;float khz=30.0f;
    memcpy(nativePen,&one,4);memcpy(nativePen+36,&one,4);
    memcpy(nativePen+40,&speed,4);memcpy(nativePen+44,&power,4);
    memcpy(nativePen+56,&khz,4);
    void*lmc=V.getLmcPar(D.marker);
    if(!lmc||!readable_ptr((BYTE*)lmc+0x21F0,4)||!readable_ptr(D.ctl,0x70))return AYE_E_STATE;
    GetDevIdNativeFn getId=(GetDevIdNativeFn)GetProcAddress(V.mark,
        "?GetDevId@CMarkAdaptor@@UAE?AV?$CStringT@_WV?$StrTraitMFC_DLL@_WV?$ChTraitsCRT@_W@ATL@@@@@ATL@@XZ");
    if(!getId)return AYE_E_SYMBOL;
    void*idObject=nullptr;DWORD idSeh=0;void*idAddr=nullptr;
    get_dev_id_protected(getId,D.adaptor,&idObject,&idSeh,&idAddr);
    if(idSeh||!idObject||!readable_ptr(idObject,2))return AYE_E_STATE;
    BYTE ctl[0x70];memcpy(ctl,D.ctl,sizeof(ctl));
    *(int*)ctl=0x14;*(int*)(ctl+0x0c)=0;*(int*)(ctl+0x1c)=0;
    auto&v=g_activeJob->shapes;
    VendorVector3 shapes={(BYTE*)v.data(),(BYTE*)(v.data()+v.size()),
                          (BYTE*)(v.data()+v.size())};
    MarkPathsResult r=call_mark_paths_protected(D.marker,lmc,&shapes,v.front(),
                                               (const wchar_t*)idObject,ctl,nativePen);
    seterrf(L"MarkPathsSDK cuadrado: red_paths=%d prepared=%d mark_call=%d stop=%d SEH=0x%08X at=%p. Confirmar fisicamente en la pieza.",
            r.paths,r.prepared,r.called,r.stopped,r.seh,r.addr);
    if(r.seh)return AYE_E_EXCEPTION;
    return r.paths==1&&r.prepared&&r.called&&r.stopped?0:AYE_E_VENDOR;
}
AYE_API int __cdecl AYE_MarkVectorDesign(HANDLE parent){
    std::lock_guard<std::mutex> lk(g_lock);
    if(!D.marker||!D.ctl||!D.adaptor||!D.mm||!g_activeJob||!g_activeJob->doc||
       g_activeJob->shapes.empty()||g_activeJob->shapes.size()>2048){
        seterr(L"Marcado vectorial: documento o conexión G2 no disponible.");return AYE_E_STATE;}
    if(!g_activeJob->penTouched[0])return AYE_E_STATE;
    BYTE*pv=(BYTE*)g_activeJob->doc+0x278;
    if(!readable_ptr(pv,12))return AYE_E_STATE;
    BYTE*first=*(BYTE**)pv,*end=*(BYTE**)(pv+4);
    if(!first||!end||end<first||(SIZE_T)(end-first)<216||
       (SIZE_T)(end-first)%216||!readable_ptr(first,216))return AYE_E_STATE;
    BYTE nativePen[216];memcpy(nativePen,first,216);
    const PenState& pen=g_activeJob->pens[0];
    int on=1,passes=pen.loops,speed=(int)std::lround(pen.speed),
        power=(int)std::lround(pen.power);
    float khz=(float)(pen.frequencyHz/1000.0);
    memcpy(nativePen,&on,4);memcpy(nativePen+36,&passes,4);
    memcpy(nativePen+40,&speed,4);memcpy(nativePen+44,&power,4);
    memcpy(nativePen+56,&khz,4);
    void*lmc=V.getLmcPar(D.marker);
    if(!lmc||!readable_ptr((BYTE*)lmc+0x21F0,4)||!readable_ptr(D.ctl,0x70))return AYE_E_STATE;
    GetDevIdNativeFn getId=(GetDevIdNativeFn)GetProcAddress(V.mark,
        "?GetDevId@CMarkAdaptor@@UAE?AV?$CStringT@_WV?$StrTraitMFC_DLL@_WV?$ChTraitsCRT@_W@ATL@@@@@ATL@@XZ");
    if(!getId)return AYE_E_SYMBOL;
    void*idObject=nullptr;DWORD idSeh=0;void*idAddr=nullptr;
    get_dev_id_protected(getId,D.adaptor,&idObject,&idSeh,&idAddr);
    if(idSeh||!idObject||!readable_ptr(idObject,2))return AYE_E_STATE;
    BYTE ctl[0x70];memcpy(ctl,D.ctl,sizeof(ctl));
    *(int*)ctl=0x14;*(int*)(ctl+0x0c)=0;*(int*)(ctl+0x1c)=0;
    auto&v=g_activeJob->shapes;
    VendorVector3 shapes={(BYTE*)v.data(),(BYTE*)(v.data()+v.size()),
                          (BYTE*)(v.data()+v.size())};
    wchar_t eventName[96]={0};
    swprintf_s(eventName,L"Local\\43AYE3_G2_MARK_STOP_%lu",GetCurrentProcessId());
    HANDLE stopEvent=CreateEventW(nullptr,TRUE,FALSE,eventName);
    if(!stopEvent||!parent){if(stopEvent)CloseHandle(stopEvent);return AYE_E_STATE;}
    MarkPathsResult r=call_mark_paths_protected(D.marker,lmc,&shapes,v.front(),
        (const wchar_t*)idObject,ctl,nativePen,(int)v.size(),stopEvent,INFINITE,parent);
    CloseHandle(stopEvent);
    seterrf(L"MarkPathsSDK vector: shapes=%d paths=%d prepared=%d mark_call=%d stop=%d interrupted=%d SEH=0x%08X at=%p.",
            (int)v.size(),r.paths,r.prepared,r.called,r.stopped,r.interrupted,r.seh,r.addr);
    if(r.seh)return AYE_E_EXCEPTION;
    return r.paths==(int)v.size()&&r.prepared&&r.called&&r.stopped&&!r.interrupted?0:AYE_E_VENDOR;
}
AYE_API int __cdecl AYE_MarkLines(const AYE_PointD*pts,int count,int pen){
    if(!pts||pen!=0||(count!=2&&count!=5))return AYE_E_ARG;
    if(count==5)return mark_square_paths_probe(pts);
    double dx=pts[1].x-pts[0].x,dy=pts[1].y-pts[0].y;
    if(!_finite(dx)||!_finite(dy)||std::hypot(dx,dy)<0.1||std::hypot(dx,dy)>1.0)return AYE_E_ARG;
    for(int i=0;i<2;i++)if(!_finite(pts[i].x)||!_finite(pts[i].y)||
                             fabs(pts[i].x)>45||fabs(pts[i].y)>45)return AYE_E_ARG;
    std::lock_guard<std::mutex>lk(g_lock);
    if(!D.marker||!D.ctl||!D.adaptor||!g_activeJob||!g_activeJob->doc){
        seterr(L"Sonda MARK: conecta G2, crea documento y asocia marcador.");return AYE_E_STATE;}
    BYTE*vec=(BYTE*)g_activeJob->doc+0x278;
    BYTE*lo=*(BYTE**)(vec+4),*hi=*(BYTE**)(vec+8);
    if(!lo||!hi||hi<lo||(SIZE_T)(hi-lo)<216||!readable_ptr(lo,216)){
        seterr(L"Sonda MARK: pluma nativa ilegible.");return AYE_E_STATE;}
    void*lmc=V.getLmcPar(D.marker);
    if(!lmc||!readable_ptr(lmc,0x21F4)||!readable_ptr(D.ctl,0x70))return AYE_E_STATE;
    // The exact native pen size is 216 bytes in this pinned SeaMark build.
    BYTE nativePen[216];memcpy(nativePen,lo,216);
    int one=1,speed=1500,power=25;float khz=30.0f;
    memcpy(nativePen+0,&one,4);memcpy(nativePen+36,&one,4);
    memcpy(nativePen+40,&speed,4);memcpy(nativePen+44,&power,4);
    memcpy(nativePen+56,&khz,4);
    struct NativePointF {float x,y;};
    NativePointF line[2]={{(float)pts[0].x,(float)pts[0].y},
                          {(float)pts[1].x,(float)pts[1].y}};
    VendorVector3 points={(BYTE*)line,(BYTE*)(line+2),(BYTE*)(line+2)};
    GetDevIdNativeFn getId=(GetDevIdNativeFn)GetProcAddress(V.mark,
        "?GetDevId@CMarkAdaptor@@UAE?AV?$CStringT@_WV?$StrTraitMFC_DLL@_WV?$ChTraitsCRT@_W@ATL@@@@@ATL@@XZ");
    if(!getId)return AYE_E_SYMBOL;
    void*idObject=nullptr;DWORD idSeh=0;void*idAddr=nullptr;
    get_dev_id_protected(getId,D.adaptor,&idObject,&idSeh,&idAddr);
    if(idSeh||!idObject||!readable_ptr(idObject,sizeof(void*))){
        seterrf(L"Sonda MARK: identificador nativo inválido. SEH=0x%08X",idSeh);
        return AYE_E_STATE;}
    const wchar_t*id=*(const wchar_t**)idObject;
    if(!readable_ptr(id,sizeof(wchar_t))){seterr(L"Sonda MARK: ID del dispositivo ilegible.");return AYE_E_STATE;}
    BYTE ctl[0x70];memcpy(ctl,D.ctl,sizeof(ctl));
    *(int*)ctl=0x14;*(int*)(ctl+0x0c)=0;*(int*)(ctl+0x1c)=0;
    int oldRedMode=*(int*)((BYTE*)lmc+0x21F0);
    *(int*)((BYTE*)lmc+0x21F0)=0;
    MarkLineResult r=call_mark_lines_protected(id,&points,ctl,nativePen,lmc);
    *(int*)((BYTE*)lmc+0x21F0)=oldRedMode;
    seterrf(L"SONDA MARK 1 mm: llamada=%d STOP=%d SEH=0x%08X en %p. Emisión física pendiente de verificación.",
            r.called,r.stopped,r.seh,r.addr);
    if(r.seh)return AYE_E_EXCEPTION;
    return r.called&&r.stopped?0:AYE_E_VENDOR;
}

BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);}else if(reason==DLL_PROCESS_DETACH){/* no vendor calls from DllMain */}return TRUE;}
