#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <cwchar>
#include <cstdlib>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <locale>
#include "43AYE3_BSL_COMPAT.h"
struct PF { float x,y; };

struct MarkInput {
    int passes=0; double speed=0,power=0,khz=0;
    std::vector<PF> points; std::vector<int> counts;
};
static bool read_mark_input(const std::filesystem::path& file, MarkInput& job) {
    std::ifstream input(file); input.imbue(std::locale::classic());
    int lines=0;
    if(!(input>>lines>>job.passes>>job.speed>>job.power>>job.khz) ||
       lines<1 || lines>2048 || job.passes<1 || job.passes>999 ||
       !std::isfinite(job.speed) || job.speed<=0 || job.speed>100000 ||
       !std::isfinite(job.power) || job.power<0 || job.power>100 ||
       !std::isfinite(job.khz) || job.khz<1 || job.khz>4000) return false;
    double lx=55,ly=55,hx=-55,hy=-55;
    for(int l=0;l<lines;++l) {
        int n=0;
        if(!(input>>n)||n<2||n>4096||job.points.size()+(size_t)n>65536) return false;
        job.counts.push_back(n);
        for(int i=0;i<n;++i) {
            double x=0,y=0;
            if(!(input>>x>>y)||!std::isfinite(x)||!std::isfinite(y)||fabs(x)>55||fabs(y)>55) return false;
            lx=std::min(lx,x);ly=std::min(ly,y);hx=std::max(hx,x);hy=std::max(hy,y);
            job.points.push_back({float(x),float(y)});
        }
    }
    std::string extra;
    return !(input>>extra) && (hx-lx>=0.1 || hy-ly>=0.1);
}
static int run_mark_queue(const wchar_t* manifest, const wchar_t* parentArg) {
    if(wcsncmp(parentArg,L"--parent=",9)!=0) return 33;
    DWORD pid=wcstoul(parentArg+9,nullptr,10);
    HANDLE parent=pid?OpenProcess(SYNCHRONIZE,FALSE,pid):nullptr;
    if(!parent) return 33;
    // Relative ASCII filenames keep manifests portable across Unicode Windows folders.
    std::filesystem::path root=std::filesystem::path(manifest).parent_path();
    std::ifstream list{std::filesystem::path(manifest)};list.imbue(std::locale::classic());
    std::vector<std::filesystem::path> files;std::string name;
    while(std::getline(list,name)) {
        if(!name.empty()&&name.back()=='\r')name.pop_back();
        if(name.empty())continue;
        std::filesystem::path relative(name);
        if(relative.has_parent_path() || relative.is_absolute()) {CloseHandle(parent);return 33;}
        files.push_back(root/relative);
    }
    if(!list.eof() || files.empty()) {CloseHandle(parent);return 33;}
    // Validate every block before any device connection / marking.
    for(const auto& file:files) {
        MarkInput job;
        if(!read_mark_input(file,job)) {
            std::wcout<<L"VECTOR_MARK_RESULT=FAIL_QUEUE_INPUT\n";
            CloseHandle(parent);return 33;
        }
    }
    wchar_t eventName[96]={0};
    swprintf_s(eventName,L"Local\\43AYE3_G2_MARK_STOP_%lu",GetCurrentProcessId());
    HANDLE stopEvent=CreateEventW(nullptr,TRUE,FALSE,eventName);
    if(!stopEvent){CloseHandle(parent);return 33;}
    int rc=0;bool connected=false,probed=false;size_t completed=0;
    wchar_t document[MAX_PATH]={0};GetFullPathNameW(L"G2_VECTOR_MARK_MEMORY_ONLY",MAX_PATH,document,nullptr);
    for(const auto& file:files) {
        if(WaitForSingleObject(stopEvent,0)==WAIT_OBJECT_0 ||
           WaitForSingleObject(parent,0)!=WAIT_TIMEOUT) {rc=34;break;}
        MarkInput job;
        if(!read_mark_input(file,job)) {rc=33;break;}
        rc=BSL_NewFile(document);
        if(!rc)rc=BSL_SetPenParam(document,0,job.passes,job.speed,job.power,0,
                                 (int)std::lround(job.khz*1000.0),0,0,0,0,0,4000,0,0,0,false,0,0);
        if(!rc)rc=BSL_AddLinesToFile2(document,job.points.data(),(int)job.counts.size(),
                                     job.counts.data(),(wchar_t*)L"VECTOR_DESIGN",0);
        if(!rc && !connected){rc=AYE_DeviceConnect();connected=!rc;}
        if(!rc && !probed){rc=AYE_ProbeMarker();probed=!rc;}
        // Shared named STOP event persists even between individual mark calls.
        if(!rc && (WaitForSingleObject(stopEvent,0)==WAIT_OBJECT_0 ||
                    WaitForSingleObject(parent,0)!=WAIT_TIMEOUT))rc=34;
        if(!rc)rc=AYE_MarkVectorDesign(parent);
        wchar_t detail[2048]={0};AYE_GetLastError(detail,2048);
        std::wcout<<L"QUEUE_BLOCK="<<(completed+1)<<L"/"<<files.size()<<L" RC="<<rc
                  <<L"\nDETAIL="<<detail<<L"\n"<<std::flush;
        BSL_UnLoadDataFile(document);
        if(rc)break;
        ++completed;
    }
    int stopped=AYE_Stop();AYE_DeviceClose();
    CloseHandle(stopEvent);CloseHandle(parent);
    bool ok=!rc&&!stopped&&completed==files.size();
    std::wcout<<L"QUEUE_COMPLETED="<<completed<<L"/"<<files.size()
              <<L"\nVECTOR_MARK_RESULT="<<(ok?L"CALL_OK_VERIFY_PIECE":L"FAIL_OR_STOP")<<L"\n";
    return ok?0:34;
}

int wmain(int argc,wchar_t**argv){
    wchar_t ver[256]={0}; AYE_GetVersion(ver,256); std::wcout<<L"SDK_VERSION="<<ver<<L"\n";
    if(argc==2 && wcscmp(argv[1],L"--queue-version")==0){std::wcout<<L"MARK_QUEUE_VERSION=1\n";return 0;}
    if(argc==4 && wcscmp(argv[1],L"--mark-vector-queue")==0)return run_mark_queue(argv[2],argv[3]);
    if(argc>1 && wcscmp(argv[1],L"--capabilities")==0){
        unsigned int flags=0;
        int rc=AYE_GetCapabilities(&flags);
        std::wcout<<L"AYE_GetCapabilities="<<rc<<L" FLAGS="<<flags<<L"\n";
        bool validated=(rc==0 && (flags & (AYE_CAP_DEVICE_CONNECT|AYE_CAP_DEVICE_STOP|
                AYE_CAP_MARKER_ASSOCIATION|AYE_CAP_RED_POINT_MOVEMENT)) ==
                (AYE_CAP_DEVICE_CONNECT|AYE_CAP_DEVICE_STOP|
                 AYE_CAP_MARKER_ASSOCIATION|AYE_CAP_RED_POINT_MOVEMENT) &&
                !(flags & (AYE_CAP_VISIBLE_RED_FRAME|AYE_CAP_LASER_MARKING)));
        std::wcout<<L"CAPABILITIES_RESULT="<<(validated?L"PASS":L"FAIL")<<L"\n";
        return validated?0:22;
    }
    if(argc>1 && wcscmp(argv[1],L"--marker-probe")==0){
        std::wcout<<L"PROBE_MODE=MARKER_ONLY_NO_ORZX_NO_FRAME_NO_MARK\n";
        int cr=AYE_DeviceConnect();std::wcout<<L"AYE_DeviceConnect="<<cr<<L"\n";
        int mr=-999;
        if(cr==0){
            AYE_DeviceInfo di={};int ir=AYE_DeviceGetInfo(&di);
            std::wcout<<L"AYE_DeviceGetInfo="<<ir<<L" VALID="<<di.valid_devices<<L" DEV="<<di.device_no<<L" TYPE="<<di.device_type<<L" USB="<<di.usb_speed_type<<L"\n";
            mr=AYE_ProbeMarker();std::wcout<<L"AYE_ProbeMarker="<<mr<<L"\n";
        }
        wchar_t e[2048]={0};AYE_GetLastError(e,2048);std::wcout<<L"SDK_ERROR="<<e<<L"\n";
        int closeRc=AYE_DeviceClose();std::wcout<<L"AYE_DeviceClose="<<closeRc<<L"\n";
        std::wcout<<L"MARKER_PROBE_RESULT="<<(cr==0&&mr==0?L"PASS":L"FAIL")<<L"\n";
        return cr==0&&mr==0?0:21;
    }
    if(argc==4 && (wcscmp(argv[1],L"--mark-line-probe")==0 ||
                   wcscmp(argv[1],L"--mark-square20-probe")==0)){
        bool square=wcscmp(argv[1],L"--mark-square20-probe")==0;
        wchar_t*ex=nullptr,*ey=nullptr;
        double x=wcstod(argv[2],&ex),y=wcstod(argv[3],&ey);
        if(!ex||*ex||!ey||*ey||!std::isfinite(x)||!std::isfinite(y)||
           fabs(x)>(square?35:44)||fabs(y)>(square?35:45)){
            std::wcerr<<L"MARK_PROBE_RESULT=FAIL_COORDINATES\n";return 31;}
        wchar_t job[MAX_PATH]={0};GetFullPathNameW(L"G2_MARK_LINE_PROBE_MEMORY_ONLY",MAX_PATH,job,nullptr);
        int nr=BSL_NewFile(job);
        int pp=nr?nr:BSL_SetPenParam(job,0,1,1500,25,0,30000,0,0,0,0,0,4000,0,0,0,false,0,0);
        AYE_PointD points[5]={{x-10,y-10},{x+10,y-10},{x+10,y+10},
                              {x-10,y+10},{x-10,y-10}};
        if(!square){points[0]={x,y};points[1]={x+1.0,y};}
        PF nativeSquare[5]={};int nativeCounts[1]={5};
        if(square)for(int i=0;i<5;i++)nativeSquare[i]={(float)points[i].x,(float)points[i].y};
        int shape=square&&!pp?BSL_AddLinesToFile2(job,nativeSquare,1,nativeCounts,(wchar_t*)L"SQUARE_20_MM",0):0;
        int cr=pp?pp:(shape?shape:AYE_DeviceConnect()),mr=cr?cr:AYE_ProbeMarker();
        int mark=mr?mr:(shape?shape:AYE_MarkLines(points,square?5:2,0));
        wchar_t detail[2048]={0};AYE_GetLastError(detail,2048);
        int stop=AYE_Stop(),close=AYE_DeviceClose();BSL_UnLoadDataFile(job);
        std::wcout<<L"DOC="<<nr<<L" PEN="<<pp<<L" CONNECT="<<cr<<L" MARKER="<<mr<<L" SHAPE="<<shape
                  <<L" MARK="<<mark<<L" STOP="<<stop<<L" CLOSE="<<close
                  <<L"\nDETAIL="<<detail<<L"\nMARK_PROBE_RESULT="
                  <<(mark==0&&stop==0?L"CALL_OK_PHYSICAL_RESULT_PENDING":L"FAIL_OR_BLOCKED")<<L"\n";
        return mark==0&&stop==0?0:32;
    }
    if(argc==4 && wcscmp(argv[1],L"--mark-vector-design")==0){
        if(wcsncmp(argv[3],L"--parent=",9)!=0){std::wcerr<<L"VECTOR_MARK_RESULT=FAIL_PARENT\n";return 33;}
        DWORD parentPid=wcstoul(argv[3]+9,nullptr,10);
        HANDLE parent=parentPid?OpenProcess(SYNCHRONIZE,FALSE,parentPid):nullptr;
        if(!parent){std::wcerr<<L"VECTOR_MARK_RESULT=FAIL_PARENT\n";return 33;}
        std::ifstream input{std::filesystem::path(argv[2])};input.imbue(std::locale::classic());
        int lines=0,passes=0;double speed=0,power=0,frequencyKhz=0;
        if(!(input>>lines>>passes>>speed>>power>>frequencyKhz)||lines<1||lines>2048||
           passes<1||passes>999||!std::isfinite(speed)||speed<=0||speed>100000||
           !std::isfinite(power)||power<0||power>100||
           !std::isfinite(frequencyKhz)||frequencyKhz<1||frequencyKhz>4000){
            std::wcerr<<L"VECTOR_MARK_RESULT=FAIL_PEN\n";return 33;}
        std::vector<PF> points;std::vector<int> counts;
        double loX=55,loY=55,hiX=-55,hiY=-55;
        for(int l=0;l<lines;l++){
            int n=0;if(!(input>>n)||n<2||n>4096||points.size()+(size_t)n>65536){
                std::wcerr<<L"VECTOR_MARK_RESULT=FAIL_POINTS\n";return 33;}
            counts.push_back(n);
            for(int i=0;i<n;i++){
                double x=0,y=0;
                if(!(input>>x>>y)||!std::isfinite(x)||!std::isfinite(y)||fabs(x)>55||fabs(y)>55){
                    std::wcerr<<L"VECTOR_MARK_RESULT=FAIL_COORDINATES\n";return 33;}
                loX=std::min(loX,x);hiX=std::max(hiX,x);
                loY=std::min(loY,y);hiY=std::max(hiY,y);
                points.push_back({float(x),float(y)});
            }
        }
        std::string extra;
        if(input>>extra ||
           (hiX-loX<0.1&&hiY-loY<0.1)){
            std::wcerr<<L"VECTOR_MARK_RESULT=FAIL_BOUNDS_OR_TRAILING_DATA\n";return 33;}
        wchar_t job[MAX_PATH]={0};GetFullPathNameW(L"G2_VECTOR_MARK_MEMORY_ONLY",MAX_PATH,job,nullptr);
        int nr=BSL_NewFile(job);
        int pp=nr?nr:BSL_SetPenParam(job,0,passes,speed,power,0,
                                    (int)std::lround(frequencyKhz*1000.0),0,0,0,0,0,4000,0,0,0,false,0,0);
        int ar=pp?pp:BSL_AddLinesToFile2(job,points.data(),lines,counts.data(),(wchar_t*)L"VECTOR_DESIGN",0);
        int cr=ar?ar:AYE_DeviceConnect(),mr=cr?cr:AYE_ProbeMarker();
        int mark=mr?mr:AYE_MarkVectorDesign(parent);
        wchar_t detail[2048]={0};AYE_GetLastError(detail,2048);
        int stop=AYE_Stop(),close=AYE_DeviceClose();BSL_UnLoadDataFile(job);CloseHandle(parent);
        std::wcout<<L"DOC="<<nr<<L" PEN="<<pp<<L" PASSES="<<passes<<L" SPEED="<<speed
                  <<L" POWER="<<power<<L" KHZ="<<frequencyKhz
                  <<L" SHAPES="<<lines<<L" POINTS="<<points.size()
                  <<L" ADD="<<ar<<L" CONNECT="<<cr<<L" MARKER="<<mr
                  <<L" MARK="<<mark<<L" STOP="<<stop<<L" CLOSE="<<close
                  <<L"\nDETAIL="<<detail<<L"\nVECTOR_MARK_RESULT="
                  <<(mark==0&&stop==0?L"CALL_OK_VERIFY_PIECE":L"FAIL")<<L"\n";
        return mark==0&&stop==0?0:34;
    }
    if(argc>1 && wcscmp(argv[1],L"--red-paths")==0){
        wchar_t job[MAX_PATH]={0};GetFullPathNameW(L"G2_RED_PATHS_MEMORY_ONLY",MAX_PATH,job,nullptr);
        int nr=BSL_NewFile(job);
        PF p[]={{-5,-5},{5,-5},{5,5},{-5,5},{-5,-5}};int n[]={5};
        int ar=nr?nr:BSL_AddLinesToFile2(job,p,1,n,(wchar_t*)L"RED_RECT_10MM",0);
        int cr=ar?ar:AYE_DeviceConnect();int mr=cr?cr:AYE_ProbeMarker();
        int paths3=0,paths4=0;
        int r3=mr?mr:AYE_ProbeRedPaths(3,&paths3);
        int r4=mr?mr:AYE_ProbeRedPaths(4,&paths4);
        wchar_t err[2048]={0};AYE_GetLastError(err,2048);
        std::wcout<<L"DOC="<<nr<<L" ADD="<<ar<<L" CONNECT="<<cr<<L" MARKER="<<mr
                  <<L" RED_BOX="<<r3<<L" PATHS="<<paths3
                  <<L" RED_OUTLINE="<<r4<<L" PATHS="<<paths4<<L"\n"
                  <<L"DETAIL="<<err<<L"\n";
        AYE_DeviceClose();BSL_UnLoadDataFile(job);
        std::wcout<<L"RED_PATHS_RESULT="<<(r3==0&&r4==0?L"PASS":L"FAIL")<<L"\n";
        return r3==0&&r4==0?0:23;
    }
    if(argc>1 && wcscmp(argv[1],L"--outline-l")==0){
        wchar_t job[MAX_PATH]={0};GetFullPathNameW(L"G2_RED_OUTLINE_L_10MM",MAX_PATH,job,nullptr);
        int nr=BSL_NewFile(job);
        PF p[]={{-5,-5},{5,-5},{5,0},{0,0},{0,5},{-5,5},{-5,-5}};
        int n[]={7};
        int ar=nr?nr:BSL_AddLinesToFile2(job,p,1,n,(wchar_t*)L"RED_L_10MM",0);
        int cr=ar?ar:AYE_DeviceConnect();int mr=cr?cr:AYE_ProbeMarker();
        int paths=0,pr=mr?mr:AYE_ProbeRedPaths(4,&paths);
        int fr=pr?pr:AYE_TestRedOutlineViaDoMark();
        wchar_t detail[2048]={0};AYE_GetLastError(detail,2048);
        std::wcout<<L"DOC="<<nr<<L" ADD="<<ar<<L" CONNECT="<<cr<<L" MARKER="<<mr
                  <<L" RED_OUTLINE="<<pr<<L" PATHS="<<paths<<L" DOMARK="<<fr
                  <<L"\nDETAIL="<<detail<<L"\n";
        int sr=AYE_Stop(),close=AYE_DeviceClose();BSL_UnLoadDataFile(job);
        std::wcout<<L"STOP="<<sr<<L" CLOSE="<<close<<L"\n"
                  <<L"OUTLINE_L_RESULT="<<(fr==0?L"PASS_CALL_USB_VISUAL_PENDING":L"FAIL")<<L"\n";
        return fr==0?0:27;
    }
    if(argc>1 && (wcscmp(argv[1],L"--domark-red")==0 || wcscmp(argv[1],L"--frame-red-box")==0 || wcscmp(argv[1],L"--frame-red-vector")==0 || wcscmp(argv[1],L"--frame-red-design")==0 || wcscmp(argv[1],L"--loop-red-box")==0 || wcscmp(argv[1],L"--loop-red-vector")==0 || wcscmp(argv[1],L"--loop-red-design")==0)){
        const bool continuous=wcsncmp(argv[1],L"--loop-red-",11)==0;
        const bool variable=wcscmp(argv[1],L"--frame-red-box")==0 || wcscmp(argv[1],L"--loop-red-box")==0;
        const bool designMode=wcscmp(argv[1],L"--loop-red-design")==0 || wcscmp(argv[1],L"--frame-red-design")==0;
        const bool vectorMode=designMode || wcscmp(argv[1],L"--frame-red-vector")==0 || wcscmp(argv[1],L"--loop-red-vector")==0;
        int dataEnd=argc-(continuous?1:0);
        DWORD parentPid=0;
        if(continuous){
            if(argc<4 || wcsncmp(argv[argc-1],L"--parent=",9)!=0){std::wcerr<<L"RED_LOOP_RESULT=FAIL_PARENT\n";return 29;}
            parentPid=wcstoul(argv[argc-1]+9,nullptr,10);
            if(!parentPid){std::wcerr<<L"RED_LOOP_RESULT=FAIL_PARENT\n";return 29;}
        }
        double xy[4]={-5,-5,5,5};
        std::vector<PF> poly;
        std::vector<int> counts;
        if(designMode){
            if(dataEnd!=3){std::wcerr<<L"FRAME_DESIGN_RESULT=FAIL_ARGUMENTS\n";return 28;}
            std::ifstream input{std::filesystem::path(argv[2])};
            input.imbue(std::locale::classic());
            int lines=0;
            if(!(input>>lines)||lines<1||lines>2048){std::wcerr<<L"FRAME_DESIGN_RESULT=FAIL_LINES\n";return 28;}
            double loX=55,loY=55,hiX=-55,hiY=-55;
            for(int line=0;line<lines;line++){
                int n=0;
                if(!(input>>n)||n<2||n>4096||poly.size()+(size_t)n>65536){
                    std::wcerr<<L"FRAME_DESIGN_RESULT=FAIL_POINTS\n";return 28;
                }
                counts.push_back(n);
                for(int point=0;point<n;point++){
                    double x=0,y=0;
                    if(!(input>>x>>y)||!std::isfinite(x)||!std::isfinite(y)||fabs(x)>55||fabs(y)>55){
                        std::wcerr<<L"FRAME_DESIGN_RESULT=FAIL_COORDINATES\n";return 28;
                    }
                    loX=std::min(loX,x);hiX=std::max(hiX,x);
                    loY=std::min(loY,y);hiY=std::max(hiY,y);
                    poly.push_back({float(x),float(y)});
                }
            }
            if(poly.empty()){
                std::wcerr<<L"FRAME_DESIGN_RESULT=FAIL_BOUNDS\n";return 28;
            }
        }else if(vectorMode){
            if(dataEnd<6 || dataEnd>258 || (dataEnd-2)%2){std::wcerr<<L"FRAME_VECTOR_RESULT=FAIL_ARGUMENTS\n";return 28;}
            double loX=55,loY=55,hiX=-55,hiY=-55;
            for(int i=2;i<dataEnd;i+=2){
                double v[2];
                for(int k=0;k<2;k++){
                    wchar_t*end=nullptr;v[k]=std::wcstod(argv[i+k],&end);
                    if(end==argv[i+k] || *end || !std::isfinite(v[k]) || fabs(v[k])>55){
                        std::wcerr<<L"FRAME_VECTOR_RESULT=FAIL_COORDINATES\n";return 28;
                    }
                }
                loX=std::min(loX,v[0]);hiX=std::max(hiX,v[0]);
                loY=std::min(loY,v[1]);hiY=std::max(hiY,v[1]);
                poly.push_back({float(v[0]),float(v[1])});
            }
            if(hiX-loX<0.1 && hiY-loY<0.1){
                std::wcerr<<L"FRAME_VECTOR_RESULT=FAIL_BOUNDS\n";return 28;
            }
            counts.push_back(int(poly.size()));
        }
        if(variable){
            if(dataEnd!=6){std::wcerr<<L"FRAME_BOX_RESULT=FAIL_ARGUMENTS\n";return 26;}
            for(int i=0;i<4;i++){
                wchar_t* end=nullptr;xy[i]=std::wcstod(argv[i+2],&end);
                if(end==argv[i+2] || *end || !std::isfinite(xy[i]) || fabs(xy[i])>55){
                    std::wcerr<<L"FRAME_BOX_RESULT=FAIL_COORDINATES\n";return 26;
                }
            }
            if(xy[2]<=xy[0] || xy[3]<=xy[1]){
                std::wcerr<<L"FRAME_BOX_RESULT=FAIL_BOUNDS\n";return 26;
            }
        }
        wchar_t job[MAX_PATH]={0};GetFullPathNameW(L"G2_DOMARK_RED_10MM",MAX_PATH,job,nullptr);
        int nr=BSL_NewFile(job);
        if(!vectorMode)poly={{float(xy[0]),float(xy[1])},{float(xy[2]),float(xy[1])},
                             {float(xy[2]),float(xy[3])},{float(xy[0]),float(xy[3])},
                             {float(xy[0]),float(xy[1])}};
        if(counts.empty())counts.push_back(int(poly.size()));
        int ar=nr?nr:BSL_AddLinesToFile2(job,poly.data(),int(counts.size()),counts.data(),(wchar_t*)L"RED_VECTOR",0);
        int cr=ar?ar:AYE_DeviceConnect();int mr=cr?cr:AYE_ProbeMarker();
        // GLaser's rectangular framing uses the vendor's bounds mode (3).
        // Mode 4 was observed to enter the loop without a visible red frame
        // on this G2. Keep design contours on mode 4 separately.
        int mode=variable?3:4;
        int paths=0,pr=mr?mr:AYE_ProbeRedPaths(mode,&paths);
        HANDLE stopEvent=nullptr,parent=nullptr;
        if(continuous && pr==0){
            wchar_t name[96]={0};swprintf_s(name,L"Local\\43AYE3_G2_RED_STOP_%lu",GetCurrentProcessId());
            stopEvent=CreateEventW(nullptr,TRUE,FALSE,name);
            parent=OpenProcess(SYNCHRONIZE,FALSE,parentPid);
            if(!stopEvent||!parent)pr=-8;
            std::wcout<<L"RED_LOOP_EVENT="<<name<<L"\n"<<std::flush;
        }
        int fr=pr,cycles=0;
        std::wcout<<L"RED_SETUP DOC="<<nr<<L" ADD="<<ar<<L" CONNECT="<<cr
                  <<L" MARKER="<<mr<<L" PROBE="<<pr<<L" MODE="<<mode
                  <<L" PATHS="<<paths<<L" CONTOURS="<<counts.size()
                  <<L" POINTS="<<poly.size()<<L"\n"<<std::flush;
        while(fr==0 && (!continuous || (WaitForSingleObject(stopEvent,0)!=WAIT_OBJECT_0 &&
              WaitForSingleObject(parent,0)==WAIT_TIMEOUT))){
            // The UI reads stdout when the process ends. Keep diagnostics
            // bounded so an indefinitely repeated frame cannot fill its pipe.
            if(cycles==0)std::wcout<<L"RED_CALL_BEGIN cycle="<<(cycles+1)<<L"\n"<<std::flush;
            fr=continuous?(variable?AYE_RunRedBoxContinuous(stopEvent,parent):
                                     AYE_RunRedVectorContinuous(stopEvent,parent)):
                          (variable?AYE_TestRedViaDoMark():AYE_TestRedOutlineViaDoMark());
            ++cycles;
            if(cycles==1 || fr!=0)std::wcout<<L"RED_CALL_END cycle="<<cycles<<L" rc="<<fr<<L"\n"<<std::flush;
            if(!continuous)break;
        }
        if(parent)CloseHandle(parent);
        if(stopEvent)CloseHandle(stopEvent);
        wchar_t detail[2048]={0};AYE_GetLastError(detail,2048);
        std::wcout<<L"DOC="<<nr<<L" ADD="<<ar<<L" CONNECT="<<cr<<L" MARKER="<<mr
                  <<L" RED_PATHS="<<pr<<L" PATHS="<<paths<<L" DOMARK="<<fr
                  <<L" MODE="<<mode<<L" CONTOURS="<<counts.size()<<L" POINTS="<<poly.size()<<L" CYCLES="<<cycles
                  <<L" BOX_MM="<<xy[0]<<L","<<xy[1]<<L","<<xy[2]<<L","<<xy[3]
                  <<L"\nDETAIL="<<detail<<L"\n";
        int sr=AYE_Stop();int close=AYE_DeviceClose();BSL_UnLoadDataFile(job);
        std::wcout<<L"STOP="<<sr<<L" CLOSE="<<close<<L"\n"
                  <<L"RED_LOOP_RESULT="<<(continuous?(fr==0&&cycles>0?L"STOPPED":L"FAIL"):L"NOT_REQUESTED")<<L"\n"
                  <<L"FRAME_VECTOR_RESULT="<<(vectorMode?(fr==0?L"PASS_CALL_VISUAL_PENDING":L"FAIL"):L"NOT_REQUESTED")<<L"\n"
                  <<L"FRAME_BOX_RESULT="<<(fr==0?L"PASS_CALL_VISUAL_PENDING":L"FAIL")<<L"\n"
                  <<L"DOMARK_RED_RESULT="<<(fr==0?L"PASS_CALL_USB_VISUAL_PENDING":L"FAIL")<<L"\n";
        return fr==0?0:25;
    }
    wchar_t out[MAX_PATH]={0}; GetFullPathNameW(L"SDK_TEST_RECT.orzx",MAX_PATH,out,nullptr);
    DeleteFileW(out); int rc=BSL_NewFile(out); std::wcout<<L"BSL_NewFile="<<rc<<L"\n"; if(rc)return 10;
    rc=BSL_SetPenParam(out,0,1,1000,20,0,30000,0,0,0,0,0,4000,0,0,0,false,0,0); std::wcout<<L"BSL_SetPenParam="<<rc<<L"\n";if(rc)return 11;
    PF p[]={ {-10,-10},{10,-10},{10,10},{-10,10},{-10,-10} };int counts[]={5};
    rc=BSL_AddLinesToFile2(out,p,1,counts,(wchar_t*)L"TEST_RECT",0);std::wcout<<L"BSL_AddLinesToFile2="<<rc<<L"\n";if(rc)return 12;
    rc=BSL_SaveEntLibToFile(out);std::wcout<<L"BSL_SaveEntLibToFile="<<rc<<L"\n";if(rc){wchar_t e[2048]={0};AYE_GetLastError(e,2048);std::wcout<<L"ERROR="<<e<<L"\n";return 13;}
    WIN32_FILE_ATTRIBUTE_DATA fad={};GetFileAttributesExW(out,GetFileExInfoStandard,&fad);ULARGE_INTEGER sz;sz.HighPart=fad.nFileSizeHigh;sz.LowPart=fad.nFileSizeLow;std::wcout<<L"ORZX_SIZE="<<sz.QuadPart<<L"\n";
    BSL_UnLoadDataFile(out);
    int markerRc=0;
    if(argc>1 && (wcscmp(argv[1],L"--device")==0 || wcscmp(argv[1],L"--marker-probe")==0)){
        rc=AYE_DeviceConnect();std::wcout<<L"AYE_DeviceConnect="<<rc<<L"\n";if(!rc){AYE_DeviceInfo di={};int ir=AYE_DeviceGetInfo(&di);std::wcout<<L"AYE_DeviceGetInfo="<<ir<<L" VALID="<<di.valid_devices<<L" DEV="<<di.device_no<<L" TYPE="<<di.device_type<<L" USB="<<di.usb_speed_type<<L"\n";if(wcscmp(argv[1],L"--marker-probe")==0){markerRc=AYE_ProbeMarker();wchar_t e[2048]={0};AYE_GetLastError(e,2048);std::wcout<<L"AYE_ProbeMarker="<<markerRc<<L" DETAIL="<<e<<L"\n";}else{int sr=AYE_Stop();std::wcout<<L"AYE_Stop="<<sr<<L"\n";}}AYE_DeviceClose();if(markerRc)return 21;
    }
    std::wcout<<L"SELFTEST_RESULT=PASS\n";return 0;
}
