"""Ayuda local: abre manuales empaquetados sin conexión a Internet."""
from pathlib import Path
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices, QKeySequence
from PySide6.QtWidgets import QMessageBox

DOCUMENTS = (
    ('Manual completo (PDF)', '01_Manual_Completo_43AYE3.pdf'),
    ('Flujos de trabajo ilustrados (PDF)', '02_Flujos_Ilustrados_43AYE3.pdf'),
    ('Programación y API con ejemplos (PDF)', '03_Programacion_API_43AYE3.pdf'),
)

def documentation_dir():
    work = Path(__file__).resolve().parent
    for directory in (work.parent / 'DOCUMENTACION', work / 'DOCUMENTACION'):
        if directory.is_dir():
            return directory
    return work.parent / 'DOCUMENTACION'

def open_document(parent, filename=None):
    target = documentation_dir()
    if filename:
        target = target / filename
    if not target.exists():
        QMessageBox.warning(parent, 'Documentación no encontrada',
                            f'Falta este archivo o carpeta:\n{target}\n\n'
                            'Copia DOCUMENTACION desde el ZIP completo junto a work.')
        return False
    if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(target))):
        QMessageBox.warning(parent, 'No se pudo abrir la documentación',
                            f'Abre este archivo con tu lector de PDF o explorador:\n{target}')
        return False
    return True

def install_help(main, menu):
    menu.setTitle('&Help / Ayuda')
    for index, (label, filename) in enumerate(DOCUMENTS):
        action = main.act(label, lambda checked=False, name=filename: open_document(main, name))
        if index == 0:
            action.setShortcut(QKeySequence('F1'))
        menu.addAction(action)
    menu.addSeparator()
    menu.addAction(main.act('Abrir carpeta de documentación', lambda: open_document(main)))
    menu.addAction(main.act('Ejemplos de programación', lambda: open_document(main, 'ejemplos')))
    menu.addSeparator()
