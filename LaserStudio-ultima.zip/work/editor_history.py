"""Bounded document history; never records or replays device commands."""
import copy
import json
from PySide6.QtCore import QObject, QTimer, QEvent, Qt
from PySide6.QtGui import QAction, QPainterPath, QTransform, QPixmap


class EditorHistory(QObject):
    def __init__(self, w):
        super().__init__(w)
        self.w = w
        self.states = []
        self.index = -1
        self.restoring = False
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.capture)
        self.undo_action = QAction('Deshacer', w)
        self.redo_action = QAction('Rehacer', w)
        self.undo_action.setShortcut('Ctrl+Z')
        self.redo_action.setShortcut('Ctrl+Y')
        self.undo_action.triggered.connect(self.undo)
        self.redo_action.triggered.connect(self.redo)
        # Replace the original placeholders and expose the same actions in Edit.
        for tb in w.findChildren(__import__('PySide6.QtWidgets', fromlist=['QToolBar']).QToolBar):
            for a in list(tb.actions()):
                if a.text() in ('↶', '↷'):
                    tb.insertAction(a, self.undo_action if a.text() == '↶' else self.redo_action)
                    tb.removeAction(a)
                    a.setShortcut('')
        edit = next(a.menu() for a in w.menuBar().actions() if a.text().replace('&', '') == 'Edit')
        edit.addAction(self.undo_action)
        edit.addAction(self.redo_action)
        w.scene.changed.connect(self.schedule)
        w.view.viewport().installEventFilter(self)
        table = getattr(w, '_cuts_table', None)
        if table:
            table.cellChanged.connect(self.schedule)
        self.capture()

    def eventFilter(self, obj, event):
        # Flush the previous transaction before another gesture begins.
        if event.type() == QEvent.Type.MouseButtonPress:
            self.capture()
        elif event.type() == QEvent.Type.MouseButtonRelease:
            QTimer.singleShot(0, self.capture)
        return False

    def schedule(self, *args):
        if not self.restoring:
            self.timer.start()

    def snapshot(self):
        from laser_studio import GItem, RasterItem, GroupItem
        records = []
        pixels = {}
        for it in reversed(self.w.scene.items()):
            if not isinstance(it, (GItem, RasterItem, GroupItem)):
                continue
            data = copy.deepcopy(it.data43())
            data['_visible'] = not it.isHidden() if hasattr(it, 'isHidden') else it.isVisible()
            data['_selected'] = it.isSelected() and it.parentItem() is None
            data['_z'] = it.zValue()
            if isinstance(it, GItem):data['_fill_rule'] = it.path().fillRule().value
            data['_origin'] = [it.transformOriginPoint().x(), it.transformOriginPoint().y()]
            if isinstance(it, RasterItem):
                key = len(records)
                pixels[key] = QPixmap(it.pixmap())
                data['_preview'] = getattr(it, 'preview_path', it.source_path)
            records.append(data)
        cuts = copy.deepcopy([c.dict() for c in self.w.cuts])
        # Selection changes do not create edits.
        comparable = [{k: v for k, v in r.items() if k != '_selected'} for r in records]
        comparable.sort(key=lambda r: json.dumps(r, sort_keys=True, ensure_ascii=False))
        signature = json.dumps([cuts, comparable], sort_keys=True, ensure_ascii=False)
        return signature, records, cuts, pixels

    def capture(self):
        if self.restoring:
            return
        self.timer.stop()
        state = self.snapshot()
        if self.index >= 0 and self.states[self.index][0] == state[0]:
            return
        if self.index >= 0:
            self.w.changed = True
        del self.states[self.index + 1:]
        self.states.append(state)
        if len(self.states) > 50:
            self.states.pop(0)
        self.index = len(self.states) - 1
        self.update_actions()

    def reset(self):
        self.states.clear()
        self.index = -1
        self.capture()

    def update_actions(self):
        self.undo_action.setEnabled(self.index > 0)
        self.redo_action.setEnabled(self.index + 1 < len(self.states))

    def undo(self):
        self.capture()
        if self.index > 0:
            self.index -= 1
            self.restore()

    def redo(self):
        self.capture()
        if self.index + 1 < len(self.states):
            self.index += 1
            self.restore()

    def restore(self):
        from laser_studio import GItem, RasterItem, GroupItem, Cut
        w = self.w
        _, records, cuts, pixels = self.states[self.index]
        self.restoring = True
        try:
            w.scene.clear()
            w._preview_geometry_cache.clear()
            w.cuts = []
            for n, values in enumerate(cuts):
                cut = Cut(n)
                cut.__dict__.update(copy.deepcopy(values))
                w.cuts.append(cut)
            for table in (w.layer_table, w._cuts_table):
                table.setRowCount(len(cuts))
            groups = {}
            for r in records:
                if 'id' in r:
                    it = GroupItem(r['id'])
                    groups[r['id']] = it
                    w.scene.addItem(it)
            pairs = []
            for n, r in enumerate(records):
                if 'id' in r:
                    it = groups[r['id']]
                    parent = groups.get(r.get('parent_group_id'))
                elif r['kind'] == 'image':
                    it = RasterItem(r['source'])
                    it.image_settings = copy.deepcopy(r['image_settings'])
                    it.setPixmap(pixels[n])
                    it.preview_path = r['_preview']
                    parent = groups.get(r.get('group_id'))
                else:
                    p = QPainterPath()
                    points = r['pts']
                    j = 0
                    while j < len(points):
                        x, y, t = points[j]
                        if t == 0:
                            p.moveTo(x, y)
                        elif t == 2:
                            a, b = points[j + 1:j + 3]
                            p.cubicTo(x, y, a[0], a[1], b[0], b[1])
                            j += 2
                        elif t == 1:
                            p.lineTo(x, y)
                        j += 1
                    p.setFillRule(Qt.FillRule(r.get('_fill_rule', 0)))
                    it = GItem(p, r['kind'])
                    for name in ('text_meta', 'source_svg', 'test_settings', 'label_width'):
                        setattr(it, name, copy.deepcopy(r.get(name)))
                    parent = groups.get(r.get('group_id'))
                if parent is not None:
                    it.setParentItem(parent)
                    it.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                if it.scene() is None:
                    w.scene.addItem(it)
                if 'layer' in r:
                    w.active_layer = r['layer']
                    w.apply_layer(it)
                it.setPos(r['x'], r['y'])
                it.setRotation(r['rot'])
                it.setScale(r.get('sx', r.get('scale', 1)))
                it.setTransform(QTransform(*r['transform']))
                it.setTransformOriginPoint(*r['_origin'])
                it.setZValue(r['_z'])
                it.setVisible(r['_visible'])
                pairs.append((it, r))
            for it, r in pairs:
                it.setSelected(r['_selected'])
                it.update_handles()
            for n in range(len(cuts)):
                w.update_cut_row(n)
            w.set_layer(min(w.active_layer, len(cuts) - 1), assign_selection=False)
            w.changed = True
            w.schedule_preview()
        finally:
            self.restoring = False
            self.timer.stop()
            self.update_actions()
