"""Editable semantic masks and bounded region heights for bas-relief maps."""
import json
from pathlib import Path
from PIL import Image,ImageOps
from PySide6.QtCore import Qt,QPoint,QSize
from PySide6.QtGui import QImage,QPainter,QColor,QPen,QPixmap,QImageReader
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,
    QPushButton,QComboBox,QSpinBox,QDoubleSpinBox,QCheckBox,QScrollArea,QWidget,
    QDialogButtonBox,QFileDialog,QMessageBox,QTableWidget)
from regional_depth import REGIONS,default_settings,region_paths,validate_settings,canonicalize_regions

class MaskCanvas(QWidget):
    def __init__(self,source,mask,parent=None):
        super().__init__(parent)
        self.mask=QImage(str(mask)).convertToFormat(QImage.Format.Format_RGB32)
        reader=QImageReader(str(source));reader.setAutoTransform(True)
        self.original=reader.read().scaled(self.mask.size(),Qt.AspectRatioMode.IgnoreAspectRatio,Qt.TransformationMode.SmoothTransformation)
        self.setFixedSize(self.mask.size());self.color=QColor(*REGIONS[3][1]);self.brush=20
        self.last=None;self.show_original=True;self.changed=False;self.history=[]
    def paintEvent(self,event):
        painter=QPainter(self)
        if self.show_original:
            painter.drawImage(0,0,self.original);painter.setOpacity(.65)
        painter.drawImage(0,0,self.mask)
    def mousePressEvent(self,event):
        if event.button()!=Qt.MouseButton.LeftButton:return
        self.history.append(self.mask.copy());self.history=self.history[-10:]
        self.last=event.position().toPoint();self.stroke(self.last)
    def mouseMoveEvent(self,event):
        if self.last is not None and event.buttons() & Qt.MouseButton.LeftButton:self.stroke(event.position().toPoint())
    def mouseReleaseEvent(self,event):self.last=None
    def stroke(self,point):
        painter=QPainter(self.mask)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing,False)
        painter.setPen(QPen(self.color,self.brush,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
        painter.drawLine(self.last,point);painter.end();self.last=point;self.changed=True;self.update()
    def undo(self):
        if self.history:self.mask=self.history.pop();self.changed=True;self.update()

class RegionalDepthDialog(QDialog):
    def __init__(self,source,raw,parent=None):
        super().__init__(parent);self.raw=raw;self.mask_path,self.config_path=region_paths(raw)
        self.settings=json.loads(self.config_path.read_text(encoding='utf-8')) if self.config_path.exists() else default_settings()
        self.setWindowTitle('Regiones y alturas · mapa geométrico');self.resize(1100,820)
        layout=QVBoxLayout(self)
        note=QLabel('Revisa las regiones sobre la imagen. Pinta pelo y ropa según su posición, aunque sean negros. Blanco = conservar superficie. Las alturas son relativas; no son milímetros.');note.setWordWrap(True);layout.addWidget(note)
        row=QHBoxLayout();layout.addLayout(row)
        self.region=QComboBox()
        for name,color,lo,hi in REGIONS:self.region.addItem(name)
        self.region.setCurrentIndex(3);row.addWidget(self.region)
        self.brush=QSpinBox();self.brush.setRange(1,200);self.brush.setValue(20);self.brush.setSuffix(' px');row.addWidget(self.brush)
        self.overlay=QCheckBox('Ver original debajo');self.overlay.setChecked(True);row.addWidget(self.overlay)
        undo=QPushButton('Deshacer pincel');row.addWidget(undo)
        body=QHBoxLayout();layout.addLayout(body,1)
        scroll=QScrollArea();self.canvas=MaskCanvas(source,self.mask_path);scroll.setWidget(self.canvas);body.addWidget(scroll,1)
        panel=QWidget();form=QFormLayout(panel);body.addWidget(panel)
        self.table=QTableWidget(len(REGIONS),3);self.table.setHorizontalHeaderLabels(['Región','Mín.','Máx.']);self.spins=[]
        for i,(name,color,_,_) in enumerate(REGIONS):
            label=QLabel(name);label.setStyleSheet('background:rgb(%d,%d,%d);color:%s;padding:4px'%(*color,'black' if sum(color)>500 else 'white'));self.table.setCellWidget(i,0,label)
            pair=[]
            for j,value in enumerate(self.settings['ranges'][i]):
                spin=QSpinBox();spin.setRange(0,255);spin.setValue(int(value));spin.setEnabled(i!=0);self.table.setCellWidget(i,j+1,spin);pair.append(spin)
            self.spins.append(pair)
        self.table.setColumnWidth(0,190);self.table.setColumnWidth(1,65);self.table.setColumnWidth(2,65);self.table.setMinimumWidth(360);self.table.setMinimumHeight(310);form.addRow(self.table)
        self.levels=QSpinBox();self.levels.setRange(0,256);self.levels.setSpecialValueText('0 · continuo (sin escalones)')
        self.levels.setValue(int(self.settings.get('levels',0)));self.levels.setToolTip('0: relieve continuo. De 2 a 256: niveles de profundidad por región. El valor 1 equivale a un único plano.')
        form.addRow('Capas de profundidad por región',self.levels)
        self.smooth=QDoubleSpinBox();self.smooth.setRange(0,12);self.smooth.setValue(self.settings['smooth']);self.smooth.setSuffix(' px');form.addRow('Suavizado dentro de región',self.smooth)
        self.contour=QDoubleSpinBox();self.contour.setRange(1,64);self.contour.setValue(self.settings['contour']);self.contour.setSuffix(' px');form.addRow('Redondeo del volumen',self.contour)
        self.volume=QSpinBox();self.volume.setRange(0,100);self.volume.setValue(round(self.settings.get('volume',.7)*100));self.volume.setSuffix(' %');form.addRow('Forma de la guía IA',self.volume)
        self.detail=QSpinBox();self.detail.setRange(0,100);self.detail.setValue(round(self.settings['detail']*100));self.detail.setSuffix(' %');form.addRow('Detalle IA limitado',self.detail)
        self.attach_brows=QCheckBox('Cejas apoyadas en la curvatura del rostro');self.attach_brows.setChecked(self.settings.get('attach_brows',True));form.addRow(self.attach_brows)
        self.attach_brows.setToolTip('Extiende la altura del rostro adyacente bajo las cejas y añade espesor. La diferencia Máx. − Mín. de cejas controla ese espesor; Máx. limita su altura. Si no contactan con una región de rostro se usa el intervalo original.')
        help_text=QLabel('Forma de la guía conserva el volumen amplio; detalle conserva rasgos pequeños. Forma 0 y detalle 0 usan solo contornos. Continuo evita escalones. Los intervalos protegen el orden entre regiones, aunque la IA puede estimar mal la forma. Revisa la máscara con el pincel.');help_text.setWordWrap(True);form.addRow(help_text)
        imported=QPushButton('Importar máscara de colores…');imported.clicked.connect(self.import_mask);form.addRow(imported)
        exported=QPushButton('Exportar máscara de colores…');exported.clicked.connect(self.export_mask);form.addRow(exported)
        self.reviewed=QCheckBox('Regiones revisadas (anotación opcional)');self.reviewed.setChecked(bool(self.settings.get('reviewed')));form.addRow(self.reviewed)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.save);buttons.rejected.connect(self.reject);layout.addWidget(buttons)
        self.region.currentIndexChanged.connect(lambda i:setattr(self.canvas,'color',QColor(*REGIONS[i][1])))
        self.brush.valueChanged.connect(lambda value:setattr(self.canvas,'brush',value))
        self.overlay.toggled.connect(self.toggle_overlay);undo.clicked.connect(self.canvas.undo)
    def toggle_overlay(self,value):self.canvas.show_original=value;self.canvas.update()
    def import_mask(self):
        path,_=QFileDialog.getOpenFileName(self,'Máscara con colores de la tabla','','Imagen (*.png *.bmp *.tif *.tiff)')
        if not path:return
        from regional_depth import decode_regions,encode_regions
        with Image.open(path) as image:
            labels,_=decode_regions(image.resize((self.canvas.width(),self.canvas.height()),Image.Resampling.NEAREST))
        encoded=encode_regions(labels);data=encoded.tobytes()
        self.canvas.history.append(self.canvas.mask.copy())
        self.canvas.mask=QImage(data,encoded.width,encoded.height,encoded.width*3,QImage.Format.Format_RGB888).copy().convertToFormat(QImage.Format.Format_RGB32)
        self.canvas.changed=True;self.reviewed.setChecked(False);self.canvas.update()
    def export_mask(self):
        path,_=QFileDialog.getSaveFileName(self,'Exportar regiones','','PNG (*.png)')
        if path:self.canvas.mask.save(path,'PNG')
    def save(self):
        settings=dict(self.settings,ranges=[[s.value() for s in pair] for pair in self.spins],levels=self.levels.value(),smooth=self.smooth.value(),contour=self.contour.value(),volume=self.volume.value()/100,detail=self.detail.value()/100,attach_brows=self.attach_brows.isChecked(),reviewed=self.reviewed.isChecked())
        try:validate_settings(settings)
        except ValueError as exc:QMessageBox.information(self,'Alturas',str(exc));return
        if not self.canvas.mask.save(str(self.mask_path),'PNG'):
            QMessageBox.information(self,'Regiones','No se pudo guardar la máscara.');return
        self.config_path.write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8');self.accept()

def create_blank_mask(source,raw):
    from regional_depth import encode_regions
    import numpy as np
    with Image.open(source) as original:
        original=ImageOps.exif_transpose(original).convert('RGBA');original.thumbnail((1024,1024))
        labels=np.ones((original.height,original.width),dtype=np.uint8)
        labels[np.asarray(original)[:,:,3]==0]=0
    mask,config=region_paths(raw);mask.parent.mkdir(parents=True,exist_ok=True)
    encode_regions(labels).save(mask)
    Image.new('L',(original.width,original.height),128).save(raw)
    config.write_text(json.dumps(default_settings(),ensure_ascii=False,indent=2),encoding='utf-8')
