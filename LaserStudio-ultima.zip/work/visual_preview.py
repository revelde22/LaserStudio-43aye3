from PySide6.QtCore import Qt,QTimer,QRectF
from PySide6.QtGui import QColor,QPen,QBrush,QPainter,QPixmap,QPainterPath,QTransform
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QGraphicsView,QGraphicsScene,
    QGraphicsPathItem,QGraphicsPixmapItem,QGraphicsRectItem,QPushButton,QSlider,QLabel,QCheckBox,QPlainTextEdit,QFileDialog,QMessageBox)

class PreviewDialog(QDialog):
    """LaserJob preview. Renders the same planned operations used by the backend."""
    def __init__(self,main):
        super().__init__(main); self.main=main; self.setWindowTitle("Preview — Laser Job"); self.resize(1050,760)
        lay=QVBoxLayout(self); self.scene=QGraphicsScene(self); self.scene.setBackgroundBrush(QColor("#dedede")); self.view=QGraphicsView(self.scene)
        self.view.setRenderHint(QPainter.RenderHint.Antialiasing)
        content=QHBoxLayout(); lay.addLayout(content,1);content.addWidget(self.view,3)
        self.audit_text=QPlainTextEdit();self.audit_text.setReadOnly(True);self.audit_text.setMinimumWidth(340)
        self.audit_text.setStyleSheet("QPlainTextEdit { background: #15212f; color: #e8f2fc; font: 10pt Consolas; }")
        content.addWidget(self.audit_text,2)
        row=QHBoxLayout(); lay.addLayout(row)
        self.play=QPushButton("▶ Play"); self.pause=QPushButton("Ⅱ Pause"); self.stop=QPushButton("■ Stop")
        self.fit_button=QPushButton("Fit design");self.save_report=QPushButton("Guardar informe")
        self.choose_factory=QPushButton("Elegir ZIP del pendrive")
        self.travel=QCheckBox("Show travel moves"); self.travel.setChecked(True)
        self.slider=QSlider(Qt.Orientation.Horizontal); self.slider.setRange(0,1000); self.slider.setValue(1000)
        self.info=QLabel();self.info.setWordWrap(True)
        for x in (self.play,self.pause,self.stop,self.fit_button,self.save_report,self.choose_factory,self.travel): row.addWidget(x)
        row.addWidget(self.slider,1); row.addWidget(self.info)
        self.timer=QTimer(self); self.timer.setInterval(25); self.timer.timeout.connect(self.tick)
        self.play.clicked.connect(self.timer.start); self.pause.clicked.connect(self.timer.stop); self.stop.clicked.connect(self.reset)
        self.fit_button.clicked.connect(self.fit_content)
        self.save_report.clicked.connect(self.save_audit)
        self.choose_factory.clicked.connect(self.choose_factory_zip)
        self.slider.valueChanged.connect(self.render_progress); self.travel.toggled.connect(self.build)
        self.ops=[]; self.travel_ops=[]; self.eta=0.; self.job=None; self.fill_previews={}; self.factory_zip=None; self.build()

    def choose_factory_zip(self):
        filename,_=QFileDialog.getOpenFileName(self,"Elegir copia ZIP del pendrive de fábrica","","ZIP (*.zip)")
        if filename:
            self.factory_zip=filename
            self.build()

    def _add_path(self,path,layer,kind,speed,passes):
        if path.isEmpty(): return None,None
        col=QColor(self.main.cuts[layer].name and __import__('laser_studio').COLORS[layer%len(__import__("laser_studio").COLORS)])
        q=QGraphicsPathItem(path); q.setPen(QPen(col,0)); q.setBrush(Qt.BrushStyle.NoBrush); self.scene.addItem(q)
        length=max(0.0,path.length()); self.eta += length/max(1.0,float(speed))*max(1,int(passes))
        self.ops.append(q); return path.pointAtPercent(0),path.pointAtPercent(1)

    def build(self):
        self.timer.stop(); old=self.slider.value(); self.scene.clear(); self.ops=[]; self.travel_ops=[]; self.fill_previews={}; self.eta=0.
        from laser_job import from_scene
        self.job=from_scene(self.main,False,use_cache=True); last=None
        field=QGraphicsRectItem(QRectF(0,0,110,110));field.setPen(QPen(QColor("#1c6b9f"),0,Qt.PenStyle.DashLine))
        field.setZValue(-20);self.scene.addItem(field)
        for op in self.job.operations:
            start=end=None
            if op.kind in ("Fill","Offset Fill") and isinstance(op.geometry,list):
                p=QPainterPath()
                for a,b in op.geometry: p.moveTo(a); p.lineTo(b)
                start,end=self._add_path(p,op.layer,op.kind,op.speed,op.passes)
                if self.ops and op.geometry:self.fill_previews[self.ops[-1]]=op.geometry
                if not op.geometry:
                    self.info.setText("Fill sin trazos: revisa que el contorno este cerrado y dentro del area")
            elif op.kind=="Image" and isinstance(op.geometry,dict):
                x,y,w,h=op.geometry["rect"]; pm=QPixmap(op.geometry["preview"])
                if pm.isNull():pm=QPixmap(op.geometry.get("source",""))
                if not pm.isNull():
                    q=QGraphicsPixmapItem(pm); tr=QTransform(); tr.translate(x,y); tr.scale(w/max(1,pm.width()),h/max(1,pm.height())); q.setTransform(tr)
                    self.scene.addItem(q); self.ops.append(q); start=QRectF(x,y,w,h).topLeft(); end=QRectF(x,y,w,h).bottomRight()
                    interval=max(.001,float(op.interval or .1)); self.eta += (w*(h/interval))/max(1.0,float(op.speed))*max(1,int(op.passes))
            elif isinstance(op.geometry,QPainterPath):
                start,end=self._add_path(op.geometry,op.layer,op.kind,op.speed,op.passes)
            if self.travel.isChecked() and last is not None and start is not None:
                tp=QPainterPath(last); tp.lineTo(start); tq=QGraphicsPathItem(tp); tq.setPen(QPen(QColor("#ff3030"),0,Qt.PenStyle.DashLine)); tq.setZValue(-10); self.scene.addItem(tq); self.travel_ops.append(tq)
            if end is not None: last=end
        from simulation_audit import audit
        report,bounds,geometry_ok=audit(self.main,self.job,factory_zip=self.factory_zip)
        self.audit_text.setPlainText(report)
        if not bounds.isEmpty():
            box=QGraphicsRectItem(bounds)
            box.setPen(QPen(QColor("#18a058" if geometry_ok else "#df3b45"),0,Qt.PenStyle.DashLine))
            box.setZValue(-5);self.scene.addItem(box)
        rect=self.main.scene.sceneRect().united(self.scene.itemsBoundingRect()).adjusted(-3,-3,3,3)
        self.scene.setSceneRect(rect); self.fit_content()
        self.slider.blockSignals(True); self.slider.setValue(old); self.slider.blockSignals(False); self.render_progress(old)
        QTimer.singleShot(0,self.fit_content)
        if not self.ops:
            self.info.setText("Vista vacia: importa o selecciona una imagen/vector y comprueba Output en la capa")
        elif self.job.warnings:
            self.info.setText(self.job.warnings[0])

    def fit_content(self):
        rect=self.scene.itemsBoundingRect() if self.ops else self.scene.sceneRect()
        if rect.isEmpty():rect=self.main.scene.sceneRect()
        margin=max(2.0,max(rect.width(),rect.height())*.08)
        self.view.fitInView(rect.adjusted(-margin,-margin,margin,margin),Qt.AspectRatioMode.KeepAspectRatio)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,"ops") and hasattr(self,"view"):
            QTimer.singleShot(0,self.fit_content)

    def render_progress(self,v):
        n=len(self.ops)
        # Un relleno completo es una operación, pero puede contener miles de trazos.
        weights=[len(self.fill_previews.get(q,())) or 1 for q in self.ops]
        target=sum(weights)*v/1000.; offset=0
        for q,weight in zip(self.ops,weights):
            fraction=max(0.,min(1.,(target-offset)/weight));offset+=weight
            if q in self.fill_previews:
                segments=self.fill_previews[q]
                partial=QPainterPath()
                for a,b in segments[:int(len(segments)*fraction)]:partial.moveTo(a);partial.lineTo(b)
                q.setPath(partial)
                q.setOpacity(1.)
            else:q.setOpacity(1. if fraction>=1. else .10)
        note=(" · "+self.job.warnings[0]) if self.job and self.job.warnings else ""
        self.info.setText(f"Operaciones: {n} · Progreso visual: {v/10:.1f}% · Solo trazado: ≥{self.eta:.2f} s"+note)
    def tick(self):
        v=self.slider.value()+5
        if v>=1000: v=1000; self.timer.stop()
        self.slider.setValue(v)
    def reset(self): self.timer.stop(); self.slider.setValue(0)

    def save_audit(self):
        filename,_=QFileDialog.getSaveFileName(self,"Guardar informe de simulación","simulacion_43aye3.txt","Texto (*.txt)")
        if not filename:return
        try:
            from pathlib import Path
            Path(filename).write_text(self.audit_text.toPlainText()+"\n",encoding="utf-8")
        except OSError as exc:
            QMessageBox.warning(self,"Informe de simulación",f"No se pudo guardar: {exc}")
