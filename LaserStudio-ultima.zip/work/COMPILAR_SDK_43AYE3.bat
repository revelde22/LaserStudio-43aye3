@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "SDKDIR=%~dp0BSL_SDK\43AYE3_G2_SDK"
set "LOG=%~dp043AYE3_SDK_BUILD.log"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "BUILDROOT=%TEMP%\43AYE3_G2_SDK_BUILD_%RANDOM%_%RANDOM%"

>"%LOG%" echo ==== 43AYE3 G2 SDK BUILD %DATE% %TIME% ====
>>"%LOG%" echo SDKDIR=%SDKDIR%
>>"%LOG%" echo BUILDROOT=%BUILDROOT%

echo ============================================================
echo   43AYE3 G2 V1 - BUILD AISLADO x86
echo ============================================================
echo Carpeta SDK: %SDKDIR%
echo Build temporal: %BUILDROOT%
echo.

if not exist "%SDKDIR%\43AYE3_BSL_COMPAT.cpp" (
  echo [ERROR] Falta 43AYE3_BSL_COMPAT.cpp
  >>"%LOG%" echo ERROR=SOURCE_NOT_FOUND
  exit /b 10
)
if not exist "%SDKDIR%\43AYE3_BSL_COMPAT.h" (
  echo [ERROR] Falta 43AYE3_BSL_COMPAT.h
  >>"%LOG%" echo ERROR=HEADER_NOT_FOUND
  exit /b 11
)
if not exist "%SDKDIR%\sdk_selftest_x86.cpp" (
  echo [ERROR] Falta sdk_selftest_x86.cpp
  >>"%LOG%" echo ERROR=SELFTEST_SOURCE_NOT_FOUND
  exit /b 12
)
if not exist "%VSWHERE%" (
  echo [ERROR] No encuentro Visual Studio Build Tools.
  echo Instala Desktop development with C++ x86/x64.
  >>"%LOG%" echo ERROR=VSWHERE_NOT_FOUND
  exit /b 13
)

set "VSROOT="
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%I"
if not defined VSROOT (
  echo [ERROR] No encuentro las herramientas C++ x86.
  >>"%LOG%" echo ERROR=VSROOT_EMPTY
  exit /b 14
)
>>"%LOG%" echo VSROOT=!VSROOT!

rem IMPORTANTE: no redirigimos vcvars32 al mismo LOG. En algunos equipos
rem un proceso hijo hereda el handle del fichero y Windows deja el LOG bloqueado.
call "!VSROOT!\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] vcvars32.bat fallo.
  >>"%LOG%" echo ERROR=VCVARS32_FAILED
  exit /b 15
)

where cl >nul 2>nul
if errorlevel 1 (
  echo [ERROR] cl.exe no quedo disponible tras vcvars32.
  >>"%LOG%" echo ERROR=CL_NOT_FOUND
  exit /b 16
)
where link >nul 2>nul
if errorlevel 1 (
  echo [ERROR] link.exe no quedo disponible tras vcvars32.
  >>"%LOG%" echo ERROR=LINK_NOT_FOUND
  exit /b 17
)

if exist "%BUILDROOT%" rd /s /q "%BUILDROOT%" >nul 2>nul
mkdir "%BUILDROOT%" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] No puedo crear la carpeta temporal de compilacion.
  >>"%LOG%" echo ERROR=TEMP_BUILD_DIR_FAILED
  exit /b 18
)

copy /y "%SDKDIR%\43AYE3_BSL_COMPAT.cpp" "%BUILDROOT%\43AYE3_BSL_COMPAT.cpp" >nul
copy /y "%SDKDIR%\43AYE3_BSL_COMPAT.h" "%BUILDROOT%\43AYE3_BSL_COMPAT.h" >nul
copy /y "%SDKDIR%\sdk_selftest_x86.cpp" "%BUILDROOT%\sdk_selftest_x86.cpp" >nul

pushd "%BUILDROOT%"

echo [1/4] Compilando C++ en carpeta temporal...
cl /nologo /std:c++17 /EHsc /O2 /MT /DWIN32_LEAN_AND_MEAN /DNOMINMAX /c 43AYE3_BSL_COMPAT.cpp /Fo:43AYE3_BSL_COMPAT.obj >compile.out 2>&1
set "RC=!ERRORLEVEL!"
type compile.out
>>"%LOG%" echo ---- COMPILE ----
>>"%LOG%" type compile.out
if not "!RC!"=="0" (
  echo [ERROR] Fallo compilando C++. CODIGO=!RC!
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 20
)
if not exist 43AYE3_BSL_COMPAT.obj (
  echo [ERROR] cl.exe termino sin crear el OBJ.
  >>"%LOG%" echo ERROR=OBJ_NOT_CREATED
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 21
)

echo [2/4] Enlazando DLL en carpeta temporal...
link /nologo /DLL /OUT:43AYE3_BSL_COMPAT.dll /IMPLIB:43AYE3_BSL_COMPAT.lib 43AYE3_BSL_COMPAT.obj ole32.lib windowscodecs.lib >link.out 2>&1
set "RC=!ERRORLEVEL!"
type link.out
>>"%LOG%" echo ---- LINK ----
>>"%LOG%" type link.out
if not "!RC!"=="0" (
  echo [ERROR] Fallo enlazando la DLL. CODIGO=!RC!
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 22
)
if not exist 43AYE3_BSL_COMPAT.dll (
  echo [ERROR] El linker no creo 43AYE3_BSL_COMPAT.dll
  >>"%LOG%" echo ERROR=DLL_NOT_CREATED
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 23
)

echo [3/4] Verificando exports...
dumpbin /nologo /exports 43AYE3_BSL_COMPAT.dll >exports.out 2>&1
set "RC=!ERRORLEVEL!"
if not "!RC!"=="0" (
  type exports.out
  echo [ERROR] dumpbin no pudo leer la DLL. CODIGO=!RC!
  >>"%LOG%" type exports.out
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 24
)
findstr /I /C:"BSL_NewFile" exports.out >nul
if errorlevel 1 (
  type exports.out
  echo [ERROR] La DLL no exporta BSL_NewFile.
  >>"%LOG%" type exports.out
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 25
)
findstr /I /C:"BSL_SaveEntLibToFile" exports.out >nul
if errorlevel 1 (
  type exports.out
  echo [ERROR] La DLL no exporta BSL_SaveEntLibToFile.
  >>"%LOG%" type exports.out
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 26
)
findstr /I /C:"AYE_GetCapabilities" exports.out >nul
if errorlevel 1 (
  echo [ERROR] La DLL no exporta AYE_GetCapabilities.
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 28
)
copy /y exports.out "%SDKDIR%\43AYE3_BSL_COMPAT_exports.txt" >nul

echo [4/4] Compilando self-test...
cl /nologo /std:c++17 /EHsc /O2 /MT /DNOMINMAX sdk_selftest_x86.cpp 43AYE3_BSL_COMPAT.lib /Fe:43AYE3_SDK_SELFTEST.exe >selftest_build.out 2>&1
set "RC=!ERRORLEVEL!"
type selftest_build.out
>>"%LOG%" echo ---- SELFTEST BUILD ----
>>"%LOG%" type selftest_build.out
if not "!RC!"=="0" (
  echo [ERROR] DLL creada, pero fallo compilando self-test. CODIGO=!RC!
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 27
)
43AYE3_SDK_SELFTEST.exe --capabilities >capabilities.out 2>&1
set "RC=!ERRORLEVEL!"
type capabilities.out
>>"%LOG%" type capabilities.out
if not "!RC!"=="0" (
  echo [ERROR] Self-test de capacidades fallido. CODIGO=!RC!
  popd
  rd /s /q "%BUILDROOT%" >nul 2>nul
  exit /b 29
)

popd

rem Copiamos al final, cuando todos los procesos de compilacion ya han cerrado.
rem Se reintenta porque Defender/antivirus puede retener una DLL unos milisegundos.
call :COPY_RETRY "%BUILDROOT%\43AYE3_BSL_COMPAT.dll" "%SDKDIR%\43AYE3_BSL_COMPAT.dll"
if errorlevel 1 goto :COPY_LOCKED
call :COPY_RETRY "%BUILDROOT%\43AYE3_BSL_COMPAT.lib" "%SDKDIR%\43AYE3_BSL_COMPAT.lib"
if errorlevel 1 goto :COPY_LOCKED
call :COPY_RETRY "%BUILDROOT%\43AYE3_SDK_SELFTEST.exe" "%SDKDIR%\43AYE3_SDK_SELFTEST.exe"
if errorlevel 1 goto :COPY_LOCKED
call :COPY_RETRY "%BUILDROOT%\43AYE3_BSL_COMPAT.dll" "%~dp0G2_RUNTIME\43AYE3_BSL_COMPAT.dll"
if errorlevel 1 goto :COPY_LOCKED
call :COPY_RETRY "%BUILDROOT%\43AYE3_BSL_COMPAT.dll" "%~dp0BSL_SDK\43AYE3_BSL_COMPAT.dll"
if errorlevel 1 goto :COPY_LOCKED

rd /s /q "%BUILDROOT%" >nul 2>nul
>>"%LOG%" echo BUILD_RESULT=PASS

echo.
echo [OK] 43AYE3_BSL_COMPAT.dll compilada correctamente.
echo [OK] La compilacion se hizo fuera de la carpeta del programa para evitar bloqueos.
echo [OK] G2_RUNTIME\43AYE3_BSL_COMPAT.dll
echo [OK] BSL_SDK\43AYE3_BSL_COMPAT.dll
exit /b 0

:COPY_LOCKED
echo.
echo [ERROR] Windows mantiene bloqueado un archivo de destino.
echo Cierra cualquier 43AYE3 Laser Studio/Python que siga abierto y vuelve a ejecutar el BAT.
echo NO hace falta borrar nada manualmente.
>>"%LOG%" echo ERROR=DESTINATION_FILE_LOCKED
rd /s /q "%BUILDROOT%" >nul 2>nul
exit /b 31

:COPY_RETRY
set "SRC=%~1"
set "DST=%~2"
set /a TRY=0
:COPY_RETRY_LOOP
set /a TRY+=1
copy /y "%SRC%" "%DST%" >nul 2>nul
if not errorlevel 1 exit /b 0
if !TRY! GEQ 8 exit /b 1
>nul 2>&1 ping 127.0.0.1 -n 2
GOTO :COPY_RETRY_LOOP
