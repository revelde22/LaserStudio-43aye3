"""Auditoría local del trabajo; nunca abre el puente ni envía órdenes al G2."""

import configparser
import math
from pathlib import Path
from pathlib import PureWindowsPath
import zipfile

from PySide6.QtCore import QPointF, QRectF
from PySide6.QtGui import QPainterPath


FIELD_MM = 110.0
CORRECTION_KEYS = ("LEN_BUCKETX", "LEN_BUCKETY", "LEN_PRRLX", "LEN_PRRLY",
                   "LEN_SCALEX", "LEN_SCALEY", "LEN_TRAPEX", "LEN_TRAPEY")
FACTORY_RELATIVE = Path("G2PRO-Glaser--win") / "G251218-5629-110"


def _factory_profile(configured_path, factory_zip=None):
    """Lee el perfil de fábrica sin extraer ni ejecutar archivos del USB."""
    candidates = [Path(configured_path)] if configured_path else []
    # El USB original puede haber cambiado de letra desde que se creó LmcPar.cfg.
    if PureWindowsPath(configured_path).name == FACTORY_RELATIVE.name:
        candidates += [Path(f"{letter}:/") / FACTORY_RELATIVE for letter in "DEFGHIJKLMNOPQRSTUVWXYZ"]
    for path in candidates:
        try:
            if path.is_file() and path.stat().st_size <= 4096:
                return str(path), path.read_bytes()
        except OSError:
            continue
    if factory_zip:
        try:
            with zipfile.ZipFile(factory_zip) as archive:
                names = [info for info in archive.infolist()
                         if ("/" + info.filename.replace("\\", "/").lower()).endswith(
                             "/g2pro-glaser--win/g251218-5629-110") and info.file_size <= 4096]
                if len(names) == 1:
                    return f"ZIP {factory_zip} → {names[0].filename}", archive.read(names[0])
        except (OSError, ValueError, zipfile.BadZipFile, RuntimeError):
            pass
    return None, None


def _configuration(factory_zip=None):
    root = Path(__file__).resolve().parent
    candidates = (root / "config", Path.home() / "Documents" / "G2PRO" / "config")
    folder = next((p for p in candidates if (p / "LmcPar.cfg").is_file()), None)
    if folder is None:
        return "SIN VERIFICAR: no se encontró config/LmcPar.cfg en la instalación local."
    cfg = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        cfg.read(folder / "LmcPar.cfg", encoding="latin-1")
        p = cfg["default"]
        size = float(p.get("LEN_WORKSIZE", "nan"))
        standalone = p.get("LEN_USE_STANDALONG_FILE", "0").strip() == "1"
        correction = p.get("LEN_STANDALONG_FILE", "").strip()
        result = [f"Configuración: {folder}", f"Campo LEN_WORKSIZE: {size:g} mm"]
        if not math.isfinite(size) or size <= 0:
            result.append("REVISAR: campo de trabajo no válido.")
        elif abs(size - FIELD_MM) > 0.001:
            result.append("REVISAR: el perfil no coincide con la simulación de 110 mm.")
        if standalone:
            source, data = _factory_profile(correction, factory_zip)
            if data is None:
                result.append("Perfil de fábrica: PENDIENTE; conecta el USB original o elige su ZIP.")
            else:
                factory = configparser.ConfigParser(interpolation=None, strict=False)
                try:
                    factory.read_string(data.decode("latin-1"))
                    values = factory["STANDALONG_MAN_COL"]
                    matching = sum(math.isclose(float(values[key]), float(p[key]), rel_tol=0, abs_tol=1e-6)
                                   and (not p.get(key + "_FROMFILE") or math.isclose(
                                       float(values[key]), float(p[key + "_FROMFILE"]), rel_tol=0, abs_tol=1e-6))
                                   for key in CORRECTION_KEYS)
                    result.append(f"Perfil de fábrica: {matching}/8 valores de corrección coinciden con LmcPar.cfg.")
                    if matching != 8: result.append("REVISAR: no sustituir ni aplicar un perfil distinto al del equipo.")
                except (KeyError, ValueError, configparser.Error):
                    result.append("Perfil de fábrica: REVISAR; no se pudo validar su contenido.")
                result.append("Origen leído (sin ejecutar): " + source)
            if correction: result.append("Ruta original configurada: " + correction)
            if source and Path(correction) != Path(source):
                result.append("La letra de unidad de la ruta original puede haber cambiado; no se ha modificado la configuración.")
        else:
            result.append("Corrección independiente: desactivada en este perfil.")
        return "\n".join(result)
    except (OSError, ValueError, KeyError, configparser.Error) as exc:
        return f"SIN VERIFICAR: no se pudo interpretar LmcPar.cfg ({type(exc).__name__})."


def _operation_metrics(op):
    """Devuelve trazado visible, desplazamientos internos y longitud aproximada."""
    g = op.geometry
    if isinstance(g, QPainterPath):
        return (1 if not g.isEmpty() else 0), max(0., g.length()), 0., (
            g.pointAtPercent(0), g.pointAtPercent(1)) if not g.isEmpty() else None
    if isinstance(g, list):
        segments = [(a, b) for a, b in g if isinstance(a, QPointF) and isinstance(b, QPointF)]
        length = sum(math.hypot(a.x()-b.x(), a.y()-b.y()) for a, b in segments)
        travel = sum(math.hypot(a.x()-b.x(), a.y()-b.y())
                     for (_, a), (b, _) in zip(segments, segments[1:]))
        return len(segments), length, travel, (segments[0][0], segments[-1][1]) if segments else None
    if isinstance(g, dict) and "rect" in g:
        x, y, w, h = g["rect"]
        interval = max(.001, float(op.interval or .1))
        return max(1, math.ceil(h / interval)), max(0., w*h/interval), 0., (
            QPointF(x, y), QPointF(x+w, y+h))
    return 0, 0., 0., None


def audit(main, job, factory_zip=None):
    """Métricas del plan 2D, no una predicción del controlador ni del material."""
    x, y, w, h = job.bounds
    finite = all(math.isfinite(float(v)) for v in (x, y, w, h))
    inside = finite and w > 0 and h > 0 and x >= 0 and y >= 0 and x+w <= FIELD_MM and y+h <= FIELD_MM
    totals = {"segments": 0, "draw": 0., "travel": 0., "seconds": 0.}
    layers = {}
    last = None
    for op in job.operations:
        count, draw, internal, ends = _operation_metrics(op)
        if not count:
            continue
        layer = layers.setdefault(op.layer, {"ops": 0, "segments": 0, "draw": 0., "seconds": 0.})
        passes = max(1, int(op.passes))
        seconds = draw * passes / max(1., float(op.speed))
        layer["ops"] += 1; layer["segments"] += count * passes
        layer["draw"] += draw * passes; layer["seconds"] += seconds
        totals["segments"] += count * passes
        totals["draw"] += draw * passes
        totals["travel"] += internal
        totals["seconds"] += seconds
        if ends:
            if last is not None:
                totals["travel"] += math.hypot(last.x()-ends[0].x(), last.y()-ends[0].y())
            last = ends[1]
    warnings = list(job.warnings)
    if not job.operations: warnings.append("No hay operaciones con salida activa.")
    elif not totals["segments"]: warnings.append("Las operaciones activas no generan trazos visibles.")
    if not inside and job.operations: warnings.append("El diseño excede el campo de 110 × 110 mm o tiene dimensiones inválidas.")
    lines = ["SIMULACIÓN LOCAL · SIN CONEXIÓN AL LÁSER", "="*42,
             "Resultado del diseño: PENDIENTE",
             f"Área de cálculo: {FIELD_MM:g} × {FIELD_MM:g} mm",
             f"Diseño: X {x:.3f} · Y {y:.3f} · Ancho {w:.3f} · Alto {h:.3f} mm",
             f"Operaciones: {len(job.operations)} · Trazos/pasadas: {totals['segments']}",
             f"Longitud de trabajo: {totals['draw']:.2f} mm",
             f"Recorrido sin marcar (aprox.): {totals['travel']:.2f} mm",
             f"Mínimo teórico de trazado: {totals['seconds']:.2f} s",
             "El tiempo real será mayor: faltan saltos, aceleración y control del equipo.", "", "CAPAS"]
    for number, data in sorted(layers.items()):
        cut = main.cuts[number]
        lines += [f"C{number:02d} {cut.mode}: {data['ops']} operaciones · {data['segments']} trazos",
                  f"  {data['draw']:.2f} mm · {data['seconds']:.2f} s · "
                  f"{cut.speed:g} mm/s · {cut.power:g}% · {cut.frequency:g} kHz · {cut.passes} pasadas"]
        if not math.isfinite(float(cut.speed)) or cut.speed <= 0 or not 0 <= cut.power <= 100 or cut.frequency <= 0:
            warnings.append(f"C{number:02d}: velocidad, potencia o frecuencia fuera de rango.")
    lines[2] = "Diseño 2D: " + ("REVISAR" if warnings else "DENTRO DEL CAMPO")
    lines += ["", "AVISOS"] + (["• " + v for v in warnings] if warnings else ["Sin avisos geométricos."])
    lines += ["", "CONFIGURACIÓN DE ESTE WINDOWS", _configuration(factory_zip), "", "RESULTADO GLOBAL: PENDIENTE DE VALIDACIÓN FÍSICA", "CONTROL FÍSICO",
              "Tamaño de reserva CMarkMgr: 0x320, observado en GLaser original.",
              "InitDevices puede ir seguido de activación de luz roja en GLaser; no se invoca aquí.",
              "SIN VALIDAR: ABI completa, calibración activa, emisión y parada de emergencia.",
              "FRAME / MARK / STOP directos: BLOQUEADOS.",
              "Esta simulación no certifica seguridad ni resultado de marcado."]
    return "\n".join(lines), QRectF(x, y, w, h), inside and not warnings
