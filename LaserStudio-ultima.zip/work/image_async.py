import os, sys, json, subprocess
from pathlib import Path
from PySide6.QtCore import QObject, Signal, QRunnable, QThreadPool

class _Signals(QObject):
    finished=Signal(int, object, object)

class PrepareTask(QRunnable):
    def __init__(self, token, source, kwargs):
        super().__init__(); self.token=token; self.source=source; self.kwargs=dict(kwargs); self.signals=_Signals()
    def run(self):
        try:
            worker=Path(__file__).with_name('image_worker_cli.py')
            creationflags=0x08000000 if os.name=='nt' else 0
            p=subprocess.run([sys.executable,str(worker),str(self.source),json.dumps(self.kwargs)],
                             capture_output=True,text=True,encoding='utf-8',errors='replace',
                             creationflags=creationflags,timeout=900)
            lines=[x.strip() for x in (p.stdout or '').splitlines() if x.strip()]
            data=None
            for line in reversed(lines):
                try:
                    cand=json.loads(line)
                    if isinstance(cand,dict) and 'ok' in cand:
                        data=cand;break
                except Exception:
                    pass
            if p.returncode!=0 or not data or not data.get('ok'):
                err=(data or {}).get('error') if isinstance(data,dict) else None
                raise RuntimeError(err or (p.stderr or p.stdout or f'worker return={p.returncode}').strip())
            self.signals.finished.emit(self.token,data['out'],None)
        except Exception as exc:
            self.signals.finished.emit(self.token,None,str(exc))

# One image calculation at a time. New slider changes discard queued stale jobs;
# the CPU-heavy Jarvis/Stucki loop runs in a separate process, never on Qt's GIL.
_POOL=QThreadPool()
_POOL.setMaxThreadCount(1)

def submit_prepare(token, source, kwargs, callback):
    try:_POOL.clear()
    except Exception:pass
    task=PrepareTask(token,source,kwargs)
    task.signals.finished.connect(callback)
    _POOL.start(task)
    return task
