"""Importar un STL como relieve dentro de 43AYE3 (menu Archivo > Importar STL como relieve).

Flujo: elegir .stl -> ventana con vista previa y opciones de simplificado (malla y relieve) -> se guarda un PNG de
profundidad (blanco = sin tallar, negro = mas hondo) -> se coloca en una capa libre -> se abre "Preparar tallado".
"""
import copy
import json
import re
import tempfile
import time
from pathlib import Path

import numpy as np
from PySide6.QtCore import QPointF, Qt, QTimer
from PySide6.QtGui import QImage, QPixmap, QTransform
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QLabel, QMessageBox, QSpinBox, QVBoxLayout, QWidget)

import stl_relief as sr

PREVIEW_PX = 380
VISTAS_TEXTO = {'superior': 'Superior (desde arriba, +Z)', 'inferior': 'Inferior (desde abajo)', 'frontal': 'Frontal',
                'trasera': 'Trasera', 'izquierda': 'Izquierda', 'derecha': 'Derecha'}


def pixmap_gris(array):
    datos = np.ascontiguousarray(array, dtype=np.uint8)
    alto, ancho = datos.shape
    return QPixmap.fromImage(QImage(datos.data, ancho, alto, ancho, QImage.Format.Format_Grayscale8).copy())


class StlReliefDialog(QDialog):
    def __init__(self, triangulos, nombre, parent=None, campo_mm=None):
        super().__init__(parent)
        self.setWindowTitle('Importar STL como relieve · ' + nombre)
        self.resize(940, 640)
        self.triangulos = triangulos
        self.campo_mm = campo_mm
        self._malla = None
        self._malla_objetivo = None
        self.temporizador = QTimer(self)
        self.temporizador.setSingleShot(True)
        self.temporizador.setInterval(150)
        self.temporizador.timeout.connect(self.actualizar)

        panel = QWidget()
        form = QFormLayout(panel)
        self.vista = QComboBox()
        for clave in sr.VISTAS:
            self.vista.addItem(VISTAS_TEXTO[clave], clave)
        self.vista.setToolTip('Desde qué lado mira el láser el modelo. Lo más cercano a ese lado queda blanco (sin tallar).')
        self.ancho = QDoubleSpinBox(); self.ancho.setRange(0, 2000); self.ancho.setDecimals(2); self.ancho.setSuffix(' mm')
        self.ancho.setSpecialValueText('tamaño original del STL')
        self.ancho.setToolTip('Ancho final del grabado. La altura del relieve se escala igual (proporciones reales).')
        self.intervalo = QDoubleSpinBox(); self.intervalo.setRange(.01, 5); self.intervalo.setDecimals(3); self.intervalo.setValue(.1)
        self.intervalo.setSuffix(' mm / píxel')
        self.intervalo.setToolTip('Tamaño de píxel del mapa. Usa el mismo intervalo que tu pluma de tallado (normalmente 0,1 mm).')
        self.simplificar = QCheckBox('Simplificar la malla (menos triángulos)')
        self.triangulos_max = QSpinBox(); self.triangulos_max.setRange(100, 2_000_000); self.triangulos_max.setSingleStep(1000)
        self.triangulos_max.setValue(min(50_000, max(100, len(triangulos))))
        self.triangulos_max.setSuffix(' triángulos')
        self.suavizado = QSpinBox(); self.suavizado.setRange(0, 60); self.suavizado.setSuffix(' px')
        self.suavizado.setToolTip('Alisa el relieve sin mezclar el borde de la pieza con el fondo. 0 = sin alisar.')
        self.niveles = QSpinBox(); self.niveles.setRange(0, 256); self.niveles.setSpecialValueText('continuo')
        self.niveles.setToolTip('Terrazas: 0 = continuo; de 2 a 256 = número de alturas distintas.')
        self.profundidad = QSpinBox(); self.profundidad.setRange(1, 100); self.profundidad.setValue(100); self.profundidad.setSuffix(' %')
        self.profundidad.setToolTip('Qué parte del rango de grises usa el relieve. 100 % = el punto más bajo llega a negro (objetivo en mm).')
        self.invertir = QCheckBox('Invertir (lo más alto se talla más)')
        for etiqueta, control in (('Vista', self.vista), ('Ancho', self.ancho), ('Resolución', self.intervalo)):
            form.addRow(etiqueta, control)
        form.addRow(self.simplificar)
        form.addRow('Objetivo de malla', self.triangulos_max)
        form.addRow('Suavizado del relieve', self.suavizado)
        form.addRow('Niveles (terrazas)', self.niveles)
        form.addRow('Profundidad', self.profundidad)
        form.addRow(self.invertir)
        self.info = QLabel(); self.info.setWordWrap(True)
        form.addRow(self.info)
        panel.setFixedWidth(340)

        self.lienzo = QLabel('Calculando…')
        self.lienzo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lienzo.setMinimumSize(420, 420)
        self.lienzo.setStyleSheet('background:#fff;color:#444')
        self.pix = None
        botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        botones.button(QDialogButtonBox.StandardButton.Ok).setText('Importar relieve')
        botones.accepted.connect(self.accept)
        botones.rejected.connect(self.reject)
        fila = QHBoxLayout()
        fila.addWidget(panel)
        derecha = QVBoxLayout()
        derecha.addWidget(QLabel('Vista previa (blanco = sin tallar, negro = más hondo)'))
        derecha.addWidget(self.lienzo, 1)
        fila.addLayout(derecha, 1)
        general = QVBoxLayout(self)
        general.addLayout(fila, 1)
        general.addWidget(botones)

        for control in (self.vista, self.simplificar):
            (control.currentIndexChanged if isinstance(control, QComboBox) else control.toggled).connect(self.programar)
        for control in (self.ancho, self.intervalo, self.triangulos_max, self.suavizado, self.niveles, self.profundidad):
            control.valueChanged.connect(self.programar)
        self.invertir.toggled.connect(self.programar)
        self.actualizar()

    # ---------------------------------------------------------- parametros
    def objetivo_malla(self):
        return self.triangulos_max.value() if self.simplificar.isChecked() else 0

    def parametros(self):
        return dict(vista=self.vista.currentData(), ancho_mm=self.ancho.value(), intervalo_mm=self.intervalo.value(),
                    suavizado=self.suavizado.value(), niveles=self.niveles.value() if self.niveles.value() >= 2 else 0,
                    profundidad=self.profundidad.value() / 100., invertir=self.invertir.isChecked())

    def malla(self):
        """Malla ya simplificada (con cache: simplificar es lo mas caro y no depende de la vista)."""
        objetivo = self.objetivo_malla()
        if objetivo != self._malla_objetivo or self._malla is None:
            self._malla = sr.simplificar_malla(self.triangulos, objetivo) if objetivo else self.triangulos
            self._malla_objetivo = objetivo
        return self._malla

    # ---------------------------------------------------------- calculo
    def programar(self, *_):
        self.temporizador.start()

    def calcular(self, max_px):
        return sr.stl_a_relieve(self.malla(), max_px=max_px, **self.parametros())

    def actualizar(self):
        try:
            r = self.calcular(PREVIEW_PX)
        except sr.ErrorSTL as error:
            self.info.setText(str(error)); self.pix = None; self.lienzo.setText(str(error)); return
        self.pix = pixmap_gris(r['gris'])
        aviso = ''
        if self.campo_mm and max(r['ancho_mm'], r['alto_mm']) > self.campo_mm:
            aviso = f'\n⚠ Supera el campo del láser ({self.campo_mm:g} mm): se reducirá al colocarlo.'
        self.info.setText(f"Triángulos: {len(self.triangulos):,} → {r['triangulos_despues']:,}\n"
                          f"Tamaño: {r['ancho_mm']:.2f} × {r['alto_mm']:.2f} mm\n"
                          f"Altura del relieve: {r['relieve_mm']:.2f} mm\n"
                          'La profundidad grabada la fija el objetivo en mm del paso siguiente (negro = objetivo).' + aviso)
        self.ajustar()

    def ajustar(self):
        if self.pix is not None:
            self.lienzo.setPixmap(self.pix.scaled(self.lienzo.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                                  Qt.TransformationMode.FastTransformation))

    def resizeEvent(self, evento):
        super().resizeEvent(evento)
        self.ajustar()

    def resultado_final(self, max_px=2400):
        """Mapa a resolucion completa (con el mismo `max_px` solo se limita el tamano maximo en pixeles)."""
        return self.calcular(max_px)


# ---------------------------------------------------------------- guardado y colocacion

def carpeta_salida():
    destino = Path(__file__).resolve().parent / 'STL_RELIEFS'
    try:
        destino.mkdir(exist_ok=True)
        prueba = destino / '.escritura'
        prueba.write_text('ok'); prueba.unlink()
        return destino
    except OSError:
        return Path(tempfile.mkdtemp(prefix='stl_relieves_'))


def guardar_mapa(resultado, ruta_stl, opciones, carpeta=None):
    carpeta = Path(carpeta) if carpeta else carpeta_salida()
    base = re.sub(r'[^\w.-]+', '_', Path(ruta_stl).stem) or 'modelo'
    ruta = carpeta / f"{base}_{time.strftime('%Y%m%d_%H%M%S')}_relieve.png"
    sr.guardar_png(resultado, ruta)
    meta = dict(stl=str(ruta_stl), opciones=opciones, ancho_mm=resultado['ancho_mm'], alto_mm=resultado['alto_mm'],
                relieve_mm=resultado['relieve_mm'], triangulos_antes=resultado['triangulos_antes'],
                triangulos_despues=resultado['triangulos_despues'])
    ruta.with_suffix('.json').write_text(json.dumps(meta, indent=1, ensure_ascii=False), encoding='utf-8')
    return ruta


def colocar_relieve(main, png, resultado, ruta_stl, opciones):
    """Coloca el PNG en una capa libre y abre Preparar tallado. Devuelve el item o None si se cancela."""
    from deep_engraving_dialog import ImageDepthDialog
    from g2_native_frame import load_calibration
    from laser_studio import GItem, RasterItem
    libre = next((i for i in range(len(main.cuts))
                  if not any(isinstance(it, (RasterItem, GItem)) and it.layer == i for it in main.scene.items())), None)
    if libre is None:
        QMessageBox.information(main, 'Capas', 'Libera una capa para importar el relieve del STL.')
        return None
    item = RasterItem(str(png))
    rect = item.boundingRect()
    campo = load_calibration().field_mm
    ancho, alto = resultado['ancho_mm'], resultado['alto_mm']
    reducido = max(ancho, alto) > campo
    if reducido:
        factor = campo / max(ancho, alto)
        ancho, alto = ancho * factor, alto * factor
    item.setScale(1)
    item.setTransform(QTransform.fromScale(ancho / rect.width(), alto / rect.height()))
    centro = item.mapToScene(rect.center())                      # boundingRect lleva medio pixel de margen: centrar con el real
    item.setPos(item.pos() + QPointF(campo / 2 - centro.x(), campo / 2 - centro.y()))
    item.layer = libre
    item.image_settings.update(mode='Grayscale', brightness=0, darkness=0, contrast=0, gamma=1., sharpen=0, invert=False,
                               depth_enabled=True, depth_pass_mode='assisted', depth_cleanup=False,
                               stl_source=str(ruta_stl), stl_options=dict(opciones))
    cut = copy.deepcopy(main.cuts[libre])
    dialogo = ImageDepthDialog(item, cut, main)
    if dialogo.exec() != QDialog.DialogCode.Accepted:
        return None
    dialogo.apply_to(item)
    destino = main.cuts[libre]
    for clave, valor in vars(cut).items():
        if clave not in ('i', 'name'):
            setattr(destino, clave, valor)
    main.scene.clearSelection()
    main.scene.addItem(item)
    item.setSelected(True)
    destino.mode = 'Image'
    destino.output = True
    main.set_layer(libre, assign_selection=False)
    main.update_cut_row(libre)
    if hasattr(main, '_sync_cut_controls'):
        main._sync_cut_controls(libre)
    main.changed = True
    main.schedule_preview()
    main.statusBar().showMessage(f'Relieve STL colocado en la capa C{libre:02d}: {ancho:.1f} × {alto:.1f} mm'
                                 + (' (reducido al campo del láser)' if reducido else '') + '.')
    return item


def importar_stl(main, ruta=None):
    if not ruta:
        ruta, _ = QFileDialog.getOpenFileName(main, 'Importar STL como relieve', '', 'Modelos STL (*.stl)')
        if not ruta:
            return None
    try:
        triangulos = sr.leer_stl(ruta)
    except (OSError, sr.ErrorSTL) as error:
        QMessageBox.warning(main, 'Importar STL', str(error))
        return None
    try:
        from g2_native_frame import load_calibration
        campo = load_calibration().field_mm
    except Exception:
        campo = None
    dialogo = StlReliefDialog(triangulos, Path(ruta).name, main, campo)
    if dialogo.exec() != QDialog.DialogCode.Accepted:
        return None
    opciones = dict(dialogo.parametros(), triangulos_max=dialogo.objetivo_malla())
    try:
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        resultado = dialogo.resultado_final()
        png = guardar_mapa(resultado, ruta, opciones)
    except (OSError, sr.ErrorSTL) as error:
        QMessageBox.warning(main, 'Importar STL', str(error))
        return None
    finally:
        QApplication.restoreOverrideCursor()
    return colocar_relieve(main, png, resultado, ruta, opciones)
