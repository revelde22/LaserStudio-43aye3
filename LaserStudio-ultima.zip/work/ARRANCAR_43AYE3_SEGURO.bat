@echo off
call "%~dp0ARRANCAR_43AYE3_COMPLETO.bat"
