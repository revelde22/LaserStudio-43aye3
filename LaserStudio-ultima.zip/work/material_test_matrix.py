"""Matriz de prueba: una capa Fill y una etiqueta vectorial por cuadrado."""
from PySide6.QtCore import QRectF,Qt
from PySide6.QtGui import QColor,QPainterPath,QPen,QBrush,QTransform
from text_tools import text_path


def label_for_cut(cut):
    return (f"V{cut.speed:g} P{cut.power:g}\n"
            f"F{cut.frequency:g} I{cut.interval:g}\n"
            f"X{cut.passes}")


def _label_path(label,width):
    path=text_path(label,"Arial",.72)
    rect=path.boundingRect()
    if rect.width()>width and rect.width()>0:
        path=QTransform.fromScale(width/rect.width(),1).map(path)
    return path


def refresh_labels(main,layer):
    cut=main.cuts[layer]
    for item in main.scene.items():
        if getattr(item,"kind",None)=="material_test" and getattr(item,"layer",None)==layer:
            item.test_settings.update({"speed":cut.speed,"power":cut.power,"frequency":cut.frequency,
                                       "interval":cut.interval,"passes":cut.passes})
        if getattr(item,"kind",None)=="material_label" and getattr(item,"layer",None)==layer:
            value=label_for_cut(cut)
            item.setPath(_label_path(value,getattr(item,"label_width",7.0)))
            item.text_meta={"text":value,"size_mm":.72,"font":"Arial"}
            item.update_handles()


def generate_matrix(main,rows,cols,speed_range,power_range,frequency_range,interval,passes,material="",liquid=""):
    from laser_studio import GItem,COLORS
    if not 2<=rows<=10 or not 2<=cols<=10:
        raise ValueError("La matriz admite entre 2 y 10 filas y columnas para caber en 110 × 110 mm")
    if interval<=0 or passes<1:raise ValueError("Intervalo y pasadas deben ser positivos")
    pitch=min(10.0,100.0/max(rows,cols))
    # Tres renglones de texto ocupan casi 4 mm; reservarlos evita solapes.
    side=pitch-4.7
    previous=[item for item in main.scene.items() if getattr(item,"kind",None) in ("material_test","material_label")]
    old_layers={item.layer for item in previous}
    occupied={item.layer for item in main.scene.items()
              if hasattr(item,'layer') and item not in previous}
    from laser_studio import Cut
    def available(layer):
        if layer in occupied:return False
        if layer in old_layers or layer>=len(main.cuts):return True
        cut=main.cuts[layer];default=Cut(layer)
        return cut.dict()==default.dict()
    count=rows*cols
    first=next((start for start in range(0,1025-count)
                if all(available(layer) for layer in range(start,start+count))),None)
    if first is None:raise ValueError('No hay un bloque libre de capas para la matriz.')
    main.ensure_cut_capacity(first+rows*cols)
    main._preview_geometry_cache.clear()
    for item in previous:main.scene.removeItem(item)
    from laser_studio import GroupItem
    for group in [item for item in main.scene.items() if isinstance(item,GroupItem) and not item.members()]:
        main.scene.removeItem(group)
    if old_layers:
        for layer in old_layers-set(range(first,first+rows*cols)):
            if layer in occupied:continue
            main.cuts[layer]=Cut(layer);main.update_cut_row(layer)
    main.scene.clearSelection()
    made=[]
    for row in range(rows):
        power=power_range[0]+(power_range[1]-power_range[0])*row/(rows-1)
        for col in range(cols):
            n=row*cols+col;layer=first+n
            speed=speed_range[0]+(speed_range[1]-speed_range[0])*col/(cols-1)
            freq=frequency_range[0]+(frequency_range[1]-frequency_range[0])*n/max(1,rows*cols-1)
            cut=main.cuts[layer]
            if layer in occupied:
                raise RuntimeError(f'La capa C{layer:02d} contiene otro diseño.')
            cut.name=f"T{row+1:02d}-{col+1:02d}"
            cut.mode="Fill";cut.speed=round(speed,2);cut.power=round(power,2)
            cut.frequency=round(freq,2);cut.interval=interval;cut.passes=passes
            cut.output=True;cut.show=True
            color=QColor(COLORS[layer%len(COLORS)])
            x=5+col*pitch;y=5+row*pitch
            path=QPainterPath();path.addRect(QRectF(x,y,side,side))
            square=GItem(path,"material_test");square.layer=layer
            square.test_settings={"speed":cut.speed,"power":cut.power,"frequency":cut.frequency,
                                  "interval":cut.interval,"passes":cut.passes,"material":material,"liquid":liquid}
            square.setPen(QPen(color,0));square.setBrush(QBrush(color));main.scene.addItem(square)
            label=label_for_cut(cut)
            lp=_label_path(label,side)
            label_item=GItem(lp,"material_label");label_item.layer=layer;label_item.label_width=side
            label_item.text_meta={"text":label,"size_mm":.72,"font":"Arial"}
            label_item.setPos(x,y+side+.3);label_item.setPen(QPen(color,0));label_item.setBrush(QBrush(color))
            main.scene.addItem(label_item)
            main.update_cut_row(layer)
            made.append(square)
    main.changed=True;main.schedule_preview()
    main.set_layer(first,assign_selection=False)
    main.view.fitInView(QRectF(3,3,cols*pitch+4,rows*pitch+4),Qt.AspectRatioMode.KeepAspectRatio)
    main.statusBar().showMessage(f"Matriz {rows} × {cols}: {len(made)} capas Fill con etiquetas V/P/F/I/X")
    return made


def group_matrix(main):
    from laser_studio import GItem,GroupItem
    items=[item for item in main.scene.items() if isinstance(item,GItem)
           and item.kind in ("material_test","material_label")]
    if not items:return None
    parents={item.parentItem() for item in items}
    if len(parents)==1 and isinstance(next(iter(parents)),GroupItem):
        group=next(iter(parents));main.scene.clearSelection();group.setSelected(True)
        main.view.fitInView(group.sceneBoundingRect().adjusted(-3,-3,3,3),Qt.AspectRatioMode.KeepAspectRatio)
        group.update_handles();return main.group()
    main.scene.clearSelection()
    for item in items:
        if item.parentItem() is None:item.setSelected(True)
    return main.group()
