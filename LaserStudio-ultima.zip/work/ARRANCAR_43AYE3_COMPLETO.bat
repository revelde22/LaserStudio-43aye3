@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title 43AYE3 Laser Studio G2 V1
set "LOG=%~dp0ARRANQUE_43AYE3.log"
>"%LOG%" echo ==== 43AYE3 ARRANQUE %DATE% %TIME% ====

echo ============================================================
echo   43AYE3 LASER STUDIO G2 V1
echo ============================================================
echo Carpeta: %CD%
echo.

if not exist "%~dp0AI_RUNTIME\tmp" mkdir "%~dp0AI_RUNTIME\tmp"
set "TEMP=%~dp0AI_RUNTIME\tmp"
set "TMP=%~dp0AI_RUNTIME\tmp"
echo Comprobando dependencias del editor (ComfyUI es opcional)...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PREPARAR_IA_COMFYUI.ps1" >"%~dp0COMPROBACION_EDITOR.log" 2>&1
if errorlevel 1 goto :SETUP_FAIL
type "%~dp0COMPROBACION_EDITOR.log"

set "G2PRO_VENDOR_DIR=%~dp0G2_RUNTIME"
set "PATH=%~dp0G2_RUNTIME;%PATH%"

"%~dp0AI_RUNTIME\python312\python.exe" "%~dp0remove_qa_fixture.py"
if errorlevel 1 goto :SETUP_FAIL
set "NEED_SDK_BUILD=0"
if not exist "BSL_SDK\43AYE3_G2_SDK\43AYE3_BSL_COMPAT.dll" set "NEED_SDK_BUILD=1"
if not exist "BSL_SDK\43AYE3_G2_SDK\43AYE3_SDK_SELFTEST.exe" set "NEED_SDK_BUILD=1"
if "!NEED_SDK_BUILD!"=="1" (
  echo [1/3] Compilando SDK 43AYE3 x86...
  call "%~dp0COMPILAR_SDK_43AYE3.bat"
  set "RC=!ERRORLEVEL!"
  if not "!RC!"=="0" goto :BUILD_FAIL
) else (
  echo [1/3] SDK ya compilado.
)

if exist "BSL_SDK\43AYE3_G2_SDK\43AYE3_BSL_COMPAT.dll" (
  copy /y "BSL_SDK\43AYE3_G2_SDK\43AYE3_BSL_COMPAT.dll" "BSL_SDK\43AYE3_BSL_COMPAT.dll" >nul 2>nul
  if errorlevel 1 goto :COPY_FAIL
  copy /y "BSL_SDK\43AYE3_G2_SDK\43AYE3_BSL_COMPAT.dll" "G2_RUNTIME\43AYE3_BSL_COMPAT.dll" >nul 2>nul
  if errorlevel 1 goto :COPY_FAIL
)

if not exist "native_bridge_x86\43aye3_g2_native_frame_x86.exe" (
  echo [2/3] Compilando backends G2...
  call "%~dp0COMPILAR_DIAGNOSTICO_G2.bat"
  set "RC=!ERRORLEVEL!"
  if not "!RC!"=="0" goto :BACKEND_FAIL
) else (
  echo [2/3] Backends G2 ya compilados.
)

echo [3/3] Iniciando 43AYE3 Laser Studio...
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" startup_safe.py
  set "RC=!ERRORLEVEL!"
) else (
  where py >nul 2>nul
  if errorlevel 1 goto :PYTHON_MISSING
  py -3 startup_safe.py
  set "RC=!ERRORLEVEL!"
)

if not "!RC!"=="0" goto :PYTHON_FAIL
if exist "%~dp0CIERRE_43AYE3.log" type "%~dp0CIERRE_43AYE3.log"
echo.
echo 43AYE3 Laser Studio se ha cerrado normalmente.
pause
exit /b 0

:BUILD_FAIL
echo.
echo ============================================================
echo [ERROR] EL SDK NO SE PUDO COMPILAR. CODIGO=!RC!
echo ============================================================
echo El BAT NO se cerrara. Revisa tambien:
echo   %~dp043AYE3_SDK_BUILD.log
echo.
if exist "%~dp043AYE3_SDK_BUILD.log" type "%~dp043AYE3_SDK_BUILD.log"
pause
exit /b !RC!

:COPY_FAIL
echo.
echo [ERROR] La DLL existe pero Windows no permite copiarla al runtime.
echo Cierra cualquier Laser Studio/Python de esta carpeta y vuelve a ejecutar.
pause
exit /b 31

:BACKEND_FAIL
echo.
echo [ERROR] Fallo compilando backends G2. CODIGO=!RC!
echo El BAT se queda abierto para que puedas copiar el error.
pause
exit /b !RC!

:PYTHON_MISSING
echo.
echo [ERROR] No encuentro Python ni .venv\Scripts\python.exe
pause
exit /b 90

:PYTHON_FAIL
if exist "%~dp0CIERRE_43AYE3.log" type "%~dp0CIERRE_43AYE3.log"
echo.
echo [ERROR] startup_safe.py termino con codigo !RC!.
echo El BAT se queda abierto para mostrar el error.
pause
exit /b !RC!

:SETUP_FAIL
if exist "%~dp0COMPROBACION_EDITOR.log" type "%~dp0COMPROBACION_EDITOR.log"
echo [ERROR] No se pudieron preparar las dependencias. Revisa COMFY_SETUP.log.
pause
exit /b 91
