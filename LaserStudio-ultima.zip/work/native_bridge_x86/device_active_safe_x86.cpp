#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdint>

static std::string joinp(const std::string&a,const std::string&b){return a.empty()?b:(a.back()=='\\'?a+b:a+"\\"+b);} 
static bool isdir(const std::string&p){DWORD a=GetFileAttributesA(p.c_str());return a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_DIRECTORY);} 
static std::string vendor(){char b[32768]={0};DWORD n=GetEnvironmentVariableA("G2PRO_VENDOR_DIR",b,sizeof(b));if(n&&n<sizeof(b)&&isdir(b))return b;n=GetEnvironmentVariableA("USERPROFILE",b,sizeof(b));if(n&&n<sizeof(b)){std::string p=joinp(joinp(b,"Documents"),"G2PRO");if(isdir(p))return p;}return ".";} 
static HMODULE load(const std::string&d,const char*n){return LoadLibraryExA(joinp(d,n).c_str(),nullptr,LOAD_WITH_ALTERED_SEARCH_PATH);} 
static void out(const std::string&s){std::cout<<s<<std::endl;}
static std::string hx32(DWORD v){char b[20];sprintf_s(b,sizeof(b),"0x%08lX",(unsigned long)v);return std::string(b);} 
static std::string hxp(const void* v){char b[24];sprintf_s(b,sizeof(b),"0x%08lX",(unsigned long)(uintptr_t)v);return std::string(b);} 

static bool pe_signature(const std::string& path, ULONGLONG& size, DWORD& timestamp){
    WIN32_FILE_ATTRIBUTE_DATA fad={};
    if(!GetFileAttributesExA(path.c_str(),GetFileExInfoStandard,&fad)) return false;
    size=((ULONGLONG)fad.nFileSizeHigh<<32)|fad.nFileSizeLow;
    HANDLE h=CreateFileA(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE) return false;
    IMAGE_DOS_HEADER dos={}; DWORD got=0; bool ok=false;
    if(ReadFile(h,&dos,sizeof(dos),&got,nullptr) && got==sizeof(dos) && dos.e_magic==IMAGE_DOS_SIGNATURE){
        if(SetFilePointer(h,dos.e_lfanew,nullptr,FILE_BEGIN)!=INVALID_SET_FILE_POINTER || GetLastError()==NO_ERROR){
            DWORD sig=0; IMAGE_FILE_HEADER fh={};
            if(ReadFile(h,&sig,sizeof(sig),&got,nullptr) && got==sizeof(sig) && sig==IMAGE_NT_SIGNATURE &&
               ReadFile(h,&fh,sizeof(fh),&got,nullptr) && got==sizeof(fh)){
                timestamp=fh.TimeDateStamp; ok=true;
            }
        }
    }
    CloseHandle(h); return ok;
}

typedef void (__thiscall *CtorFn)(void*);
typedef void (__thiscall *DtorFn)(void*);
typedef void (__thiscall *SetParamFn)(void*, void*);
typedef int  (__thiscall *InitFn)(void*, int&);
typedef int  (__thiscall *CloseFn)(void*);
typedef void (__thiscall *GetValidDevCountFn)(void*, int&);
typedef bool (__thiscall *IsValidFn)(void*, int);
typedef void (__thiscall *AdaptorStopFn)(void*, int);

static void* call_para_ctor(void* mem, void* fn){
    void* result=nullptr;
    __asm {
        mov eax, mem
        mov edx, fn
        call edx
        mov result, eax
    }
    return result;
}
static void call_para_dtor(void* mem, void* fn){
    __asm {
        push mem
        mov eax, fn
        call eax
    }
}

struct ProbeResult {
    int phase;
    int init_rc, init_ref, valid_count, isvalid;
    int close_rc;
    int stop_before, stop_after;
    int close_cleanup_attempted;
    DWORD seh_code; void* seh_addr;
    void* adaptor_ptr;
};

__declspec(noinline) static ProbeResult run_active_sequence(
    void* pm, void* mm, void* paraCtorRaw, void* paraDtorRaw,
    CtorFn ctor, DtorFn dtor, SetParamFn setParam, InitFn init,
    CloseFn closeAll, GetValidDevCountFn getValidCount, IsValidFn isValid,
    AdaptorStopFn adaptorStop){

    ProbeResult r={};
    r.valid_count=-777; r.isvalid=-1; r.close_rc=-777;
    bool paramCtorDone=false, markCtorDone=false, initialized=false, closed=false;

    __try {
        r.phase=1; call_para_ctor(pm,paraCtorRaw); paramCtorDone=true;
        r.phase=2; ctor(mm); markCtorDone=true;
        r.phase=3; setParam(mm,pm);
        r.phase=4; { int ref=0; r.init_rc=init(mm,ref); r.init_ref=ref; initialized=(r.init_rc==1 || ref>0); }
        r.phase=5; {
            int c=0; getValidCount(mm,c); r.valid_count=c;
            r.adaptor_ptr=*(void**)((BYTE*)mm+0x28);
            if(r.adaptor_ptr) r.isvalid=isValid(r.adaptor_ptr,1)?1:0;
        }

        if(r.init_rc==1 && r.init_ref>0 && r.valid_count==1 && r.adaptor_ptr && r.isvalid==1){
            r.phase=6; adaptorStop(r.adaptor_ptr,1); r.stop_before=1;
            r.phase=7; Sleep(100);
            r.phase=8; adaptorStop(r.adaptor_ptr,1); r.stop_after=1;
        }

        r.phase=9; r.close_rc=closeAll(mm); closed=true;
        r.phase=10; dtor(mm); markCtorDone=false;
        r.phase=11; call_para_dtor(pm,paraDtorRaw); paramCtorDone=false;
        r.phase=12;
    }
    __except((r.seh_code=GetExceptionCode(), r.seh_addr=GetExceptionInformation()->ExceptionRecord->ExceptionAddress), EXCEPTION_EXECUTE_HANDLER) {}

    if(initialized && !closed && closeAll && mm){
        r.close_cleanup_attempted=1;
        __try { r.close_rc=closeAll(mm); closed=true; } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    if(markCtorDone && dtor && mm){ __try { dtor(mm); } __except(EXCEPTION_EXECUTE_HANDLER) {} }
    if(paramCtorDone && paraDtorRaw && pm){ __try { call_para_dtor(pm,paraDtorRaw); } __except(EXCEPTION_EXECUTE_HANDLER) {} }
    return r;
}

int main(){
    SetConsoleOutputCP(CP_UTF8);
    std::string d=vendor(); SetDllDirectoryA(d.c_str()); SetCurrentDirectoryA(d.c_str());
    out("ACTIVE_SAFE_PHASE=START");
    out("ACTIVE_SAFE_TEST=STOP_ONLY_PLUS_RED_API_STATIC");
    out("ACTIVE_SAFE_VENDOR_DIR="+d);
    out("LASER_MARK_EMISSION_ALLOWED=NO");
    out("MARK_CALL_EXECUTED=NO");
    out("SETLASERON_CALL_EXECUTED=NO");
    out("GALVO_PATH_CALL_EXECUTED=NO");
    out("RED_PILOT_BASELINE=ALWAYS_ON_USER_CONFIRMED");
    out("RED_VISUAL_ON_OFF_IS_VALID_TEST=NO");
    out("REDLIGHT_COMMAND_EXECUTED=NO");

    ULONGLONG sbSize=0, smSize=0; DWORD sbTs=0, smTs=0;
    bool sbSig=pe_signature(joinp(d,"SeaBase.dll"),sbSize,sbTs), smSig=pe_signature(joinp(d,"SeaMark.dll"),smSize,smTs);
    const bool exact = sbSig && smSig && sbSize==1271808ULL && sbTs==0x6655B3C3UL && smSize==744448ULL && smTs==0x6655B439UL;
    out(std::string("PRIVATE_RVA_VERSION_GATE=")+(exact?"PASS":"FAIL"));
    if(!exact){out("ACTIVE_SAFE_RESULT=REFUSED_VENDOR_VERSION_MISMATCH");return 45;}

    const char* deps[]={"libcodebar.dll","LPCodeAddin.dll","crypto3.dll","crypto5.0.dll","crypto6.0.dll"};
    std::vector<HMODULE> hs;
    for(auto n:deps){HMODULE h=load(d,n);if(!h){out(std::string("ACTIVE_SAFE_FAIL=LOAD_")+n+" ERROR="+std::to_string(GetLastError()));return 40;}hs.push_back(h);}
    HMODULE sb=load(d,"SeaBase.dll"); if(!sb){out("ACTIVE_SAFE_FAIL=LOAD_SeaBase.dll");return 41;} hs.push_back(sb);
    HMODULE sd=load(d,"SeaDraw.dll"); if(!sd){out("ACTIVE_SAFE_FAIL=LOAD_SeaDraw.dll");return 41;} hs.push_back(sd);
    HMODULE sm=load(d,"SeaMark.dll"); if(!sm){out("ACTIVE_SAFE_FAIL=LOAD_SeaMark.dll");return 41;} hs.push_back(sm);
    out("ACTIVE_SAFE_PHASE=DLLS_LOADED");

    auto ctor=(CtorFn)GetProcAddress(sm,"??0CMarkMgr@@QAE@XZ");
    auto dtor=(DtorFn)GetProcAddress(sm,"??1CMarkMgr@@UAE@XZ");
    auto init=(InitFn)GetProcAddress(sm,"?InitDevices@CMarkMgr@@UAEHAAH@Z");
    auto closeAll=(CloseFn)GetProcAddress(sm,"?CloseAllDevice@CMarkMgr@@UAEHXZ");
    auto setParam=(SetParamFn)GetProcAddress(sb,"?SetParam@CBaseMarkMgr@@UAEXPAVCParaMgr@@@Z");
    auto getValidCount=(GetValidDevCountFn)GetProcAddress(sm,"?GetValidDevCount@CMarkMgr@@QAEXAAH@Z");
    auto isValid=(IsValidFn)GetProcAddress(sm,"?IsValid@CMarkAdaptor@@UAE_NH@Z");
    auto adaptorStop=(AdaptorStopFn)GetProcAddress(sm,"?StopMark@CMarkAdaptor@@UAEXH@Z");

    // Solo resolución estática: NO se llama a ninguna API de luz roja o encuadre en esta fase.
    void* redMgr=(void*)GetProcAddress(sm,"?EnableInfiniteRedlightOut@CMarkMgr@@UAEH_N@Z");
    void* redData=(void*)GetProcAddress(sm,"?EnableRedlightInfiniteOut@CDataMarker@@UAEX_N@Z");
    void* markPaths=(void*)GetProcAddress(sm,"?MarkPathsSDK@CMarkMgr@@UAE_NPA_WABV?$vector@UtagPathData@@V?$allocator@UtagPathData@@@std@@@std@@QAUtagMarkCtlData@@AAUtagPenPar@@AAUtagLmcPar@@@Z");
    void* doMark=(void*)GetProcAddress(sm,"?DoMark@CMarkMgr@@UAE_NABV?$vector@UtagDevDocs@@V?$allocator@UtagDevDocs@@@std@@@std@@QAUtagMarkCtlData@@PAX_N@Z");
    out(std::string("ACTIVE_SAFE_SYMBOLS=CTOR:")+(ctor?"YES":"NO")+" SETPARAM:"+(setParam?"YES":"NO")+" INIT:"+(init?"YES":"NO")+" VALIDCOUNT:"+(getValidCount?"YES":"NO")+" ISVALID:"+(isValid?"YES":"NO")+" ADAPTOR_STOP:"+(adaptorStop?"YES":"NO")+" CLOSE:"+(closeAll?"YES":"NO")+" DTOR:"+(dtor?"YES":"NO"));
    out(std::string("RED_FRAME_STATIC_SYMBOLS=RED_MGR:")+(redMgr?"YES":"NO")+" RED_DATAMARKER:"+(redData?"YES":"NO")+" MARK_PATHS_SDK:"+(markPaths?"YES":"NO")+" DOMARK:"+(doMark?"YES":"NO"));
    if(!(ctor&&dtor&&setParam&&init&&getValidCount&&isValid&&adaptorStop&&closeAll)){out("ACTIVE_SAFE_RESULT=FAIL_SYMBOLS");return 42;}

    const SIZE_T markSize=0x320, paramSize=0x380;
    void* paraCtorRaw=(void*)((uintptr_t)sb+0xFC80);
    void* paraDtorRaw=(void*)((uintptr_t)sb+0x10370);
    void* pm=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,paramSize);
    void* mm=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,markSize);
    if(!(pm&&mm)){out("ACTIVE_SAFE_RESULT=FAIL_ALLOC");return 43;}

    out("ACTIVE_SAFE_PHASE=CALL_SEQUENCE");
    ProbeResult r=run_active_sequence(pm,mm,paraCtorRaw,paraDtorRaw,ctor,dtor,setParam,init,closeAll,getValidCount,isValid,adaptorStop);
    out("ACTIVE_SAFE_LAST_PHASE="+std::to_string(r.phase));
    out("PHASE_MAP=1:PARAM_CTOR 2:MARK_CTOR 3:SETPARAM 4:INIT 5:VALIDATE_ONE_DEVICE 6:STOP_IDLE_BEFORE 7:WAIT_100MS 8:STOP_IDLE_AFTER 9:CLOSE 10:MARK_DTOR 11:PARAM_DTOR 12:DONE");
    out("INITDEVICES_RETURN="+std::to_string(r.init_rc));
    out("INITDEVICES_REF_VALUE="+std::to_string(r.init_ref));
    out("VALID_DEVICE_COUNT="+std::to_string(r.valid_count));
    out("ADAPTOR_PTR="+hxp(r.adaptor_ptr));
    out("ADAPTOR_ISVALID_1="+std::to_string(r.isvalid));
    out("STOP_IDLE_BEFORE_EXECUTED="+std::to_string(r.stop_before));
    out("STOP_IDLE_AFTER_EXECUTED="+std::to_string(r.stop_after));
    out("CLOSEALLDEVICE_RETURN="+std::to_string(r.close_rc));
    out("CLOSE_CLEANUP_ATTEMPTED="+std::to_string(r.close_cleanup_attempted));

    if(r.seh_code){
        out("ACTIVE_SAFE_SEH="+hx32(r.seh_code));
        out("ACTIVE_SAFE_SEH_ADDRESS="+hxp(r.seh_addr));
        out("ACTIVE_SAFE_RESULT=SEH_EXCEPTION");
    } else if(r.init_rc!=1 || r.init_ref<=0 || r.valid_count!=1 || !r.adaptor_ptr || r.isvalid!=1){
        out("ACTIVE_SAFE_RESULT=REFUSED_DEVICE_GUARD");
    } else if(r.phase==12 && r.stop_before==1 && r.stop_after==1){
        out("ACTIVE_SAFE_RESULT=PASS");
    } else {
        out("ACTIVE_SAFE_RESULT=INCOMPLETE");
    }
    out("MARK_CALL_EXECUTED=NO");
    out("LASER_MARK_EMISSION_EXECUTED=NO");
    out("REDLIGHT_COMMAND_EXECUTED=NO");

    HeapFree(GetProcessHeap(),0,mm); HeapFree(GetProcessHeap(),0,pm);
    std::cout.flush();
    return (r.seh_code?44:0);
}
