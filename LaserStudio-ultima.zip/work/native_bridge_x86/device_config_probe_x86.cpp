#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>

// Read-only configuration probe. Does not connect a device, create a marker,
// move galvos, use the red-light output, or enable laser emission.
typedef void (__thiscall *CtorFn)(void*);
typedef void (__thiscall *DtorFn)(void*);
typedef bool (__thiscall *LoadFn)(void*, HINSTANCE);
typedef bool (__thiscall *UnloadFn)(void*);
struct Probe { int phase; int loaded; DWORD seh; void* address; void* param; void* first; void* last; int unloaded; };
static int filter(EXCEPTION_POINTERS* e, Probe* p) {
    p->seh=e && e->ExceptionRecord ? e->ExceptionRecord->ExceptionCode : 0;
    p->address=e && e->ExceptionRecord ? e->ExceptionRecord->ExceptionAddress : 0;
    return EXCEPTION_EXECUTE_HANDLER;
}
static void call_vendor(void* mm, HINSTANCE module, CtorFn ctor, LoadFn load,
                        UnloadFn unload, DtorFn dtor, Probe* p) {
    __try {
        p->phase=1; ctor(mm);
        p->phase=2; p->loaded=load(mm,module)?1:0;
        p->phase=3; p->param=*(void**)((BYTE*)mm+0x08);
        if(p->param) {
            p->first=*(void**)((BYTE*)p->param+0x36C);
            p->last=*(void**)((BYTE*)p->param+0x370);
        }
        p->phase=4; p->unloaded=unload(mm)?1:0;
        p->phase=5; dtor(mm);
        p->phase=6;
    } __except(filter(GetExceptionInformation(),p)) {}
}
static bool pecheck(const wchar_t* path, ULONGLONG bytes, DWORD timestamp) {
    WIN32_FILE_ATTRIBUTE_DATA a={};
    if(!GetFileAttributesExW(path,GetFileExInfoStandard,&a))return false;
    ULONGLONG size=((ULONGLONG)a.nFileSizeHigh<<32)|a.nFileSizeLow;
    HANDLE h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
                         NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE)return false;
    IMAGE_DOS_HEADER dos={}; IMAGE_FILE_HEADER fh={}; DWORD n=0,sig=0;
    bool ok=ReadFile(h,&dos,sizeof(dos),&n,NULL)&&n==sizeof(dos)&&dos.e_magic==IMAGE_DOS_SIGNATURE;
    if(ok){SetFilePointer(h,dos.e_lfanew,NULL,FILE_BEGIN);
        ok=ReadFile(h,&sig,4,&n,NULL)&&sig==IMAGE_NT_SIGNATURE&&
           ReadFile(h,&fh,sizeof(fh),&n,NULL)&&n==sizeof(fh);}
    CloseHandle(h); return ok&&size==bytes&&fh.TimeDateStamp==timestamp;
}
int wmain(int argc,wchar_t**argv) {
    SetConsoleOutputCP(CP_UTF8);
    puts("CONFIG_PROBE=READ_ONLY_NO_DEVICE_CONNECT_NO_FRAME_NO_MARK");
    if(argc!=2){puts("RESULT=FAIL_VENDOR_PATH");return 2;}
    wchar_t base[MAX_PATH]={},mark[MAX_PATH]={};
    if(wcslen(argv[1])+14>=MAX_PATH){puts("RESULT=FAIL_PATH_LENGTH");return 3;}
    wcscpy_s(base,argv[1]); wcscat_s(base,L"\\SeaBase.dll");
    wcscpy_s(mark,argv[1]); wcscat_s(mark,L"\\SeaMark.dll");
    if(!pecheck(base,1271808ULL,0x6655B3C3UL)||
       !pecheck(mark,744448ULL,0x6655B439UL)){
        puts("RESULT=REFUSED_VENDOR_VERSION_MISMATCH");return 4;}
    SetDllDirectoryW(argv[1]); SetCurrentDirectoryW(argv[1]);
    HMODULE sb=LoadLibraryExW(base,NULL,LOAD_WITH_ALTERED_SEARCH_PATH);
    HMODULE sm=LoadLibraryExW(mark,NULL,LOAD_WITH_ALTERED_SEARCH_PATH);
    if(!sb||!sm){printf("RESULT=FAIL_LOAD_DLL ERROR=%lu\n",GetLastError());return 5;}
    CtorFn ctor=(CtorFn)GetProcAddress(sm,"??0CMarkMgr@@QAE@XZ");
    DtorFn dtor=(DtorFn)GetProcAddress(sm,"??1CMarkMgr@@UAE@XZ");
    LoadFn load=(LoadFn)GetProcAddress(sm,"?loadSeaPar@CMarkMgr@@QAE_NPAUHINSTANCE__@@@Z");
    UnloadFn unload=(UnloadFn)GetProcAddress(sm,"?unloadSeaPar@CMarkMgr@@QAE_NXZ");
    if(!ctor||!dtor||!load||!unload){puts("RESULT=FAIL_EXPORTS");return 6;}
    void* mm=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,0x320);
    if(!mm){puts("RESULT=FAIL_ALLOC");return 7;}
    Probe p={}; call_vendor(mm,(HINSTANCE)sm,ctor,load,unload,dtor,&p);
    printf("PHASE=%d LOAD=%d PARAM=%p VECTOR_FIRST=%p VECTOR_LAST=%p UNLOAD=%d SEH=0x%08lX ADDRESS=%p\n",
           p.phase,p.loaded,p.param,p.first,p.last,p.unloaded,p.seh,p.address);
    // On an exception do not guess which objects were constructed; the process
    // exits without calling additional vendor functions. Heap memory is reclaimed.
    if(p.phase==6)HeapFree(GetProcessHeap(),0,mm);
    if(p.seh){puts("RESULT=FAIL_VENDOR_EXCEPTION");return 8;}
    if(p.loaded&&p.param&&p.first&&p.last&&
       (uintptr_t)p.last>(uintptr_t)p.first&&
       ((uintptr_t)p.last-(uintptr_t)p.first)%0x22A0==0){
        puts("RESULT=CONFIG_VECTOR_PRESENT");return 0;}
    puts("RESULT=CONFIG_VECTOR_EMPTY_OR_LOAD_FAILED");return 9;
}
