#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>

#pragma pack(push,1)
struct FileHeader { char magic[8]; uint32_t penCount, groupCount, imageCount; };
#pragma pack(pop)
struct PenRec { uint32_t pen, passes; double speed, power, freqKHz; };
struct PointD { double x,y; };
struct LineGroup { uint32_t pen; std::vector<std::vector<PointD>> lines; };
struct ImageRec { uint32_t pen; double w,h,cx,cy,rot; std::wstring path; };
struct PointF2 { float x,y; };

typedef int (__cdecl *PFN_NewFile)(wchar_t*);
typedef int (__cdecl *PFN_SaveEntLibToFile)(wchar_t*);
typedef int (__cdecl *PFN_UnLoadDataFile)(wchar_t*);
typedef int (__cdecl *PFN_AddLinesToFile2)(wchar_t*,PointF2*,int,int*,wchar_t*,int);
typedef int (__cdecl *PFN_AddBmpToFile)(wchar_t*,wchar_t*,wchar_t*,double,double,double,double,double,int);
typedef int (__cdecl *PFN_GetPenParam)(wchar_t*,unsigned int,int*,double*,double*,double*,int*,int*,int*,int*,int*,int*,double*,int*,int*,double*,bool*,int*,float*);
typedef int (__cdecl *PFN_SetPenParam)(wchar_t*,unsigned int,int,double,double,double,int,int,int,int,int,int,double,int,int,double,bool,int,float);
typedef int (__cdecl *PFN_AyeGetLastError)(wchar_t*,int);

static bool read_u32(std::ifstream& f,uint32_t& v){ return !!f.read((char*)&v,4); }
static bool read_wstr(std::ifstream& f,std::wstring& s){
    uint32_t n=0; if(!read_u32(f,n) || n>32768) return false;
    s.resize(n); return n==0 || !!f.read((char*)s.data(),n*2);
}
static std::wstring joinp(const std::wstring&a,const std::wstring&b){ if(a.empty())return b; wchar_t c=a.back(); return a+((c==L'\\'||c==L'/')?L"":L"\\")+b; }
static FARPROC gp_compat(HMODULE h,const char* n){
    FARPROC p=GetProcAddress(h,n);
    if(p) return p;
    std::string d="_"; d+=n;
    return GetProcAddress(h,d.c_str());
}
static bool has_required(HMODULE h){ return gp_compat(h,"BSL_NewFile") && gp_compat(h,"BSL_SaveEntLibToFile") && gp_compat(h,"BSL_AddLinesToFile2"); }
static std::wstring find_sdk_dll(const std::wstring&dir){
    WIN32_FIND_DATAW fd{}; HANDLE fh=FindFirstFileW(joinp(dir,L"*.dll").c_str(),&fd); if(fh==INVALID_HANDLE_VALUE)return L"";
    std::wstring found;
    do{
        if(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)continue;
        if(_wcsicmp(fd.cFileName,L"43AYE3_BSL_COMPAT.dll")==0)continue;
        std::wstring p=joinp(dir,fd.cFileName);
        HMODULE h=LoadLibraryExW(p.c_str(),NULL,DONT_RESOLVE_DLL_REFERENCES);
        if(h){ if(has_required(h)){found=p;FreeLibrary(h);break;} FreeLibrary(h); }
    }while(FindNextFileW(fh,&fd));
    FindClose(fh); return found;
}
static FARPROC req(HMODULE h,const char*n){ FARPROC p=gp_compat(h,n); if(!p) std::cout<<"MISSING_SYMBOL="<<n<<"\n"; return p; }
static int probe(const std::wstring&sdk,const std::wstring&runtime){
    std::wcout<<L"SDK_DIR="<<sdk<<L"\nRUNTIME_DIR="<<runtime<<L"\n";
    std::wstring dll=find_sdk_dll(sdk); if(dll.empty()){std::cout<<"SDK_PROBE_RESULT=NO_PUBLIC_API_DLL\n";return 2;}
    std::wcout<<L"SDK_DLL="<<dll<<L"\n";
    HMODULE h=LoadLibraryExW(dll.c_str(),NULL,DONT_RESOLVE_DLL_REFERENCES); if(!h){std::cout<<"SDK_PROBE_RESULT=MAP_FAILED\n";return 3;}
    const char* names[]={"BSL_NewFile","BSL_SaveEntLibToFile","BSL_AddLinesToFile2","BSL_AddBmpToFile","BSL_SetPenParam","BSL_UnLoadDataFile"};
    bool ok=true; for(auto n:names){bool y=gp_compat(h,n)!=NULL;std::cout<<n<<"="<<(y?"YES":"NO")<<"\n"; if(!y && strcmp(n,"BSL_AddBmpToFile")!=0)ok=false;}
    FreeLibrary(h); std::cout<<"SDK_PROBE_RESULT="<<(ok?"PASS":"MISSING_EXPORTS")<<"\n"; return ok?0:4;
}
static bool load_input(const wchar_t*fn,std::vector<PenRec>&pens,std::vector<LineGroup>&groups,std::vector<ImageRec>&images){
    std::ifstream f(fn,std::ios::binary); if(!f)return false; FileHeader h{}; if(!f.read((char*)&h,sizeof(h)))return false;
    if(memcmp(h.magic,"43BSL501",8)!=0 || h.penCount>256 || h.groupCount>256 || h.imageCount>4096)return false;
    for(uint32_t i=0;i<h.penCount;i++){PenRec p{}; if(!f.read((char*)&p,sizeof(p)))return false;pens.push_back(p);}
    for(uint32_t i=0;i<h.groupCount;i++){
        LineGroup g{};uint32_t lc=0;if(!read_u32(f,g.pen)||!read_u32(f,lc)||lc>1000000)return false;
        g.lines.resize(lc);
        for(uint32_t j=0;j<lc;j++){uint32_t pc=0;if(!read_u32(f,pc)||pc>10000000)return false;g.lines[j].resize(pc);if(pc&&!f.read((char*)g.lines[j].data(),sizeof(PointD)*pc))return false;}
        groups.push_back(std::move(g));
    }
    for(uint32_t i=0;i<h.imageCount;i++){ImageRec im{};if(!f.read((char*)&im.pen,4))return false;if(!f.read((char*)&im.w,sizeof(double)*5))return false;if(!read_wstr(f,im.path))return false;images.push_back(std::move(im));}
    return true;
}
static int do_export(const std::wstring&input,const std::wstring&output,const std::wstring&sdk,const std::wstring&runtime){
    std::vector<PenRec> pens;std::vector<LineGroup>groups;std::vector<ImageRec>images;
    if(!load_input(input.c_str(),pens,groups,images)){std::cout<<"BSL_SDK_EXPORT_RESULT=BAD_INPUT\n";return 10;}
    std::wstring dll=find_sdk_dll(sdk); if(dll.empty()){std::cout<<"BSL_SDK_EXPORT_RESULT=SDK_DLL_NOT_FOUND\n";return 11;}
    std::wcout<<L"SDK_DLL="<<dll<<L"\n";
    SetCurrentDirectoryW(runtime.c_str()); SetDllDirectoryW(runtime.c_str());
    HMODULE h=LoadLibraryW(dll.c_str()); if(!h){std::cout<<"LOAD_LIBRARY_ERROR="<<GetLastError()<<"\nBSL_SDK_EXPORT_RESULT=SDK_LOAD_FAILED\n";return 12;}
    auto NewFile=(PFN_NewFile)req(h,"BSL_NewFile"); auto Save=(PFN_SaveEntLibToFile)req(h,"BSL_SaveEntLibToFile"); auto Unload=(PFN_UnLoadDataFile)gp_compat(h,"BSL_UnLoadDataFile");
    auto AddLines=(PFN_AddLinesToFile2)req(h,"BSL_AddLinesToFile2"); auto AddBmp=(PFN_AddBmpToFile)gp_compat(h,"BSL_AddBmpToFile");
    auto GetPen=(PFN_GetPenParam)gp_compat(h,"BSL_GetPenParam"); auto SetPen=(PFN_SetPenParam)req(h,"BSL_SetPenParam");
    auto AyeError=(PFN_AyeGetLastError)gp_compat(h,"AYE_GetLastError");
    auto printAyeError=[&](){ if(AyeError){wchar_t eb[2048]={0};AyeError(eb,2048);if(eb[0])std::wcout<<L"AYE_ERROR="<<eb<<L"\n";} };
    if(!NewFile||!Save||!AddLines||!SetPen){FreeLibrary(h);std::cout<<"BSL_SDK_EXPORT_RESULT=MISSING_EXPORTS\n";return 13;}
    std::vector<wchar_t> outbuf(output.begin(),output.end());outbuf.push_back(0);
    int rc=NewFile(outbuf.data());std::cout<<"BSL_NewFile="<<rc<<"\n";if(rc!=0){printAyeError();FreeLibrary(h);std::cout<<"BSL_SDK_EXPORT_RESULT=NEWFILE_FAILED\n";return 14;}
    bool failed=false;
    for(const auto&p:pens){
        int loops=(int)p.passes,freq=(int)(p.freqKHz*1000.0+0.5),q=0,start=0,off=0,end=0,poly=0,jp=0,jd=0,pn=0;double current=0,jump=4000,endcomp=0;bool pulse=false;float pt=0;
        if(GetPen){double oldSpeed=0,oldPower=0,oldCurrent=0;int tr=GetPen(outbuf.data(),p.pen,&loops,&oldSpeed,&oldPower,&oldCurrent,&freq,&q,&start,&off,&end,&poly,&jump,&jp,&jd,&endcomp,&pulse,&pn,&pt);if(tr==0)current=oldCurrent;loops=(int)p.passes;}
        rc=SetPen(outbuf.data(),p.pen,loops,p.speed,p.power,current,freq,q,start,off,end,poly,jump,jp,jd,endcomp,pulse,pn,pt);
        std::cout<<"BSL_SetPenParam[C"<<p.pen<<"]="<<rc<<"\n"; if(rc!=0){printAyeError();failed=true;break;}
    }
    if(!failed){
        int ent=0;
        for(const auto&g:groups){
            size_t total=0;for(auto&ln:g.lines)total+=ln.size();std::vector<PointF2> pts;pts.reserve(total);std::vector<int> counts;counts.reserve(g.lines.size());
            for(auto&ln:g.lines){counts.push_back((int)ln.size());for(auto&p:ln)pts.push_back({(float)p.x,(float)p.y});}
            std::wstring name=L"C"+(g.pen<10?L"0":L"")+std::to_wstring(g.pen)+L"_LINES";std::vector<wchar_t> nb(name.begin(),name.end());nb.push_back(0);
            rc=AddLines(outbuf.data(),pts.data(),(int)g.lines.size(),counts.data(),nb.data(),(int)g.pen);
            std::cout<<"BSL_AddLinesToFile2[C"<<g.pen<<"]="<<rc<<" LINES="<<g.lines.size()<<" POINTS="<<pts.size()<<"\n"; if(rc!=0){printAyeError();failed=true;break;} ent++;
        }
        if(!failed && !images.empty() && !AddBmp){std::cout<<"BSL_AddBmpToFile=MISSING\n";failed=true;}
        int ix=0;
        for(const auto&im:images){if(failed)break;std::wstring name=L"IMG_"+std::to_wstring(ix++);std::vector<wchar_t> nb(name.begin(),name.end());nb.push_back(0);std::vector<wchar_t> pb(im.path.begin(),im.path.end());pb.push_back(0);
            rc=AddBmp(outbuf.data(),pb.data(),nb.data(),im.w,im.h,im.cx,im.cy,im.rot,(int)im.pen);std::cout<<"BSL_AddBmpToFile="<<rc<<"\n";if(rc!=0){printAyeError();failed=true;break;}}
    }
    if(!failed){rc=Save(outbuf.data());std::cout<<"BSL_SaveEntLibToFile="<<rc<<"\n";if(rc!=0){printAyeError();failed=true;}}
    if(Unload){int ur=Unload(outbuf.data());std::cout<<"BSL_UnLoadDataFile="<<ur<<"\n";}
    FreeLibrary(h);
    if(failed){std::cout<<"BSL_SDK_EXPORT_RESULT=API_ERROR\n";return 15;}
    WIN32_FILE_ATTRIBUTE_DATA fad{}; if(!GetFileAttributesExW(output.c_str(),GetFileExInfoStandard,&fad)){std::cout<<"BSL_SDK_EXPORT_RESULT=FILE_MISSING\n";return 16;}
    ULARGE_INTEGER sz{};sz.HighPart=fad.nFileSizeHigh;sz.LowPart=fad.nFileSizeLow;std::cout<<"ORZX_OUTPUT_SIZE="<<sz.QuadPart<<"\nBSL_SDK_EXPORT_RESULT=PASS\n";return 0;
}
int wmain(int argc,wchar_t**argv){
    if(argc>=4 && wcscmp(argv[1],L"--probe")==0)return probe(argv[2],argv[3]);
    if(argc>=6 && wcscmp(argv[1],L"--export")==0)return do_export(argv[2],argv[3],argv[4],argv[5]);
    std::cout<<"USAGE: --probe SDKDIR RUNTIME | --export INPUT OUTPUT SDKDIR RUNTIME\n";return 1;
}
