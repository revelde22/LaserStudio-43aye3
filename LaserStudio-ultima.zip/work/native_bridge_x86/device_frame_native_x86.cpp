#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>

struct Pt { double x,y; };
struct AYE_PointD { double x,y; };
typedef int (__cdecl *ConnectFn)();
typedef int (__cdecl *FrameFn)(const AYE_PointD*,int,int,int);
typedef int (__cdecl *ProbeFn)();
typedef int (__cdecl *StopFn)();
typedef int (__cdecl *CloseFn)();
typedef int (__cdecl *ErrFn)(wchar_t*,int);

static void out(const std::string&s){std::cout<<s<<std::endl;}
static bool readpts(const char*path,std::vector<Pt>&pts){std::ifstream f(path);if(!f)return false;std::string s;while(std::getline(f,s)){if(s.empty()||s[0]=='#')continue;std::istringstream q(s);Pt p;if(q>>p.x>>p.y)pts.push_back(p);}return pts.size()>=2;}
static int envi(const char*n,int d){char b[64]={0};DWORD k=GetEnvironmentVariableA(n,b,sizeof(b));if(!k||k>=sizeof(b))return d;int v=atoi(b);return v>0?v:d;}
static std::wstring sdkpath(){wchar_t b[32768]={0};DWORD n=GetEnvironmentVariableW(L"AYE_SDK_DLL",b,_countof(b));if(n&&n<_countof(b))return b;return L"BSL_SDK\\43AYE3_G2_SDK\\43AYE3_BSL_COMPAT.dll";}
static std::string narrow(const std::wstring&s){if(s.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,s.c_str(),(int)s.size(),nullptr,0,nullptr,nullptr);if(n<=0)return {};std::string r((size_t)n,'\0');if(WideCharToMultiByte(CP_UTF8,0,s.c_str(),(int)s.size(),&r[0],n,nullptr,nullptr)<=0)return {};return r;}
int main(int argc,char**argv){
    SetConsoleOutputCP(CP_UTF8);if(argc<2){out("NATIVE_FRAME_RESULT=FAIL_NO_PATH");return 2;}
    std::vector<Pt>p;if(!readpts(argv[1],p)){out("NATIVE_FRAME_RESULT=FAIL_BAD_PATH");return 3;}
    int rep=envi("G2_FRAME_REPEATS",2),delay=envi("G2_FRAME_DELAY_MS",80);rep=std::min(50,std::max(1,rep));delay=std::min(1000,std::max(1,delay));
    if(p.size()>513){out("NATIVE_FRAME_RESULT=FAIL_TOO_MANY_POINTS");return 3;}
    for(const auto&v:p)if(!std::isfinite(v.x)||!std::isfinite(v.y)||std::abs(v.x)>75.0||std::abs(v.y)>75.0){out("NATIVE_FRAME_RESULT=FAIL_OUT_OF_BOUNDS");return 3;}
    std::wstring dll=sdkpath();HMODULE h=LoadLibraryW(dll.c_str());if(!h){std::cout<<"SDK_LOAD_ERROR="<<GetLastError()<<"\nNATIVE_FRAME_RESULT=FAIL_SDK_LOAD\n";return 4;}
    auto connect=(ConnectFn)GetProcAddress(h,"AYE_DeviceConnect");auto probe=(ProbeFn)GetProcAddress(h,"AYE_ProbeMarker");auto frame=(FrameFn)GetProcAddress(h,"AYE_FramePolyline");auto stop=(StopFn)GetProcAddress(h,"AYE_Stop");auto close=(CloseFn)GetProcAddress(h,"AYE_DeviceClose");auto err=(ErrFn)GetProcAddress(h,"AYE_GetLastError");
    if(!connect||!probe||!frame||!stop||!close||!err){out("NATIVE_FRAME_RESULT=FAIL_SDK_EXPORTS");FreeLibrary(h);return 5;}
    out("NATIVE_FRAME_BACKEND=43AYE3_G2_SDK");out("GLASER_EXE_USED=NO");out("LASER_MARK_EMISSION_ALLOWED=NO");
    int rc=connect();std::cout<<"AYE_DeviceConnect="<<rc<<"\n";if(rc!=0){wchar_t e[2048]={0};err(e,_countof(e));std::cout<<"SDK_ERROR="<<narrow(e)<<"\nNATIVE_FRAME_RESULT=FAIL_CONNECT\n";close();FreeLibrary(h);return 6;}
    int pr=probe();std::cout<<"AYE_ProbeMarker="<<pr<<"\n";
    if(pr!=0){wchar_t e[2048]={0};err(e,_countof(e));std::cout<<"SDK_ERROR="<<narrow(e)<<"\nNATIVE_FRAME_RESULT=FAIL_MARKER_ASSOCIATION\n";stop();close();FreeLibrary(h);return 7;}
    std::vector<AYE_PointD>q;q.reserve(p.size());for(auto&v:p)q.push_back({v.x,v.y});
    ULONGLONG t0=GetTickCount64();
    rc=frame(q.data(),(int)q.size(),rep,delay);
    std::cout<<"FRAME_ELAPSED_MS="<<(GetTickCount64()-t0)<<"\n";
    std::cout<<"AYE_FramePolyline="<<rc<<"\n";
    if(rc!=0){wchar_t e[2048]={0};err(e,_countof(e));std::cout<<"SDK_ERROR="<<narrow(e)<<"\n";}
    int sr=stop();std::cout<<"AYE_Stop="<<sr<<"\n";
    int cr=close();std::cout<<"AYE_DeviceClose="<<cr<<"\n";out(rc==0&&sr==0?"NATIVE_FRAME_RESULT=COMMANDS_OK_VERIFY_VISUALLY":"NATIVE_FRAME_RESULT=FAIL_SDK_FRAME");FreeLibrary(h);return rc==0&&sr==0?0:7;
}
