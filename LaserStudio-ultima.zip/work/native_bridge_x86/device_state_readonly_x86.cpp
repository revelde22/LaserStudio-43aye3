#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdint>

static std::string joinp(const std::string&a,const std::string&b){return a.empty()?b:(a.back()=='\\'?a+b:a+"\\"+b);} 
static bool isdir(const std::string&p){DWORD a=GetFileAttributesA(p.c_str());return a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_DIRECTORY);} 
static std::string vendor(){char b[32768]={0};DWORD n=GetEnvironmentVariableA("G2PRO_VENDOR_DIR",b,sizeof(b));if(n&&n<sizeof(b)&&isdir(b))return b;n=GetEnvironmentVariableA("USERPROFILE",b,sizeof(b));if(n&&n<sizeof(b)){std::string p=joinp(joinp(b,"Documents"),"G2PRO");if(isdir(p))return p;}return ".";} 
static HMODULE load(const std::string&d,const char*n){return LoadLibraryExA(joinp(d,n).c_str(),nullptr,LOAD_WITH_ALTERED_SEARCH_PATH);} 
static void out(const std::string&s){std::cout<<s<<std::endl;}
static std::string hx32(DWORD v){char b[20];sprintf_s(b,sizeof(b),"0x%08lX",(unsigned long)v);return std::string(b);} 
static std::string hxp(const void* v){char b[24];sprintf_s(b,sizeof(b),"0x%08lX",(unsigned long)(uintptr_t)v);return std::string(b);} 

static bool pe_signature(const std::string& path, ULONGLONG& size, DWORD& timestamp){
    WIN32_FILE_ATTRIBUTE_DATA fad={};
    if(!GetFileAttributesExA(path.c_str(),GetFileExInfoStandard,&fad)) return false;
    size=((ULONGLONG)fad.nFileSizeHigh<<32)|fad.nFileSizeLow;
    HANDLE h=CreateFileA(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE) return false;
    IMAGE_DOS_HEADER dos={}; DWORD got=0; bool ok=false;
    if(ReadFile(h,&dos,sizeof(dos),&got,nullptr) && got==sizeof(dos) && dos.e_magic==IMAGE_DOS_SIGNATURE){
        if(SetFilePointer(h,dos.e_lfanew,nullptr,FILE_BEGIN)!=INVALID_SET_FILE_POINTER || GetLastError()==NO_ERROR){
            DWORD sig=0; IMAGE_FILE_HEADER fh={};
            if(ReadFile(h,&sig,sizeof(sig),&got,nullptr) && got==sizeof(sig) && sig==IMAGE_NT_SIGNATURE &&
               ReadFile(h,&fh,sizeof(fh),&got,nullptr) && got==sizeof(fh)){
                timestamp=fh.TimeDateStamp; ok=true;
            }
        }
    }
    CloseHandle(h); return ok;
}

typedef void (__thiscall *CtorFn)(void*);
typedef void (__thiscall *DtorFn)(void*);
typedef void (__thiscall *SetParamFn)(void*, void*);
typedef int  (__thiscall *InitFn)(void*, int&);
typedef int  (__thiscall *CloseFn)(void*);
typedef void (__thiscall *GetValidDevCountFn)(void*, int&);
typedef int  (__thiscall *GetUsbSpeedTypeFn)(void*);
typedef bool (__thiscall *IsValidFn)(void*, int);
typedef int  (__thiscall *GetIntNoArgFn)(void*);

static void* call_para_ctor(void* mem, void* fn){
    void* ret=nullptr;
    __asm {
        mov eax, mem
        mov edx, fn
        call edx
        mov ret, eax
    }
    return ret;
}
static void call_para_dtor(void* mem, void* fn){
    __asm {
        push mem
        mov eax, fn
        call eax
    }
}

struct ProbeResult {
    int phase;
    int init_rc;
    int init_ref;
    int mgr_initialized_count;
    int valid_count;
    int usb_speed_type;
    int adaptor_isvalid_0;
    int adaptor_isvalid_1;
    int marker_flag_f5;
    int marker_flag_f6;
    int dev_no;
    int dev_type;
    int close_rc;
    DWORD seh_code;
    void* seh_addr;
    void* mark_param_ptr;
    void* adaptor_ptr;
    void* marker_ptr;
};

// PRUEBA 3B: solo inspecciona estado interno ya creado por InitDevices.
// IsValid() se ha revisado estaticamente: solo consulta punteros/flags internos.
// NO FRAME, MARK, REDLIGHT, STOP, galvos, puertos, laser enable ni datos de marcado.
__declspec(noinline) static ProbeResult run_calls(
    void* pm, void* mm, void* paraCtorRaw, void* paraDtorRaw,
    CtorFn ctor, SetParamFn setParam, InitFn init,
    GetValidDevCountFn getValidCount, GetUsbSpeedTypeFn getUsbSpeed,
    IsValidFn isValid, GetIntNoArgFn getDevNo, GetIntNoArgFn getDevType,
    CloseFn closeAll, DtorFn dtor){
    ProbeResult r={};
    r.valid_count=-777; r.usb_speed_type=-777;
    r.adaptor_isvalid_0=-1; r.adaptor_isvalid_1=-1;
    r.marker_flag_f5=-1; r.marker_flag_f6=-1; r.dev_no=-777; r.dev_type=-777;
    __try {
        r.phase=1; call_para_ctor(pm,paraCtorRaw);
        r.phase=2; ctor(mm);
        r.phase=3; setParam(mm,pm); r.mark_param_ptr=*(void**)((BYTE*)mm+0x08);
        r.phase=4; { int ref=0; r.init_rc=init(mm,ref); r.init_ref=ref; }

        r.phase=5;
        r.mgr_initialized_count=*(int*)((BYTE*)mm+0x24);
        r.adaptor_ptr=*(void**)((BYTE*)mm+0x28);
        if(r.adaptor_ptr){
            r.marker_ptr=*(void**)((BYTE*)r.adaptor_ptr+0x08);
            if(r.marker_ptr){
                r.marker_flag_f5=(int)(*((BYTE*)r.marker_ptr+0xF5));
                r.marker_flag_f6=(int)(*((BYTE*)r.marker_ptr+0xF6));
            }
        }

        r.phase=6;
        if(r.adaptor_ptr){
            r.adaptor_isvalid_0=isValid(r.adaptor_ptr,0)?1:0;
            r.adaptor_isvalid_1=isValid(r.adaptor_ptr,1)?1:0;
        }

        r.phase=7;
        if(r.adaptor_ptr){
            r.dev_no=getDevNo(r.adaptor_ptr);
            r.dev_type=getDevType(r.adaptor_ptr);
        }
        r.phase=8; { int c=0; getValidCount(mm,c); r.valid_count=c; }
        r.phase=9; r.usb_speed_type=getUsbSpeed(mm);
        r.phase=10; r.close_rc=closeAll(mm);
        r.phase=11; dtor(mm);
        r.phase=12; call_para_dtor(pm,paraDtorRaw);
        r.phase=13;
    } __except((r.seh_code=GetExceptionCode(), r.seh_addr=GetExceptionInformation()->ExceptionRecord->ExceptionAddress), EXCEPTION_EXECUTE_HANDLER) {
    }
    return r;
}

int main(){
    SetConsoleOutputCP(CP_UTF8);
    std::string d=vendor(); SetDllDirectoryA(d.c_str()); SetCurrentDirectoryA(d.c_str());
    out("STATE_PROBE_PHASE=START");
    out("STATE_PROBE_TEST=FULL_SAFE_DIAGNOSTIC_ONE_BUTTON");
    out("STATE_PROBE_VENDOR_DIR="+d);
    out("LASER_EMISSION_ALLOWED=NO");
    out("FRAME_CALL_EXECUTED=NO");
    out("MARK_CALL_EXECUTED=NO");
    out("REDLIGHT_CALL_EXECUTED=NO");
    out("STOP_CALL_EXECUTED=NO");
    out("GALVO_MOVE_EXECUTED=NO");
    out("PORT_WRITE_EXECUTED=NO");

    ULONGLONG sbSize=0, smSize=0; DWORD sbTs=0, smTs=0;
    bool sbSig=pe_signature(joinp(d,"SeaBase.dll"),sbSize,sbTs), smSig=pe_signature(joinp(d,"SeaMark.dll"),smSize,smTs);
    const bool exact = sbSig && smSig && sbSize==1271808ULL && sbTs==0x6655B3C3UL && smSize==744448ULL && smTs==0x6655B439UL;
    out(std::string("PRIVATE_RVA_VERSION_GATE=")+(exact?"PASS":"FAIL"));
    if(!exact){out("STATE_PROBE_RESULT=REFUSED_VENDOR_VERSION_MISMATCH");return 45;}

    const char* deps[]={"libcodebar.dll","LPCodeAddin.dll","crypto3.dll","crypto5.0.dll","crypto6.0.dll"};
    std::vector<HMODULE> hs;
    for(auto n:deps){HMODULE h=load(d,n);if(!h){out(std::string("STATE_PROBE_FAIL=LOAD_")+n+" ERROR="+std::to_string(GetLastError()));return 40;}hs.push_back(h);}
    HMODULE sb=load(d,"SeaBase.dll"); if(!sb){out("STATE_PROBE_FAIL=LOAD_SeaBase.dll");return 41;} hs.push_back(sb);
    HMODULE sd=load(d,"SeaDraw.dll"); if(!sd){out("STATE_PROBE_FAIL=LOAD_SeaDraw.dll");return 41;} hs.push_back(sd);
    HMODULE sm=load(d,"SeaMark.dll"); if(!sm){out("STATE_PROBE_FAIL=LOAD_SeaMark.dll");return 41;} hs.push_back(sm);
    out("STATE_PROBE_PHASE=DLLS_LOADED");

    auto ctor=(CtorFn)GetProcAddress(sm,"??0CMarkMgr@@QAE@XZ");
    auto dtor=(DtorFn)GetProcAddress(sm,"??1CMarkMgr@@UAE@XZ");
    auto init=(InitFn)GetProcAddress(sm,"?InitDevices@CMarkMgr@@UAEHAAH@Z");
    auto closeAll=(CloseFn)GetProcAddress(sm,"?CloseAllDevice@CMarkMgr@@UAEHXZ");
    auto setParam=(SetParamFn)GetProcAddress(sb,"?SetParam@CBaseMarkMgr@@UAEXPAVCParaMgr@@@Z");
    auto getValidCount=(GetValidDevCountFn)GetProcAddress(sm,"?GetValidDevCount@CMarkMgr@@QAEXAAH@Z");
    auto getUsbSpeed=(GetUsbSpeedTypeFn)GetProcAddress(sm,"?GetUsbSpeedType@CMarkMgr@@UAEHXZ");
    auto isValid=(IsValidFn)GetProcAddress(sm,"?IsValid@CMarkAdaptor@@UAE_NH@Z");
    auto getDevNo=(GetIntNoArgFn)GetProcAddress(sm,"?GetDevNo@CMarkAdaptor@@UAEHXZ");
    auto getDevType=(GetIntNoArgFn)GetProcAddress(sm,"?GetDevType@CMarkAdaptor@@UAEHXZ");

    // Comprobación ESTÁTICA de APIs de la siguiente fase. Se resuelven símbolos, NO se llaman.
    void* symStop=(void*)GetProcAddress(sm,"?StopMark@CMarkMgr@@UAE_NPA_WH@Z");
    void* symEmergency=(void*)GetProcAddress(sm,"?EmergenyStop@CMarkMgr@@UAE_NPA_W@Z");
    void* symRedInfinite=(void*)GetProcAddress(sm,"?EnableInfiniteRedlightOut@CMarkMgr@@UAEH_N@Z");
    void* symDataMarkerRed=(void*)GetProcAddress(sm,"?EnableRedlightInfiniteOut@CDataMarker@@UAEX_N@Z");
    void* symRedClose=(void*)GetProcAddress(sm,"?CloseAutoRedLightOutPort@CMarkMgr@@UAEXPA_WQAUtagMarkCtlData@@AAUtagPenPar@@AAUtagLmcPar@@@Z");
    void* symDoMark=(void*)GetProcAddress(sm,"?DoMark@CMarkMgr@@UAE_NABV?$vector@UtagDevDocs@@V?$allocator@UtagDevDocs@@@std@@@std@@QAUtagMarkCtlData@@PAX_N@Z");
    void* symMarkPathsSDK=(void*)GetProcAddress(sm,"?MarkPathsSDK@CMarkMgr@@UAE_NPA_WABV?$vector@UtagPathData@@V?$allocator@UtagPathData@@@std@@@std@@QAUtagMarkCtlData@@AAUtagPenPar@@AAUtagLmcPar@@@Z");
    void* symLaserState=(void*)GetProcAddress(sm,"?GetLaserState@CMarkMgr@@UAEHPB_W@Z");
    void* symMarkState=(void*)GetProcAddress(sm,"?GetMarkState@CMarkMgr@@UAE_NPB_WAAUtagMarkState@@@Z");
    void* symAddLines=(void*)GetProcAddress(sm,"?AddLinesToFile@CMarkMgr@@QAE_NPA_WQAY01NH0H@Z");
    void* symSaveOrz=(void*)GetProcAddress(sd,"?SaveOrz@CFileUtil@@SA_NPB_WPAVCDocParam@@ABV?$vector@PAVCBaseShape@@V?$allocator@PAVCBaseShape@@@std@@@std@@@Z");
    void* symLoadOrz=(void*)GetProcAddress(sd,"?LoadOrz@CFileUtil@@SA_NPB_WAAV?$vector@PAVCBaseShape@@V?$allocator@PAVCBaseShape@@@std@@@std@@_N@Z");
    out(std::string("NEXT_API_SYMBOLS=STOP:")+(symStop?"YES":"NO")+" EMERGENCY:"+(symEmergency?"YES":"NO")+" REDLIGHT_MGR:"+(symRedInfinite?"YES":"NO")+" REDLIGHT_DATAMARKER:"+(symDataMarkerRed?"YES":"NO")+" REDLIGHT_CLOSE:"+(symRedClose?"YES":"NO")+" MARK:"+(symDoMark?"YES":"NO"));
    out(std::string("FRAME_API_SYMBOLS=REDLIGHT_MGR:")+(symRedInfinite?"YES":"NO")+" REDLIGHT_DATAMARKER:"+(symDataMarkerRed?"YES":"NO")+" REDLIGHT_CLOSE:"+(symRedClose?"YES":"NO")+" MARK_PATHS_SDK:"+(symMarkPathsSDK?"YES":"NO")+" ADD_LINES:"+(symAddLines?"YES":"NO"));
    out(std::string("MARK_API_SYMBOLS=MARK:")+(symDoMark?"YES":"NO")+" STOP:"+(symStop?"YES":"NO")+" EMERGENCY:"+(symEmergency?"YES":"NO"));
    out(std::string("READ_STATE_SYMBOLS=LASER_STATE:")+(symLaserState?"YES":"NO")+" MARK_STATE:"+(symMarkState?"YES":"NO"));
    out(std::string("ORZ_ORZX_SYMBOLS=ADD_LINES:")+(symAddLines?"YES":"NO")+" SAVE_ORZ:"+(symSaveOrz?"YES":"NO")+" LOAD_ORZ:"+(symLoadOrz?"YES":"NO"));
    out("NEXT_API_CALLS_EXECUTED=NO");
    out(std::string("STATE_PROBE_SYMBOLS=CTOR:")+(ctor?"YES":"NO")+" SETPARAM:"+(setParam?"YES":"NO")+" INIT:"+(init?"YES":"NO")+" VALIDCOUNT:"+(getValidCount?"YES":"NO")+" USBSPEED:"+(getUsbSpeed?"YES":"NO")+" ISVALID:"+(isValid?"YES":"NO")+" DEVNO:"+(getDevNo?"YES":"NO")+" DEVTYPE:"+(getDevType?"YES":"NO")+" CLOSE:"+(closeAll?"YES":"NO")+" DTOR:"+(dtor?"YES":"NO"));
    if(!(ctor&&dtor&&setParam&&init&&getValidCount&&getUsbSpeed&&isValid&&getDevNo&&getDevType&&closeAll)){out("STATE_PROBE_RESULT=FAIL_SYMBOLS");return 42;}

    const SIZE_T markSize=0x320, paramSize=0x380;
    void* paraCtorRaw=(void*)((uintptr_t)sb+0xFC80);
    void* paraDtorRaw=(void*)((uintptr_t)sb+0x10370);
    void* pm=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,paramSize);
    void* mm=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,markSize);
    if(!(pm&&mm)){out("STATE_PROBE_RESULT=FAIL_ALLOC");return 43;}

    out("STATE_PROBE_PHASE=CALL_READ_ONLY_SEQUENCE");
    ProbeResult r=run_calls(pm,mm,paraCtorRaw,paraDtorRaw,ctor,setParam,init,getValidCount,getUsbSpeed,isValid,getDevNo,getDevType,closeAll,dtor);
    out("STATE_PROBE_LAST_PHASE="+std::to_string(r.phase));
    out("PHASE_MAP=1:PARAM_CTOR 2:MARKMGR_CTOR 3:SETPARAM 4:INIT 5:READ_INTERNALS 6:ISVALID_READ 7:GET_DEV_NO_TYPE 8:GET_VALID_COUNT 9:GET_USB_SPEED 10:CLOSE 11:MARK_DTOR 12:PARAM_DTOR 13:DONE");
    out("MARKMGR_PARAM_PTR="+hxp(r.mark_param_ptr));
    if(r.seh_code){
        out("STATE_PROBE_SEH="+hx32(r.seh_code)); out("STATE_PROBE_SEH_ADDRESS="+hxp(r.seh_addr));
        out("STATE_PROBE_RESULT=SEH_EXCEPTION"); std::cout.flush(); TerminateProcess(GetCurrentProcess(),44);
    }
    out("INITDEVICES_RETURN="+std::to_string(r.init_rc));
    out("INITDEVICES_REF_VALUE="+std::to_string(r.init_ref));
    out("MARKMGR_INITIALIZED_COUNT="+std::to_string(r.mgr_initialized_count));
    out("ADAPTOR_PTR="+hxp(r.adaptor_ptr));
    out("MARKER_PTR="+hxp(r.marker_ptr));
    out("MARKER_FLAG_F5="+std::to_string(r.marker_flag_f5));
    out("MARKER_FLAG_F6="+std::to_string(r.marker_flag_f6));
    out("ADAPTOR_ISVALID_0="+std::to_string(r.adaptor_isvalid_0));
    out("ADAPTOR_ISVALID_1="+std::to_string(r.adaptor_isvalid_1));
    out("DEVICE_NO="+std::to_string(r.dev_no));
    out("DEVICE_TYPE="+std::to_string(r.dev_type));
    out("VALID_DEVICE_COUNT="+std::to_string(r.valid_count));
    out("USB_SPEED_TYPE="+std::to_string(r.usb_speed_type));
    out("CLOSEALLDEVICE_RETURN="+std::to_string(r.close_rc));
    out("DEVICE_CLOSED_BEFORE_EXIT=YES");
    out("STATE_PROBE_RESULT=PASS");
    HeapFree(GetProcessHeap(),0,mm); HeapFree(GetProcessHeap(),0,pm);
    std::cout.flush(); TerminateProcess(GetCurrentProcess(),0); return 0;
}
