"""Count only fully returned SDK batches, without inventing hardware telemetry."""
class PassCounter:
    def __init__(self, segments=()):
        self.segments = list(segments)  # (number of blocks, passes, description)
        self.completed_blocks = 0
        self.total_blocks = sum(blocks for blocks, _, _ in self.segments)
        self.total_passes = sum(passes for _, passes, _ in self.segments)

    def confirm_block(self):
        self.completed_blocks = min(self.total_blocks, self.completed_blocks + 1)

    def text(self, stopped=False):
        end = done = 0
        current = ''
        for blocks, passes, description in self.segments:
            end += blocks
            if self.completed_blocks >= end:
                done += passes
            elif not current:
                current = description + f' · {passes} pasada(s) en este tramo'
        suffix = ' · DETENIDO' if stopped else (' · ' + current if current else '')
        return (f'Pasadas completadas según SDK: {done}/{self.total_passes}'
                f' · bloques: {self.completed_blocks}/{self.total_blocks}' + suffix)
