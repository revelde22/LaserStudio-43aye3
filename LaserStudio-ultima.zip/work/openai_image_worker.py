import json,sys
from pathlib import Path
from PySide6.QtCore import QObject,QProcess,QProcessEnvironment,Signal
class OpenAIWorker(QObject):
 status=Signal(str);result=Signal(str);failed=Signal(str);finished=Signal()
 def __init__(self,options,key,parent=None):
  super().__init__(parent);self.options=options;self.key=key;self.active=False;self.done=False;self.cancelled=False;self.buffer='';self.has_result=False;self.has_error=False
  self.process=QProcess(self);self.process.readyReadStandardOutput.connect(self.read);self.process.started.connect(self.send);self.process.finished.connect(self.complete);self.process.errorOccurred.connect(self.error)
 def start(self):
  env=QProcessEnvironment.systemEnvironment();env.insert('PYTHONIOENCODING','utf-8');self.process.setProcessEnvironment(env)
  self.active=True;self.process.start(sys.executable,['-u',str(Path(__file__).with_name('openai_image_cli.py'))])
 def send(self):
  if self.cancelled:self.process.kill();return
  self.process.write(json.dumps({'api_key':self.key,'options':self.options},ensure_ascii=False).encode());self.process.closeWriteChannel();self.key=''
 def read(self):
  self.buffer+=bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace')
  while '\n' in self.buffer:
   line,self.buffer=self.buffer.split('\n',1)
   try:event=json.loads(line)
   except ValueError:continue
   if self.cancelled:continue
   if 'status' in event:self.status.emit(event['status'])
   if 'result' in event:self.has_result=True;self.result.emit(event['result'])
   if 'error' in event:self.has_error=True;self.failed.emit(event['error'])
 def finish(self):
  self.active=False;self.key=''
  if not self.done:self.done=True;self.finished.emit()
 def complete(self,code,*args):
  self.read()
  if self.cancelled:self.failed.emit('Cancelado localmente. Una solicitud ya enviada puede continuar y facturarse en OpenAI; no se reintenta automáticamente.')
  elif not self.has_result and not self.has_error:self.failed.emit('No se pudo obtener el diseño de OpenAI (código '+str(code)+').')
  self.finish()
 def error(self,error):
  if error==QProcess.ProcessError.FailedToStart:self.failed.emit('No se pudo iniciar Python para OpenAI.');self.finish()
 def isRunning(self):return self.active and not self.done
 def requestInterruption(self):
  self.cancelled=True;self.key=''
  if self.process.state()!=QProcess.ProcessState.NotRunning:self.process.kill()
 def stop(self):self.requestInterruption()
 def wait(self,ms):
  if self.process.state()==QProcess.ProcessState.NotRunning:return True
  return self.process.waitForFinished(ms)
