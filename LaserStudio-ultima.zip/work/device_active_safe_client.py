from pathlib import Path
import os, subprocess


def _build(base, timeout=120):
    bat=base/'COMPILAR_DIAGNOSTICO_G2.bat'
    if not bat.exists():
        return False,['AUTO_BUILD: BAT no encontrado: '+str(bat)]
    try:
        p=subprocess.run(['cmd.exe','/d','/c',str(bat)],cwd=str(base),capture_output=True,text=True,timeout=timeout,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        lines=[x.rstrip() for x in (p.stdout+'\n'+p.stderr).splitlines() if x.strip()]
        lines.insert(0,'AUTO_BUILD: compilando/recompilando FASE ACTIVA STOP x86')
        lines.append('AUTO_BUILD_RETURN='+str(p.returncode))
        return p.returncode==0,lines
    except Exception as e:
        return False,['AUTO_BUILD_EXCEPTION='+repr(e)]


def run_device_active_safe_probe(base=None,vendor_dir=None,timeout=35):
    base=Path(base or Path(__file__).parent)
    exe=base/'native_bridge_x86'/'43aye3_g2_active_safe_x86.exe'
    pre=[]
    src=base/'native_bridge_x86'/'device_active_safe_x86.cpp'
    needs_build=(not exe.exists())
    try:
        if exe.exists() and src.exists() and src.stat().st_mtime > exe.stat().st_mtime:
            needs_build=True
    except Exception:
        needs_build=True
    if needs_build:
        ok,lines=_build(base);pre.extend(lines)
        if not ok or not exe.exists():
            pre += ['FASE ACTIVA STOP: no se pudo construir el ejecutable x86.',
                    'MARK/LASER: NO EJECUTADOS']
            return {'ok':False,'result':'BUILD_FAILED','lines':pre}
        pre.append('AUTO_BUILD_RESULT=PASS')
    env=os.environ.copy()
    if vendor_dir: env['G2PRO_VENDOR_DIR']=str(Path(vendor_dir))
    try:
        p=subprocess.run([str(exe)],cwd=str(base),capture_output=True,text=True,timeout=timeout,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),env=env)
        lines=pre+[x.strip() for x in (p.stdout+'\n'+p.stderr).splitlines() if x.strip()]
        result=next((x.split('=',1)[1] for x in reversed(lines) if x.startswith('ACTIVE_SAFE_RESULT=')),None)
        return {'ok':p.returncode==0 and result=='PASS','returncode':p.returncode,'result':result,'lines':lines}
    except subprocess.TimeoutExpired as e:
        out=e.stdout or ''
        if isinstance(out,bytes): out=out.decode(errors='replace')
        lines=pre+[x.strip() for x in out.splitlines() if x.strip()]
        lines.append('FASE ACTIVA STOP: TIMEOUT - proceso aislado terminado por el padre')
        lines.append('La emisión de fibra permanece bloqueada. Cierra GLaser/43AYE3 si la controladora quedara ocupada.')
        return {'ok':False,'result':'TIMEOUT','lines':lines}
