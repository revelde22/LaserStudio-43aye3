"""Importa contornos SVG preservando subtrazos, curvas y dimensiones fisicas."""
from __future__ import annotations

import math
import re
from xml.etree import ElementTree

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QPainterPath
from svgpathtools import Arc, CubicBezier, Document, QuadraticBezier

_LENGTH = re.compile(r"^\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*(mm|cm|in|px|pt|pc)?\s*$", re.I)
_MM = {"mm": 1.0, "cm": 10.0, "in": 25.4, "px": 25.4 / 96.0, "pt": 25.4 / 72.0, "pc": 25.4 / 6.0}


def _length_mm(value):
    if value is None:
        return None
    m = _LENGTH.fullmatch(value)
    if not m:
        return None
    return float(m.group(1)) * _MM[(m.group(2) or "px").lower()]


def _viewport(path):
    root = ElementTree.parse(path).getroot()
    vb = root.get("viewBox")
    vals = [float(x) for x in re.split(r"[\s,]+", vb.strip()) if x] if vb else None
    if vals is not None and (len(vals) != 4 or vals[2] <= 0 or vals[3] <= 0):
        raise ValueError("viewBox SVG no valido")
    width, height = _length_mm(root.get("width")), _length_mm(root.get("height"))
    if vals:
        x0, y0, vw, vh = vals
        if width is None and height is None:
            width, height = vw * _MM["px"], vh * _MM["px"]
        elif width is None:
            width = height * vw / vh
        elif height is None:
            height = width * vh / vw
    else:
        x0 = y0 = 0.0
        vw = float(re.match(r"\s*[\d.]+", root.get("width", "0")).group()) if re.match(r"\s*[\d.]+", root.get("width", "0")) else 0.0
        vh = float(re.match(r"\s*[\d.]+", root.get("height", "0")).group()) if re.match(r"\s*[\d.]+", root.get("height", "0")) else 0.0
        if not vw or not vh:
            raise ValueError("El SVG necesita viewBox o width/height numericos")
        width = width or vw * _MM["px"]
        height = height or vh * _MM["px"]
    if width <= 0 or height <= 0:
        raise ValueError("Dimensiones SVG no validas")
    return x0, y0, width / vw, height / vh


def load_svg_paths(filename):
    """Devuelve un QPainterPath por elemento, con subtrazos sin puentes."""
    x0, y0, sx, sy = _viewport(filename)
    result = []

    def pt(z):
        return QPointF((z.real - x0) * sx, (z.imag - y0) * sy)

    for svg_path in Document(str(filename)).paths():
        q = QPainterPath()
        q.setFillRule(Qt.FillRule.OddEvenFill)
        beginning = previous = None
        for seg in svg_path:
            a = seg.start
            if previous is None or abs(a - previous) > 1e-7:
                if previous is not None and beginning is not None and abs(previous - beginning) <= 1e-7:
                    q.closeSubpath()
                q.moveTo(pt(a))
                beginning = a
            b = seg.end
            if isinstance(seg, CubicBezier):
                q.cubicTo(pt(seg.control1), pt(seg.control2), pt(b))
            elif isinstance(seg, QuadraticBezier):
                q.quadTo(pt(seg.control), pt(b))
            elif isinstance(seg, Arc):
                steps = max(8, min(512, math.ceil(seg.length() * max(sx, sy) / 0.15)))
                for i in range(1, steps + 1):
                    q.lineTo(pt(seg.point(i / steps)))
            else:
                q.lineTo(pt(b))
            previous = b
        if beginning is not None and previous is not None and abs(previous - beginning) <= 1e-7:
            q.closeSubpath()
        if not q.isEmpty():
            result.append(q)
    return result
