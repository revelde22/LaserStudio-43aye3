"""Pinned, checksum verified optional model downloads. No inference or laser calls."""
import hashlib,json,sys
from pathlib import Path
from urllib.request import urlopen
BASE=Path(__file__).resolve().parent
# label, destination, repository, revision, remote filename, bytes, sha256
CATALOG={
 'sdxl':('SDXL Base 1.0','43AYE3_SDXL_BASE_1.0.safetensors','stabilityai/stable-diffusion-xl-base-1.0','462165984030d82259a11f4367a4eed129e94a7b','sd_xl_base_1.0.safetensors',6938078334,'31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b'),
 'sd15':('Stable Diffusion 1.5','43AYE3_SD15.safetensors','stable-diffusion-v1-5/stable-diffusion-v1-5','451f4fe16113bff5a5d2269ed5ad43b0592e9a14','v1-5-pruned-emaonly.safetensors',4265146304,'6ce0161689b3853acaa03779ec93eafe75a02f4ced659bee03f50797806fa2fa')}
def destination(key):return BASE/'AI_RUNTIME/ComfyUI/models/checkpoints'/CATALOG[key][1]
def installed(key):return destination(key).exists() and destination(key).stat().st_size==CATALOG[key][5]
def emit(**data):print(json.dumps(data,ensure_ascii=False),flush=True)
def fetch(key,opener=urlopen):
 label,filename,repo,rev,remote,size,checksum=CATALOG[key];target=destination(key)
 target.parent.mkdir(parents=True,exist_ok=True)
 def digest(path):
  h=hashlib.sha256()
  with path.open('rb') as stream:
   for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
  return h.hexdigest()
 if installed(key):
  emit(message='Verificando '+label)
  if digest(target)==checksum:emit(message=label+' ya está instalado y verificado.');return
 part=target.with_suffix(target.suffix+'.part');h=hashlib.sha256();count=0;reported=-1
 emit(message='Descargando '+label)
 with opener('https://huggingface.co/'+repo+'/resolve/'+rev+'/'+remote,timeout=30) as response,part.open('wb') as stream:
  for block in iter(lambda:response.read(1024*1024),b''):
   stream.write(block);h.update(block);count+=len(block)
   if count>size:raise RuntimeError('Tamaño inesperado: '+label)
   percent=int(count*100/size)
   if percent!=reported:emit(percent=percent,message=f'{label}: {count/1e9:.2f} / {size/1e9:.2f} GB');reported=percent
 if count!=size or h.hexdigest()!=checksum:
  part.unlink(missing_ok=True);raise RuntimeError('La descarga no supera la comprobación SHA256: '+label)
 part.replace(target);emit(message=label+' instalado y verificado.',percent=100)
if __name__=='__main__':
 try:
  for key in sys.argv[1:]:fetch(key)
 except Exception as exc:emit(message=str(exc));sys.exit(1)
