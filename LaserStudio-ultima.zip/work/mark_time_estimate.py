"""Geometric ETA refined by completed native blocks; no hardware telemetry."""
import math
import time
from datetime import datetime, timedelta


def block_seconds(group):
    _, paths, passes, speed, _, _ = group
    length = sum(math.hypot(b[0]-a[0], b[1]-a[1])
                 for path in paths for a, b in zip(path, path[1:]))
    if not math.isfinite(speed) or speed <= 0:
        raise ValueError('La velocidad debe ser positiva y finita.')
    # Include a small floor for tiny blocks. USB, jumps and setup are learned
    # from completed blocks instead of asserted as known machine parameters.
    return max(.05, length * passes / speed)


def duration(seconds):
    seconds = max(0, math.ceil(seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return f'{hours:d}:{minutes:02d}:{seconds:02d}'


class MarkTimeEstimate:
    def __init__(self, groups, clock=time.monotonic):
        self.weights = [block_seconds(group) for group in groups]
        self.clock = clock
        self.started = clock()
        self.finished = None
        self.completed = 0
        self.stopped = False
        self.confirmed_at = self.started

    def confirm_block(self):
        if self.finished is not None:
            return
        self.completed = min(len(self.weights), self.completed + 1)
        self.confirmed_at = self.clock()
        if self.completed == len(self.weights):
            self.finished = self.confirmed_at

    def stop(self):
        if self.finished is None:
            self.finished = self.clock()
            self.stopped = True

    @property
    def percent(self):
        total = sum(self.weights)
        if not total:
            return 0
        # Only completed blocks advance the bar, including on cancellation.
        return min(100, int(100 * sum(self.weights[:self.completed]) / total))

    def text(self):
        now = self.clock() if self.finished is None else self.finished
        elapsed = now - self.started
        if self.finished is not None:
            state = 'Detenido' if self.stopped else 'Terminado según SDK'
            return f'{state} · transcurrido {duration(elapsed)}'
        done = sum(self.weights[:self.completed])
        remaining = sum(self.weights[self.completed:])
        if self.completed:
            remaining *= (self.confirmed_at - self.started) / done
        remaining = max(0, remaining - (now - self.confirmed_at))
        if remaining <= 0:
            return f'Transcurrido {duration(elapsed)} · esperando confirmación SDK'
        finish = (datetime.now() + timedelta(seconds=remaining)).strftime('%H:%M:%S')
        kind = 'ajustada por bloques' if self.completed else 'inicial por trayectorias'
        return (f'Transcurrido {duration(elapsed)} · restante aprox. {duration(remaining)}'
                f' · fin aprox. {finish} · estimación {kind}')
