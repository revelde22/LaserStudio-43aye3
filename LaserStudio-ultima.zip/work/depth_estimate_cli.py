"""Local Depth Anything V2 Small inference; automatic CUDA inference with CPU fallback."""
import argparse,sys,time
from pathlib import Path
from comfy_setup import STATE,ensure_depth

def report(message):
    print(message,flush=True)
    with (Path(__file__).resolve().parent/'DEPTH_INFERENCE.log').open('a',encoding='utf-8') as log:
        log.write(time.strftime('%Y-%m-%d %H:%M:%S')+' | '+message+'\n')

def estimate(source,output):
    report('Iniciando inferencia. Python: '+sys.executable)
    report('Cargando PyTorch y dependencias de imagen…')
    import torch,numpy as np
    from PIL import Image,ImageOps
    report('Cargando Transformers…')
    from transformers import AutoImageProcessor,AutoModelForDepthEstimation
    model_dir=STATE/'models/depth_anything_v2_small'
    started=time.monotonic()
    report('Cargando modelo de profundidad desde disco…')
    processor=AutoImageProcessor.from_pretrained(model_dir,local_files_only=True)
    model=AutoModelForDepthEstimation.from_pretrained(model_dir,local_files_only=True).eval()
    report('Modelo cargado. Preparando imagen…')
    with Image.open(source) as original:artwork=ImageOps.exif_transpose(original).convert('RGBA')
    image=artwork.convert('RGB')
    inputs=processor(images=image,return_tensors='pt')
    torch.set_num_threads(max(1,min(8,torch.get_num_threads())))
    prediction=predict_depth(model,inputs,torch)
    report('Inferencia terminada. Ajustando resolución y guardando PNG en CPU…')
    # Resize on CPU so very large originals do not exhaust GPU memory.
    prediction=torch.nn.functional.interpolate(prediction.unsqueeze(1),size=(image.height,image.width),mode='bicubic',align_corners=False).squeeze().numpy()
    from depth_map_tools import normalize_depth_prediction
    Image.fromarray(normalize_depth_prediction(prediction,artwork)).save(output)
    report('Contraste relativo calculado sobre la figura, excluyendo el fondo blanco exterior.')
    report(f'Tiempo de modelo y cálculo: {time.monotonic()-started:.1f} s')
    report('Mapa relativo creado. Blanco: más próximo / menos tallado. Negro: más alejado / más tallado.')
def predict_depth(model,inputs,torch):
    if torch.cuda.is_available():
        try:
            report('Calculando con GPU: '+torch.cuda.get_device_name(0))
            model.to('cuda')
            gpu_inputs={key:value.to('cuda') for key,value in inputs.items()}
            with torch.inference_mode():
                prediction=model(**gpu_inputs).predicted_depth.detach().float().cpu()
            return prediction
        except Exception as exc:
            report('GPU no disponible para este cálculo; reintentando en CPU: '+str(exc))
            model.to('cpu')
            gpu_inputs=None
            torch.cuda.empty_cache()
    else:
        report('Calculando con CPU.')
    model.to('cpu')
    with torch.inference_mode():
        return model(**inputs).predicted_depth.detach().float().cpu()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--output',required=True);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    try:
        if not args.run:
            report('Solicitud de mapa recibida. Preparando entorno…')
            import subprocess
            python=ensure_depth()
            command=['-u',str(Path(__file__).resolve()),'--run','--source',args.source,'--output',args.output]
            result=subprocess.run([str(python),*command])
            if result.returncode:
                from comfy_setup import ensure_depth_cpu
                cpu_python=ensure_depth_cpu()
                if str(cpu_python)==str(python):raise RuntimeError('No se pudo calcular el mapa en CPU.')
                print('Reintentando con el entorno independiente de CPU…',flush=True)
                subprocess.run([str(cpu_python),*command],check=True)
        else:estimate(args.source,args.output)
    except Exception as e:
        import traceback
        report('ERROR: '+traceback.format_exc());sys.exit(1)
