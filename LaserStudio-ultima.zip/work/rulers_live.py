
import math, pathlib, tempfile
from PySide6.QtCore import Qt,QRectF,QTimer
from PySide6.QtGui import QPainter,QPen,QColor,QFont,QPixmap
from PySide6.QtWidgets import QWidget,QDockWidget,QVBoxLayout,QFormLayout,QComboBox,QSlider,QLabel,QCheckBox,QPushButton,QHBoxLayout,QGroupBox
from PIL import Image,ImageEnhance,ImageOps,ImageFilter

class Ruler(QWidget):
    def __init__(self,view,orientation,parent=None):
        super().__init__(parent);self.view=view;self.orientation=orientation;self.unit="mm"
        self.setFixedHeight(24) if orientation==Qt.Orientation.Horizontal else self.setFixedWidth(32)
    def setUnit(self,u):self.unit=u;self.update()
    def paintEvent(self,e):
        p=QPainter(self);p.fillRect(self.rect(),QColor("#eeeeee"));p.setPen(QPen(QColor("#555")))
        font=QFont();font.setPointSize(7);p.setFont(font)
        vr=self.view.viewport().rect();a=self.view.mapToScene(vr.topLeft());b=self.view.mapToScene(vr.bottomRight())
        lo,hi=(a.x(),b.x()) if self.orientation==Qt.Orientation.Horizontal else (a.y(),b.y())
        if hi<lo:lo,hi=hi,lo
        pxpermm=abs(self.view.transform().m11() if self.orientation==Qt.Orientation.Horizontal else self.view.transform().m22())
        choices=[.1,.2,.5,1,2,5,10,20,50,100]
        major=next((x for x in choices if x*pxpermm>=45),100);minor=major/10
        x=math.floor(lo/minor)*minor
        edge=24 if self.orientation==Qt.Orientation.Horizontal else 32
        while x<=hi+minor:
            pos=self.view.mapFromScene(x,0).x() if self.orientation==Qt.Orientation.Horizontal else self.view.mapFromScene(0,x).y()
            k=round(x/minor);ismajor=(k%10==0)
            if self.orientation==Qt.Orientation.Horizontal:
                p.drawLine(pos,edge,pos,9 if ismajor else 17)
                if ismajor:p.drawText(pos+2,8,f"{x:g}")
            else:
                p.drawLine(edge,pos,17 if ismajor else 25,pos)
                if ismajor:p.drawText(1,pos-2,f"{x:g}")
            x+=minor
        # Selected object's dimensions projected in red onto both rulers.
        try:
            sel=self.view.scene().selectedItems()
            if sel:
                r=sel[0].sceneBoundingRect();p.setPen(QPen(QColor("#d40000"),2))
                if self.orientation==Qt.Orientation.Horizontal:
                    p1=self.view.mapFromScene(r.left(),0).x();p2=self.view.mapFromScene(r.right(),0).x()
                    p.drawLine(p1,22,p2,22);p.drawLine(p1,17,p1,24);p.drawLine(p2,17,p2,24)
                    p.setPen(QPen(QColor("#d40000")));p.drawText((p1+p2)/2-18,16,f"{r.width():.2f} mm")
                else:
                    p1=self.view.mapFromScene(0,r.top()).y();p2=self.view.mapFromScene(0,r.bottom()).y()
                    p.drawLine(30,p1,30,p2);p.drawLine(24,p1,32,p1);p.drawLine(24,p2,32,p2)
                    p.save();p.translate(15,(p1+p2)/2+18);p.rotate(-90);p.drawText(0,0,f"{r.height():.2f} mm");p.restore()
        except RuntimeError:pass

def process_preview(source,mode="Grayscale",brightness=0,contrast=0,gamma=1.0,sharpen=0,invert=False,threshold=128):
    from laser_image_pipeline import prepare
    return prepare(source,mode,brightness,0,contrast,gamma,sharpen,invert,threshold,254)

def install_rulers_live_image(w):
    """Install non-overlapping rulers around the QGraphicsView.
    Image controls are intentionally owned by image_controller.py only.
    """
    from PySide6.QtWidgets import QWidget,QGridLayout
    view=w.view
    # Replace direct central view by a container. The view is reparented into the grid,
    # so rulers consume layout space instead of covering toolbars or canvas.
    container=QWidget(w)
    grid=QGridLayout(container);grid.setContentsMargins(0,0,0,0);grid.setSpacing(0)
    corner=QWidget(container);corner.setFixedSize(32,24)
    hr=Ruler(view,Qt.Orientation.Horizontal,container);hr.setFixedHeight(24)
    vr=Ruler(view,Qt.Orientation.Vertical,container);vr.setFixedWidth(32)
    grid.addWidget(corner,0,0);grid.addWidget(hr,0,1);grid.addWidget(vr,1,0);grid.addWidget(view,1,1)
    grid.setRowStretch(1,1);grid.setColumnStretch(1,1)
    w.setCentralWidget(container);w.ruler_container=container;w.hruler=hr;w.vruler=vr

    # Update only while objects are alive.
    timer=QTimer(w);timer.setInterval(100)
    def tick():
        try:
            if w.isVisible():
                hr.update();vr.update()
        except RuntimeError:
            timer.stop()
    timer.timeout.connect(tick);timer.start();w._ruler_timer=timer

