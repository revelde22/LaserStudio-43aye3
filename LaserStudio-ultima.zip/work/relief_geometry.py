"""Height-field mesh and binary STL. No image lighting is stored as geometry."""
from pathlib import Path
import struct
import uuid
import numpy as np
from PIL import Image

def load_height(path,limit=None):
    with Image.open(path) as image:
        high=image.mode in ('I','I;16','I;16L','I;16B')
        values=np.asarray(image if high else image.convert('L'),dtype=np.float32)
    values=np.clip(values/(65535. if high else 255.),0,1)
    if limit and max(values.shape)>limit:
        rows=max(2,round(values.shape[0]*limit/max(values.shape)))
        cols=max(2,round(values.shape[1]*limit/max(values.shape)))
        values=np.asarray(Image.fromarray(values).resize((cols,rows),Image.Resampling.BILINEAR),dtype=np.float32)
    if min(values.shape)<2:raise ValueError('El mapa necesita al menos 2 × 2 píxeles.')
    return values

def mesh(height,width_mm,height_mm,relief_mm,base_mm):
    height=np.asarray(height,dtype=np.float32)
    dimensions=np.asarray([width_mm,height_mm,relief_mm,base_mm],dtype=float)
    if not np.isfinite(dimensions).all() or (dimensions<=0).any():raise ValueError('Las dimensiones deben ser positivas.')
    if height.ndim!=2 or min(height.shape)<2 or not np.isfinite(height).all():raise ValueError('Mapa no válido.')
    rows,cols=height.shape
    x,y=np.meshgrid(np.linspace(0,width_mm,cols),np.linspace(height_mm,0,rows))
    vertices=np.stack([x,y,base_mm+np.clip(height,0,1)*relief_mm],axis=-1).reshape(-1,3).astype(np.float32)
    a=np.arange(rows*cols).reshape(rows,cols)[:-1,:-1].ravel()
    # Image rows run down; order gives outward +Z on the top surface.
    faces=np.concatenate([np.stack([a,a+cols,a+1],axis=1),np.stack([a+1,a+cols,a+cols+1],axis=1)])
    grid=np.arange(rows*cols).reshape(rows,cols)
    boundary=np.concatenate([grid[0,:],grid[1:,-1],grid[-1,-2::-1],grid[-2:0:-1,0]])
    bottom=vertices[boundary].copy();bottom[:,2]=0
    offset=len(vertices);center=offset+len(bottom)
    vertices=np.concatenate([vertices,bottom,[[width_mm/2,height_mm/2,0]]]).astype(np.float32)
    b=np.arange(len(boundary));n=(b+1)%len(b)
    sides=np.concatenate([np.stack([boundary[b],boundary[n],offset+b],axis=1),np.stack([boundary[n],offset+n,offset+b],axis=1)])
    underside=np.stack([np.full(len(b),center),offset+b,offset+n],axis=1)
    return vertices,np.concatenate([faces,sides,underside])

def export_stl(height_path,output,width_mm,height_mm,relief_mm,base_mm=1.,resolution=512):
    vertices,faces=mesh(load_height(height_path,int(resolution)),width_mm,height_mm,relief_mm,base_mm)
    output=Path(output)
    temporary=output.with_name(output.name+'.'+uuid.uuid4().hex+'.tmp')
    with temporary.open('wb') as stream:
        stream.write(b'43AYE3 relative relief; units mm; estimated geometry'.ljust(80,b'\0'))
        stream.write(struct.pack('<I',len(faces)))
        dtype=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attribute','<u2')])
        for start in range(0,len(faces),32768):
            triangles=vertices[faces[start:start+32768]]
            normal=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
            normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-12)
            records=np.zeros(len(triangles),dtype=dtype);records['normal']=normal;records['vertices']=triangles
            stream.write(records.tobytes())
    temporary.replace(output)
    return dict(stl=str(output),triangles=len(faces),units='mm')
