"""Read-only published observations. Never converted into a calibration curve."""
import json
from pathlib import Path
from PySide6.QtCore import Qt,QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QTableWidget,QTableWidgetItem,QPlainTextEdit,QPushButton
CATALOG=Path(__file__).with_name('external_depth_references.json')
RELATIONS={'reported':'reportada','greater_than_approximate':'algo mayor, aproximada','greater_than':'mayor que','reported_mixed_process':'proceso mixto','reported_approximate':'aproximada'}
LANGUAGES={'en':'Inglés','ru':'Ruso','pt':'Portugués','de':'Alemán','fr':'Francés','es':'Español','zh':'Chino','ja':'Japonés','it':'Italiano'}
def load_catalog():
 data=json.loads(CATALOG.read_text(encoding='utf-8'))
 ids=set()
 for row in data['reports']:
  if row['id'] in ids or not row['source_url'].startswith('https://') or row['usable_as_calibration'] is not False:raise ValueError('Referencia externa no válida.')
  ids.add(row['id'])
 return data
class ExternalDepthDialog(QDialog):
 def __init__(self,parent=None):
  super().__init__(parent);self.setWindowTitle('Mediciones publicadas · referencias externas');self.resize(1060,700);self.selected_report=None;self.catalog=load_catalog();self.rows=[]
  layout=QVBoxLayout(self);note=QLabel('Resultados reportados por otros usuarios, con fuente y condiciones. No están calibrados para tu G2. Una pasada, ciclo o ejecución puede representar procesos distintos. Los ensayos con ajustes diferentes no se unen en una curva.');note.setWordWrap(True);layout.addWidget(note)
  filters=QHBoxLayout();layout.addLayout(filters);self.material=QComboBox();self.material.addItem('Todos los materiales',None)
  for value in sorted({r['material'] for r in self.catalog['reports']}):self.material.addItem(value,value)
  self.language=QComboBox();self.language.addItem('Todos los idiomas encontrados',None)
  for value in sorted({r['language'] for r in self.catalog['reports']}):self.language.addItem(LANGUAGES.get(value,value),value)
  filters.addWidget(self.material);filters.addWidget(self.language)
  self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(['Material','Equipo','Profundidad publicada','Pasadas / ciclos','Idioma']);self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows);self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection);self.table.horizontalHeader().setStretchLastSection(True);layout.addWidget(self.table,1)
  self.details=QPlainTextEdit();self.details.setReadOnly(True);layout.addWidget(self.details,1)
  row=QHBoxLayout();layout.addLayout(row);self.open=QPushButton('Abrir fuente original');self.draft=QPushButton('Preparar mi calibración con mediciones propias');close=QPushButton('Cerrar');row.addWidget(self.open);row.addWidget(self.draft);row.addWidget(close)
  self.open.clicked.connect(self.open_source);self.draft.clicked.connect(self.make_draft);close.clicked.connect(self.reject)
  self.material.currentIndexChanged.connect(self.populate);self.language.currentIndexChanged.connect(self.populate);self.table.itemSelectionChanged.connect(self.show_report);self.populate()
 def current(self):
  row=self.table.currentRow();return self.rows[row] if 0<=row<len(self.rows) else None
 def populate(self):
  self.rows=[r for r in self.catalog['reports'] if (not self.material.currentData() or r['material']==self.material.currentData()) and (not self.language.currentData() or r['language']==self.language.currentData())]
  self.table.setRowCount(len(self.rows))
  for i,r in enumerate(self.rows):
   m=r['measurement'];depth='Sin cifra transcrita' if not m else f'{m["depth_mm"]:g} mm ({RELATIONS.get(m["relation"],m["relation"])})';passes='Estudio; ver detalle' if not m else f'{m["passes"]}: {m["pass_kind"]}'
   for c,v in enumerate([r['material'],r['machine'],depth,passes,LANGUAGES.get(r['language'],r['language'])]):self.table.setItem(i,c,QTableWidgetItem(v))
  for c,width in enumerate((140,215,195,335,95)):self.table.setColumnWidth(c,width)
  if self.rows:self.table.selectRow(0)
  self.show_report()
 def show_report(self):
  r=self.current();self.open.setEnabled(bool(r));self.draft.setEnabled(bool(r))
  if not r:self.details.clear();return
  m=r['measurement'];lines=[r['title'],'Autor: '+r['author'],'Fecha publicada: '+r['published']+' · Consulta: '+r['checked'],'Fuente: '+r['source_url'],'Tipo de evidencia: '+{'publicacion_usuario':'relato del usuario','estudio_experimental':'estudio experimental','extracto_indexado_no_verificado_en_pagina':'sólo extracto indexado, página no recuperada'}.get(r['evidence'],r['evidence']),'']
  if m:
   lines+=['Profundidad: '+str(m['depth_mm'])+' mm ('+RELATIONS.get(m['relation'],m['relation'])+')','Pasadas / ciclos: '+str(m['passes'])+' · '+m['pass_kind']]
   if m.get('original_depth'):lines.append('Unidad original: '+m['original_depth'])
  else:lines.append('Sin profundidad numérica transcrita; consulta el estudio original.')
  labels={'speed':'Velocidad publicada (mm/s)','power':'Potencia publicada (%)','frequency':'Frecuencia publicada (kHz)','interval':'Intervalo publicado (mm)','focus_mm':'Enfoque anotado (mm)','angle':'Ángulo / relleno','cleanup':'Limpieza','frequency_original':'Control de frecuencia original','depth_control_original':'Control de profundidad original','resolution_original':'Resolución original','focus_description':'Enfoque','strategy':'Estrategia','passes_tested':'Pasadas ensayadas','pulse_overlap_percent':'Solapamiento de pulsos (%)','measurement_method':'Método de medición'}
  lines+=['','Ajustes publicados (valores ausentes = desconocidos):']
  lines += [labels.get(k,k)+': '+str(v) for k,v in r['parameters'].items()]
  lines+=['','Límites:']+['• '+x for x in r['limitations']]+['','No hay curva apta para usar en tu equipo. Preparar mi calibración sólo copia nombre y material: conserva tu pluma y requiere nuevas mediciones propias.','','Búsqueda: '+', '.join(LANGUAGES.get(x,x) for x in self.catalog['languages_searched'])+'. '+self.catalog['coverage']]
  self.details.setPlainText('\n'.join(lines))

 def open_source(self):
  r=self.current()
  if r:QDesktopServices.openUrl(QUrl(r['source_url']))
 def make_draft(self):
  if self.current():self.selected_report=self.current();self.accept()
