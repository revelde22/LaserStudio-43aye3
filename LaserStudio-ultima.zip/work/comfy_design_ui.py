import json,os,subprocess,sys,uuid
from pathlib import Path
from PySide6.QtCore import QThread,Signal,Qt,QTimer
from PySide6.QtGui import QPixmap,QTransform,QAction
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QHBoxLayout,QPlainTextEdit,QComboBox,
    QDoubleSpinBox,QSpinBox,QCheckBox,QPushButton,QLabel,QFileDialog,QMessageBox,QProgressBar,QLineEdit,QWidget,QScrollArea)
from comfy_design_client import available_models,workflow,generate,upload_image,prepare_artwork,DEFAULT_MODEL,reload_endpoint
BASE=Path(__file__).resolve().parent

class DesignWorker(QThread):
    status=Signal(str);result=Signal(str);failed=Signal(str)
    def __init__(self,options,parent=None):super().__init__(parent);self.options=options
    def run(self):
        try:
            options=dict(self.options);reference=options.pop('reference');circular=options.pop('circular');border=options.pop('border',True)
            width_mm=options.pop('width_mm');height_mm=options.pop('height_mm')
            original_prompt=options['prompt']
            language=options.pop('language','es')
            if language=='es':
                from prompt_spanish import translate_prompt
                options['prompt']=translate_prompt(original_prompt,self.status.emit,self.isInterruptionRequested)
            if self.isInterruptionRequested():raise RuntimeError('Generación cancelada.')
            models=available_models()
            if options['model'] not in models:raise RuntimeError('El modelo seleccionado ya no está disponible. Pulsa Conectar / comprobar.')
            if reference:self.status.emit('Subiendo referencia local…');reference=upload_image(reference)
            if circular:height_mm=width_mm
            ratio=width_mm/height_mm
            pixels=self.options.get('pixels',768) if options['model']==DEFAULT_MODEL else 1024 if 'sdxl' in options['model'].lower() else 512
            options.pop('pixels',None)
            width=pixels if ratio>=1 else max(64,round(pixels*ratio/64)*64)
            height=pixels if ratio<=1 else max(64,round(pixels/ratio/64)*64)
            data=generate(workflow(**options,width=width,height=height,reference=reference,circular=circular),self.status.emit,self.isInterruptionRequested)
            out=BASE/'AI_DESIGNS';out.mkdir(exist_ok=True)
            path=out/f'design_{uuid.uuid4().hex}.png'
            prepare_artwork(data,path,options['style'],width_mm,height_mm,circular,border)
            path.with_suffix('.json').write_text(json.dumps({'prompt_original':original_prompt,'language':language,'prompt_model':options['prompt'],'model':options['model'],'steps':options['steps'],'width_px':width,'height_px':height,'style':options['style'],'strength':None if options['model']==DEFAULT_MODEL else options['strength'],'reference_original':self.options.get('reference'),'width_mm':width_mm,'height_mm':height_mm,'circular':circular,'border':border},ensure_ascii=False,indent=2),encoding='utf-8')
            self.result.emit(str(path))
        except Exception as e:self.failed.emit(str(e))

def stop_owned_server():
    config=BASE/'AI_RUNTIME/comfy_config.json'
    try:
        saved=json.loads(config.read_text(encoding='utf-8'))
        if saved.get('owner')!=os.getpid():return
        stop=BASE/'AI_RUNTIME'/saved['stop_file']
        if stop.parent!=BASE/'AI_RUNTIME':return
        stop.touch()
    except (OSError,ValueError,KeyError):pass

class SetupWorker(QThread):
    status=Signal(str);models=Signal(list);failed=Signal(str)
    def __init__(self,parent=None):super().__init__(parent);self.process=None
    def stop(self):
        self.requestInterruption()
        process=self.process
        if process and process.poll() is None:
            if os.name=='nt':
                subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                               creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            else:process.terminate()
    def run(self):
        try:
            if self.isInterruptionRequested():return
            self.status.emit('Preparando IA en work/AI_RUNTIME…')
            self.process=subprocess.Popen([sys.executable,'-u',str(BASE/'comfy_setup.py'),'--comfy-only','--owner',str(os.getpid())],
                cwd=str(BASE),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',
                env={**os.environ,'PYTHONIOENCODING':'utf-8'},creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            for line in self.process.stdout:
                if self.isInterruptionRequested():self.stop();break
                if line.strip():self.status.emit(line.strip())
            code=self.process.wait()
            if self.isInterruptionRequested():return
            if code:raise RuntimeError(f'Preparación interrumpida o fallida (código {code}). Revisa el registro y pulsa Conectar / instalar para reintentar.')
            reload_endpoint();models=available_models()
            if DEFAULT_MODEL not in models:raise RuntimeError('El servidor arrancó pero no detecta '+DEFAULT_MODEL+'. Reintenta la preparación.')
            self.models.emit(models)
        except Exception as e:
            if not self.isInterruptionRequested():self.failed.emit(str(e)+'\nConsulta COMFY_SETUP.log y COMFY_SERVER.log.')

class DesignDialog(QDialog):
    def __init__(self,main):
        super().__init__(main);self.main=main;self.worker=None;self.setup=None;self.result_path=None;self.reference=None;self.model_manager=None;self.local_models=[]
        self.setWindowTitle('Crear diseño con IA · Local / OpenAI');self.resize(800,880)
        layout=QVBoxLayout(self);form=QFormLayout();self.form=form
        body=QWidget();body.setLayout(form);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(body);layout.addWidget(scroll,1)
        self.provider=QComboBox();self.provider.addItem('Local · FLUX.2 Klein / ComfyUI','local');self.provider.addItem('OpenAI · API en Internet','openai');form.addRow('Proveedor de IA',self.provider)
        self.api_panel=QWidget();api_form=QFormLayout(self.api_panel)
        self.api_key=QLineEdit(os.environ.get('OPENAI_API_KEY',''));self.api_key.setEchoMode(QLineEdit.EchoMode.Password);self.api_key.setPlaceholderText('Clave API · cifrada para este usuario de Windows');api_form.addRow('Clave OpenAI',self.api_key)
        self.key_status=QLabel();self.key_status.setWordWrap(True);api_form.addRow(self.key_status)
        forget=QPushButton('Olvidar clave guardada');forget.clicked.connect(self.forget_api_key);api_form.addRow(forget)
        from openai_credentials import load_key
        try:
            stored=load_key()
            if stored:self.api_key.setText(stored);self.key_status.setText('Clave guardada con cifrado Windows para este usuario.')
        except Exception:self.key_status.setText('No se pudo leer la clave guardada. Vuelve a introducirla.')
        self.api_key.editingFinished.connect(self.store_api_key)
        from openai_image_client import MODELS
        self.api_model=QComboBox();self.api_model.addItems(MODELS);api_form.addRow('Modelo OpenAI',self.api_model)
        self.api_quality=QComboBox();self.api_quality.addItem('Borrador · baja','low');self.api_quality.addItem('Media','medium');self.api_quality.addItem('Alta','high');self.api_quality.setCurrentIndex(1);api_form.addRow('Calidad OpenAI',self.api_quality)
        self.api_size=QComboBox();self.api_size.addItem('Automático según formato físico','auto');self.api_size.addItems(['1024x1024','1536x1024','1024x1536']);api_form.addRow('Tamaño OpenAI (px)',self.api_size)
        disclosure=QLabel('Al pulsar Generar se envían la descripción y la referencia a OpenAI. La API tiene coste. La clave se guarda cifrada con Windows DPAPI para tu usuario. Cancelar detiene la espera local; una solicitud ya enviada puede continuar y facturarse.');disclosure.setWordWrap(True);api_form.addRow(disclosure)
        links=QLabel('<a href="https://platform.openai.com/api-keys">Crear / gestionar clave API</a> · <a href="https://platform.openai.com/settings/organization/billing/overview">Facturación API</a>');links.setOpenExternalLinks(True);api_form.addRow(links);form.addRow(self.api_panel);self.api_panel.hide()
        self.prompt=QPlainTextEdit();self.prompt.setPlaceholderText('Describe el diseño. Ejemplo: Virgen del Pilar centrada, líneas negras y fondo blanco.');self.prompt.setMaximumHeight(110)
        form.addRow('Descripción',self.prompt)
        self.language=QComboBox();self.language.addItem('Español · traducción local automática','es');self.language.addItem('Inglés · sin traducción','en');form.addRow('Idioma del prompt',self.language)
        self.style=QComboBox();self.style.addItems(['Blanco y negro para vectorizar','Escala de grises']);form.addRow('Acabado',self.style)
        self.model=QComboBox();self.model.addItem('Preparando FLUX.2 Klein 4B FP8…');self.model.setEnabled(False);form.addRow('Modelo',self.model)
        self.width=QDoubleSpinBox();self.height=QDoubleSpinBox()
        for field in (self.width,self.height):field.setRange(1,1000);field.setDecimals(2);field.setSuffix(' mm');field.setValue(35)
        form.addRow('Ancho',self.width);form.addRow('Alto',self.height)
        self.circular=QCheckBox('Redondo: diámetro = ancho');self.circular.toggled.connect(self.sync_circle)
        self.width.valueChanged.connect(lambda:self.sync_circle(self.circular.isChecked()));form.addRow(self.circular)
        self.circle_border=QCheckBox('Añadir borde circular');self.circle_border.setChecked(True);self.circle_border.setEnabled(False);form.addRow(self.circle_border)
        self.steps=QSpinBox();self.steps.setRange(1,100);self.steps.setValue(4);form.addRow('Pasos de generación',self.steps)
        self.pixels=QComboBox();self.pixels.addItem('768 px · perfil 8 GB',768);self.pixels.addItem('512 px · menor memoria',512);form.addRow('Resolución IA',self.pixels)
        self.model.currentTextChanged.connect(self.sync_model)
        self.strength=QDoubleSpinBox();self.strength.setRange(.05,1);self.strength.setSingleStep(.05);self.strength.setValue(.65);form.addRow('Cambio de la referencia (0–1)',self.strength)
        row=QHBoxLayout();layout.addLayout(row)
        self.connect_btn=QPushButton('Conectar / instalar lo que falte');self.connect_btn.clicked.connect(self.connect_comfy);row.addWidget(self.connect_btn)
        self.models_btn=models_btn=QPushButton('Descargar otros modelos…');models_btn.clicked.connect(self.open_models);row.addWidget(models_btn)
        self.ref_btn=QPushButton('Imagen de referencia…');self.ref_btn.clicked.connect(self.pick_reference);row.addWidget(self.ref_btn)
        clear=QPushButton('Quitar referencia');clear.clicked.connect(self.clear_reference);row.addWidget(clear);self.clear_ref_btn=clear
        self.reference_label=QLabel('Sin referencia: generar desde texto');layout.addWidget(self.reference_label)
        self.preview=QLabel('Vista previa');self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter);self.preview.setMinimumHeight(130);self.preview.setMaximumHeight(180);layout.addWidget(self.preview)
        self.status=QLabel('OpenAI disponible con tu clave; ComfyUI se conecta o instala sólo cuando lo elijas.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.progress=QProgressBar();self.progress.setRange(0,0);self.progress.hide();layout.addWidget(self.progress)
        row=QHBoxLayout();layout.addLayout(row)
        self.generate_btn=QPushButton('Generar diseño');self.generate_btn.setEnabled(False);self.generate_btn.clicked.connect(self.start_generation);row.addWidget(self.generate_btn)
        self.cancel_btn=QPushButton('Cancelar IA');self.cancel_btn.setEnabled(False);self.cancel_btn.clicked.connect(self.cancel_generation);row.addWidget(self.cancel_btn)
        self.import_btn=QPushButton('Importar al lienzo');self.import_btn.setEnabled(False);self.import_btn.clicked.connect(self.import_design);row.addWidget(self.import_btn)
        note=QLabel('B/N produce una imagen lista para la opción Vectorizar imagen. Grises produce tonos para grabado; no es un mapa de profundidad calibrado. Para letras exactas, añade el texto con el editor.');note.setWordWrap(True);layout.addWidget(note)
        self.ready=False
        self.details=QPlainTextEdit();self.details.setReadOnly(True);self.details.setMaximumHeight(85);self.details.setPlaceholderText("Registro de preparación y conexión");layout.addWidget(self.details)
        try:saved=json.loads((BASE/'ai_provider_settings.json').read_text(encoding='utf-8'))
        except (OSError,ValueError):saved={}
        if saved.get('model') in MODELS:self.api_model.setCurrentText(saved['model'])
        quality_index=self.api_quality.findData(saved.get('quality','medium'));self.api_quality.setCurrentIndex(max(0,quality_index))
        if saved.get('size') in ('auto','1024x1024','1536x1024','1024x1536'):self.api_size.setCurrentText('Automático según formato físico' if saved['size']=='auto' else saved['size'])
        self.provider.currentIndexChanged.connect(self.provider_changed)
        self.api_key.textChanged.connect(self.api_key_changed)
        for control in (self.api_model,self.api_quality,self.api_size):control.currentIndexChanged.connect(self.save_api_preferences)
        if saved.get('provider','openai')=='openai':self.provider.setCurrentIndex(1)
        else:self.provider_changed()
    def store_api_key(self):
        if not self.api_key.text().strip():return
        from openai_credentials import save_key
        try:save_key(self.api_key.text());self.key_status.setText('Clave guardada con cifrado Windows para este usuario.')
        except Exception as exc:self.key_status.setText(str(exc))
    def forget_api_key(self):
        from openai_credentials import forget_key
        try:forget_key();self.api_key.clear();self.key_status.setText('Clave eliminada del almacenamiento y de esta sesión.')
        except OSError:self.key_status.setText('No se pudo eliminar la clave guardada.')
    def cloud(self):return self.provider.currentData()=='openai'
    def save_api_preferences(self):
        settings=dict(provider=self.provider.currentData(),model=self.api_model.currentText(),quality=self.api_quality.currentData(),size=self.api_size.currentData() or self.api_size.currentText())
        try:
            path=BASE/'ai_provider_settings.json';temp=path.with_suffix('.tmp');temp.write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)
        except OSError:pass
    def api_key_changed(self):
        if self.cloud() and not (self.worker and self.worker.isRunning()):self.generate_btn.setEnabled(bool(self.api_key.text().strip()))
    def provider_changed(self):
        cloud=self.cloud();self.api_panel.setVisible(cloud)
        for control in (self.model,self.steps,self.pixels,self.strength,self.language):self.form.setRowVisible(control,not cloud)
        self.connect_btn.setVisible(not cloud);self.models_btn.setVisible(not cloud)
        if cloud:
            if self.setup and self.setup.isRunning():self.setup.stop()
            if not (self.worker and self.worker.isRunning()):self.progress.hide();self.generate_btn.setEnabled(bool(self.api_key.text().strip()));self.cancel_btn.setEnabled(False)
            self.status.setText('OpenAI seleccionado. Introduce tu clave API y genera; no necesita ComfyUI.')
        else:
            if self.local_models:self.set_models(self.local_models)
            self.generate_btn.setEnabled(self.ready);self.status.setText('IA local disponible.' if self.ready else 'Pulsa Conectar / instalar para preparar la IA local.')
        self.save_api_preferences()
    def open_models(self):
        if any(w and w.isRunning() for w in (self.setup,self.worker)):
            self.status.setText('Espera a que termine la instalación o generación antes de descargar modelos.');return
        from model_manager_ui import ModelManagerDialog
        if self.model_manager is None:
            self.model_manager=ModelManagerDialog(self);self.model_manager.completed.connect(self.refresh_models)
        self.model_manager.show();self.model_manager.raise_()
    def refresh_models(self):
        try:self.set_models(available_models())
        except Exception:self.status.setText('Modelos guardados. Pulsa Conectar / instalar para usarlos.')
    def sync_circle(self,checked):
        self.height.setEnabled(not checked);self.circle_border.setEnabled(checked)
        if checked:self.height.setValue(self.width.value())
    def sync_model(self,model):
        if self.cloud():return
        klein=model==DEFAULT_MODEL
        self.pixels.setEnabled(klein);self.strength.setEnabled(not klein)
        self.strength.setToolTip('Klein edita por prompt y referencia; este control se usa con SDXL / SD1.5.')
        self.steps.setValue(4 if klein else 28 if 'sdxl' in model.lower() else 24)
    def set_models(self,models):
        self.local_models=list(models);self.ready=bool(models)
        if self.cloud():return
        self.ready=bool(models);self.model.setEnabled(bool(models));self.model.clear();self.model.addItems(models)
        if DEFAULT_MODEL in models:self.model.setCurrentText(DEFAULT_MODEL)
        self.generate_btn.setEnabled(bool(models));self.status.setText('IA conectada · modelo disponible.' if models else 'No hay checkpoints compatibles.')
    def connect_comfy(self):
        if self.cloud():return
        if self.model_manager and self.model_manager.running():return
        if self.setup and self.setup.isRunning():return
        self.ready=False;self.generate_btn.setEnabled(False);self.model.setEnabled(False);self.model.clear();self.model.addItem('Preparando modelo…')
        self.setup=SetupWorker(self);self.connect_btn.setEnabled(False);self.progress.show()
        self.setup.status.connect(self.local_setup_message);self.setup.models.connect(self.set_models);self.setup.failed.connect(self.error)
        self.setup.status.connect(lambda message:self.main.statusBar().showMessage('IA · '+message))
        self.setup.models.connect(lambda models:self.main.statusBar().showMessage('IA lista · '+DEFAULT_MODEL))
        self.setup.failed.connect(lambda message:self.main.statusBar().showMessage('IA: '+message.splitlines()[0]))
        self.cancel_btn.setEnabled(True)
        self.setup.finished.connect(self.setup_finished);self.setup.start()
    def setup_finished(self):
        if self.cloud():
            if not (self.worker and self.worker.isRunning()):self.progress.hide();self.cancel_btn.setEnabled(False);self.generate_btn.setEnabled(bool(self.api_key.text().strip()))
            self.connect_btn.setEnabled(True);return
        self.connect_btn.setEnabled(True);self.progress.hide();self.generate_btn.setEnabled(self.ready);self.cancel_btn.setEnabled(False)
        if not self.ready:self.model.clear();self.model.addItem('Modelo no disponible · reintenta la conexión')
    def local_setup_message(self,message):
        if not self.cloud():self.setup_message(message)
    def setup_message(self,message):
        self.status.setText(message);self.details.appendPlainText(message)
    def pick_reference(self):
        path,_=QFileDialog.getOpenFileName(self,'Imagen de referencia','','Imagen (*.png *.jpg *.jpeg *.webp *.bmp)')
        if path:self.reference=path;self.reference_label.setText(Path(path).name)
    def clear_reference(self):self.reference=None;self.reference_label.setText('Sin referencia: generar desde texto')
    def start_generation(self):
        if self.cloud():self.store_api_key()
        if self.model_manager and self.model_manager.running():return
        if not self.cloud() and not self.ready:
            self.connect_comfy();return
        if self.worker and self.worker.isRunning():return
        if not self.prompt.toPlainText().strip():return QMessageBox.information(self,'Diseño','Escribe una descripción.')
        options=dict(prompt=self.prompt.toPlainText().strip(),language=self.language.currentData(),style=self.style.currentText(),model=self.model.currentText(),
                     steps=self.steps.value(),pixels=self.pixels.currentData(),strength=self.strength.value(),reference=self.reference,
                     width_mm=self.width.value(),height_mm=self.height.value(),circular=self.circular.isChecked(),border=self.circle_border.isChecked())
        if self.cloud():
            if not self.api_key.text().strip():return QMessageBox.information(self,'OpenAI','Introduce una clave API de OpenAI.')
            size=self.api_size.currentData() or self.api_size.currentText()
            if size=='auto':
                ratio=1 if options['circular'] else options['width_mm']/options['height_mm']
                size='1024x1024' if .8<=ratio<=1.25 else '1536x1024' if ratio>1 else '1024x1536'
            options.update(model=self.api_model.currentText(),quality=self.api_quality.currentData(),api_size=size)
        self.result_dimensions=(options['width_mm'],options['width_mm'] if options['circular'] else options['height_mm']);self.result_style=options['style']
        self.result_path=None;self.import_btn.setEnabled(False);self.generate_btn.setEnabled(False);self.cancel_btn.setEnabled(True)
        self.connect_btn.setEnabled(False);self.progress.show()
        if self.cloud():
            from openai_image_worker import OpenAIWorker
            self.worker=OpenAIWorker(options,self.api_key.text().strip(),self)
        else:self.worker=DesignWorker(options,self)
        for control in (self.provider,self.api_key,self.api_model,self.api_quality,self.api_size,self.ref_btn,self.clear_ref_btn,self.import_btn):control.setEnabled(False)
        self.worker.status.connect(self.setup_message);self.worker.result.connect(self.show_result);self.worker.failed.connect(self.error)
        self.worker.finished.connect(self.generation_finished);self.worker.start()
    def generation_finished(self):
        for control in (self.provider,self.api_key,self.api_model,self.api_quality,self.api_size,self.ref_btn,self.clear_ref_btn):control.setEnabled(True)
        self.generate_btn.setEnabled(bool(self.api_key.text().strip()) if self.cloud() else self.ready);self.cancel_btn.setEnabled(False);self.connect_btn.setEnabled(True);self.progress.hide()
    def show_result(self,path):
        self.result_path=path;self.preview.setPixmap(QPixmap(path).scaled(min(500,max(1,self.preview.width())),max(1,min(180,self.preview.height())),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        self.import_btn.setEnabled(True);self.status.setText('Diseño listo. Revisa la imagen antes de importarla.')
    def error(self,message):self.status.setText(message);self.details.appendPlainText(message)
    def cancel_generation(self):
        if self.setup and self.setup.isRunning():self.setup.stop()
        if self.worker and self.worker.isRunning():self.worker.requestInterruption()
        self.status.setText('Cancelando…')
    def import_design(self):
        if not self.result_path:return
        from laser_studio import RasterItem,GItem
        main=self.main
        layer=next((i for i in range(len(main.cuts)) if not any(isinstance(x,(RasterItem,GItem)) and x.layer==i for x in main.scene.items())),None)
        if layer is None:return QMessageBox.information(self,'Capas','No hay una capa libre. Libera una capa antes de importar.')
        item=RasterItem(self.result_path);rect=item.boundingRect();width,height=self.result_dimensions
        item.setScale(1);item.setTransform(QTransform.fromScale(width/rect.width(),height/rect.height()))
        item.image_settings['mode']='Threshold' if self.result_style.startswith('Blanco') else 'Floyd-Steinberg'
        item.image_settings['ai_generated']=True;item.layer=layer
        from g2_native_frame import load_calibration
        field=load_calibration().field_mm
        main.scene.clearSelection();main.scene.addItem(item);item.setPos((field-width)/2,(field-height)/2);item.setSelected(True)
        main.cuts[layer].mode='Image';main.set_layer(layer,assign_selection=False);main.update_cut_row(layer)
        if hasattr(main,'_sync_cut_controls'):main._sync_cut_controls(layer)
        main.changed=True;main.schedule_preview();main.statusBar().showMessage(f'Diseño IA importado · {width:g} × {height:g} mm · C{layer:02d}')
        self.accept()
    def shutdown(self):
        if self.model_manager:self.model_manager.stop()
        if self.setup and self.setup.isRunning():self.setup.stop();self.setup.wait(8000)
        if self.worker and self.worker.isRunning():
            self.worker.requestInterruption()
        stop_owned_server()
        if self.worker and self.worker.isRunning():self.worker.wait(4000)
        return not any(worker and worker.isRunning() for worker in (self.setup,self.worker))
    def reject(self):
        if (self.worker and self.worker.isRunning()) or (self.setup and self.setup.isRunning()):
            self.status.setText('Espera a que termine la instalación o cancela la generación antes de cerrar.');return
        super().reject()

def open_design(main):
    dialog=getattr(main,'_ai_design_dialog',None)
    if dialog is None:dialog=DesignDialog(main);main._ai_design_dialog=dialog
    dialog.show();dialog.raise_();dialog.activateWindow()

def install_ai_design(main):
    action=QAction('Crear diseño con IA · Local / OpenAI',main);action.triggered.connect(lambda:open_design(main))
    tools=next((a.menu() for a in main.menuBar().actions() if a.menu() and a.text().replace('&','')=='Tools'),None)
    if tools:tools.addAction(action)
    toolbar=main.addToolBar('Diseños IA');toolbar.addAction(action)
    main._ai_design_dialog=DesignDialog(main)
