import copy,math,os,subprocess,sys,uuid,json,shutil
from pathlib import Path
from PySide6.QtCore import Signal,Qt,QObject,QProcess,QProcessEnvironment,QTimer
from PySide6.QtGui import QPixmap,QTransform,QAction
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QPushButton,QLabel,QFileDialog,
    QComboBox,QCheckBox,QSpinBox,QDoubleSpinBox,QPlainTextEdit,QProgressBar,QMessageBox,QScrollArea,QWidget)
from depth_map_tools import prepare_depth_map
BASE=Path(__file__).resolve().parent

class DepthWorker(QObject):
    status=Signal(str);result=Signal(str);failed=Signal(str);finished=Signal()
    def __init__(self,source,parent=None):
        super().__init__(parent);self.source=source;self.process=QProcess(self)
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.finished.connect(self.complete)
        self.process.errorOccurred.connect(self.error)
        self.buffer='';self.cancelled=False;self.done=False;self.active=False
    def start(self):
        try:
            from comfy_setup import runtime_env,STATE
            output=BASE/'DEPTH_MAPS';output.mkdir(exist_ok=True)
            self.raw=output/f'raw_{uuid.uuid4().hex}.png'
            cuda_python=STATE/'comfy_venv/Scripts/python.exe'
            model=STATE/'models/depth_anything_v2_small'
            ready=cuda_python.exists() and all((model/name).exists() for name in ('config.json','preprocessor_config.json','model.safetensors'))
            python=str(cuda_python) if ready else sys.executable
            if Path(python).name.lower()=='pythonw.exe':python=str(Path(python).with_name('python.exe'))
            args=['-u',str(BASE/'depth_estimate_cli.py'),'--source',self.source,'--output',str(self.raw)]
            if ready:args.append('--run')
            self.status.emit('Iniciando cálculo directo en el entorno CUDA preparado…' if ready else 'Preparando entorno de profundidad…')
            env=QProcessEnvironment()
            for key,value in {**runtime_env(),'PYTHONIOENCODING':'utf-8'}.items():env.insert(key,value)
            self.process.setProcessEnvironment(env);self.process.setWorkingDirectory(str(BASE))
            self.active=True;self.process.start(python,args)
        except Exception as exc:
            self.failed.emit(str(exc));self.finish_once()
    def read_output(self):
        self.buffer+=bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace')
        while '\n' in self.buffer:
            line,self.buffer=self.buffer.split('\n',1)
            if line.strip():self.status.emit(line.strip())
    def finish_once(self):
        if not self.done:self.done=True;self.active=False;self.finished.emit()
    def complete(self,code,*args):
        self.read_output()
        if self.buffer.strip():self.status.emit(self.buffer.strip());self.buffer=''
        if not self.cancelled:
            if code or not self.raw.exists():self.failed.emit('El cálculo falló. Consulta work/DEPTH_INFERENCE.log y el registro del diálogo.')
            else:self.result.emit(str(self.raw))
        self.finish_once()
    def error(self,error):
        if error==QProcess.ProcessError.FailedToStart:
            self.failed.emit('No se pudo iniciar Python: '+self.process.errorString());self.finish_once()
    def isRunning(self):return self.active and not self.done
    def stop(self):
        self.cancelled=True
        if self.process.state()!=QProcess.ProcessState.NotRunning:
            if os.name=='nt':
                subprocess.run(['taskkill','/PID',str(self.process.processId()),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            self.process.kill()
    def wait(self,milliseconds):return self.process.waitForFinished(milliseconds)

class DepthMapDialog(QDialog):
    def __init__(self,main):
        super().__init__(main);self.main=main;self.worker=None;self.source=None;self.raw=None;self.processed=None;self.snapshot=None;self.pending_region_mask=None;self.pending_region_config=None
        self.preview_worker=None;self.preview_workers=[];self.preview_revision=0
        self.preview_timer=QTimer(self);self.preview_timer.setSingleShot(True);self.preview_timer.timeout.connect(self.start_preview)
        self.setWindowTitle('Imagen → mapa de profundidad IA → tallado · RELIEVE 8 · VOLUMEN 3D Y STL');self.resize(820,760)
        layout=QVBoxLayout(self);row=QHBoxLayout();layout.addLayout(row)
        self.selected_btn=QPushButton('Usar imagen seleccionada');self.selected_btn.clicked.connect(self.use_selected);row.addWidget(self.selected_btn)
        self.file_btn=QPushButton('Abrir imagen…');self.file_btn.clicked.connect(self.open_file);row.addWidget(self.file_btn)
        self.source_label=QLabel('Selecciona una imagen o abre un archivo.');self.source_label.setWordWrap(True);layout.addWidget(self.source_label)
        self.device_label=QLabel('Dispositivo IA: pendiente de comprobar al generar');self.device_label.setWordWrap(True);layout.addWidget(self.device_label)
        self.device_label.setToolTip('Archivo cargado: '+str(Path(__file__).resolve()))
        row=QHBoxLayout();layout.addLayout(row,1)
        self.original_preview=QLabel('Original');self.map_preview=QLabel('Mapa de profundidad')
        for preview in (self.original_preview,self.map_preview):preview.setAlignment(Qt.AlignmentFlag.AlignCenter);preview.setMinimumSize(300,200);row.addWidget(preview)
        form_widget=QWidget();form=QFormLayout(form_widget)
        form_scroll=QScrollArea();form_scroll.setWidgetResizable(True);form_scroll.setWidget(form_widget)
        form_scroll.setMinimumHeight(180);form_scroll.setMaximumHeight(420);layout.addWidget(form_scroll)
        self.provider=QComboBox();self.provider.addItem('OpenAI · usa la clave guardada','openai');self.provider.addItem('Local · Depth Anything (opcional)','local');form.addRow('Proveedor del mapa',self.provider)
        configure=QPushButton('Clave, modelo y calidad de OpenAI…');configure.clicked.connect(self.configure_openai);form.addRow(configure)
        cloud_note=QLabel('OpenAI envía la imagen y tiene coste de API. Usa el modelo y calidad de Crear diseño con IA. ComfyUI no se inicia automáticamente.');cloud_note.setWordWrap(True);form.addRow(cloud_note)
        self.correction=QPlainTextEdit();self.correction.setMaximumHeight(65);self.correction.setPlaceholderText('Ej.: redondea las mejillas y la frente; conserva nariz, labios y contornos.');form.addRow('Corrección para ChatGPT',self.correction)
        self.correction_region=QComboBox();self.correction_region.addItem('Todo el mapa',-1)
        from regional_depth import REGIONS
        for i,(name,*_) in enumerate(REGIONS):
            if i:self.correction_region.addItem(name,i)
        form.addRow('Región que puede cambiar',self.correction_region)
        self.correct_btn=QPushButton('Corregir mapa con ChatGPT · 1 solicitud API');self.correct_btn.setEnabled(False);self.correct_btn.clicked.connect(lambda:self.generate(True));form.addRow(self.correct_btn)
        correction_note=QLabel('Corrección opcional con coste API. Se conserva la guía fuera de la región elegida; la máscara se mantiene. Si el límite de un objeto está mal, corrígelo primero con el pincel. Modelo sugerido para edición: Sunburst.');correction_note.setWordWrap(True);form.addRow(correction_note)
        self.profile=QComboBox();self.profile.addItem('Lineal · una muestra (estimación)',None)
        from depth_calibration import load_profiles
        for profile in load_profiles():self.profile.addItem(profile['name']+' · '+profile['material'],profile)
        form.addRow('Curva medida guardada',self.profile)
        manage=QPushButton('Medir / editar calibraciones…');manage.clicked.connect(self.manage_profiles);form.addRow(manage)
        self.profile.currentIndexChanged.connect(self.profile_changed)
        self.regional=QCheckBox('Geometría por regiones · volumen suave y detalle protegido');self.regional.setChecked(True)
        form.addRow('Construcción del relieve',self.regional)
        self.regions_btn=QPushButton('Revisar / pintar regiones y ajustar alturas…');self.regions_btn.clicked.connect(self.edit_regions);form.addRow(self.regions_btn)
        self.region_levels=QSpinBox();self.region_levels.setRange(0,256);self.region_levels.setSpecialValueText('0 · continuo (sin escalones)')
        self.region_levels.setToolTip('Introduce manualmente cualquier número de 1 a 256. 0 genera profundidad continua.')
        self.region_levels.valueChanged.connect(self.refresh_map);form.addRow('Capas de profundidad por región',self.region_levels)
        regional_note=QLabel('OpenAI separa regiones y calcula una guía de volumen (2 imágenes API si no hay máscara guardada). Los grises finales salen de alturas por región. Pelo, cejas y ropa no se hunden por ser oscuros. Con IA local dibuja o importa las regiones primero. Revisa la alineación antes de enviar.');regional_note.setWordWrap(True);form.addRow(regional_note)
        self.planes=QCheckBox('Por planos · sin mezclar los colores de la foto');self.planes.setChecked(True)
        self.plane_levels=QSpinBox();self.plane_levels.setRange(1,256);self.plane_levels.setValue(8)
        form.addRow('Relieve geométrico',self.planes);form.addRow('Niveles de profundidad',self.plane_levels)
        self.planes_note=QLabel('Los planos se calculan del mapa IA, no del brillo de la foto. La IA puede confundir sombras con volumen: revisa el resultado. Cambiar niveles no corrige una geometría mal estimada.');self.planes_note.setWordWrap(True);form.addRow(self.planes_note)
        self.artistic=QCheckBox('Relieve artístico · combinar IA con grises del diseño')
        self.detail_weight=QSpinBox();self.detail_weight.setRange(0,100);self.detail_weight.setSuffix(' %');self.detail_weight.setValue(0);self.detail_weight.setEnabled(False)
        form.addRow('Modo de mapa',self.artistic);form.addRow('Peso de grises originales',self.detail_weight)
        self.artistic_note=QLabel('Para medallones y dibujos: conserva letras y detalles de los grises originales. También incorpora sus sombras; revisa el mapa. No reconstruye geometría exacta.');self.artistic_note.setWordWrap(True);form.addRow(self.artistic_note)
        self.artistic.setEnabled(False)
        self.planes.toggled.connect(self.planes_changed);self.plane_levels.valueChanged.connect(self.refresh_map)
        self.regional.toggled.connect(self.regional_changed)
        self.artistic.toggled.connect(lambda checked:self.detail_weight.setEnabled(checked))
        self.artistic.toggled.connect(self.refresh_map);self.detail_weight.valueChanged.connect(self.refresh_map)
        self.width=QDoubleSpinBox();self.height=QDoubleSpinBox()
        for field in (self.width,self.height):field.setRange(1,1000);field.setDecimals(2);field.setSuffix(' mm');field.setValue(35)
        form.addRow('Ancho',self.width);form.addRow('Alto',self.height)
        self.mm_enabled=QCheckBox('Definir relieve objetivo en milímetros');self.mm_enabled.setChecked(False)
        self.target_mm=QDoubleSpinBox();self.target_mm.setRange(.001,100);self.target_mm.setDecimals(3);self.target_mm.setSuffix(' mm');self.target_mm.setValue(.2)
        self.measured_mm=QDoubleSpinBox();self.measured_mm.setRange(0,100);self.measured_mm.setDecimals(4);self.measured_mm.setSuffix(' mm');self.measured_mm.setValue(0)
        self.calibration_passes=QSpinBox();self.calibration_passes.setRange(1,999);self.calibration_passes.setValue(10)
        for title,control in [('Profundidad en mm',self.mm_enabled),('Objetivo máximo',self.target_mm),('Profundidad medida en muestra',self.measured_mm),('Pasadas de esa muestra',self.calibration_passes)]:form.addRow(title,control)
        self.mm_note=QLabel('Introduce una medida real de tu material para convertir mm a pasadas.');self.mm_note.setWordWrap(True);form.addRow(self.mm_note)
        self.invert=QCheckBox('Invertir relieve');self.white=QCheckBox('Excluir solo el fondo blanco conectado al borde');self.white.setChecked(True)
        self.circle=QCheckBox('Recortar en círculo · diámetro = ancho')
        self.disable_original=QCheckBox('Desactivar salida de la capa original al enviar');self.disable_original.setChecked(True);self.disable_original.setEnabled(False);form.addRow('Original',self.disable_original)
        self.gamma=QDoubleSpinBox();self.gamma.setRange(.1,5);self.gamma.setSingleStep(.1);self.gamma.setValue(1)
        for label,widget in (('Relieve',self.invert),('Fondo',self.white),('Formato',self.circle),('Curva del mapa',self.gamma)):form.addRow(label,widget)
        for control in (self.target_mm,self.measured_mm,self.calibration_passes):control.valueChanged.connect(self.refresh_map)
        self.mm_enabled.toggled.connect(self.refresh_map)
        self.invert.toggled.connect(self.refresh_map);self.white.toggled.connect(self.refresh_map);self.gamma.valueChanged.connect(self.refresh_map)
        self.circle.toggled.connect(self.circle_changed);self.width.valueChanged.connect(lambda:self.circle_changed(self.circle.isChecked()))
        self.progress=QProgressBar();self.progress.setRange(0,0);self.progress.hide();layout.addWidget(self.progress)
        self.status=QLabel('Blanco = sin tallar; negro = máximo de pasadas. La IA estima relieve relativo, no profundidad en mm.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMinimumHeight(70);self.log.setMaximumHeight(100);layout.addWidget(self.log)
        row=QHBoxLayout();layout.addLayout(row)
        self.generate_btn=QPushButton('Generar mapa IA');self.generate_btn.clicked.connect(self.generate);row.addWidget(self.generate_btn)
        self.cancel_btn=QPushButton('Cancelar');self.cancel_btn.setEnabled(False);self.cancel_btn.clicked.connect(self.cancel);row.addWidget(self.cancel_btn)
        self.send_btn=QPushButton('Pasar a tallado…');self.send_btn.setEnabled(False);self.send_btn.clicked.connect(self.send_to_depth);row.addWidget(self.send_btn)
        self.relief_btn=QPushButton('Ver relieve 3D / STL…');self.relief_btn.setEnabled(False);self.relief_btn.clicked.connect(self.show_relief);row.addWidget(self.relief_btn)
        note=QLabel('Blanco = sin tallar; negro = más pasadas. El mapa IA estima relieve relativo y necesita revisión; no expresa profundidad física en milímetros.');note.setWordWrap(True);layout.addWidget(note)
        self.regional_changed(True)
    def planes_changed(self,checked):
        if checked:self.artistic.setChecked(False)
        self.artistic.setEnabled(not checked and not self.regional.isChecked());self.detail_weight.setEnabled(not checked and not self.regional.isChecked() and self.artistic.isChecked())
        self.plane_levels.setEnabled(checked);self.refresh_map()
    def regional_changed(self,checked):
        if checked:
            self.artistic.setChecked(False);self.invert.setChecked(False);self.gamma.setValue(1.)
        for control in (self.planes,self.plane_levels,self.artistic,self.detail_weight,self.invert,self.gamma,self.white):control.setEnabled(not checked)
        self.regions_btn.setEnabled(checked)
        self.region_levels.setEnabled(checked)
        if not checked:self.planes_changed(self.planes.isChecked())
        self.refresh_map()
    def edit_regions(self):
        if self.worker and self.worker.isRunning():return
        if not self.source:return QMessageBox.information(self,'Imagen','Selecciona una imagen primero.')
        self.stop_preview()
        from regional_depth import region_paths
        from regional_depth_ui import RegionalDepthDialog,create_blank_mask
        if not self.raw:
            folder=BASE/'DEPTH_MAPS';folder.mkdir(exist_ok=True);self.raw=str(folder/('raw_manual_'+uuid.uuid4().hex+'.png'))
        mask,_=region_paths(self.raw)
        if not mask.exists():create_blank_mask(self.source,self.raw)
        if RegionalDepthDialog(self.source,self.raw,self).exec()==QDialog.DialogCode.Accepted:
            _,config=region_paths(self.raw)
            settings=json.loads(config.read_text(encoding='utf-8'));self.region_levels.setValue(int(settings.get('levels',0)))
        self.refresh_map()
    def enable_send(self):
        # Reviewing masks is advisory; it must not prevent opening setup.
        self.send_btn.setEnabled(bool(self.processed))
        self.relief_btn.setEnabled(bool(self.processed))
        self.correct_btn.setEnabled(bool(self.raw) and not (self.worker and self.worker.isRunning()))
    def show_relief(self):
        if not self.processed or not self.send_btn.isEnabled():return
        from relief_3d_ui import Relief3DDialog
        Relief3DDialog(getattr(self,'height_path',None) or self.processed,self.width.value(),self.height.value(),self.target_mm.value(),self).exec()
    def set_source(self,path,snapshot=None):
        if self.worker and self.worker.isRunning():return
        self.stop_preview()
        self.correct_btn.setEnabled(False)
        self.source=str(path);self.snapshot=snapshot;self.raw=None;self.processed=None;self.pending_region_mask=None;self.pending_region_config=None;self.send_btn.setEnabled(False);self.map_preview.clear()
        self.disable_original.setEnabled(snapshot is not None)
        self.source_label.setText(Path(path).name)
        self.original_preview.setPixmap(QPixmap(path).scaled(350,250,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        if snapshot:
            self.width.setValue(snapshot['width']);self.height.setValue(snapshot['height'])
            snapshot['display_width']=self.width.value();snapshot['display_height']=self.height.value()
    def use_selected(self):
        from laser_studio import RasterItem,GroupItem
        def images(item):
            if isinstance(item,GroupItem):
                for child in item.members():yield from images(child)
            elif isinstance(item,RasterItem):yield item
        selected=list({id(item):item for root in self.main.selected() for item in images(root)}.values())
        if len(selected)!=1:return QMessageBox.information(self,'Imagen','Selecciona exactamente una imagen.')
        item=selected[0];rect=item.boundingRect();origin=item.mapToScene(rect.topLeft())
        width=math.hypot(*(item.mapToScene(rect.topRight())-origin).toTuple());height=math.hypot(*(item.mapToScene(rect.bottomLeft())-origin).toTuple())
        self._image_original_path=str(item.original_source)
        self._selected_image_settings=dict(item.image_settings)
        self.set_source(item.original_source,dict(transform=QTransform(item.sceneTransform()),rect_width=rect.width(),rect_height=rect.height(),width=width,height=height,layer=item.layer))
        if hasattr(self,'simple_contrast'):
            self.simple_contrast.blockSignals(True)
            self.simple_contrast.setValue(int(item.image_settings.get('contrast',0)))
            self.simple_contrast.blockSignals(False)
            self._rebuild_adjusted_source()
    def _rebuild_adjusted_source(self,*args):
        if not hasattr(self,'simple_contrast') or not getattr(self,'_image_original_path',None):return
        try:
            from laser_image_pipeline import process_array
            from PIL import Image
            import numpy as np
            settings=dict(getattr(self,'_selected_image_settings',{}))
            settings['contrast']=self.simple_contrast.value()
            array=process_array(self._image_original_path,'Grayscale',
                settings.get('brightness',0),settings.get('darkness',0),
                settings.get('contrast',0),settings.get('gamma',1.0),
                settings.get('sharpen',0),settings.get('invert',False))
            cache=BASE/'DEPTH_MAPS';cache.mkdir(exist_ok=True)
            path=cache/('edited_source_'+uuid.uuid4().hex+'.png')
            Image.fromarray(np.asarray(array,dtype=np.uint8)).save(path)
            self.source=str(path)
            self.original_preview.setPixmap(QPixmap(str(path)).scaled(350,250,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
            self.refresh_map()
        except Exception as exc:self.message('No se pudo sincronizar el contraste: '+str(exc))
    def open_file(self):
        path,_=QFileDialog.getOpenFileName(self,'Imagen para mapa de profundidad','','Imagen (*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff)')
        if path:
            self._image_original_path=str(path)
            self._selected_image_settings={}
            self.set_source(path)
            if hasattr(self,'simple_contrast'):
                self.simple_contrast.setValue(0)
    def circle_changed(self,checked):
        self.height.setEnabled(not checked)
        if checked:self.height.setValue(self.width.value())
        self.refresh_map()
    def message(self,message):
        try:
            from datetime import datetime
            with (BASE/'MAPAS_PROFUNDIDAD.log').open('a',encoding='utf-8') as log:log.write(datetime.now().isoformat(timespec='seconds')+' | '+message+'\n')
        except OSError:pass
        self.status.setText(message);self.log.appendPlainText(message)
        if message.startswith('Calculando con GPU:'):self.device_label.setText('Dispositivo IA: '+message)
        elif message.startswith('Calculando con CPU'):self.device_label.setText('Dispositivo IA: CPU · consulta el registro para conocer el motivo')
        elif 'reintentando en CPU' in message or 'alternativa CPU' in message:self.device_label.setText('Dispositivo IA: alternativa CPU · '+message)
        elif message.startswith(('Iniciando cálculo','Cargando','Modelo cargado','Preparando entorno')):self.device_label.setText('Etapa IA: '+message)
        elif message.startswith(('ERROR:','El cálculo falló','No se pudo iniciar')):self.device_label.setText('Error de cálculo: consulta el registro visible debajo')
    def profile_changed(self):
        for control in (self.measured_mm,self.calibration_passes):control.setEnabled(not bool(self.profile.currentData()))
        self.refresh_map()
    def manage_profiles(self):
        from depth_calibration_ui import CalibrationLibraryDialog
        cut=copy.deepcopy(self.main.cuts[self.snapshot['layer'] if self.snapshot else 0])
        dialog=CalibrationLibraryDialog(cut,.05,self)
        if dialog.exec() and dialog.selected_profile:
            profile=dialog.selected_profile;self.profile.addItem(profile['name']+' · '+profile['material'],profile);self.profile.setCurrentIndex(self.profile.count()-1)
    def configure_openai(self):
        dialog=getattr(self.main,'_ai_design_dialog',None)
        if dialog:
            dialog.provider.setCurrentIndex(dialog.provider.findData('openai'));dialog.show();dialog.raise_();dialog.activateWindow()
    def generate(self,refine=False):
        if self.worker and self.worker.isRunning():return
        ai=getattr(self.main,'_ai_design_dialog',None)
        if self.provider.currentData()=='local' and ai and ai.setup and ai.setup.isRunning():
            self.message('El arranque está preparando los modelos. Espera a que termine y vuelve a generar.');return
        if not self.source:return QMessageBox.information(self,'Imagen','Selecciona una imagen o abre un archivo.')
        cloud=self.provider.currentData()=='openai'
        previous_raw=self.raw
        if refine:
            if not cloud:return QMessageBox.information(self,'ChatGPT','Selecciona OpenAI como proveedor para corregir el mapa.')
            if not previous_raw:return
            if not self.correction.toPlainText().strip():return QMessageBox.information(self,'Corrección','Describe qué quieres corregir en el mapa.')
            if self.correction_region.currentData()>=0 and not self.regional.isChecked():return QMessageBox.information(self,'Regiones','Activa Geometría por regiones para corregir solo una región.')
        if cloud and (not ai or not ai.api_key.text().strip()):
            self.message('Introduce la clave en Clave, modelo y calidad de OpenAI.');self.configure_openai();return
        self.device_label.setText('Dispositivo IA: OpenAI en Internet' if cloud else 'Dispositivo IA: comprobando / preparando CUDA…')
        self.pending_region_mask=None;self.pending_region_config=None
        if self.regional.isChecked():
            from regional_depth import region_paths
            if self.raw:
                mask,config=region_paths(self.raw)
                if mask.exists():self.pending_region_mask=str(mask);self.pending_region_config=str(config)
            if not cloud and not self.pending_region_mask:
                self.message('Con IA local primero dibuja o importa regiones en Revisar / pintar regiones.');self.edit_regions();return
        self.stop_preview()
        self.previous_map=(self.raw,self.processed,getattr(self,'height_path',None))
        self.raw=None;self.processed=None;self.send_btn.setEnabled(False);self.progress.show()
        self.regional.setEnabled(False);self.regions_btn.setEnabled(False)
        for button in (self.generate_btn,self.file_btn,self.selected_btn,self.correct_btn,self.correction,self.correction_region):button.setEnabled(False)
        self.cancel_btn.setEnabled(True);self.provider.setEnabled(False)
        if cloud:
            from openai_image_worker import OpenAIWorker
            ai.store_api_key()
            size=ai.api_size.currentData() or ai.api_size.currentText()
            if size=='auto':size='1024x1024' if self.circle.isChecked() or .8<=self.width.value()/self.height.value()<=1.25 else ('1536x1024' if self.width.value()>self.height.value() else '1024x1536')
            options=dict(purpose='depth',geometric_regions=self.regional.isChecked(),region_mask=self.pending_region_mask,region_config=self.pending_region_config,plane_levels=self.plane_levels.value() if self.planes.isChecked() else 0,prompt='Convert this reference into an engraving bas-relief depth map.',reference=self.source,model=ai.api_model.currentText(),quality=ai.api_quality.currentData(),api_size=size)
            if refine:options.update(refine_from=previous_raw,correction=self.correction.toPlainText().strip(),correction_region=self.correction_region.currentData())
            self.worker=OpenAIWorker(options,ai.api_key.text(),self)
        else:self.worker=DepthWorker(self.source,self)
        try:
            self.worker.status.connect(self.message);self.worker.failed.connect(self.message);self.worker.result.connect(self.ready);self.worker.finished.connect(self.worker_finished);self.worker.start()
        except Exception as exc:
            self.message('ERROR: no se pudo iniciar el cálculo: '+str(exc));self.worker_finished()
    def worker_finished(self):
        self.progress.hide();self.cancel_btn.setEnabled(False);self.provider.setEnabled(True);self.regional.setEnabled(True);self.regions_btn.setEnabled(self.regional.isChecked())
        for button in (self.generate_btn,self.file_btn,self.selected_btn):button.setEnabled(True)
        self.correction.setEnabled(True);self.correction_region.setEnabled(True)
        if not self.raw and getattr(self,'previous_map',None):
            self.raw,self.processed,self.height_path=self.previous_map
            if self.raw:self.message('Se conserva el mapa anterior. Puedes revisarlo o repetir la corrección.')
        self.enable_send()
    def ready(self,path):
        self.raw=path
        if self.regional.isChecked():
            from regional_depth import region_paths
            mask,config=region_paths(path)
            if not mask.exists() and self.pending_region_mask:
                shutil.copyfile(self.pending_region_mask,mask)
                if self.pending_region_config and Path(self.pending_region_config).exists():shutil.copyfile(self.pending_region_config,config)
        self.refresh_map()
        self.message('Mapa por regiones preparado. Puedes revisar / pintar regiones o pasar a Preparar tallado para configurar las pasadas.' if self.regional.isChecked() else 'Mapa preparado. Ajusta el relieve y pulsa Enviar a tallado para elegir las pasadas.')
    def stop_preview(self):
        self.preview_timer.stop();self.preview_revision+=1
        self.relief_btn.setEnabled(False)
        if self.preview_worker and self.preview_worker.isRunning():self.preview_worker.stop()
    def refresh_map(self,*args):
        if not self.raw or not self.source:return
        self.stop_preview();self.processed=None;self.send_btn.setEnabled(False)
        self.preview_timer.start(180)
    def start_preview(self):
        if not self.raw or not self.source:return
        from depth_preview_worker import PreviewWorker
        revision=self.preview_revision;regional=self.regional.isChecked()
        output=Path(self.raw).with_name('map_preview_'+uuid.uuid4().hex+'.png')
        options=dict(raw=self.raw,source=self.source,output=str(output),regional=regional,
            region_levels=self.region_levels.value(),
            shadow_detail=getattr(self,'simple_shadow_detail',None).value()/100. if hasattr(self,'simple_shadow_detail') else .75,
            face_levels=self.face_levels.value() if hasattr(self,'face_levels') else 32,
            face_depth_strength=self.face_strength.value() if hasattr(self,'face_strength') else 150,
            invert=self.invert.isChecked() if not regional else False,
            gamma=self.gamma.value() if not regional else 1.,
            remove_white=self.white.isChecked() if not regional else False,
            circular=self.circle.isChecked(),
            detail_weight=self.detail_weight.value()/100 if self.artistic.isChecked() and not regional else 0.,
            plane_levels=self.plane_levels.value() if self.planes.isChecked() and not regional else 0,
            mm_enabled=self.mm_enabled.isChecked(),target_mm=self.target_mm.value(),
            measured_mm=self.measured_mm.value(),calibration_passes=self.calibration_passes.value(),
            profile=self.profile.currentData())
        worker=PreviewWorker(options,self);self.preview_worker=worker;self.preview_workers.append(worker)
        worker.result.connect(lambda result,rev=revision:self.preview_ready(rev,result))
        worker.failed.connect(lambda error,rev=revision:self.preview_failed(rev,error))
        worker.finished.connect(lambda job=worker:self.preview_finished(job))
        self.cancel_btn.setEnabled(True);self.progress.show()
        self.message('Calculando volumen y niveles en segundo plano…');worker.start()
    def preview_finished(self,worker):
        if worker in self.preview_workers:self.preview_workers.remove(worker)
        if self.preview_worker is worker:
            self.preview_worker=None
            if not (self.worker and self.worker.isRunning()):self.cancel_btn.setEnabled(False);self.progress.hide()
        worker.deleteLater()
    def preview_ready(self,revision,result):
        if revision!=self.preview_revision:return
        self.processed=result['processed'];self.calibrated_path=result.get('calibrated_path')
        self.height_path=result.get('height_path',self.processed)
        if result.get('mm_text'):self.mm_note.setText(result['mm_text'])
        self.map_preview.setToolTip(self.calibrated_path or self.processed)
        self.map_preview.setPixmap(QPixmap(self.processed).scaled(350,250,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        self.enable_send()
        levels=self.region_levels.value()
        self.message('Mapa calculado · '+('continuo' if not levels else str(levels)+' niveles por región')+'. Revisa las regiones antes de tallar.')
    def preview_failed(self,revision,error):
        if revision!=self.preview_revision:return
        self.processed=None;self.send_btn.setEnabled(False);self.message('ERROR: '+error)
    def send_to_depth(self):
        if not self.processed:return
        self.enable_send()
        if not self.send_btn.isEnabled():return
        mm_settings=dict(depth_mm_enabled=False,depth_target_mm=self.target_mm.value(),depth_measured_mm=self.measured_mm.value(),depth_calibration_passes=self.calibration_passes.value())
        if self.mm_enabled.isChecked():
            from depth_map_tools import passes_from_mm
            try:
                profile=self.profile.currentData()
                if profile:
                    from depth_calibration import maximum_passes
                    count=maximum_passes(self.target_mm.value(),profile);rate=0
                else:count,rate=passes_from_mm(self.target_mm.value(),self.measured_mm.value(),self.calibration_passes.value())
            except ValueError as exc:
                self.message('Sin calibración válida: se abre tallado con pasadas manuales. '+str(exc))
            else:
                mm_settings.update(depth_mm_enabled=True,depth_passes=count,depth_mm_per_pass=rate)
        if mm_settings['depth_mm_enabled'] and self.profile.currentData():mm_settings['depth_calibration_profile']=copy.deepcopy(self.profile.currentData())
        from laser_studio import RasterItem,GItem
        from deep_engraving_dialog import ImageDepthDialog
        free=next((i for i in range(len(self.main.cuts)) if not any(isinstance(item,(RasterItem,GItem)) and item.layer==i for item in self.main.scene.items())),None)
        if free is None:return QMessageBox.information(self,'Capas','Libera una capa para importar el mapa de profundidad.')
        item=RasterItem(self.processed);rect=item.boundingRect();width=self.width.value();height=self.height.value()
        if self.snapshot:
            if width==self.snapshot['display_width']:width=self.snapshot['width']
            if not self.circle.isChecked() and height==self.snapshot['display_height']:height=self.snapshot['height']
            if self.circle.isChecked():height=width
        item.setScale(1)
        if self.snapshot:
            snap=self.snapshot
            item.setTransform(QTransform.fromScale(snap['rect_width']/rect.width()*width/snap['width'],snap['rect_height']/rect.height()*height/snap['height'])*snap['transform'])
        else:
            from g2_native_frame import load_calibration
            field=load_calibration().field_mm
            item.setTransform(QTransform.fromScale(width/rect.width(),height/rect.height()));item.setPos((field-width)/2,(field-height)/2)
        item.layer=free
        item.image_settings.update(mode='Grayscale',brightness=0,darkness=0,contrast=0,gamma=1.,sharpen=0,invert=False,depth_enabled=True,depth_estimated=True,depth_pass_mode='assisted',depth_interval=.05,depth_cleanup=False)
        item.image_settings.update(mm_settings)
        item.image_settings['depth_map_method']='regional_bounded_geometry' if self.regional.isChecked() else 'relative_ai_planes' if self.planes.isChecked() else ('artistic_mix' if self.artistic.isChecked() else 'relative_ai')
        item.image_settings['depth_plane_levels']=self.plane_levels.value() if self.planes.isChecked() and not self.regional.isChecked() else 0
        if self.regional.isChecked():
            from regional_depth import region_paths
            mask,config=region_paths(self.raw)
            item.image_settings['depth_region_settings']=json.loads(config.read_text(encoding='utf-8'))
            item.image_settings['depth_region_mask']=str(mask)
        item.image_settings['depth_original_gray_weight']=self.detail_weight.value()/100 if self.artistic.isChecked() else 0.
        cut=copy.deepcopy(self.main.cuts[free])
        if self.snapshot:
            # Copy the source pen so a proposal can use its material recipe.
            for key,value in vars(self.main.cuts[self.snapshot['layer']]).items():
                if key not in ('i','name','sublayers'):setattr(cut,key,value)
        settings=ImageDepthDialog(item,cut,self.main)
        # The generator is finished. Review engraving on the main window instead.
        self.hide()
        if settings.exec()!=QDialog.DialogCode.Accepted:
            self.show();self.raise_();self.activateWindow();return
        settings.apply_to(item)
        target=self.main.cuts[free]
        for key,value in vars(cut).items():
            if key not in ('i','name'):setattr(target,key,value)
        cut=target
        if self.snapshot and self.disable_original.isChecked():
            self.main.cuts[self.snapshot['layer']].output=False;self.main.update_cut_row(self.snapshot['layer'])
        self.main.scene.clearSelection();self.main.scene.addItem(item);item.setSelected(True)
        cut.mode='Image';cut.output=True;self.main.set_layer(free,assign_selection=False);self.main.update_cut_row(free)
        if hasattr(self.main,'_sync_cut_controls'):self.main._sync_cut_controls(free)
        self.main.changed=True;self.main.schedule_preview()
        self.main.statusBar().showMessage(f'Mapa IA listo para tallado · C{free:02d} · máximo {item.image_settings["depth_passes"]} pasadas')
        self.accept()
    def cancel(self):
        self.stop_preview()
        if self.worker and self.worker.isRunning():self.worker.stop();self.message('Cancelando el mapa…')
    def shutdown(self):
        self.stop_preview()
        for job in list(self.preview_workers):
            job.stop();job.wait(1000)
        if self.worker and self.worker.isRunning():self.worker.stop();self.worker.wait(8000)
        return not (self.worker and self.worker.isRunning())
    def reject(self):
        if not self.shutdown():return
        super().reject()



class SimpleDepthMapDialog(DepthMapDialog):
    """Four-control front-end; use the existing image and engraving pipeline."""
    def __init__(self, main):
        super().__init__(main)
        self.setWindowTitle('43AYE3 · Tallado 3D sencillo')
        self.resize(850, 625)
        # Only the simplified controls are displayed. Existing options stay in
        # memory for compatibility with the preview, output and job pipeline.
        self.regional.setChecked(True)
        self.planes.setChecked(False)
        self.region_levels.setValue(16)
        self.mm_enabled.setChecked(False)  # physical mm need material calibration
        self.artistic.setChecked(False)
        self.circle.setChecked(False)
        self.form_scroll = next((w for w in self.findChildren(QScrollArea)
                                 if w.widget() and w.widget().layout() and
                                 isinstance(w.widget().layout(), QFormLayout)), None)
        if self.form_scroll:
            self.form_scroll.hide()
        # Add a compact control strip directly above the picture previews.
        main_layout = self.layout()
        bar = QWidget(self)
        short = QFormLayout(bar)
        short.setContentsMargins(8, 5, 8, 5)
        picture = QLabel('Imagen: usa «Abrir imagen» o «Usar imagen seleccionada»')
        picture.setWordWrap(True)
        short.addRow('1 · Imagen', picture)
        self.simple_levels = QSpinBox()
        self.simple_levels.setRange(2, 256)
        self.simple_levels.setValue(16)
        self.simple_levels.valueChanged.connect(self.region_levels.setValue)
        self.region_levels.valueChanged.connect(self.simple_levels.setValue)
        short.addRow('2 · Capas de profundidad', self.simple_levels)
        self.simple_depth = QDoubleSpinBox()
        self.simple_depth.setRange(.001, 10)
        self.simple_depth.setDecimals(3)
        self.simple_depth.setSuffix(' mm')
        self.simple_depth.setValue(.2)
        self.simple_depth.valueChanged.connect(self.target_mm.setValue)
        short.addRow('3 · Profundidad de referencia', self.simple_depth)
        self.simple_contrast=QSpinBox();self.simple_contrast.setRange(-100,300)
        self.simple_contrast.setSuffix(' %');self.simple_contrast.valueChanged.connect(self._rebuild_adjusted_source)
        short.addRow('Contraste (sincronizado)',self.simple_contrast)
        self.simple_shadow_detail=QSpinBox();self.simple_shadow_detail.setRange(0,300)
        self.simple_shadow_detail.setValue(80);self.simple_shadow_detail.setSuffix(' %')
        self.simple_shadow_detail.valueChanged.connect(self.refresh_map)
        short.addRow('Definición y sombras',self.simple_shadow_detail)
        self.face_levels=QSpinBox();self.face_levels.setRange(2,256);self.face_levels.setValue(32)
        self.face_levels.valueChanged.connect(self.refresh_map)
        short.addRow('Niveles del rostro',self.face_levels)
        self.face_strength=QSpinBox();self.face_strength.setRange(0,300);self.face_strength.setValue(150)
        self.face_strength.setSuffix(' %');self.face_strength.valueChanged.connect(self.refresh_map)
        short.addRow('Relieve del rostro',self.face_strength)
        self.relief_btn.setText('4 · Ver 3D')
        self.generate_btn.setText('Generar relieve')
        self.send_btn.setText('Pasar a tallado')
        self.status.setText('Vista de tallado sincronizada: contraste y sombras recalculan el mapa sin cambiar el orden de planos. Tras editar, revisa el resultado antes de tallar.')
        self.log.hide()
        self.device_label.hide()
        # Locate the image preview row and insert the new controls above it.
        main_layout.insertWidget(2, bar)
        for widget in self.findChildren(QLabel):
            if widget is picture or widget in (self.status, self.source_label,
                                              self.original_preview, self.map_preview):
                continue
            if widget.parentWidget() is self:
                widget.hide()
        self._compact_bar = bar


def open_depth_map(main):
    dialog=getattr(main,'_depth_map_dialog',None)
    if dialog is None:dialog=SimpleDepthMapDialog(main);main._depth_map_dialog=dialog
    dialog.show();dialog.raise_();dialog.activateWindow()
    if main.selected():dialog.use_selected()
    from depth_calibration import load_profiles
    selected=dialog.profile.currentData();selected_id=selected.get('id') if selected else None
    dialog.profile.blockSignals(True);dialog.profile.clear();dialog.profile.addItem('Lineal · una muestra (estimación)',None)
    for profile in load_profiles():
        dialog.profile.addItem(profile['name']+' · '+profile['material'],profile)
        if profile.get('id')==selected_id:dialog.profile.setCurrentIndex(dialog.profile.count()-1)
    dialog.profile.blockSignals(False);dialog.refresh_map()
    dialog.show();dialog.raise_();dialog.activateWindow()

def install_depth_map(main):
    action=QAction('Crear mapa de profundidad IA desde imagen',main);action.triggered.connect(lambda:open_depth_map(main))
    tools=next((action.menu() for action in main.menuBar().actions() if action.menu() and action.text().replace('&','')=='Tools'),None)
    if tools:tools.addAction(action)
    main.addToolBar('Mapa de profundidad').addAction(action)
