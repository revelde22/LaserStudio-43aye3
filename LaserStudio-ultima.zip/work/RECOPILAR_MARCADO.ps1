﻿$ErrorActionPreference = 'Stop'
$work = $PSScriptRoot
$destination = Join-Path (Split-Path $work -Parent) 'DIAGNOSTICO_MARCADO.zip'
$temporary = Join-Path $work ('diagnostico_marcado_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temporary | Out-Null
try {
    foreach ($name in @('RESULTADO_MARCADO_VECTORIAL.txt','MARCADO_UI_DIAGNOSTICO.txt','ARRANQUE_43AYE3.log','43AYE3_SDK_BUILD.log','RESULTADO_UNIFICADO_G2_ORZX.txt','RESULTADO_DEVICE_STATE_READONLY.txt','RESULTADO_ENCUADRE_UI.txt','COMFY_SETUP.log','COMFY_SERVER.log','DEPTH_INFERENCE.log')) {
        $source = Join-Path $work $name
        if (Test-Path $source) { Copy-Item -LiteralPath $source -Destination $temporary }
    }
    $native = Join-Path $work 'BSL_SDK\43AYE3_G2_SDK\43AYE3_SDK_SELFTEST.exe'
    $report = @()
    $report += ('Work: ' + $work)
    $report += 'Revision: RECUPERACION_SDXL_ESPANOL_CONTADOR_ETA'
    if (Test-Path $native) {
        $hash = Get-FileHash -LiteralPath $native -Algorithm SHA256
        $report += 'Native SHA256: ' + $hash.Hash
        $report += 'Native modified: ' + (Get-Item -LiteralPath $native).LastWriteTime.ToString('s')
    } else { $report += 'Native executable: missing' }
    $report | Set-Content -LiteralPath (Join-Path $temporary 'ESTADO.txt') -Encoding UTF8
    Compress-Archive -Path (Join-Path $temporary '*') -DestinationPath $destination -Force
    Write-Host ('Creado: ' + $destination)
    Write-Host 'Adjunta DIAGNOSTICO_MARCADO.zip en la conversacion.'
} finally { Remove-Item -LiteralPath $temporary -Recurse -Force }
