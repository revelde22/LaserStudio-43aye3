import json
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QHBoxLayout,QComboBox,QLineEdit,QDoubleSpinBox,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QCheckBox,QMessageBox,QFileDialog,QAbstractItemView)
from PySide6.QtGui import QAction
from depth_material_tests import generate_coupons,write_record,measured_profile,assert_test_unchanged

class DepthMaterialTestsDialog(QDialog):
 def __init__(self,main):
  super().__init__(main);self.main=main;self.record=None;self.setWindowTitle('Pruebas de tallado por material');self.resize(740,740)
  layout=QVBoxLayout(self);form=QFormLayout();layout.addLayout(form)
  cut=main.cuts[main.active_layer]
  self.material=QComboBox();self.material.setEditable(True);self.material.addItems(['Latón','Acero inoxidable','Aluminio','Cobre','Acero al carbono']);self.material.setCurrentText(getattr(cut,'material','') or 'Latón');form.addRow('Material / aleación / acabado',self.material)
  self.fields={}
  for key,label,value,minimum,maximum in [('speed','Velocidad (mm/s)',cut.speed,.01,100000),('power','Potencia (%)',cut.power,.0001,100),('frequency','Frecuencia (kHz)',cut.frequency,1,4000),('interval','Intervalo (mm)',cut.interval,.0001,10),('side_mm','Lado de cada cuadrado (mm)',6,2,15),('focus_mm','Desenfoque anotado (mm)',0,-100,100)]:
   field=QDoubleSpinBox();field.setDecimals(6 if key=='interval' else 4);field.setRange(minimum,maximum);field.setValue(value);self.fields[key]=field;form.addRow(label,field)
  self.counts=QLineEdit('5, 10, 20, 40');form.addRow('Pasadas por muestra (2 a 8 valores)',self.counts)
  self.name=QLineEdit('');self.name.setPlaceholderText('Nombre para guardar tu curva medida');form.addRow('Nombre de calibración',self.name)
  self.isolate=QCheckBox('Marcar sólo estas pruebas: desactivar salida de otras capas');self.isolate.setChecked(True);layout.addWidget(self.isolate)
  note=QLabel('Cada cuadrado usa la misma pluma y barrido a 0°, sin cruce ni limpieza; sólo cambian las pasadas. Se toman los parámetros de la capa activa: revísalos para el material elegido. Generar prepara el lienzo. El grabado se inicia desde MARCAR en el panel del láser.');note.setWordWrap(True);layout.addWidget(note)
  self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(['Muestra / capa','Pasadas','Posición X/Y mm','Profundidad medida mm']);self.table.horizontalHeader().setStretchLastSection(True);layout.addWidget(self.table)
  self.confirm=QCheckBox('He realizado y medido estas muestras en este equipo, material y pluma');layout.addWidget(self.confirm)
  self.status=QLabel('Las profundidades quedan vacías hasta que introduzcas tus mediciones.');self.status.setWordWrap(True);layout.addWidget(self.status)
  row=QHBoxLayout();layout.addLayout(row)
  self.generate_btn=QPushButton('Generar pruebas en el lienzo');self.generate_btn.clicked.connect(self.generate);row.addWidget(self.generate_btn)
  self.save_btn=QPushButton('Guardar curva medida');self.save_btn.clicked.connect(self.save_curve);self.save_btn.setEnabled(False);row.addWidget(self.save_btn)
  export=QPushButton('Exportar ensayo JSON…');export.clicked.connect(self.export_record);row.addWidget(export)
  close=QPushButton('Cerrar');close.clicked.connect(self.reject);row.addWidget(close)
 def recipe(self):
  values=[int(value.strip()) for value in self.counts.text().split(',') if value.strip()]
  return dict(material=self.material.currentText().strip(),passes=values,**{key:field.value() for key,field in self.fields.items()})
 def generate(self):
  try:
   record=generate_coupons(self.main,self.recipe(),self.isolate.isChecked());self.record=record
   self.table.setRowCount(len(record['positions']));self.confirm.setChecked(False)
   for row,position in enumerate(record['positions']):
    for col,text in enumerate([f'{row+1} · C{position["layer"]:02d}',str(position['passes']),f'{position["x_mm"]:g} / {position["y_mm"]:g}','']):
     cell=QTableWidgetItem(text)
     if col<3:cell.setFlags(cell.flags() & ~cell.flags().__class__.ItemIsEditable)
     self.table.setItem(row,col,cell)
   self.save_btn.setEnabled(True)
   if not self.name.text().strip():self.name.setText(record['recipe']['material']+' · prueba de tallado')
   path=write_record(record);self.status.setText('Pruebas preparadas. Cierra esta ventana y pulsa MARCAR. Después vuelve para anotar profundidades. Ensayo guardado: '+path)
  except Exception as exc:QMessageBox.information(self,'Prueba de tallado',str(exc))
 def save_curve(self):
  try:
   if not self.record:raise ValueError('Genera primero las pruebas.')
   if not self.confirm.isChecked():raise ValueError('Confirma que has realizado y medido las muestras en este equipo.')
   assert_test_unchanged(self.main,self.record)
   depths=[float(self.table.item(row,3).text().strip().replace(',','.')) for row in range(self.table.rowCount())]
   profile=measured_profile(self.record,depths,self.name.text().strip())
   from depth_calibration import load_profiles,save_profiles
   profiles=[p for p in load_profiles() if p['id']!=profile['id']];save_profiles(profiles+[profile])
   self.record.update(measurement_status='locally_measured',points=profile['points'],profile_name=profile['name']);write_record(self.record)
   self.status.setText('Curva guardada: '+profile['name']+'. Ya puedes seleccionarla en el mapa IA o en Configurar tallado de imagen. No se extrapola fuera del máximo medido.')
  except Exception as exc:QMessageBox.information(self,'Guardar curva',str(exc))
 def export_record(self):
  if not self.record:return QMessageBox.information(self,'Ensayo','Genera primero las pruebas.')
  path,_=QFileDialog.getSaveFileName(self,'Exportar ensayo','prueba_tallado.json','JSON (*.json)')
  if path:
   try:
    from pathlib import Path
    Path(path).write_text(json.dumps(self.record,ensure_ascii=False,indent=2),encoding='utf-8')
   except OSError as exc:QMessageBox.information(self,'Exportar ensayo',str(exc))

def open_depth_tests(main):
 dialog=getattr(main,'_depth_material_tests_dialog',None)
 if dialog is None:dialog=DepthMaterialTestsDialog(main);main._depth_material_tests_dialog=dialog
 dialog.show();dialog.raise_();dialog.activateWindow()

def install_depth_tests(main):
 action=QAction('Pruebas de tallado por material…',main);action.triggered.connect(lambda:open_depth_tests(main))
 menu=next((a.menu() for a in main.menuBar().actions() if a.menu() and a.text().replace('&','')=='Laser'),None)
 if menu:menu.addAction(action)
 main.addToolBar('Pruebas de tallado').addAction(action)
