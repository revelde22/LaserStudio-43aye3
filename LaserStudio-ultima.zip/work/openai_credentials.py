"""Windows CurrentUser DPAPI credential, outside application/patch folders."""
import ctypes,os
from pathlib import Path

def credential_path():
 return Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / '43AYE3' / 'openai_key.dpapi'

def _crypt(data,decrypt=False):
 if os.name!='nt':raise RuntimeError('El guardado cifrado requiere Windows. La clave se mantiene sólo en esta sesión.')
 from ctypes import wintypes
 class Blob(ctypes.Structure):_fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
 buffer=ctypes.create_string_buffer(data);source=Blob(len(data),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));output=Blob()
 crypt=ctypes.WinDLL('crypt32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 function=crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
 function.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)];function.restype=wintypes.BOOL
 kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
 if not function(ctypes.byref(source),None,None,None,None,1,ctypes.byref(output)):raise RuntimeError('Windows no pudo '+('leer' if decrypt else 'cifrar')+' la clave API (DPAPI).')
 try:return ctypes.string_at(output.data,output.size)
 finally:kernel.LocalFree(output.data)

def save_key(key,path=None,protect=None):
 key=key.strip()
 if not key or any(c.isspace() for c in key):raise ValueError('Clave API vacía o con espacios.')
 encrypted=(protect or _crypt)(key.encode('utf-8'))
 target=Path(path or credential_path());target.parent.mkdir(parents=True,exist_ok=True)
 temporary=target.with_suffix('.tmp')
 try:temporary.write_bytes(encrypted);temporary.replace(target)
 finally:temporary.unlink(missing_ok=True)

def load_key(path=None,unprotect=None):
 target=Path(path or credential_path())
 if not target.exists():return ''
 return (unprotect or (lambda data:_crypt(data,True)))(target.read_bytes()).decode('utf-8')

def forget_key(path=None):Path(path or credential_path()).unlink(missing_ok=True)
