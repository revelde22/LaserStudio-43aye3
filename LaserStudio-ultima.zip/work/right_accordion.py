"""Keep existing controls and callbacks inside a single scrollable right dock."""
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QToolButton,QPushButton,
    QDockWidget,QScrollArea,QSizePolicy,QLayout)

class Section(QWidget):
    def __init__(self,title,body,parent=None):
        super().__init__(parent);self.body=body
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
        self.header=QToolButton();self.header.setText(title);self.header.setCheckable(True)
        self.header.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.header.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
        self.header.setMinimumHeight(32)
        self.header.setStyleSheet('QToolButton {background:#e5e5e5; border:1px solid #b9b9b9; padding:5px; text-align:left; font-weight:600;} QToolButton:checked {background:#dce8f3;}')
        layout.addWidget(self.header);layout.addWidget(body)
        body.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Preferred)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Maximum)
        self.header.toggled.connect(self.toggle);self.toggle(False)
    def toggle(self,expanded):
        self.header.setArrowType(Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow)
        self.body.setVisible(expanded)
    def expand(self):self.header.setChecked(True)

def install_right_accordion(window):
    titles={'Laser':'Láser y tallado','Cuts / Layers':'Capas y plumas',
        'Image / Scale':'Imagen, tamaño y posición','Shape Properties':'Propiedades de formas',
        'Move':'Mover y transformar','Material Library':'Biblioteca de materiales',
        'Variable Text':'Texto variable','Material Test Matrix':'Pruebas de materiales'}
    excluded=[getattr(window,key,None) for key in ('image_scale_dock','live_image_dock')]
    candidates=[d for d in window.findChildren(QDockWidget) if d not in excluded and window.dockWidgetArea(d)==Qt.DockWidgetArea.RightDockWidgetArea]
    # Older callbacks still reference controls in the superseded hidden docks.
    # Retain their Python owners when Qt removes them from the dock layout.
    window._accordion_legacy_docks=candidates+[d for d in excluded if d is not None]
    # Later installers replace obsolete layer/image panels.
    unique={d.windowTitle():d for d in candidates}
    panel=QDockWidget('Opciones',window);panel.setObjectName('right_accordion')
    host=QWidget();outer=QVBoxLayout(host);outer.setContentsMargins(4,4,4,4)
    actions=QHBoxLayout();outer.addLayout(actions)
    expand=QPushButton('Abrir todo');collapse=QPushButton('Cerrar todo');actions.addWidget(expand);actions.addWidget(collapse)
    scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QScrollArea.Shape.NoFrame)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    content=QWidget();layout=QVBoxLayout(content);layout.setContentsMargins(0,0,0,0);layout.setSpacing(5)
    layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
    scroll.setWidget(content);outer.addWidget(scroll,1)
    sections=[];by_dock={}
    order=['Laser','Cuts / Layers','Image / Scale','Shape Properties','Move','Material Library','Material Test Matrix','Variable Text']
    for title in order+[name for name in unique if name not in order]:
        dock=unique.get(title)
        if dock is None:continue
        body=dock.widget()
        body.setParent(None)
        if isinstance(body,QScrollArea) and body.widget() is not None:
            old_scroll=body;body=old_scroll.takeWidget();old_scroll.deleteLater()
        section=Section(titles.get(title,title),body,content);layout.addWidget(section)
        sections.append(section);by_dock[dock]=section
        window.removeDockWidget(dock);dock.hide()
        def reveal(section=section):
            section.expand();panel.show();panel.raise_()
            QTimer.singleShot(0,lambda:scroll.ensureWidgetVisible(section.header,0,8))
        # Existing commands (reset layout, image invert, material tests) still
        # address their original dock; route these to the matching section.
        dock.show=reveal;dock.raise_=reveal;dock.widget=lambda body=body:body
        dock.visibilityChanged.connect(lambda visible,dock=dock,reveal=reveal: (dock.hide(),reveal()) if visible else None)
        dock.toggleViewAction().triggered.connect(lambda checked=False,reveal=reveal:reveal())
    for dock in candidates:
        if dock not in by_dock:window.removeDockWidget(dock);dock.hide()
    for dock in excluded:
        if dock is not None:window.removeDockWidget(dock);dock.hide()
    layout.addStretch(1)
    expand.clicked.connect(lambda:[s.header.setChecked(True) for s in sections])
    collapse.clicked.connect(lambda:[s.header.setChecked(False) for s in sections])
    panel.setWidget(host);panel.setMinimumWidth(320)
    window.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,panel)
    window.resizeDocks([panel],[390],Qt.Orientation.Horizontal)
    window.right_accordion_dock=panel;window.right_accordion_scroll=scroll
    window.right_accordion_sections=sections
    for dock in (getattr(window,'laser_dock',None),getattr(window,'layers_dock',None)):
        if dock in by_dock:by_dock[dock].expand()
