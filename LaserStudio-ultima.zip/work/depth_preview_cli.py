"""Heavy preview calculation outside the Qt UI process; JSON on stdin/stdout."""
import json,sys,traceback
from pathlib import Path

def calculate(options):
    if options.get('task')=='export_stl':
        from relief_geometry import export_stl
        return export_stl(options['height_path'],options['output'],options['width_mm'],options['height_mm'],options['relief_mm'],options['base_mm'],options['resolution'])
    from depth_map_tools import prepare_depth_map,export_mm_map,passes_from_mm
    raw=options['raw'];output=options['output'];map_input=raw
    if options['regional']:
        from regional_depth import build_regional_map,region_paths,default_settings
        _,config=region_paths(raw)
        settings=json.loads(config.read_text(encoding='utf-8')) if config.exists() else default_settings()
        settings['levels']=int(options.get('region_levels',0))
        settings['shadow_detail']=float(options.get('shadow_detail',.75))
        settings['face_levels']=int(options.get('face_levels',32))
        settings['face_depth_strength']=float(options.get('face_depth_strength',150))
        map_input=build_regional_map(raw,Path(output).with_name(Path(output).stem+'_geometry.png'),settings,source=options['source'])
    processed=prepare_depth_map(map_input,options['source'],output,
        options['invert'],options['gamma'],options['remove_white'],options['circular'],
        detail_weight=options['detail_weight'],plane_levels=options['plane_levels'])
    result=dict(processed=processed)
    if options['regional']:
        # Preserve the floating-point geometry export through source/circle masks.
        # Do not upconvert the 8-bit engraving map and claim 16-bit precision.
        import numpy as np
        from PIL import Image,ImageOps,ImageDraw
        from depth_map_tools import depth_background_mask
        precise=Path(map_input).with_name(Path(map_input).stem+'_height16.png')
        with Image.open(precise) as image:values=np.array(image,dtype=np.uint16)
        with Image.open(options['source']) as original:source=ImageOps.exif_transpose(original).convert('RGBA').resize((values.shape[1],values.shape[0]))
        values[depth_background_mask(source,False)]=65535
        if options['circular']:
            circle=Image.new('L',source.size,0);ImageDraw.Draw(circle).ellipse((0,0,source.width-1,source.height-1),fill=255)
            values[np.asarray(circle)==0]=65535
        final_height=Path(output).with_name(Path(output).stem+'_height16.png')
        Image.fromarray(values).save(final_height)
        result['height_path']=str(final_height)
    else:result['height_path']=processed
    if options['mm_enabled']:
        try:
            target=options['target_mm'];profile=options.get('profile')
            if profile:
                from depth_calibration import export_calibrated,maximum_passes
                result['calibrated_path']=export_calibrated(processed,target,profile)
                result['mm_text']=f"Curva {profile['name']}: objetivo {target:g} mm, máximo {maximum_passes(target,profile)} pasadas. PNG16 y curva JSON guardados."
            else:
                result['calibrated_path']=export_mm_map(processed,target,options['measured_mm'],options['calibration_passes'])
                text=f'Objetivo: blanco 0 mm · gris medio {target/2:.3f} mm · negro {target:.3f} mm. PNG de 16 bits y escala JSON guardados.'
                if options['measured_mm']>0:
                    count,rate=passes_from_mm(target,options['measured_mm'],options['calibration_passes'])
                    text+=f' Estimación lineal: {count} pasadas máximas ({rate:.5f} mm/pasada).'
                else:text+=' Falta medir una muestra para enviar a tallado en mm.'
                result['mm_text']=text
        except ValueError as exc:
            result['mm_error']=str(exc)
            result['mm_text']='Mapa listo. Sin calibración válida: puedes pasar a tallado y elegir las pasadas manualmente. '+str(exc)
    return result

def main():
    try:
        print(json.dumps({'result':calculate(json.load(sys.stdin))},ensure_ascii=False),flush=True)
        return 0
    except Exception as exc:
        traceback.print_exc(file=sys.stderr)
        print(json.dumps({'error':str(exc)},ensure_ascii=False),flush=True)
        return 1

if __name__=='__main__':sys.exit(main())
