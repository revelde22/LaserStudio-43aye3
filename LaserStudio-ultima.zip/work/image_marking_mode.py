"""Single routing policy for bitmap engraving versus explicitly enabled depth."""
from laser_image_pipeline import MODES


def is_depth_image(settings):
    return settings.get('mode', 'Grayscale') == 'Grayscale' and bool(settings.get('depth_enabled', False))


def apply_image_settings(item, updates, main=None):
    item.image_settings.update(updates)
    settings = item.image_settings
    mode = settings.get('mode', 'Grayscale')
    if mode not in MODES:
        raise ValueError(f'Método de imagen desconocido: {mode}')
    # A binary method always means bitmap engraving, even for older projects
    # which retain calibration data from an earlier depth operation.
    if mode != 'Grayscale':
        settings['depth_enabled'] = False
        settings['depth_mm_enabled'] = False
    if main is not None:
        cut = main.cuts[item.layer]
        cut.interval = float(settings.get('interval', cut.interval))
        # Do not change a mixed vector/image layer's vector mode.
        from laser_studio import GItem
        if not any(isinstance(it, GItem) and it.layer == item.layer for it in main.scene.items()):
            cut.mode = 'Image'
        main.update_cut_row(item.layer)
        if main.active_layer == item.layer and hasattr(main, '_sync_cut_controls'):
            main._sync_cut_controls(item.layer)


def validate_image_for_marking(settings):
    mode = settings.get('mode', 'Grayscale')
    if mode not in MODES:
        raise ValueError(f'Método de imagen desconocido: {mode}')
    if mode == 'Grayscale' and not is_depth_image(settings):
        raise ValueError('La imagen está en Escala de grises sin tallado activado. '
                         'Para grabar una foto elige Jarvis, Stucki, Floyd-Steinberg, '
                         'Atkinson u otro tramado. Para tallar, activa expresamente '
                         '«Configurar tallado de imagen». No se ha enviado marcado.')
    return 'depth' if is_depth_image(settings) else 'raster'


def raster_grid(item, interval=None):
    import math
    interval=float(item.image_settings.get('interval',.1) if interval is None else interval)
    if not math.isfinite(interval) or interval<=0:
        raise ValueError('El intervalo de imagen debe ser mayor que cero.')
    rect=item.boundingRect()
    a=item.mapToScene(rect.topLeft());b=item.mapToScene(rect.topRight());c=item.mapToScene(rect.bottomLeft())
    width=math.hypot(b.x()-a.x(),b.y()-a.y());height=math.hypot(c.x()-a.x(),c.y()-a.y())
    if not math.isfinite(width+height) or width<=0 or height<=0:
        raise ValueError('La imagen no tiene tamaño físico válido.')
    columns=max(1,round(width/interval));rows=max(1,round(height/interval))
    if columns*rows>16000000:
        raise ValueError('La resolución supera 16 millones de puntos. Aumenta el intervalo o reduce el tamaño.')
    return columns,rows
