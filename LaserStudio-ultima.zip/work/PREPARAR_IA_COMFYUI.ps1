﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$runtime = Join-Path $PSScriptRoot 'AI_RUNTIME'
$target = Join-Path $runtime 'python312'
$pythonPath = Join-Path $target 'python.exe'
$cache = Join-Path $runtime 'cache'
$tmp = Join-Path $runtime 'tmp'
New-Item -ItemType Directory -Force -Path $cache,$tmp | Out-Null
$env:TEMP = $tmp
$env:TMP = $tmp
$env:PIP_CACHE_DIR = Join-Path $cache 'pip'
Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
if (-not (Test-Path $pythonPath)) {
    Write-Host 'Descargando Python portable completo dentro de work/AI_RUNTIME...'
    $archive = Join-Path $cache 'cpython-3.12.11-windows-x64.tar.gz'
    $url = 'https://github.com/astral-sh/python-build-standalone/releases/download/20250612/cpython-3.12.11%2B20250612-x86_64-pc-windows-msvc-install_only.tar.gz'
    $expectedHash = '7b93afa91931dbc37b307a81b8680b30193736b5ef29a44ef6452f702c306e7a'
    $validArchive = $false
    if (Test-Path $archive) { $validArchive = (Get-FileHash $archive -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expectedHash }
    if (-not $validArchive) {
        $partial = $archive + '.part'
        Invoke-WebRequest $url -OutFile $partial -UseBasicParsing
        if ((Get-FileHash $partial -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw 'Descarga de Python incompleta o no válida. Vuelve a ejecutar el arranque.' }
        Move-Item -LiteralPath $partial -Destination $archive -Force
    }
    $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
    if (-not $tar) { throw 'No encuentro tar.exe de Windows para extraer Python portable.' }
    $staging = Join-Path $tmp ('python_extract_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $staging | Out-Null
    & $tar.Source -xzf $archive -C $staging
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo extraer el archivo de Python.' }
    $extracted = Join-Path $staging 'python'
    if (-not (Test-Path (Join-Path $extracted 'python.exe'))) { throw 'El archivo no contiene el Python esperado.' }
    if (Test-Path $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    Move-Item -LiteralPath $extracted -Destination $target
    Remove-Item -LiteralPath $staging -Recurse -Force
}
& $pythonPath -c 'import sys,struct,venv,ensurepip; assert sys.version_info[:2] == (3,12); assert struct.calcsize(chr(80)) == 8; print(sys.executable)'
if ($LASTEXITCODE -ne 0) { throw 'Python local no pasó la comprobación de ejecución.' }
& $pythonPath -m pip --version
if ($LASTEXITCODE -ne 0) {
    & $pythonPath -m ensurepip --upgrade
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar pip en Python local.' }
}
& $pythonPath (Join-Path $PSScriptRoot 'comfy_setup.py') --prepare-only
if ($LASTEXITCODE -ne 0) { throw 'No se pudieron preparar las dependencias del editor. Consulta COMFY_SETUP.log.' }
exit 0
