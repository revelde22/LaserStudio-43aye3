from pathlib import Path
from datetime import datetime

from PySide6.QtCore import Qt, QRectF, QSize
from PySide6.QtGui import QImage, QPainter, QColor, QPen, QBrush
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QHBoxLayout, QLabel, QComboBox,
    QSpinBox, QPushButton, QMessageBox, QDialogButtonBox
)
from PySide6.QtSvg import QSvgGenerator


APP = Path(__file__).resolve().parent
EXPORT_DIR = APP / "EXPORTS_IMAGENES"


def _safe_name(text: str) -> str:
    out = "".join(c if c.isalnum() or c in "-_" else "_" for c in text.strip())
    return out.strip("_") or "diseno"


def _is_helper_item(item) -> bool:
    name = type(item).__name__.lower()
    if "resizehandle" in name or "handle" == name:
        return True
    # Items used only by UI/selection helpers normally ignore transforms.
    try:
        if getattr(item, "_is_helper", False):
            return True
    except Exception:
        pass
    return False


def _selected_or_all(scene, area: str):
    all_items = [i for i in scene.items() if not _is_helper_item(i)]
    if area == "SELECCION":
        roots = [i for i in scene.selectedItems() if not _is_helper_item(i)]
        if not roots:
            raise RuntimeError("No hay objetos seleccionados.")
        roots_set = set(roots)

        def belongs(item):
            cur = item
            while cur is not None:
                if cur in roots_set:
                    return True
                try:
                    cur = cur.parentItem()
                except Exception:
                    cur = None
            return False

        chosen = [i for i in all_items if belongs(i)]
        return roots, chosen, all_items

    # TODO: only real visible design items; UI helpers are already filtered.
    chosen = [i for i in all_items if i.isVisible()]
    if not chosen:
        raise RuntimeError("No hay objetos en el trabajo.")
    return chosen, chosen, all_items


def _bounds(items):
    r = QRectF()
    first = True
    for i in items:
        try:
            b = i.sceneBoundingRect()
            if b.isNull() or b.isEmpty():
                continue
            r = QRectF(b) if first else r.united(b)
            first = False
        except Exception:
            pass
    if first or r.isNull() or r.isEmpty():
        raise RuntimeError("No se pudo calcular el área de exportación.")
    return r


class _SceneExportState:
    def __init__(self, scene, chosen, all_items, bw_vectors=False):
        self.scene = scene
        self.chosen = set(chosen)
        self.all_items = all_items
        self.bw_vectors = bw_vectors
        self.state = []

    def __enter__(self):
        for item in self.all_items:
            rec = {"item": item}
            try:
                rec["visible"] = item.isVisible()
            except Exception:
                rec["visible"] = True
            try:
                rec["selected"] = item.isSelected()
                item.setSelected(False)
            except Exception:
                rec["selected"] = False
            if item not in self.chosen:
                try:
                    item.setVisible(False)
                except Exception:
                    pass
            if self.bw_vectors and item in self.chosen:
                try:
                    rec["pen"] = item.pen()
                    p = QPen(rec["pen"])
                    p.setColor(QColor("black"))
                    item.setPen(p)
                except Exception:
                    pass
                try:
                    rec["brush"] = item.brush()
                    b = QBrush(rec["brush"])
                    if b.style() != Qt.BrushStyle.NoBrush:
                        b.setColor(QColor("black"))
                        item.setBrush(b)
                except Exception:
                    pass
            self.state.append(rec)
        return self

    def __exit__(self, exc_type, exc, tb):
        for rec in reversed(self.state):
            item = rec["item"]
            try:
                item.setVisible(rec["visible"])
            except Exception:
                pass
            if "pen" in rec:
                try:
                    item.setPen(rec["pen"])
                except Exception:
                    pass
            if "brush" in rec:
                try:
                    item.setBrush(rec["brush"])
                except Exception:
                    pass
            try:
                item.setSelected(rec["selected"])
            except Exception:
                pass


def export_scene(window, fmt="PNG", area="SELECCION", color_mode="ORIGINAL",
                 bg_mode="BLANCO", dpi=600, margin_px=0):
    scene = window.scene
    roots, chosen, all_items = _selected_or_all(scene, area)
    source = _bounds(roots if area == "SELECCION" else chosen)

    fmt = fmt.upper()
    area = area.upper()
    color_mode = color_mode.upper()
    bg_mode = bg_mode.upper()
    dpi = int(dpi)
    margin_px = max(0, int(margin_px))

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = _safe_name("seleccion" if area == "SELECCION" else "trabajo")
    ext = {"PNG":"png", "JPG":"jpg", "BMP":"bmp", "SVG":"svg"}[fmt]
    path = EXPORT_DIR / f"{base}_{stamp}.{ext}"

    bw = color_mode in ("BLANCO_Y_NEGRO", "B&N", "BN")
    transparent = bg_mode == "TRANSPARENTE" and fmt in ("PNG", "SVG")

    # Scene coordinates in 43AYE3 are millimetres. Raster dimensions therefore
    # follow the requested physical DPI exactly.
    px_per_mm = max(1.0, dpi / 25.4)
    width_px = max(1, int(round(source.width() * px_per_mm)) + 2 * margin_px)
    height_px = max(1, int(round(source.height() * px_per_mm)) + 2 * margin_px)

    # Keep accidental gigantic exports from exhausting RAM.
    max_side = 20000
    if width_px > max_side or height_px > max_side:
        raise RuntimeError(
            f"La exportación sería demasiado grande ({width_px}×{height_px} px). "
            "Reduce los PPP o el tamaño del trabajo."
        )

    with _SceneExportState(scene, chosen, all_items, bw_vectors=(bw and fmt == "SVG")):
        if fmt == "SVG":
            gen = QSvgGenerator()
            gen.setFileName(str(path))
            gen.setSize(QSize(width_px, height_px))
            gen.setViewBox(QRectF(0, 0, width_px, height_px))
            gen.setResolution(dpi)
            gen.setTitle("43AYE3 Laser Studio Pro")
            gen.setDescription("Exportación nativa de 43AYE3 Laser Studio Pro")
            p = QPainter(gen)
            try:
                if not transparent:
                    p.fillRect(QRectF(0, 0, width_px, height_px), QColor("white"))
                target = QRectF(margin_px, margin_px,
                                max(1, width_px - 2 * margin_px),
                                max(1, height_px - 2 * margin_px))
                scene.render(p, target, source, Qt.AspectRatioMode.IgnoreAspectRatio)
            finally:
                p.end()
            if not path.exists() or path.stat().st_size < 100:
                raise RuntimeError("Qt no pudo crear el SVG.")
            return path

        img = QImage(width_px, height_px, QImage.Format.Format_ARGB32)
        img.setDotsPerMeterX(int(round(dpi / 0.0254)))
        img.setDotsPerMeterY(int(round(dpi / 0.0254)))
        img.fill(QColor(0, 0, 0, 0) if transparent else QColor("white"))

        p = QPainter(img)
        try:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
            target = QRectF(margin_px, margin_px,
                            max(1, width_px - 2 * margin_px),
                            max(1, height_px - 2 * margin_px))
            scene.render(p, target, source, Qt.AspectRatioMode.IgnoreAspectRatio)
        finally:
            p.end()

        if bw:
            # Native Qt conversion: no Pillow or external dependency required.
            # Threshold dithering creates a true 1-bit engraving-friendly image.
            mono = img.convertToFormat(
                QImage.Format.Format_Mono,
                Qt.ImageConversionFlag.ThresholdDither | Qt.ImageConversionFlag.AvoidDither
            )
            img = mono.convertToFormat(QImage.Format.Format_ARGB32)

        if fmt in ("JPG", "BMP") and img.hasAlphaChannel():
            flat = QImage(img.size(), QImage.Format.Format_RGB32)
            flat.fill(QColor("white"))
            pp = QPainter(flat)
            pp.drawImage(0, 0, img)
            pp.end()
            img = flat

        quality = 95 if fmt == "JPG" else -1
        if not img.save(str(path), fmt, quality):
            raise RuntimeError(f"Qt no pudo guardar {fmt}.")

    if not path.exists() or path.stat().st_size <= 0:
        raise RuntimeError("El archivo no se creó.")
    return path


class ImageExportDialog(QDialog):
    def __init__(self, window, default_area=None, default_preset=None):
        super().__init__(window)
        self.window = window
        self.setWindowTitle("Exportar imagen")
        self.setMinimumWidth(430)

        main = QVBoxLayout(self)
        intro = QLabel(
            "Exporta directamente el trabajo de 43AYE3. No usa GLaser y no necesita Pillow."
        )
        intro.setWordWrap(True)
        main.addWidget(intro)

        form = QFormLayout()
        self.fmt = QComboBox(); self.fmt.addItems(["PNG", "JPG", "BMP", "SVG"])
        self.area = QComboBox(); self.area.addItems(["SELECCION", "TODO"])
        try:
            if default_area:
                self.area.setCurrentText(str(default_area).upper())
            elif not window.scene.selectedItems():
                self.area.setCurrentText("TODO")
        except Exception:
            pass
        self.color = QComboBox(); self.color.addItems(["ORIGINAL", "BLANCO_Y_NEGRO"])
        self.bg = QComboBox(); self.bg.addItems(["BLANCO", "TRANSPARENTE"])
        self.dpi = QSpinBox(); self.dpi.setRange(72, 2400); self.dpi.setValue(600); self.dpi.setSuffix(" ppp")
        self.margin = QSpinBox(); self.margin.setRange(0, 500); self.margin.setValue(0); self.margin.setSuffix(" px")
        form.addRow("Formato", self.fmt)
        form.addRow("Área", self.area)
        form.addRow("Color", self.color)
        form.addRow("Fondo", self.bg)
        form.addRow("Resolución", self.dpi)
        form.addRow("Margen", self.margin)
        main.addLayout(form)

        presets = QHBoxLayout()
        b_grab = QPushButton("GRABADO 600 PPP")
        b_social = QPushButton("PREVIEW COLOR")
        presets.addWidget(b_grab); presets.addWidget(b_social)
        main.addLayout(presets)

        def preset_grabado():
            self.fmt.setCurrentText("PNG")
            self.color.setCurrentText("BLANCO_Y_NEGRO")
            self.bg.setCurrentText("BLANCO")
            self.dpi.setValue(600)
        def preset_preview():
            self.fmt.setCurrentText("PNG")
            self.color.setCurrentText("ORIGINAL")
            self.bg.setCurrentText("BLANCO")
            self.dpi.setValue(300)
        b_grab.clicked.connect(preset_grabado)
        b_social.clicked.connect(preset_preview)
        if default_preset == "GRABADO":
            preset_grabado()
        elif default_preset == "PREVIEW":
            preset_preview()

        note = QLabel(f"Salida automática: {EXPORT_DIR}")
        note.setWordWrap(True); note.setTextInteractionFlags(Qt.TextSelectableByMouse)
        main.addWidget(note)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Save).setText("EXPORTAR")
        bb.accepted.connect(self._do_export); bb.rejected.connect(self.reject)
        main.addWidget(bb)

    def _do_export(self):
        try:
            path = export_scene(
                self.window,
                fmt=self.fmt.currentText(),
                area=self.area.currentText(),
                color_mode=self.color.currentText(),
                bg_mode=self.bg.currentText(),
                dpi=self.dpi.value(),
                margin_px=self.margin.value(),
            )
        except Exception as e:
            QMessageBox.warning(self, "Exportar imagen", str(e))
            return
        QMessageBox.information(
            self, "Exportar imagen",
            f"Exportación terminada.\n\n{path}\n\n"
            f"Tamaño: {path.stat().st_size / 1024:.1f} KB"
        )
        self.accept()
