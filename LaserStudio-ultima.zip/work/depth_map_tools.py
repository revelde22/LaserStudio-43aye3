"""Image-depth postprocessing and editable pass proposals; no physical Z claim."""
from pathlib import Path

def depth_background_mask(source_image,remove_white=True):
    """Exclude transparency and border-connected white, preserving white detail."""
    import numpy as np
    pixels=np.asarray(source_image.convert('RGBA'))
    transparent=pixels[:,:,3]==0
    if not remove_white:return transparent
    from PIL import Image,ImageOps,ImageDraw
    white=(pixels[:,:,:3]>=245).all(axis=2) | transparent
    # A white padding joins every edge component to one outside seed.
    # Pillow is installed in both editor and CUDA runtimes; cv2 is not.
    padded=ImageOps.expand(Image.fromarray(white.astype('uint8')*255),border=1,fill=255)
    ImageDraw.floodfill(padded,(0,0),128)
    exterior=np.asarray(padded)[1:-1,1:-1]==128
    return transparent | exterior

def normalize_depth_prediction(prediction,source_image):
    """Robust relative contrast over the artwork, excluding its white exterior."""
    import numpy as np
    values=np.asarray(prediction,dtype=float)
    if values.ndim!=2 or not np.isfinite(values).all():
        raise ValueError('La IA ha devuelto un mapa no válido.')
    mask=depth_background_mask(source_image.resize((values.shape[1],values.shape[0])))
    samples=values[~mask]
    if not samples.size:raise ValueError('La imagen solo contiene fondo blanco o transparente.')
    low,high=np.percentile(samples,[1,99])
    if high-low<1e-8:low,high=float(samples.min()),float(samples.max())
    if high-low<1e-8:raise ValueError('La IA no ha encontrado variación de relieve en la figura.')
    return np.round(np.clip((values-low)/(high-low),0,1)*255).astype('uint8')

def passes_from_mm(target_mm,measured_mm,calibration_passes):
    """Linear estimate from a user-measured coupon, never inferred by AI."""
    import math
    values=(float(target_mm),float(measured_mm),float(calibration_passes))
    if not all(math.isfinite(v) and v>0 for v in values):
        raise ValueError('Introduce profundidad objetivo, profundidad medida y pasadas de calibración mayores que cero.')
    rate=values[1]/values[2]
    count=math.ceil(values[0]/rate)
    if count>999:raise ValueError('La calibración requiere más de 999 pasadas. Revisa los valores o reduce el objetivo.')
    return count,rate

def export_mm_map(map_path,target_mm,measured_mm=0,calibration_passes=1,output_dir=None):
    """16-bit desired-depth map with an explicit scale and calibration sidecar."""
    import json
    import numpy as np
    from PIL import Image
    target=float(target_mm)
    if not np.isfinite(target) or target<=0:raise ValueError('La profundidad objetivo debe ser mayor que cero.')
    calibration=None
    if measured_mm != 0:
        count,rate=passes_from_mm(target,measured_mm,calibration_passes)
        calibration=dict(measured_mm=measured_mm,passes=calibration_passes,mm_per_pass=rate,estimated_max_passes=count,method='linear_user_coupon')
    path=Path(map_path)
    with Image.open(path) as image:
        gray=np.asarray(image.convert('L'),dtype=float)
    # Here larger 16-bit values represent greater desired material removal.
    desired=np.round((255-gray)/255*65535).astype('uint16')
    if output_dir is None:output=path.with_name(path.stem+'_mm16.png')
    else:
        import uuid
        folder=Path(output_dir);folder.mkdir(parents=True,exist_ok=True)
        output=folder/(path.stem+'_'+uuid.uuid4().hex+'_mm16.png')
    Image.fromarray(desired).save(output)
    output.with_suffix('.json').write_text(json.dumps(dict(version=1,kind='desired_depth_not_measurement',unit='mm',target_max_mm=target,formula='depth_mm = pixel_uint16 / 65535 * target_max_mm',zero_pixel=0,max_pixel=65535,calibration=calibration),indent=2),encoding='utf-8')
    return str(output)

def prepare_depth_map(raw_path,source_path,out_path,invert=False,gamma=1.,remove_white=True,circular=False,detail_weight=0.,plane_levels=0):
    from PIL import Image,ImageOps,ImageDraw
    import numpy as np
    gamma=float(gamma)
    if not np.isfinite(gamma) or gamma<=0:raise ValueError('La curva debe ser positiva y finita.')
    with Image.open(raw_path) as raw:image=raw.convert('L')
    values=np.asarray(image,dtype=float)/255.
    with Image.open(source_path) as original:source=ImageOps.exif_transpose(original).convert('RGBA').resize(image.size)
    weight=float(detail_weight)
    if not np.isfinite(weight) or not 0<=weight<=1:raise ValueError('El peso de los grises debe estar entre 0 y 1.')
    levels=int(plane_levels)
    if not 0<=levels<=256:raise ValueError('El número de planos debe estar entre 0 y 256.')
    if levels and weight:raise ValueError('El modo por planos no admite mezcla con los grises originales.')
    if weight:
        # Artistic height composition, not additional predicted geometry.
        detail=np.asarray(source.convert('L'),dtype=float)/255.
        values=(1-weight)*values+weight*detail
    if invert:values=1-values
    values=values**gamma
    if levels:
        # Quantize inferred depth, never the original photograph.
        values=np.round(values*(levels-1))/(levels-1) if levels>1 else np.full_like(values,0.5)
    image=Image.fromarray(np.round(255*values).astype('uint8'))
    mask=depth_background_mask(source,remove_white)
    array=np.array(image);array[mask]=255;image=Image.fromarray(array)
    if circular:
        circle=Image.new('L',image.size,0);ImageDraw.Draw(circle).ellipse((0,0,image.width-1,image.height-1),fill=255)
        image=Image.composite(image,Image.new('L',image.size,255),circle)
    image.save(out_path);return str(out_path)

def propose_passes(cut,map_path=None):
    """Prefer saved material recipes; fallback is editable tonal resolution."""
    from material_library import _load
    material=getattr(cut,'material','')
    candidates=[]
    if material:
        for row in _load()[0]:
            if len(row)<12:continue
            if row[0].casefold()!=material.casefold():continue
            if not any(word in row[2].casefold() for word in ('tallado','profund','relieve')):continue
            if 'NO ' in row[11].upper() or row[2].upper()=='NO USAR':continue
            try:
                value=int(float(row[8]))
                if not 1<=value<=999:continue
                rank=0 if row[11].casefold() in ('usuario','43aye3') else 1
                candidates.append((rank,value,row))
            except (ValueError,IndexError):continue
    if candidates:
        _,passes,row=min(candidates,key=lambda candidate:candidate[0])
        return passes,f'Biblioteca: {row[0]} · {row[2]} · {row[11]}. Revisa que la pluma coincida con ese ajuste.'
    base=max(1,int(cut.passes))
    if base>1:return base,f'Base de la pluma: {base} pasadas máximas. Propuesta editable; no predice profundidad en mm.'
    tones=0
    if map_path:
        from PIL import Image
        with Image.open(map_path) as image:
            histogram=image.convert('L').histogram();tones=sum(n>0 for n in histogram[:-1])
    passes=1 if tones<=1 else 4 if tones<16 else 8
    return passes,f'Propuesta orientativa: {passes} niveles de tallado según los tonos del mapa IA. Sin receta calibrada para este material; prueba en una muestra.'
