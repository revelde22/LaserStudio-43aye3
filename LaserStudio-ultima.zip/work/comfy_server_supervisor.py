"""An owned ComfyUI server stops on request or when Laser Studio exits."""
import argparse,ctypes,os,subprocess,time
from pathlib import Path
from comfy_setup import BASE,STATE,runtime_env

def supervise(owner,port,token):
    parent=None
    if os.name=='nt':
        kernel=ctypes.windll.kernel32
        kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];kernel.OpenProcess.restype=ctypes.c_void_p
        kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32];kernel.WaitForSingleObject.restype=ctypes.c_uint32
        kernel.CloseHandle.argtypes=[ctypes.c_void_p]
        parent=kernel.OpenProcess(0x00100000,False,owner)
        if not parent:return
        alive=lambda:kernel.WaitForSingleObject(parent,0)==258
    else:
        def alive():
            try:os.kill(owner,0);return True
            except ProcessLookupError:return False
    root=STATE/'ComfyUI';python=STATE/'comfy_venv/Scripts/python.exe'
    stop=STATE/f'stop_{token}.flag';process=None
    try:
        if not alive() or stop.exists():return
        process=subprocess.Popen([str(python),str(root/'main.py'),'--listen','127.0.0.1','--port',str(port),'--lowvram','--cpu-vae','--reserve-vram','1','--preview-method','none'],cwd=str(root),env=runtime_env())
        while alive() and not stop.exists() and process.poll() is None:time.sleep(.25)
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            try:process.wait(timeout=8)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        stop.unlink(missing_ok=True)
        if parent:kernel.CloseHandle(parent)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--owner',type=int,required=True);parser.add_argument('--port',type=int,required=True);parser.add_argument('--token',required=True);args=parser.parse_args()
    supervise(args.owner,args.port,args.token)
