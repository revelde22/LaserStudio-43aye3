from pathlib import Path
from PySide6.QtCore import QSize, QPointF
from PySide6.QtGui import QImageReader, QPixmap, QTransform

DISPLAY_MAX_SIDE = 2048

def load_display_pixmap(path, max_side=DISPLAY_MAX_SIDE):
    """Load a memory-friendly pixmap for the canvas; the full-res file stays on disk."""
    path=str(path)
    reader=QImageReader(path)
    reader.setAutoTransform(True)
    sz=reader.size()
    if sz.isValid() and max(sz.width(), sz.height()) > int(max_side):
        scale=float(max_side)/float(max(sz.width(), sz.height()))
        reader.setScaledSize(QSize(max(1,round(sz.width()*scale)), max(1,round(sz.height()*scale))))
    img=reader.read()
    if not img.isNull():
        return QPixmap.fromImage(img)
    pm=QPixmap(path)
    if pm.isNull():
        raise RuntimeError(f"No se pudo cargar la imagen procesada: {path}")
    if max(pm.width(),pm.height()) > int(max_side):
        pm=pm.scaled(int(max_side),int(max_side), aspectMode=1, mode=1)
    return pm

def _move_scene_delta(item, dx, dy):
    parent=item.parentItem()
    if parent is None:
        item.moveBy(dx,dy)
        return
    p0=parent.mapFromScene(QPointF(0.0,0.0))
    p1=parent.mapFromScene(QPointF(float(dx),float(dy)))
    item.moveBy(p1.x()-p0.x(), p1.y()-p0.y())

def replace_pixmap_keep_scene_bounds(item, pixmap):
    """Replace raster pixels while keeping its physical scene bounding box.

    RasterItem starts life with a legacy item.scale() (e.g. 40/pixel_width).
    Applying another transform without clearing that scale multiplies the two and
    shrinks the image. This routine canonicalises scale and restores the exact
    scene bounds after the pixel dimensions change.
    """
    old=item.sceneBoundingRect()
    if old.width() <= 0 or old.height() <= 0:
        item.setPixmap(pixmap)
        return
    item.setPixmap(pixmap)
    item.setScale(1.0)
    item.setTransform(QTransform(), False)
    # Two correction passes make the scene AABB stable even if item.rotation()!=0.
    for _ in range(2):
        now=item.sceneBoundingRect()
        if now.width() <= 0 or now.height() <= 0:
            break
        fx=old.width()/now.width(); fy=old.height()/now.height()
        t=QTransform(item.transform()); t.scale(fx,fy); item.setTransform(t,False)
    now=item.sceneBoundingRect()
    _move_scene_delta(item, old.x()-now.x(), old.y()-now.y())
    if hasattr(item,'update_handles'):
        item.update_handles()
