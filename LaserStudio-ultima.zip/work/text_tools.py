"""Contornos de texto editables con dimensiones fisicas en milimetros."""
from PySide6.QtCore import QPointF,Qt
from PySide6.QtGui import QPainterPath,QFont,QFontMetricsF,QTransform


def text_path(text,font_family="Arial",size_mm=8,bold=False,italic=False,
              tracking_mm=0,line_spacing=1.2,align="Left",mirror_h=False,mirror_v=False):
    font=QFont(font_family);font.setBold(bold);font.setItalic(italic);font.setPixelSize(1000)
    metrics=QFontMetricsF(font)
    cap=QPainterPath();cap.addText(QPointF(0,0),font,"H")
    unit=size_mm/max(1.0,cap.boundingRect().height())
    tracking=tracking_mm/max(.0001,unit)
    lines=text.split("\n");paths=[];widths=[]
    for row,line in enumerate(lines):
        path=QPainterPath();x=0.0;y=row*metrics.lineSpacing()*line_spacing
        for char in line:
            if char!=" ":path.addText(QPointF(x,y),font,char)
            x+=metrics.horizontalAdvance(char)+tracking
        paths.append(path);widths.append(max(0,x-tracking))
    widest=max(widths,default=0)
    combined=QPainterPath();combined.setFillRule(Qt.FillRule.WindingFill)
    for path,width in zip(paths,widths):
        dx=(widest-width)/2 if align=="Center" else (widest-width if align=="Right" else 0)
        shift=QTransform();shift.translate(dx,0);combined.addPath(shift.map(path))
    bounds=combined.boundingRect()
    transform=QTransform(unit,0,0,unit,-bounds.left()*unit,-bounds.top()*unit)
    result=transform.map(combined)
    box=result.boundingRect();center=box.center()
    if mirror_h or mirror_v:
        sx=-1 if mirror_h else 1;sy=-1 if mirror_v else 1
        mirror=QTransform(sx,0,0,sy,center.x()*(1-sx),center.y()*(1-sy))
        result=mirror.map(result)
    return result
