"""Local ComfyUI API; no dependency on custom nodes or cloud services."""
import io,json,os,secrets,time,uuid
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError
BASE_URL='http://127.0.0.1:8188'
from flux_klein import MODEL as DEFAULT_MODEL

def reload_endpoint():
    global BASE_URL
    config=Path(__file__).resolve().parent/'AI_RUNTIME/comfy_config.json'
    if config.exists():
        saved=json.loads(config.read_text(encoding='utf-8'))
        BASE_URL=saved.get('url','http://127.0.0.1:8188')
    return BASE_URL

def api(route,data=None,timeout=30):
    request=Request(BASE_URL+route,data=None if data is None else json.dumps(data).encode(),
                    headers={'Content-Type':'application/json'} if data is not None else {})
    try:
        with urlopen(request,timeout=timeout) as response:return json.load(response)
    except HTTPError as e:
        detail=e.read().decode('utf-8',errors='replace')
        raise RuntimeError(f'ComfyUI HTTP {e.code}: {detail[:1800]}') from e

def available_models():
    info=api('/object_info/CheckpointLoaderSimple')
    models=list(info['CheckpointLoaderSimple']['input']['required']['ckpt_name'][0])
    from flux_klein import REQUIRED_NODES
    all_nodes=api('/object_info')
    if all(name in all_nodes for name in REQUIRED_NODES):
        unets=all_nodes['UNETLoader']['input']['required']['unet_name'][0]
        encoders=all_nodes['CLIPLoader']['input']['required']['clip_name'][0]
        vaes=all_nodes['VAELoader']['input']['required']['vae_name'][0]
        from flux_klein import TEXT_ENCODER,VAE
        if DEFAULT_MODEL in unets and TEXT_ENCODER in encoders and VAE in vaes:models.insert(0,DEFAULT_MODEL)
    return models

def upload_image(path):
    boundary='43AYE3'+uuid.uuid4().hex
    name='43aye3_ref_'+uuid.uuid4().hex+Path(path).suffix.lower()
    body=(f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{name}"\r\n'
          'Content-Type: application/octet-stream\r\n\r\n').encode()+Path(path).read_bytes()+f'\r\n--{boundary}--\r\n'.encode()
    req=Request(BASE_URL+'/upload/image',data=body,headers={'Content-Type':f'multipart/form-data; boundary={boundary}'})
    with urlopen(req,timeout=60) as response:result=json.load(response)
    return '/'.join(part for part in (result.get('subfolder',''),result['name']) if part)

def workflow(prompt,style,model,width,height,steps=24,reference=None,strength=.65,seed=None,circular=False):
    # SD1.5 / SDXL checkpoints supported by the built-in CheckpointLoaderSimple.
    hints={'Blanco y negro para vectorizar':'monochrome black ink illustration, bold clean silhouettes, flat white background, crisp contour lines, engraving stencil, no gradients',
           'Escala de grises':'monochrome grayscale illustration, white background, clear tonal separation, engraving artwork, detailed subject'}
    positive=prompt+', '+hints[style]+', centered composition, complete subject, no watermark'
    negative='color, blurry, watermark, signature, cropped subject, cluttered background'
    if circular:
        if width!=height:raise ValueError('El diseño redondo requiere una imagen cuadrada.')
        positive+=', circular medallion composition, round engraving emblem, all details inside a circle, complete subject inside circular boundary, generous white margin, centered round layout'
        negative+=', square frame, rectangular frame, rectangular layout, subject outside circle, cropped head, cropped feet'
    if model==DEFAULT_MODEL:
        from flux_klein import graph
        return graph(positive,width,height,steps,reference,seed if seed is not None else secrets.randbelow(2**53))
    nodes={
      '1':{'class_type':'CheckpointLoaderSimple','inputs':{'ckpt_name':model}},
      '2':{'class_type':'CLIPTextEncode','inputs':{'text':positive,'clip':['1',1]}},
      '3':{'class_type':'CLIPTextEncode','inputs':{'text':negative,'clip':['1',1]}},
      '4':{'class_type':'EmptyLatentImage','inputs':{'width':width,'height':height,'batch_size':1}},
      '5':{'class_type':'KSampler','inputs':{'seed':seed if seed is not None else secrets.randbelow(2**53),'steps':steps,
             'cfg':6.0 if 'sdxl' in model.lower() else 7.0,'sampler_name':'dpmpp_2m' if 'sdxl' in model.lower() else 'euler','scheduler':'karras' if 'sdxl' in model.lower() else 'normal','denoise':strength if reference else 1.,
             'model':['1',0],'positive':['2',0],'negative':['3',0],'latent_image':['4',0]}},
      '6':{'class_type':'VAEDecode','inputs':{'samples':['5',0],'vae':['1',2]}},
      '7':{'class_type':'SaveImage','inputs':{'images':['6',0],'filename_prefix':'43AYE3_design'}}}
    if reference:
        nodes['8']={'class_type':'LoadImage','inputs':{'image':reference}}
        nodes['9']={'class_type':'ImageScale','inputs':{'image':['8',0],'upscale_method':'lanczos','width':width,'height':height,'crop':'disabled'}}
        nodes['4']={'class_type':'VAEEncode','inputs':{'pixels':['9',0],'vae':['1',2]}}
    return nodes

def generate(graph,notify=lambda message:None,cancelled=lambda:False):
    client_id=uuid.uuid4().hex
    job=api('/prompt',{'prompt':graph,'client_id':client_id})
    if job.get('node_errors'):raise RuntimeError(str(job['node_errors']))
    prompt_id=job['prompt_id'];missing=0;notify('Trabajo enviado a ComfyUI. Esperando imagen…')
    try:
        while not cancelled():
            history=api('/history/'+prompt_id,timeout=20).get(prompt_id)
            if history:
                status=history.get('status',{})
                if status.get('status_str')=='error':raise RuntimeError('ComfyUI: '+str(status.get('messages',[]))[-1800:])
                for output in history.get('outputs',{}).values():
                    for image in output.get('images',[]):
                        if image.get('type','output')!='output':continue
                        with urlopen(BASE_URL+'/view?'+urlencode(image),timeout=60) as response:return response.read()
                if status.get('completed'):raise RuntimeError('El flujo terminó sin producir una imagen.')
            queue=api('/queue')
            pending=[job[1] for job in queue.get('queue_pending',[])]
            running=[job[1] for job in queue.get('queue_running',[])]
            missing=missing+1 if prompt_id not in running and prompt_id not in pending else 0
            if missing>10:raise RuntimeError('El trabajo desapareció de la cola de ComfyUI. Vuelve a generar.')
            notify('Generando imagen…' if prompt_id in running else f'En cola · {pending.index(prompt_id)+1}' if prompt_id in pending else 'Procesando resultado…')
            time.sleep(1)
        # Delete only this pending job. Interrupt the engine only if our job is running.
        try:
            api('/api/jobs/'+prompt_id+'/cancel',{})
        except RuntimeError as e:
            if 'HTTP 404' not in str(e):raise
            # Older ComfyUI has no atomic per-job interrupt. Avoid stopping
            # unrelated work if the active job changes between two requests.
            api('/queue',{'delete':[prompt_id]})
            raise RuntimeError('Cancelada en Laser Studio. Si ya estaba ejecutándose, ComfyUI antiguo terminará esa imagen en segundo plano.')
        raise RuntimeError('Generación cancelada.')
    except Exception:
        raise

def prepare_artwork(data,path,style,width_mm,height_mm,circular=False,border=True):
    from PIL import Image,ImageOps,ImageDraw
    image=Image.open(io.BytesIO(data)).convert('L')
    if circular:height_mm=width_mm
    width=1024; height=max(1,round(width*height_mm/width_mm))
    if height>2048:width=max(1,round(2048*width_mm/height_mm));height=2048
    canvas=Image.new('L',(width,height),255)
    margin=max(2,round(width*.025)) if circular else 0
    fit=ImageOps.contain(image,(max(1,width-2*margin),max(1,height-2*margin)),Image.Resampling.LANCZOS)
    canvas.paste(fit,((width-fit.width)//2,(height-fit.height)//2))
    if style=='Blanco y negro para vectorizar':canvas=canvas.point(lambda value:0 if value<150 else 255)
    if circular:
        mask=Image.new('L',canvas.size,0);ImageDraw.Draw(mask).ellipse((0,0,width-1,height-1),fill=255)
        canvas=Image.composite(canvas,Image.new('L',canvas.size,255),mask)
        if border:
            inset=max(2,round(width*.008))
            ImageDraw.Draw(canvas).ellipse((inset,inset,width-1-inset,height-1-inset),outline=0,width=max(1,round(width*.003)))
    canvas.save(path)
    return str(path)
