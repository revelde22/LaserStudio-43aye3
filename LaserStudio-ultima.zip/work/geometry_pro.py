import math
from PySide6.QtCore import QPointF
from PySide6.QtGui import QPainterPath

def path_from_points(points, closed=False):
    p=QPainterPath()
    if not points:return p
    p.moveTo(*points[0])
    for q in points[1:]:p.lineTo(*q)
    if closed:p.closeSubpath()
    return p

def regular_polygon(cx,cy,r,n,rotation=-90):
    return [(cx+r*math.cos(math.radians(rotation+360*i/n)),
             cy+r*math.sin(math.radians(rotation+360*i/n))) for i in range(n)]

def star(cx,cy,r1,r2,n,rotation=-90):
    out=[]
    for i in range(n*2):
        a=math.radians(rotation+180*i/n);r=r1 if i%2==0 else r2
        out.append((cx+r*math.cos(a),cy+r*math.sin(a)))
    return out

def union(paths):
    out=QPainterPath()
    for p in paths:out=out.united(p)
    return out.simplified()

def intersect(paths):
    if not paths:return QPainterPath()
    out=paths[0]
    for p in paths[1:]:out=out.intersected(p)
    return out.simplified()

def subtract(base, cutters):
    out=base
    for p in cutters:out=out.subtracted(p)
    return out.simplified()

def xor(paths):
    if not paths:return QPainterPath()
    out=paths[0]
    for p in paths[1:]:
        u=out.united(p); inter=out.intersected(p); out=u.subtracted(inter)
    return out.simplified()

def hatch_segments(path, interval=.1, angle_deg=0, cross=False):
    # robust clipping by QPainterPath intersections using thin scan rectangles.
    if interval<=0:raise ValueError("interval must be >0")
    bounds=path.boundingRect();diag=math.hypot(bounds.width(),bounds.height())*2+10
    center=bounds.center(); segs=[]
    angles=[angle_deg]+([angle_deg+90] if cross else [])
    for ang in angles:
        rad=math.radians(ang); nx=-math.sin(rad);ny=math.cos(rad);tx=math.cos(rad);ty=math.sin(rad)
        extent=diag
        k=-extent
        while k<=extent:
            cx=center.x()+nx*k;cy=center.y()+ny*k
            a=QPointF(cx-tx*extent,cy-ty*extent);b=QPointF(cx+tx*extent,cy+ty*extent)
            # sample containment into contiguous segments; deterministic and safe for preview/planner.
            N=max(64,int(diag/max(interval,.02)))
            active=None
            for i in range(N+1):
                t=i/N;x=a.x()+(b.x()-a.x())*t;y=a.y()+(b.y()-a.y())*t
                inside=path.contains(QPointF(x,y))
                if inside and active is None:active=(x,y)
                if active is not None and (not inside or i==N):
                    end=(x,y);segs.append((active,end));active=None
            k+=interval
    return segs
