from pathlib import Path
import os, subprocess


def _build(base, timeout=120):
    bat=base/'COMPILAR_DIAGNOSTICO_G2.bat'
    if not bat.exists():
        return False,['AUTO_BUILD: BAT no encontrado: '+str(bat)]
    try:
        p=subprocess.run(['cmd.exe','/d','/c',str(bat)],cwd=str(base),capture_output=True,text=True,timeout=timeout,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        lines=[x.rstrip() for x in (p.stdout+'\n'+p.stderr).splitlines() if x.strip()]
        lines.insert(0,'AUTO_BUILD: iniciado porque faltaba DIAGNÓSTICO UNIFICADO x86')
        lines.append('AUTO_BUILD_RETURN='+str(p.returncode))
        return p.returncode==0,lines
    except Exception as e:
        return False,['AUTO_BUILD_EXCEPTION='+repr(e)]


def _values(lines):
    out={}
    for line in lines:
        if '=' in line:
            k,v=line.split('=',1)
            out[k.strip()]=v.strip()
    return out


def _int(v, default=-999999):
    try: return int(str(v),0)
    except Exception: return default


def run_device_state_readonly_probe(base=None,vendor_dir=None,timeout=25):
    base=Path(base or Path(__file__).parent)
    exe=base/'native_bridge_x86'/'43aye3_g2_device_state_readonly_x86.exe'
    pre=[]
    if not exe.exists():
        ok,lines=_build(base);pre.extend(lines)
        if not ok or not exe.exists():
            pre += ['DIAGNÓSTICO COMPLETO: no se pudo construir el ejecutable x86.','FRAME/MARK/REDLIGHT/STOP: NO EJECUTADOS']
            return {'ok':False,'device_ready':False,'result':'BUILD_FAILED','lines':pre,'values':_values(pre)}
        pre.append('AUTO_BUILD_RESULT=PASS')
    env=os.environ.copy()
    if vendor_dir: env['G2PRO_VENDOR_DIR']=str(Path(vendor_dir))
    try:
        p=subprocess.run([str(exe)],cwd=str(base),capture_output=True,text=True,timeout=timeout,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),env=env)
        lines=pre+[x.strip() for x in (p.stdout+'\n'+p.stderr).splitlines() if x.strip()]
        vals=_values(lines)
        result=vals.get('STATE_PROBE_RESULT')
        structural_ok=(p.returncode==0 and result=='PASS')
        device_ready=(
            structural_ok and
            _int(vals.get('INITDEVICES_RETURN'))==1 and
            _int(vals.get('INITDEVICES_REF_VALUE'))>=1 and
            _int(vals.get('MARKMGR_INITIALIZED_COUNT'))>=1 and
            _int(vals.get('VALID_DEVICE_COUNT'))==1 and
            _int(vals.get('ADAPTOR_ISVALID_1'))==1 and
            _int(vals.get('DEVICE_NO'))>=0 and
            _int(vals.get('DEVICE_TYPE'))>=0
        )
        lines.append('DEVICE_READY_FOR_ACTIVE_TEST='+('YES' if device_ready else 'NO'))
        return {'ok':structural_ok,'device_ready':device_ready,'returncode':p.returncode,'result':result,'lines':lines,'values':vals}
    except subprocess.TimeoutExpired as e:
        out=e.stdout or ''
        if isinstance(out,bytes): out=out.decode(errors='replace')
        lines=pre+[x.strip() for x in out.splitlines() if x.strip()]
        lines.append('STATE PROBE: TIMEOUT - proceso aislado terminado por el padre')
        return {'ok':False,'device_ready':False,'result':'TIMEOUT','lines':lines,'values':_values(lines)}
