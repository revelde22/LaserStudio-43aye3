import json
from pathlib import Path
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QTableWidget,QTableWidgetItem,QPushButton,QMessageBox,
 QFileDialog,QAbstractItemView,QLabel,QComboBox,QGroupBox,QFormLayout,QHeaderView,QCheckBox,
 QLineEdit,QDoubleSpinBox,QSpinBox,QDialogButtonBox)

BASE=Path(__file__).resolve().parent
USER_FILE=BASE/'material_library_user.json'
COLS=['Material','Variante/acabado','Objetivo','Liquido','Velocidad mm/s','Potencia %','Frecuencia kHz','Hatch mm','Pasadas','Desenfoque mm','Fuente/nota','Estado']
LIQCOLS=['Marca','Producto','Materiales compatibles','Aplicacion / secado','Notas']

# Presets are STARTING POINTS collected from manufacturer/community references. They are deliberately editable.
# Where a source is for a different optical setup, the note says so; test on scrap before production.
DEFAULT_ROWS=[
 ['Acero inoxidable','304/316','Marcado oscuro','Sin liquido','1000','90','40','0.020','1','0','Triumph 30W reference; cross hatch','Referencia web'],
 ['Acero inoxidable','304/316','Marcado blanco','Sin liquido','1500','50','35','0.040','1','0','LaserTips Raycus 30W; interval source gives 0.03-0.05','Referencia web'],
 ['Acero inoxidable','304/316','Negro ligado','CerMark LMM6000','180','30','50','0.0508','1','0','LMM6000 Fiber/YAG table: 9W,18cm/s,.002in, >=50kHz','Fabricante'],
 ['Acero inoxidable','304/316','Negro ligado','Brilliance BLI101MBAS','300','30','50','0.050','1','0','Compatible per Brilliance; starting point intentionally conservative: run grid','Experimental'],
 ['Acero inoxidable','304/316','Rojo/cobre ligado','Brilliance BLI201MRAS','250','30','50','0.050','1','0','BLI201 is stainless-only; run grid for exact machine','Experimental'],
 ['Acero inoxidable','Pulido','43AYE3 probado','Sin liquido','1200','50','30','0.030','1','0','Valor de trabajo guardado para esta maquina','43AYE3'],
 ['Aluminio','Natural','Negro','Sin liquido','100','100','30','0.020','1','0','LaserTips Raycus 30W','Referencia web'],
 ['Aluminio','Natural','Negro','Brilliance BLI404ABAS','100','33','50','0.050','1','0','BLI404 compatible con Fiber >=30W; empezar con prueba','Experimental'],
 ['Aluminio','Natural','Negro ligado','CerMark LMM6000','100','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG:10W,10cm/s,.002in,>=50kHz','Fabricante'],
 ['Aluminio','Anodizado','Retirar anodizado','Sin liquido','600','30','25','0.030','1','0','LaserTips Raycus 30W painted/anodized-style removal reference','Referencia web'],
 ['Aluminio','Natural','Grabado profundo','Sin liquido','1000','100','30','0.040','25','0','LaserTips Raycus 30W; deep engraving','Referencia web'],
 ['Laton','Desnudo','Marcado','Sin liquido','200','50','20','0.010','1','0','LaserTips Raycus 30W brass coins','Referencia web'],
 ['Laton','G2 / muestra por medir','Tallado inicial editable','Sin liquido','1000','70','30','0.020','10','0','Gweike G2: velocidad/potencia/frecuencia; 10 pasadas y hatch elegidos para muestra. https://www.gweikecloud.com/blogs/gweike-g2/setting-parameter-for-gweike-g2','Experimental'],
 ['Laton','Desnudo','Negro ligado','CerMark LMM6000','100','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG:10W,10cm/s,.002in,>=50kHz','Fabricante'],
 ['Laton','Desnudo','Negro ligado','Brilliance BLI101MBAS','100','35','50','0.050','1','0','BLI101 compatible; run grid','Experimental'],
 ['Cobre','Desnudo','Marcado oscuro','Sin liquido','200','50','20','0.010','1','0','30W brass/copper reference; copper conducts heat strongly','Referencia web'],
 ['Cobre','Desnudo','Negro ligado','Brilliance BLI101MBAS','75','40','50','0.050','2','0','BLI101 compatible; copper needs slower dwell; test grid','Experimental'],
 ['Plata','999 fina','Negro','Sin liquido','100','60','30','0.002','1','0','BWM/LaserTips: Black on Silver, Raycus 30W 70mm','Referencia web'],
 ['Plata','950','Negro','Sin liquido','100','60','30','0.002','1','0','Base 30W Black-on-Silver; aleacion no especificada por fuente','Referencia adaptada'],
 ['Plata','925 Sterling','Negro','Sin liquido','100','60','30','0.002','1','0','BWM: Black on Silver Raycus 30W; test first','Referencia web'],
 ['Plata','925 Sterling','Detalle fino','Sin liquido','1100','32','30','0.030','1','0','Bonny JPT MOPA 30W:1100mm/s 32%; freq/hatch from 30W baseline','Combinado'],
 ['Plata','900','Negro','Sin liquido','100','60','30','0.002','1','0','Base 30W Black-on-Silver; aleacion no especificada por fuente','Referencia adaptada'],
 ['Plata','830','Gris','Sin liquido','1500','90','37','0.010','1','3','Referencia publicada es 80W MOPA/200ns, NO equivalente a 30W','NO APLICAR 30W'],
 ['Plata','Chapada','Negro ligado','CerMark LMM6000','30','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG Silver Plating:10W,3cm/s,.002in,>=50kHz','Fabricante'],
 ['Plata','925 Sterling','Con coating','Brilliance BLI101MBAS','50','100','50','0.050','1','0','Brilliance no recomienda oficialmente plata; algunos usuarios logran 925. Probar','Experimental'],
 ['Oro','18K','Grabado','Sin liquido','700','40','20','0.010','2','0','LaserTips Raycus 30W Gold engraving 18K','Referencia web'],
 ['Oro','Chapado','Negro ligado','CerMark LMM6000','150','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG Gold Plating:10W,15cm/s,.002in,>=50kHz','Fabricante'],
 ['Titanio','Desnudo','Marcado ligado','CerMark LMM6000','300','23.3','50','0.0508','1','0','LMM6000 Fiber/YAG:7W,30cm/s,.002in,>=50kHz','Fabricante'],
 ['Titanio','Desnudo','Marcado','Sin liquido','800','35','30','0.030','1','0','Starting point; color needs pulse control/MOPA','Experimental'],
 ['Acero al carbono','Desnudo','Marcado oscuro','Sin liquido','500','70','20','0.020','6','0','LaserTips 30W iron dog-tag style reference','Referencia web'],
 ['Acero galvanizado','Desnudo','Negro ligado','CerMark LMM6000','200','30','50','0.0508','1','0','LMM6000 Fiber/YAG:9W,20cm/s,.002in,>=50kHz','Fabricante'],
 ['Niquel','Chapado','Negro ligado','CerMark LMM6000','250','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG Nickel Plating:10W,25cm/s,.002in,>=50kHz','Fabricante'],
 ['Cromo','Chapado','Negro ligado','CerMark LMM6000','60','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG Chrome Plating:10W,6cm/s,.002in,>=50kHz','Fabricante'],
 ['Peltre','Desnudo','Negro ligado','CerMark LMM6000','300','33.3','50','0.0508','1','0','LMM6000 Fiber/YAG:10W,30cm/s,.002in,>=50kHz','Fabricante'],
 ['Granito / piedra','Natural','Marcado','Sin liquido','500','30','37','0.050','1','0','LaserTips JPT 30W; cross hatch','Referencia web'],
 ['Vidrio','Compatible','Negro ligado','Brilliance BLI420CGBA','100','30','50','0.050','1','0','BLI420 is glass/ceramic product; exact value requires test grid','Experimental'],
 ['Ceramica','Compatible','Negro ligado','Brilliance BLI420CGBA','100','30','50','0.050','1','0','BLI420 is glass/ceramic product; exact value requires test grid','Experimental'],
 ['PVC','Cualquiera','NO USAR','Sin liquido','','','','','','','No grabar: gases corrosivos/toxicos','NO USAR'],
]

DEFAULT_LIQUIDS=[
 ['Sin liquido','Sin liquido','Materiales compatibles con 1064nm','Superficie limpia y enfocada','Usa el preset directo del material'],
 ['CerMark','LMM6000','Inox, galvanizado, laton, aluminio, chapados cromo/niquel/oro/plata, titanio, peltre','Limpiar, capa uniforme, secar, marcar y lavar','Incluye tabla Fiber/YAG publicada; ajustar con matriz'],
 ['CerMark','ULTRA Aerosol','Metales desnudos: inox, laton, aluminio, titanio, estano, cobre, niquel y otros','Agitar, capa fina uniforme, secar, marcar, lavar y prueba de abrasion','Fabricante da puntos CO2; para Fiber/YAG pide optimizar con test grid'],
 ['Brilliance Laser Inks','BLI101MBAS','Inox, laton, cobre desnudos','Limpiar IPA, capa fina, secar totalmente, air assist OFF, extraccion ON, lavar','Negro; no recomendado oficialmente para plata pura'],
 ['Brilliance Laser Inks','BLI404ABAS','Aluminio desnudo','Limpiar IPA, capa fina, secar totalmente, air assist OFF, extraccion ON, lavar','Negro; Fiber minimo recomendado 30W'],
 ['Brilliance Laser Inks','BLI201MRAS','Acero inoxidable desnudo','Limpiar IPA, capa fina, secar totalmente, air assist OFF, extraccion ON, lavar','Marca rojo/cobre; solo inoxidable'],
 ['Brilliance Laser Inks','BLI420CGBA','Vidrio y ceramica compatibles','Limpiar, capa algo mas gruesa, secar, marcar, lavar','Negro; vidrio/ceramica'],
 ['Generico','Laser Marking Fluid','Definir por usuario','Seguir ficha y SDS del producto','No transferir parametros entre productos sin prueba'],
]

def _load():
    if USER_FILE.exists():
        try:
            d=json.loads(USER_FILE.read_text(encoding='utf-8'))
            # Merge defaults + user rows by exact row so updates add new researched presets without erasing user edits.
            pres=d.get('presets',[]); liq=d.get('liquids',[])
            if d.get('version',2)>=3:return pres,liq
            for row in DEFAULT_ROWS:
                if row not in pres: pres.append(row[:])
            for row in DEFAULT_LIQUIDS:
                if row not in liq: liq.append(row[:])
            return pres,liq
        except Exception: pass
    return [r[:] for r in DEFAULT_ROWS],[r[:] for r in DEFAULT_LIQUIDS]

def _table(cols,rows):
    t=QTableWidget(0,len(cols));t.setHorizontalHeaderLabels(cols);t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows);t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    for row in rows:_append(t,row)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents);return t

def _append(t,row=None):
    r=t.rowCount();t.insertRow(r);row=row or ['']*t.columnCount()
    for c in range(t.columnCount()):t.setItem(r,c,QTableWidgetItem(str(row[c] if c<len(row) else '')))

def _rows(t):return [[t.item(r,c).text() if t.item(r,c) else '' for c in range(t.columnCount())] for r in range(t.rowCount())]

class ManualPresetDialog(QDialog):
    def __init__(self,main,parent=None):
        super().__init__(parent or main);self.setWindowTitle('Agregar parámetros · Biblioteca de materiales')
        form=QFormLayout(self)
        selected=[item for item in main.scene.selectedItems() if hasattr(item,'layer')]
        layer=int(selected[0].layer) if selected else int(main.active_layer)
        cut=main.cuts[layer]
        form.addRow(QLabel(f'Ajustes iniciales de C{layer:02d}. Puedes cambiarlos antes de guardarlos.'))
        self.fields=[]
        initial=[getattr(cut,'material',''),getattr(cut,'material_variant',''),
                 getattr(cut,'preset_objective','Grabado'),getattr(cut,'marking_liquid','Sin liquido'),
                 cut.speed,cut.power,cut.frequency,cut.interval,cut.passes,0,'Ajuste manual','Usuario']
        for index,label in enumerate(COLS):
            if index in (4,5,6,7,9):
                field=QDoubleSpinBox();field.setDecimals(4 if index==7 else 2)
                field.setRange(*{4:(.01,100000),5:(0,100),6:(1,4000),7:(.001,10),9:(-100,100)}[index])
                field.setValue(float(initial[index]))
            elif index==8:
                field=QSpinBox();field.setRange(1,999);field.setValue(int(initial[index]))
            else:field=QLineEdit(str(initial[index]))
            self.fields.append(field);form.addRow(label,field)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);form.addRow(buttons)
    def values(self):
        return [str(field.value()) if isinstance(field,(QDoubleSpinBox,QSpinBox)) else field.text().strip()
                for field in self.fields]
    def accept(self):
        if not self.fields[0].text().strip():
            QMessageBox.warning(self,'Material','Escribe el nombre del material.');self.fields[0].setFocus();return
        super().accept()

class MaterialLibraryDialog(QDialog):
    def __init__(self,main):
        super().__init__(main);self.main=main;self.setWindowTitle('Biblioteca de materiales + liquidos · G2 Pro 30W');self.resize(1480,760)
        v=QVBoxLayout(self)
        info=QLabel('Selecciona MATERIAL + LIQUIDO. La tabla se filtra y muestra los parametros encontrados/adaptados. "AJUSTES SELECCIONADO" los pasa a Cut Info y Cuts / Layers de la capa seleccionada. Haz siempre una prueba en retal.')
        info.setWordWrap(True);v.addWidget(info)
        top=QGroupBox('Seleccion rapida');form=QFormLayout(top);self.material=QComboBox();self.liquid=QComboBox();self.only30=QCheckBox('Ocultar referencias incompatibles con 30W');self.only30.setChecked(True)
        form.addRow('Material',self.material);form.addRow('Liquido de marcado',self.liquid);form.addRow('',self.only30);v.addWidget(top)
        pres,liq=_load();self.all_pres=pres;self.pres=_table(COLS,[]);self.liq=_table(LIQCOLS,liq);v.addWidget(self.pres,1)
        mats=['Todos']+sorted({r[0] for r in pres});self.material.addItems(mats)
        liquids=['Todos']+sorted({r[3] for r in pres});self.liquid.addItems(liquids)
        self.material.currentTextChanged.connect(self.refresh);self.liquid.currentTextChanged.connect(self.refresh);self.only30.toggled.connect(self.refresh);self.refresh()
        h=QHBoxLayout();v.addLayout(h)
        for text,fn in [('AJUSTES SELECCIONADO',self.apply_preset),('Agregar parámetros',self.add_parameters),('Editar fila',self.edit_hint),('Duplicar',self.duplicate),('Eliminar',self.delete),('Gestionar liquidos',self.manage_liquids),('Guardar',self.save),('Importar JSON',self.import_json),('Exportar JSON',self.export_json),('Cerrar',self.accept)]:
            b=QPushButton(text);b.clicked.connect(fn);h.addWidget(b)
    def refresh(self):
        self._sync_visible_edits()
        mat=self.material.currentText();liq=self.liquid.currentText();self.pres.setRowCount(0)
        self._visible_indices=[]
        for index,row in enumerate(self.all_pres):
            if mat not in ('','Todos') and row[0]!=mat:continue
            if liq not in ('','Todos') and row[3]!=liq:continue
            if self.only30.isChecked() and 'NO APLICAR 30W' in row[11]:continue
            _append(self.pres,row)
            self._visible_indices.append(index)
    def add_parameters(self):
        dialog=ManualPresetDialog(self.main,self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        self._sync_visible_edits();row=dialog.values();self.all_pres.append(row)
        try:self._write_library()
        except OSError as e:
            self.all_pres.pop();QMessageBox.warning(self,'Guardar parámetros',f'No se pudo guardar: {e}');return
        for combo,values in ((self.material,[r[0] for r in self.all_pres]),(self.liquid,[r[3] for r in self.all_pres])):
            combo.blockSignals(True);combo.clear();combo.addItems(['Todos']+sorted(set(values)));combo.setCurrentText('Todos');combo.blockSignals(False)
        self.only30.blockSignals(True);self.only30.setChecked(False);self.only30.blockSignals(False)
        self.refresh();self.pres.selectRow(self.pres.rowCount()-1)
        QMessageBox.information(self,'Parámetros guardados',f'{row[0]} · {row[2]}\nGuardados en la biblioteca para volver a utilizarlos.')
    def selected_values(self):
        r=self.pres.currentRow();return None if r<0 else [self.pres.item(r,c).text().strip() if self.pres.item(r,c) else '' for c in range(self.pres.columnCount())]
    def add_preset(self):
        row=['','','','Sin liquido','','','','','','','Usuario','Usuario'];self.all_pres.append(row);self.material.setCurrentText('Todos');self.liquid.setCurrentText('Todos');self.refresh();self.pres.selectRow(self.pres.rowCount()-1);self.pres.editItem(self.pres.item(self.pres.rowCount()-1,0))
    def edit_hint(self):
        if self.pres.currentRow()<0:return QMessageBox.information(self,'Editar','Selecciona una fila.')
        self.pres.editItem(self.pres.item(self.pres.currentRow(),0))
    def _sync_visible_edits(self):
        for index,row in zip(getattr(self,'_visible_indices',[]),_rows(self.pres)):
            self.all_pres[index]=row
    def duplicate(self):
        vals=self.selected_values()
        if vals:self.all_pres.append(vals[:]);self.refresh()
    def delete(self):
        self._sync_visible_edits()
        vals=self.selected_values()
        if not vals:return
        del self.all_pres[self._visible_indices[self.pres.currentRow()]]
        self._visible_indices=[]
        self.refresh()
    def manage_liquids(self):
        d=QDialog(self);d.setWindowTitle('Liquidos de marcado · añadir / editar / quitar');d.resize(1100,500);v=QVBoxLayout(d);v.addWidget(self.liq)
        h=QHBoxLayout();v.addLayout(h)
        add=QPushButton('Añadir');dele=QPushButton('Eliminar');close=QPushButton('Cerrar');h.addWidget(add);h.addWidget(dele);h.addWidget(close)
        add.clicked.connect(lambda:_append(self.liq));dele.clicked.connect(lambda:self.liq.removeRow(self.liq.currentRow()) if self.liq.currentRow()>=0 else None);close.clicked.connect(d.accept);d.exec()
    def save(self):
        self._sync_visible_edits()
        try:self._write_library()
        except OSError as e:return QMessageBox.warning(self,'Guardar biblioteca',f'No se pudo guardar: {e}')
        QMessageBox.information(self,'Biblioteca','Biblioteca guardada.')
    def _write_library(self):
        temporary=USER_FILE.with_suffix('.json.tmp')
        temporary.write_text(json.dumps({'version':3,'presets':self.all_pres,'liquids':_rows(self.liq)},ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(USER_FILE)
    def export_json(self):
        self._sync_visible_edits();p,_=QFileDialog.getSaveFileName(self,'Exportar biblioteca','43aye3_materiales.json','JSON (*.json)')
        if p:Path(p).write_text(json.dumps({'version':3,'presets':self.all_pres,'liquids':_rows(self.liq)},ensure_ascii=False,indent=2),encoding='utf-8')
    def import_json(self):
        p,_=QFileDialog.getOpenFileName(self,'Importar biblioteca','','JSON (*.json)')
        if not p:return
        try:
            d=json.loads(Path(p).read_text(encoding='utf-8'));self._visible_indices=[];self.all_pres=d.get('presets',[]);self.liq=_replace_table(self.liq,LIQCOLS,d.get('liquids',[]));self.refresh()
        except Exception as e:QMessageBox.warning(self,'Importar',str(e))
    def apply_preset(self):
        vals=self.selected_values()
        if not vals:return QMessageBox.information(self,'Ajustes','Selecciona un preset de la tabla.')
        if vals[2].upper()=='NO USAR' or 'NO USAR' in vals[11].upper():return QMessageBox.warning(self,'Material bloqueado','Este material esta marcado como NO USAR.')
        if 'NO APLICAR 30W' in vals[11]:return QMessageBox.warning(self,'Referencia incompatible','Este ajuste procede de otra potencia/fuente y esta marcado para no aplicarlo al G2 Pro 30W.')
        try:
            selected=[x for x in self.main.scene.selectedItems() if hasattr(x,'layer')]
            layer=int(selected[0].layer) if selected else int(self.main.active_layer)
            self.main.set_layer(layer,assign_selection=False)
            cut=self.main.cuts[layer]
            if vals[4]:cut.speed=float(vals[4])
            if vals[5]:cut.power=float(vals[5])
            if vals[6]:cut.frequency=float(vals[6])
            if vals[7]:cut.interval=float(vals[7])
            if vals[8]:cut.passes=int(float(vals[8]))
            # A material preset is normally a filled mark; keep Image mode for raster layers.
            if cut.mode not in ('Image','Offset Fill'):cut.mode='Fill'
            cut.material=vals[0];cut.material_variant=vals[1];cut.marking_liquid=vals[3];cut.preset_objective=vals[2];cut.preset_source=vals[10]
            self.main.update_cut_row(layer)
            if hasattr(self.main,'_sync_cut_controls'):self.main._sync_cut_controls(layer)
            self.main.changed=True
            self.main.statusBar().showMessage(f'C{layer:02d} AJUSTADO · {vals[0]} {vals[1]} · {vals[3]} · V{cut.speed:g} P{cut.power:g} F{cut.frequency:g} I{cut.interval:g} X{cut.passes}')
            QMessageBox.information(self,'Ajustes aplicados',f'Capa C{layer:02d}\n{vals[0]} · {vals[1]}\n{vals[2]} · {vals[3]}\n\nSpeed: {cut.speed:g} mm/s\nPower: {cut.power:g}%\nFrequency: {cut.frequency:g} kHz\nHatch: {cut.interval:g} mm\nPasses: {cut.passes}\n\nActualizado en Cut Info y Cuts / Layers.')
        except Exception as e:QMessageBox.warning(self,'Ajustes',f'No se pudo aplicar: {e}')

def _replace_table(old,cols,rows):
    old.setRowCount(0);old.setColumnCount(len(cols));old.setHorizontalHeaderLabels(cols)
    for r in rows:_append(old,r)
    return old

def open_library(main,add_parameters=False):
    dialog=MaterialLibraryDialog(main)
    if add_parameters:dialog.add_parameters()
    dialog.exec()
