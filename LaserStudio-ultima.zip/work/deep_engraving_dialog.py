"""Graphical setup for vector depth engraving on the G2."""
import math
from pathlib import Path

from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
                               QFormLayout, QGroupBox, QLabel, QPushButton, QSpinBox,
                               QVBoxLayout, QWidget, QComboBox, QHBoxLayout, QScrollArea, QLineEdit, QMessageBox)


class HatchPreview(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.angle = 45.0
        self.cross = True
        self.interval = .02
        self.setMinimumSize(260, 170)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor('#f4f6fa'))
        target = QRectF(36, 18, max(40, self.width()-72), max(40, self.height()-36))
        p.setPen(QPen(QColor('#3568a0'), 2))
        p.setBrush(QColor('#e5eff9'))
        p.drawRoundedRect(target, 16, 16)
        p.save()
        from PySide6.QtGui import QPainterPath
        clip = QPainterPath()
        clip.addRoundedRect(target, 16, 16)
        p.setClipPath(clip)
        p.translate(target.center())
        # This depicts orientation and relative density, not machine coordinates.
        spacing = max(5.0, min(23.0, 5.0 + 110.0*self.interval))
        length = math.hypot(self.width(), self.height())
        p.setPen(QPen(QColor('#3976b8'), 1))
        for angle in ([self.angle, self.angle+90] if self.cross else [self.angle]):
            p.save()
            p.rotate(angle)
            for i in range(-math.ceil(length/spacing), math.ceil(length/spacing)+1):
                y = i*spacing
                p.drawLine(-length, y, length, y)
            p.restore()
        p.restore()
        p.end()


class DeepEngravingDialog(QDialog):
    def __init__(self, layer, cut, vector_count, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Tallado en profundidad · G2')
        self.setMinimumWidth(440)
        layout = QVBoxLayout(self)
        note = QLabel(f'{vector_count} vector(es) seleccionados · pluma C{layer:02d}. '
                      'Los ajustes de la pluma se aplicarán a todos los objetos de esta capa.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.preview = HatchPreview()
        layout.addWidget(self.preview)
        hint = QLabel('Vista orientativa del rayado. La profundidad real depende del material, foco y número de pasadas; no se expresa en mm.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        controls = QGroupBox('Parámetros de tallado')
        form = QFormLayout(controls)
        self.passes = QSpinBox(); self.passes.setRange(1, 999); self.passes.setValue(cut.passes)
        self.pass_mode=QComboBox();self.pass_mode.addItems(['Manual','Propuesta biblioteca / pluma · editable'])
        self.proposal_note=QLabel('Puedes introducir las pasadas o utilizar tus ajustes de material.');self.proposal_note.setWordWrap(True)
        def suggest():
            from depth_map_tools import propose_passes
            value,note=propose_passes(cut);self.passes.setValue(value);self.proposal_note.setText(note)
        self.pass_mode.currentIndexChanged.connect(lambda index:suggest() if index==1 else None)
        form.addRow('Elección de pasadas',self.pass_mode);form.addRow(self.proposal_note)
        self.interval = QDoubleSpinBox(); self.interval.setRange(.001, 10); self.interval.setDecimals(3); self.interval.setSingleStep(.005); self.interval.setSuffix(' mm'); self.interval.setValue(cut.interval)
        self.angle = QDoubleSpinBox(); self.angle.setRange(-360, 360); self.angle.setDecimals(1); self.angle.setSuffix(' °'); self.angle.setValue(cut.angle)
        self.cross = QCheckBox('Segunda dirección perpendicular'); self.cross.setChecked(cut.cross)
        self.speed = QDoubleSpinBox(); self.speed.setRange(.01, 100000); self.speed.setDecimals(2); self.speed.setSuffix(' mm/s'); self.speed.setValue(cut.speed)
        self.power = QDoubleSpinBox(); self.power.setRange(0, 100); self.power.setDecimals(1); self.power.setSuffix(' %'); self.power.setValue(cut.power)
        self.frequency = QDoubleSpinBox(); self.frequency.setRange(1, 4000); self.frequency.setDecimals(1); self.frequency.setSuffix(' kHz'); self.frequency.setValue(cut.frequency)
        for title, field in [('Pasadas', self.passes), ('Intervalo entre líneas', self.interval),
                             ('Ángulo', self.angle), ('Relleno cruzado', self.cross),
                             ('Velocidad', self.speed), ('Potencia', self.power), ('Frecuencia', self.frequency)]:
            form.addRow(title, field)
        layout.addWidget(controls)
        cleaning = QGroupBox('Pasada final de limpieza')
        clean_form = QFormLayout(cleaning)
        self.cleanup = QCheckBox('Ejecutar una pasada tras completar el tallado')
        self.cleanup.setChecked(bool(getattr(cut, 'depth_cleanup', False)))
        self.cleanup_speed = QDoubleSpinBox(); self.cleanup_speed.setRange(.01, 100000); self.cleanup_speed.setDecimals(2); self.cleanup_speed.setSuffix(' mm/s'); self.cleanup_speed.setValue(getattr(cut, 'cleanup_speed', 1000.))
        self.cleanup_power = QDoubleSpinBox(); self.cleanup_power.setRange(0, 100); self.cleanup_power.setDecimals(1); self.cleanup_power.setSuffix(' %'); self.cleanup_power.setValue(getattr(cut, 'cleanup_power', 10.))
        self.cleanup_frequency = QDoubleSpinBox(); self.cleanup_frequency.setRange(1, 4000); self.cleanup_frequency.setDecimals(1); self.cleanup_frequency.setSuffix(' kHz'); self.cleanup_frequency.setValue(getattr(cut, 'cleanup_frequency', 30.))
        for title, field in [('Activar', self.cleanup), ('Velocidad', self.cleanup_speed), ('Potencia', self.cleanup_power), ('Frecuencia', self.cleanup_frequency)]:
            clean_form.addRow(title, field)
        for field in (self.cleanup_speed, self.cleanup_power, self.cleanup_frequency):
            field.setEnabled(self.cleanup.isChecked())
            self.cleanup.toggled.connect(field.setEnabled)
        note_cleanup = QLabel('Recorre el mismo relleno una vez con los parámetros elegidos. Su capacidad para desprender residuos depende del material; comprueba el resultado en una muestra.')
        note_cleanup.setWordWrap(True); clean_form.addRow(note_cleanup)
        layout.addWidget(cleaning)
        preset = QPushButton('Latón · punto inicial editable: 10 pasadas · 0,02 mm')
        preset.setToolTip('Base Gweike G2 para latón: 1000 mm/s, 70%, 30 kHz. Intervalo 0,02 mm y 10 pasadas son una propuesta de prueba, sin profundidad calibrada.')
        preset.clicked.connect(self.load_reference)
        layout.addWidget(preset)
        for widget in (self.interval, self.angle): widget.valueChanged.connect(self.update_preview)
        self.cross.toggled.connect(self.update_preview)
        self.update_preview()
        self.pass_mode.setCurrentIndex(1 if getattr(cut,'depth_pass_mode','manual')=='assisted' else 0)
        self.passes.setValue(cut.passes)
        # ApplyRole does not emit QDialogButtonBox.accepted; use an accepting button.
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText('Aplicar a pluma')
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def load_reference(self):
        self.passes.setValue(10); self.interval.setValue(.02); self.angle.setValue(45)
        self.cross.setChecked(True); self.speed.setValue(1000); self.power.setValue(70)
        self.frequency.setValue(30)
        self.proposal_note.setText('Base Gweike G2: 1000 / 70 / 30.\nPasadas e intervalo propuestos; mide una muestra.')

    def update_preview(self, *args):
        self.preview.interval = self.interval.value()
        self.preview.angle = self.angle.value()
        self.preview.cross = self.cross.isChecked()
        self.preview.update()

    def apply_to(self, cut):
        cut.depth_pass_mode='assisted' if self.pass_mode.currentIndex()==1 else 'manual'
        cut.mode = 'Fill'
        cut.passes = self.passes.value()
        cut.interval = self.interval.value()
        cut.angle = self.angle.value()
        cut.cross = self.cross.isChecked()
        cut.speed = self.speed.value()
        cut.power = self.power.value()
        cut.frequency = self.frequency.value()
        cut.depth_cleanup = self.cleanup.isChecked()
        cut.cleanup_speed = self.cleanup_speed.value()
        cut.cleanup_power = self.cleanup_power.value()
        cut.cleanup_frequency = self.cleanup_frequency.value()


class ImageDepthDialog(QDialog):
    """Pass-count depth map settings stored on the image, not the whole layer."""
    def __init__(self, item, cut, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f'Preparar tallado · capa C{getattr(item, "layer", 0):02d}')
        self.item=item;self._applied_item=None
        s = item.image_settings
        import copy
        self._target_cut=cut;self.cut=copy.deepcopy(cut)
        self.resize(700,780)
        outer=QVBoxLayout(self);body=QWidget();form=QFormLayout(body);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(body);outer.addWidget(scroll)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows);scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        note = QLabel('Configura las pasadas y la pluma de esta imagen. Guardar tallado y pluma aplica los ajustes a la capa y vuelve al lienzo. Negro: máximo de pasadas. Blanco: ninguna. Los grises siguen la curva medida cuando se selecciona una calibración. La profundidad física depende del material y del enfoque.')
        note.setWordWrap(True); form.addRow(note)
        self.enabled = QCheckBox('Usar la imagen como mapa de profundidad')
        self.enabled.setChecked(bool(s.get('depth_enabled', False)))
        self.passes = QSpinBox(); self.passes.setRange(1,999); self.passes.setValue(int(s.get('depth_passes',max(1,int(cut.passes)))))
        self.pass_mode=QComboBox();self.pass_mode.addItems(['Manual','Propuesta asistida · editable'])
        self.proposal_note=QLabel('Introduce las pasadas máximas o solicita una propuesta.');self.proposal_note.setWordWrap(True)
        def suggest():
            from depth_map_tools import propose_passes
            value,note=propose_passes(cut,item.original_source);self.passes.setValue(value);self.proposal_note.setText(note)
        self.pass_mode.currentIndexChanged.connect(lambda index:suggest() if index==1 else None)
        form.addRow('Elección de pasadas',self.pass_mode);form.addRow(self.proposal_note)
        self.pass_mode.setCurrentIndex(1 if s.get('depth_pass_mode')=='assisted' else 0)
        if s.get('depth_passes') is not None:self.passes.setValue(int(s['depth_passes']))
        self.mm_enabled=QCheckBox('Calcular pasadas desde profundidad objetivo en mm');self.mm_enabled.setChecked(bool(s.get('depth_mm_enabled',False)))
        self.target_mm=QDoubleSpinBox();self.target_mm.setRange(.001,100);self.target_mm.setDecimals(3);self.target_mm.setSuffix(' mm');self.target_mm.setValue(float(s.get('depth_target_mm',.2)))
        self.measured_mm=QDoubleSpinBox();self.measured_mm.setRange(0,100);self.measured_mm.setDecimals(4);self.measured_mm.setSuffix(' mm');self.measured_mm.setValue(float(s.get('depth_measured_mm',0)))
        self.calibration_passes=QSpinBox();self.calibration_passes.setRange(1,999);self.calibration_passes.setValue(int(s.get('depth_calibration_passes',10)))
        for label,widget in [('Modo mm',self.mm_enabled),('Profundidad objetivo máxima',self.target_mm),('Profundidad medida en muestra',self.measured_mm),('Pasadas de la muestra',self.calibration_passes)]:form.addRow(label,widget)
        self.profile=QComboBox();self.profile.setMinimumContentsLength(20);self.profile.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon);self.profile.addItem('Lineal: una muestra (estimación)',None)
        from depth_calibration import load_profiles
        snapshot=s.get('depth_calibration_profile')
        if snapshot:self.profile.addItem('Curva guardada en este trabajo · '+snapshot['name'],snapshot)
        for p in load_profiles():self.profile.addItem(p['name']+' · '+p['material'],p)
        if snapshot:self.profile.setCurrentIndex(1)
        row=QHBoxLayout();row.addWidget(self.profile)
        manage=QPushButton('Medir / editar perfiles…');manage.clicked.connect(self.manage_profiles);row.addWidget(manage)
        form.addRow('Curva medida',row)
        self.apply_pen=QPushButton('Cargar pluma e intervalo de la curva');self.apply_pen.clicked.connect(self.apply_profile_pen);form.addRow(self.apply_pen)
        self.material=QLineEdit(str(getattr(cut,'material','')));form.addRow('Material de la pluma',self.material)
        self.pen_fields={}
        for key,label,minimum,maximum in [('speed','Velocidad de tallado',.01,100000),('power','Potencia de tallado',.0001,100),('frequency','Frecuencia de tallado',.0001,4000)]:
            field=QDoubleSpinBox();field.setDecimals(6);field.setRange(minimum,maximum);field.setValue(float(getattr(cut,key)))
            field.setSuffix(' mm/s' if key=='speed' else ' %' if key=='power' else ' kHz');self.pen_fields[key]=field;form.addRow(label,field)
        self.pen_note=QLabel('Edita la pluma aquí. Los cambios se guardan en la capa al pulsar Guardar tallado y pluma.');self.pen_note.setWordWrap(True);form.addRow(self.pen_note)
        self.mm_note=QLabel('Calibración del mismo material, foco, intervalo y pluma. Estimación lineal; comprueba la profundidad conseguida.');self.mm_note.setWordWrap(True);form.addRow(self.mm_note)
        self.interval = QDoubleSpinBox(); self.interval.setRange(.0001,10); self.interval.setDecimals(6); self.interval.setSuffix(' mm'); self.interval.setValue(float(s.get('depth_interval',s.get('interval',.1))))
        self.cleanup = QCheckBox('Pasada final de limpieza sobre la zona tallada')
        self.cleanup.setChecked(bool(s.get('depth_cleanup',False)))
        self.speed = QDoubleSpinBox(); self.speed.setRange(.01,100000); self.speed.setSuffix(' mm/s'); self.speed.setValue(float(s.get('depth_cleanup_speed',1000.)))
        self.power = QDoubleSpinBox(); self.power.setRange(0,100); self.power.setSuffix(' %'); self.power.setValue(float(s.get('depth_cleanup_power',10.)))
        self.frequency = QDoubleSpinBox(); self.frequency.setRange(1,4000); self.frequency.setSuffix(' kHz'); self.frequency.setValue(float(s.get('depth_cleanup_frequency',30.)))
        for label, widget in [('Activar',self.enabled),('Máximo de pasadas',self.passes),('Intervalo',self.interval),('Limpieza final',self.cleanup),('Velocidad limpieza',self.speed),('Potencia limpieza',self.power),('Frecuencia limpieza',self.frequency)]:
            form.addRow(label,widget)
        def sync_mm(*args):
            self.apply_pen.setEnabled(bool(self.profile.currentData()));self.apply_pen.setToolTip('Selecciona una curva medida guardada para cargar su pluma.' if not self.profile.currentData() else 'Carga los valores medidos; después guarda el tallado para aplicarlos a la capa.')
            enabled=self.mm_enabled.isChecked();self.passes.setEnabled(not enabled);self.pass_mode.setEnabled(not enabled)
            self.target_mm.setEnabled(enabled)
            for control in (self.measured_mm,self.calibration_passes):control.setEnabled(enabled and not self.profile.currentData())
            if enabled:
                from depth_map_tools import passes_from_mm
                try:
                    count,rate=self.compute_passes();self.passes.setValue(count)
                    p=self.profile.currentData()
                    self.mm_note.setText(f'Curva medida: {p["name"]} · {count} pasadas máximas · rango 0 - {p["points"][-1][1]:g} mm · enfoque anotado {p.get("focus_mm",0):g} mm. Verifica el foco real.' if p else f'Estimación lineal: {count} pasadas máximas · {rate:.5f} mm/pasada. Para calibrar usa varios puntos medidos.')
                except ValueError as exc:self.mm_note.setText(str(exc))
        for control in (self.target_mm,self.measured_mm,self.calibration_passes):control.valueChanged.connect(sync_mm)
        self.mm_enabled.toggled.connect(sync_mm);self.profile.currentIndexChanged.connect(sync_mm);sync_mm()
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Save).setText('Guardar tallado y pluma')
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); outer.addWidget(bb)

    def compute_passes(self):
        p=self.profile.currentData()
        if p:
            from depth_calibration import maximum_passes
            return maximum_passes(self.target_mm.value(),p),0
        from depth_map_tools import passes_from_mm
        return passes_from_mm(self.target_mm.value(),self.measured_mm.value(),self.calibration_passes.value())

    def manage_profiles(self):
        from depth_calibration_ui import CalibrationLibraryDialog
        dialog=CalibrationLibraryDialog(self.cut,self.interval.value(),self)
        if dialog.exec() and dialog.selected_profile:
            p=dialog.selected_profile;self.profile.addItem(p['name']+' · '+p['material'],p);self.profile.setCurrentIndex(self.profile.count()-1);self.mm_enabled.setChecked(True)

    def sync_pen(self):
        for key,field in self.pen_fields.items():setattr(self.cut,key,field.value())
        self.cut.material=self.material.text().strip();self.cut.interval=self.interval.value()

    def apply_profile_pen(self):
        p=self.profile.currentData()
        if not p:
            self.pen_note.setText('Selecciona una curva medida guardada. Para la estimación lineal, introduce la pluma de tu muestra en los campos de tallado.');return
        for key,field in self.pen_fields.items():field.setValue(p['pen'][key])
        self.material.setText(p['material']);self.interval.setValue(p['pen']['interval']);self.sync_pen()
        self.pen_note.setText(f'Pluma cargada: {p["material"]} · {self.cut.speed:g} mm/s · {self.cut.power:g} % · {self.cut.frequency:g} kHz · intervalo {self.interval.value():g} mm. Pulsa Guardar tallado y pluma para aplicarla a la capa.')

    def accept(self):
        try:
            self.apply_to(self.item)
        except Exception as exc:
            QMessageBox.information(self,'No se pudo guardar el tallado',str(exc));return
        super().accept()

    def apply_to(self, item):
        if self._applied_item is item:return
        self.sync_pen()
        if self.enabled.isChecked() and (self.cut.speed<=0 or self.cut.power<=0 or self.cut.frequency<=0):raise ValueError('Introduce velocidad, potencia y frecuencia de tallado mayores que cero.')
        updates=dict(item.image_settings);rate=0;count=self.passes.value()
        if self.mm_enabled.isChecked():
            count,rate=self.compute_passes()
            updates['depth_calibration_pen']={'speed':float(self.cut.speed),'power':float(self.cut.power),'frequency':float(self.cut.frequency),'interval':self.interval.value()}
            profile=self.profile.currentData()
            if profile:
                from depth_calibration import assert_matching,export_calibrated
                profile=assert_matching(profile,self.cut,self.interval.value())
                from laser_image_pipeline import prepare
                source=prepare(item.original_source,mode='Grayscale',**{k:updates[k] for k in ('brightness','darkness','contrast','gamma','sharpen','invert','threshold','dpi') if k in updates})
                updates['depth_mm_map']=export_calibrated(source,self.target_mm.value(),profile,Path(__file__).resolve().parent/'DEPTH_MAPS')
                updates['depth_calibration_profile']=profile
            else:
                from depth_map_tools import export_mm_map
                updates.pop('depth_calibration_profile',None)
                updates['depth_mm_map']=export_mm_map(item.original_source,self.target_mm.value(),self.measured_mm.value(),self.calibration_passes.value(),output_dir=Path(__file__).resolve().parent/'DEPTH_MAPS')
        updates.update(depth_mm_enabled=self.mm_enabled.isChecked(),depth_target_mm=self.target_mm.value(),depth_measured_mm=self.measured_mm.value(),depth_calibration_passes=self.calibration_passes.value(),depth_mm_per_pass=rate,
            depth_pass_mode='assisted' if self.pass_mode.currentIndex()==1 else 'manual',depth_enabled=self.enabled.isChecked(),depth_passes=count,
            depth_interval=self.interval.value(),depth_cleanup=self.cleanup.isChecked(),depth_cleanup_speed=self.speed.value(),depth_cleanup_power=self.power.value(),depth_cleanup_frequency=self.frequency.value())
        for key in ('speed','power','frequency','material','interval'):setattr(self._target_cut,key,getattr(self.cut,key))
        if self.enabled.isChecked():
            self._target_cut.mode='Image'
            updates['mode']='Grayscale'
        item.image_settings.clear();item.image_settings.update(updates);self.passes.setValue(count);self._applied_item=item
