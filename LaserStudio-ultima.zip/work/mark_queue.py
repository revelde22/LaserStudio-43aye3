"""Prepare a native mark queue preserving layer parameters and block order."""
from pathlib import Path
import tempfile

def write_mark_queue(groups, directory):
    folder=Path(tempfile.mkdtemp(prefix='mark_queue_',dir=str(directory)))
    try:
        names=[]
        for index,(layer,paths,passes,speed,power,khz) in enumerate(groups):
            name=f'block_{index:06d}.txt'
            (folder/name).write_text(
                f'{len(paths)} {passes} {speed:.4f} {power:.4f} {khz:.4f}\n'+
                ''.join(str(len(path))+'\n'+''.join(f'{x:.4f} {y:.4f}\n' for x,y in path)
                        for path in paths),encoding='ascii')
            names.append(name)
        manifest=folder/'queue.txt'
        manifest.write_text('\n'.join(names)+'\n',encoding='ascii')
        return manifest
    except Exception:
        import shutil
        shutil.rmtree(folder,ignore_errors=True)
        raise
