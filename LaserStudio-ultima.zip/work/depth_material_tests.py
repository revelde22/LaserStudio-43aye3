"""Fixed-recipe depth coupons; prepare only, never call a laser backend."""
import copy,json,math,uuid
from datetime import datetime,timezone
from pathlib import Path

def validate_recipe(recipe):
 recipe=copy.deepcopy(recipe)
 if not str(recipe.get('material','')).strip():raise ValueError('Introduce el material y acabado de la muestra.')
 counts=recipe['passes']
 if not 2<=len(counts)<=8 or any(not isinstance(n,int) or not 1<=n<=999 for n in counts) or sorted(set(counts))!=counts:raise ValueError('Introduce de 2 a 8 cantidades de pasadas distintas, crecientes, de 1 a 999.')
 for key in ('speed','power','frequency','interval','side_mm'):
  value=float(recipe[key])
  if not math.isfinite(value) or value<=0:raise ValueError('Valor positivo requerido: '+key)
 if recipe['power']>100 or not 1<=recipe['frequency']<=4000 or recipe['speed']>100000 or not 2<=recipe['side_mm']<=15 or recipe['interval']>recipe['side_mm']:raise ValueError('Revisa potencia, tamaño de muestra e intervalo.')
 if not math.isfinite(float(recipe['focus_mm'])):raise ValueError('Enfoque anotado no válido.')
 return recipe

def generate_coupons(main,recipe,isolate=True):
 from laser_studio import GItem,Cut,COLORS
 from PySide6.QtCore import QRectF,Qt
 from PySide6.QtGui import QPainterPath,QPen,QBrush,QColor
 recipe=validate_recipe(recipe);side=recipe['side_mm'];count=len(recipe['passes']);cols=min(4,count);rows=math.ceil(count/cols);pitch=side+4
 from g2_native_frame import load_calibration
 field=load_calibration().field_mm;width=cols*pitch-4;height=rows*pitch-4
 if width>field or height>field:raise ValueError('Las muestras no caben en el campo calibrado. Reduce su tamaño.')
 start_x=(field-width)/2;start_y=(field-height)/2
 occupied={item.layer for item in main.scene.items() if hasattr(item,'layer')}
 free=[]
 for layer in range(1024):
  if layer not in occupied and (layer>=len(main.cuts) or main.cuts[layer].dict()==Cut(layer).dict()):free.append(layer)
  if len(free)==count:break
 if len(free)<count:raise ValueError('No hay suficientes capas libres para estas pruebas.')
 main.ensure_cut_capacity(max(free)+1)
 made=[];positions=[]
 for index,(layer,passes) in enumerate(zip(free,recipe['passes'])):
  cut=main.cuts[layer];cut.name=f'Tallado {passes} pasadas';cut.mode='Fill';cut.material=recipe['material'];cut.passes=passes
  for key in ('speed','power','frequency','interval'):setattr(cut,key,recipe[key])
  cut.angle=0;cut.cross=False;cut.output=True;cut.show=True;cut.depth_cleanup=False
  x=start_x+(index%cols)*pitch;y=start_y+(index//cols)*pitch
  path=QPainterPath();path.addRect(QRectF(x,y,side,side));item=GItem(path,'depth_coupon');item.layer=layer
  color=QColor(COLORS[layer%len(COLORS)]);item.setPen(QPen(color,0));item.setBrush(QBrush(color));main.scene.addItem(item)
  item.test_settings=dict(recipe,passes=passes,test_kind='depth_coupon');made.append(item)
  positions.append(dict(layer=layer,passes=passes,x_mm=x,y_mm=y,side_mm=side))
  main.update_cut_row(layer)
 if isolate:
  for index,cut in enumerate(main.cuts):
   if index not in free and cut.output:cut.output=False;main.update_cut_row(index)
 main.scene.clearSelection()
 for item in made:item.setSelected(True)
 main.changed=True;main.set_layer(free[0],assign_selection=False);main.schedule_preview()
 main.view.fitInView(QRectF(start_x-2,start_y-2,width+4,height+4),Qt.AspectRatioMode.KeepAspectRatio)
 return dict(id=uuid.uuid4().hex,created_utc=datetime.now(timezone.utc).isoformat(),kind='depth_coupon_test',recipe=recipe,positions=positions,measurement_status='pending')

def assert_test_unchanged(main,record):
 recipe=record['recipe']
 for position in record['positions']:
  cut=main.cuts[position['layer']]
  for key in ('speed','power','frequency','interval'):
   if not math.isclose(float(getattr(cut,key)),recipe[key],rel_tol=0,abs_tol=1e-8):raise ValueError('La pluma de las pruebas cambió. Genera otro ensayo o restaura sus valores: '+key)
  if cut.passes!=position['passes'] or cut.material!=recipe['material'] or cut.mode!='Fill' or cut.cross or cut.angle!=0:raise ValueError('Los ajustes de las capas de prueba cambiaron; no guardes esa curva como si correspondiera al ensayo inicial.')
  matches=[item for item in main.scene.items() if getattr(item,'kind',None)=='depth_coupon' and item.layer==position['layer']]
  if len(matches)!=1:raise ValueError('Falta una muestra de la prueba en el proyecto.')
  rect=matches[0].sceneBoundingRect()
  # Scene geometry has a cosmetic pen; compare mapped path, without its stroke.
  rect=matches[0].mapToScene(matches[0].path()).boundingRect()
  actual=(rect.x(),rect.y(),rect.width(),rect.height());expected=(position['x_mm'],position['y_mm'],position['side_mm'],position['side_mm'])
  if any(not math.isclose(a,b,abs_tol=1e-6) for a,b in zip(actual,expected)):raise ValueError('Una muestra cambió de tamaño o posición. Revisa el ensayo antes de calibrar.')

def write_record(record,folder=None):
 folder=Path(folder or Path(__file__).resolve().parent/'DEPTH_TESTS');folder.mkdir(parents=True,exist_ok=True)
 path=folder/(record['id']+'.json');temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');temporary.replace(path);return str(path)

def measured_profile(record,depths,name):
 from depth_calibration import validate_profile
 if len(depths)!=len(record['positions']):raise ValueError('Falta una medición por muestra.')
 recipe=record['recipe']
 return validate_profile(dict(id=record['id'],name=name,material=recipe['material'],points=[[position['passes'],float(depth)] for position,depth in zip(record['positions'],depths)],pen={key:recipe[key] for key in ('speed','power','frequency','interval')},focus_mm=recipe['focus_mm'],test_origin=dict(test_id=record['id'],created_utc=record['created_utc'],side_mm=recipe['side_mm'],strategy='unidirectional_angle_0_no_cleanup',locally_measured=True)))
