from __future__ import annotations
import os, struct, subprocess, tempfile, shutil, uuid
from pathlib import Path
from bsl_sdk_loader import detect_sdk_dll, report as sdk_auto_report, write_manifest

APP=Path(__file__).resolve().parent
RUNTIME=APP/'G2_RUNTIME'
SDKDIR=APP/'BSL_SDK'
BRIDGE_DIR=APP/'native_bridge_x86'
SDK_RUNTIME=APP/'BSL_RUNTIME'
EXE=BRIDGE_DIR/'43aye3_bsl_sdk_bridge_x86.exe'
SRC=BRIDGE_DIR/'device_bsl_sdk_bridge_x86.cpp'
BAT=APP/'COMPILAR_SDK_BSL.bat'

class NativeOrzxError(RuntimeError): pass

SUPPORTED_IMAGE_EXTS={'.gif','.jpg','.jpeg','.png','.bmp','.tif','.tiff','.emf'}

def _prepare_sdk_runtime():
    """Crea un runtime autocontenido G2 + SDK detectado por exports.

    No depende del nombre de la DLL: escanea recursivamente BSL_SDK, elige la
    DLL x86 que expone BSL_NewFile/SaveEntLib/AddLines/SetPen y copia todo el
    paquete del SDK junto al runtime G2.
    """
    try:
        selected=detect_sdk_dll(SDKDIR, require_x86=True)
    except Exception as e:
        raise NativeOrzxError(str(e)) from e
    sdk_files=[x for x in SDKDIR.rglob('*') if x.is_file()]
    if not sdk_files:
        raise NativeOrzxError('BSL_SDK esta vacia.')
    marker=SDK_RUNTIME/'.43aye3_sdk_ready'
    manifest=SDK_RUNTIME/'43aye3_sdk_detected.json'
    newest=max([x.stat().st_mtime for x in sdk_files]+[x.stat().st_mtime for x in RUNTIME.rglob('*') if x.is_file()])
    if marker.exists() and manifest.exists() and marker.stat().st_mtime>=newest:
        try:
            import json
            m=json.loads(manifest.read_text(encoding='utf-8'))
            if Path(m.get('path','')).name == Path(selected.path).name:
                return SDK_RUNTIME
        except Exception:
            pass
    if SDK_RUNTIME.exists(): shutil.rmtree(SDK_RUNTIME)
    SDK_RUNTIME.mkdir(parents=True,exist_ok=True)
    for src in RUNTIME.rglob('*'):
        if not src.is_file(): continue
        if src.name.lower()=='glaser.exe': continue
        rel=src.relative_to(RUNTIME); dst=SDK_RUNTIME/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    # Copia el paquete SDK completo manteniendo estructura y, ademas, aplana DLL/CFG
    # en la raiz para que Windows resuelva dependencias antiguas del SDK 5.x.
    for src in sdk_files:
        rel=src.relative_to(SDKDIR); dst=SDK_RUNTIME/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
        if src.suffix.lower() in {'.dll','.cfg','.ini','.dat'} and src.name.casefold()!='43aye3_bsl_compat.dll':
            rootdst=SDK_RUNTIME/src.name
            try:
                # Los archivos del SDK tienen prioridad sobre homonimos del runtime.
                shutil.copy2(src,rootdst)
            except Exception:
                pass
    selected_src=Path(selected.path)
    # Fuerza la DLL elegida a raiz con su nombre original.
    shutil.copy2(selected_src, SDK_RUNTIME/selected_src.name)
    write_manifest(manifest, selected)
    marker.write_text('43AYE3 BSL SDK runtime auto-detected\n',encoding='utf-8')
    return SDK_RUNTIME

def _polylines(geometry):
    out=[]
    if isinstance(geometry,list):
        for seg in geometry:
            if isinstance(seg,(tuple,list)) and len(seg)>=2 and hasattr(seg[0],'x'):
                pts=[(float(p.x()),float(p.y())) for p in seg]
                if len(pts)>=2: out.append(pts)
        return out
    if hasattr(geometry,'toSubpathPolygons'):
        for poly in geometry.toSubpathPolygons():
            pts=[(float(p.x()),float(p.y())) for p in poly]
            if len(pts)>=2: out.append(pts)
    return out

def _image_record(op):
    g=op.geometry if isinstance(op.geometry,dict) else {}
    rect=g.get('rect') or (0,0,0,0)
    x,y,w,h=[float(v) for v in rect]
    # Prefer preview because it includes the current image adjustments and is normally PNG.
    choices=[g.get('preview'),g.get('source')]
    path=None
    for c in choices:
        if c and Path(c).is_file() and Path(c).suffix.lower() in SUPPORTED_IMAGE_EXTS:
            path=str(Path(c).resolve()); break
    if not path:
        raise NativeOrzxError(f'C{int(op.layer):02d}: la imagen no tiene un archivo PNG/JPG/BMP/TIF/EMF compatible disponible.')
    return {
        'pen': max(0,min(255,int(op.layer))),
        'path': path,
        'w': max(0.001,w),'h': max(0.001,h),
        'cx': x+w/2.0,'cy': y+h/2.0,'rot': 0.0,
    }

def _job_data(main,selected_only=False):
    from laser_job import from_scene
    job=from_scene(main,selected_only=selected_only)
    if not job.operations: raise NativeOrzxError('El trabajo no contiene geometría exportable.')
    pens={}; lines_by_pen={}; images=[]
    for op in job.operations:
        pen=max(0,min(255,int(op.layer)))
        pens.setdefault(pen,(max(1,min(255,int(op.passes))),float(op.speed),float(op.power),float(op.frequency)))
        if str(op.kind).lower()=='image':
            images.append(_image_record(op)); continue
        lines=lines_by_pen.setdefault(pen,[])
        for pts in _polylines(op.geometry):
            clean=[]
            for x,y in pts:
                if -100000.0 < x < 100000.0 and -100000.0 < y < 100000.0:
                    clean.append((x,y))
            if len(clean)>=2: lines.append(clean)
    if not any(lines_by_pen.values()) and not images:
        raise NativeOrzxError('No hay líneas, vectores o imágenes compatibles para ORZX.')
    return job,pens,lines_by_pen,images

def _write_u16_string(f,text):
    data=str(text).encode('utf-16le')
    f.write(struct.pack('<I',len(data)//2)); f.write(data)

def _write_input(path,pens,lines_by_pen,images):
    groups=[(pen,lines) for pen,lines in sorted(lines_by_pen.items()) if lines]
    with open(path,'wb') as f:
        f.write(struct.pack('<8sIII',b'43BSL501',len(pens),len(groups),len(images)))
        for pen,(passes,speed,power,freq_khz) in sorted(pens.items()):
            f.write(struct.pack('<IIddd',pen,passes,speed,power,freq_khz))
        for pen,lines in groups:
            f.write(struct.pack('<II',pen,len(lines)))
            for pts in lines:
                f.write(struct.pack('<I',len(pts)))
                for x,y in pts: f.write(struct.pack('<dd',x,y))
        for rec in images:
            f.write(struct.pack('<Iddddd',rec['pen'],rec['w'],rec['h'],rec['cx'],rec['cy'],rec['rot']))
            _write_u16_string(f,rec['path'])

def _build(timeout=180):
    p=subprocess.run(['cmd.exe','/d','/c',str(BAT)],cwd=str(APP),capture_output=True,text=True,timeout=timeout,
                     creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return p.returncode==0,(p.stdout+'\n'+p.stderr)

def _ensure_bridge():
    if os.name!='nt': raise NativeOrzxError('El puente BSL SDK requiere Windows.')
    if (not EXE.exists()) or (SRC.exists() and SRC.stat().st_mtime>EXE.stat().st_mtime):
        ok,log=_build()
        if not ok or not EXE.exists(): raise NativeOrzxError('No se pudo compilar el puente 43AYE3 G2 SDK x86.\n'+log[-7000:])

def sdk_status():
    try:
        base_report=sdk_auto_report(SDKDIR)
        selected=detect_sdk_dll(SDKDIR, require_x86=True)
    except Exception as e:
        return ('MISSING' if not list(SDKDIR.rglob('*.dll')) else 'INVALID', sdk_auto_report(SDKDIR)+'\n\n'+str(e))
    if os.name!='nt':
        return ('PRESENT_UNCHECKED', base_report+'\nLa validacion de carga real se ejecuta en Windows.')
    try:
        _ensure_bridge()
        rt=_prepare_sdk_runtime()
        p=subprocess.run([str(EXE),'--probe',str(rt),str(rt)],cwd=str(APP),capture_output=True,text=True,timeout=40,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        log=(p.stdout+'\n'+p.stderr).strip()
        return ('API_PRESENT_UNVERIFIED' if 'SDK_PROBE_RESULT=PASS' in log else 'INVALID',base_report+'\n\n'+log[-5000:])
    except Exception as e:
        return ('ERROR',base_report+'\n\n'+str(e))

def export_job(main,filename,selected_only=False):
    if os.name!='nt': raise NativeOrzxError('ORZX mediante BSL SDK requiere Windows.')
    if not RUNTIME.is_dir(): raise NativeOrzxError('Falta G2_RUNTIME dentro de la carpeta del programa.')
    try:
        detect_sdk_dll(SDKDIR, require_x86=True)
    except Exception as e:
        raise NativeOrzxError(
            'Exportación ORZX pendiente de la DLL oficial BSLAPP-SDK 5.x (x86), '
            'MarkAPI.h y dependencias. La DLL 43AYE3_BSL_COMPAT es para conexión '
            'y encuadre; no se usará para crear un ORZX no verificado.\n\n'
            + sdk_auto_report(SDKDIR) + '\n\n' + str(e)
        ) from e
    _ensure_bridge()
    sdk_runtime=_prepare_sdk_runtime()
    out=Path(filename)
    if out.suffix.lower()!='.orzx': out=out.with_suffix('.orzx')
    out=out.resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    job,pens,lines_by_pen,images=_job_data(main,selected_only)
    inp=Path(tempfile.gettempdir())/f'43aye3_bsl_sdk_job_{uuid.uuid4().hex}.bin'
    tmpout=out.with_name(f'.{out.stem}.{uuid.uuid4().hex}.orzx')
    _write_input(inp,pens,lines_by_pen,images)
    env=os.environ.copy(); env['G2PRO_VENDOR_DIR']=str(sdk_runtime); env['BSL_SDK_DIR']=str(sdk_runtime)
    try:
        p=subprocess.run([str(EXE),'--export',str(inp),str(tmpout),str(sdk_runtime),str(sdk_runtime)],cwd=str(APP),
                         capture_output=True,text=True,env=env,timeout=300,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        log=(p.stdout+'\n'+p.stderr).strip()
        if p.returncode!=0 or 'BSL_SDK_EXPORT_RESULT=PASS' not in log or not tmpout.is_file() or tmpout.stat().st_size<64:
            raise NativeOrzxError('El BSL SDK no pudo crear el ORZX.\n\n'+log[-9000:])
        with tmpout.open('rb') as f:
            if f.read(4)!=b'\x3c\x00\x00\x00':
                raise NativeOrzxError('El SDK produjo un archivo con cabecera ORZX inesperada; se conservó el destino anterior.')
        os.replace(tmpout,out)
    finally:
        inp.unlink(missing_ok=True)
        tmpout.unlink(missing_ok=True)
    return str(out),job,log
