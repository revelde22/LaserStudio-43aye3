@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (echo [ERROR] Faltan Microsoft Visual C++ Build Tools x86.&exit /b 1)
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%I"
if not defined VSROOT (echo [ERROR] Faltan Microsoft Visual C++ Build Tools x86.&exit /b 1)
call "%VSROOT%\VC\Auxiliary\Build\vcvars32.bat" >nul
if errorlevel 1 exit /b 1
pushd native_bridge_x86
del /q device_bsl_sdk_bridge_x86.obj 2>nul
echo Compilando puente BSLAPP-SDK 5.x x86...
cl /nologo /EHsc /O2 /MT device_bsl_sdk_bridge_x86.cpp /Fe:43aye3_bsl_sdk_bridge_x86.exe
if errorlevel 1 (popd&exit /b 1)
popd
echo [OK] Puente BSLAPP-SDK compilado.
exit /b 0
