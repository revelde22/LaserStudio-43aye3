import pathlib
from PySide6.QtCore import Qt
from PySide6.QtGui import QFontDatabase, QAction, QPixmap, QKeySequence, QPainterPath
from PySide6.QtWidgets import *
import json, pathlib

DEFAULT_DEVICE={
 "name":"Gweike G2 Pro","type":"Galvo / Fiber","workspace":[110.0,110.0],
 "origin":"Center","backend":"BSL","vid":"04B4","pid":"1004","driver":"CYUSB3",
 "connection":"Control nativo G2"
}

def install_professional_ui(w):
    # Device profile and editor controls.
    w.device.clear(); w.device.addItem(DEFAULT_DEVICE["name"])
    w.pos.setText("Gweike G2 Pro · 110 × 110 mm")
    w.device_profile=DEFAULT_DEVICE.copy()

    # Numeric transform bar.
    tb=QToolBar("Numeric",w); w.addToolBar(Qt.ToolBarArea.TopToolBarArea,tb)
    w._num={}
    for key,label in [("x","X"),("y","Y"),("w","W"),("h","H"),("r","Rotate")]:
        tb.addWidget(QLabel(label))
        s=QDoubleSpinBox();s.setDecimals(3);s.setRange(-100000,100000);s.setSuffix("°" if key=="r" else " mm")
        s.setKeyboardTracking(False);w._num[key]=s;tb.addWidget(s)
    lock=QCheckBox("Lock aspect");lock.setChecked(True);w._aspect=lock;tb.addWidget(lock)
    apply=QPushButton("Apply");apply.clicked.connect(lambda:apply_numeric(w));tb.addWidget(apply)
    w.scene.selectionChanged.connect(lambda:update_numeric(w))

    # Extra professional docks.
    make_shape_properties(w)
    make_move_dock(w)
    make_library_dock(w)
    make_variable_text_dock(w)
    make_optimization_action(w)
    make_devices_action(w)

def update_numeric(w):
    s=w.selected()
    if not s:return
    r=s[0].sceneBoundingRect()
    vals={"x":r.x(),"y":r.y(),"w":r.width(),"h":r.height(),"r":s[0].rotation()}
    for k,v in vals.items():
        w._num[k].blockSignals(True);w._num[k].setValue(v);w._num[k].blockSignals(False)

def apply_numeric(w):
    s=w.selected()
    if not s:return
    for i in s:
        r=i.sceneBoundingRect(); nx=w._num["x"].value();ny=w._num["y"].value()
        nw=max(.001,w._num["w"].value());nh=max(.001,w._num["h"].value())
        if w._aspect.isChecked() and r.width()>0:
            ratio=r.height()/r.width(); nh=nw*ratio
        i.setPos(i.pos().x()+nx-r.x(),i.pos().y()+ny-r.y())
        if r.width()>0 and r.height()>0:
            if hasattr(i,"setScale") and abs(r.width()-r.height())>=0:
                # scene ratio -> multiplicative scale; raster keeps aspect when requested.
                sx=nw/r.width(); sy=nh/r.height()
                if i.__class__.__name__=="RasterItem" or w._aspect.isChecked():
                    i.setScale(i.scale()*sx)
                else:
                    t=i.transform();t.scale(sx,sy);i.setTransform(t)
        i.setRotation(w._num["r"].value())
    update_numeric(w)

def make_shape_properties(w):
    d=QDockWidget("Shape Properties",w); box=QWidget();f=QFormLayout(box)
    f.addRow("Selected",QLabel("Use numeric toolbar for exact X/Y/W/H/rotation"))
    f.addRow("Layer",QLabel("Palette / Cuts-Layers"))
    d.setWidget(box);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);d.hide()
    w.menuBar().findChild(QMenu).parent()
    w.shape_dock=d

def make_move_dock(w):
    d=QDockWidget("Mover selección · lienzo",w);x=QWidget();g=QGridLayout(x)
    dist=QDoubleSpinBox();dist.setRange(.001,1000);dist.setValue(1);dist.setSuffix(" mm")
    g.addWidget(QLabel("Paso en el lienzo"),0,0);g.addWidget(dist,0,1)
    note=QLabel("Mueve el diseño. No mueve el láser ni cambia el enfoque.");note.setWordWrap(True);g.addWidget(note,1,0,1,3)
    def move(dx,dy):
        items=w.selected()
        if not items:return w.statusBar().showMessage("Selecciona objetos para moverlos.")
        for item in items:item.moveBy(dx*dist.value(),dy*dist.value())
        w.changed=True;w.schedule_preview()
    def center():
        items=w.selected()
        if not items:return
        bounds=items[0].sceneBoundingRect()
        for item in items[1:]:bounds=bounds.united(item.sceneBoundingRect())
        delta=w.scene.sceneRect().center()-bounds.center()
        for item in items:item.moveBy(delta.x(),delta.y())
        w.changed=True;w.schedule_preview()
    for row,col,txt,fn in [(2,1,"↑",lambda:move(0,-1)),(3,0,"←",lambda:move(-1,0)),(3,1,"Centrar",center),(3,2,"→",lambda:move(1,0)),(4,1,"↓",lambda:move(0,1))]:
        button=QPushButton(txt);button.clicked.connect(fn);g.addWidget(button,row,col)
    d.setWidget(x);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);d.hide();w.move_dock=d


def make_library_dock(w):
    d=QDockWidget("Material Library",w);x=QWidget();v=QVBoxLayout(x)
    note=QLabel("Biblioteca editable con materiales, líquidos y procedencia de los parámetros. Se aplica a la capa seleccionada.");note.setWordWrap(True);v.addWidget(note)
    button=QPushButton("Elegir y aplicar material…");button.clicked.connect(w.material_library);v.addWidget(button)
    button=QPushButton("Guardar parámetros actuales…");button.clicked.connect(w.add_material_parameters);v.addWidget(button)
    d.setWidget(x);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);d.hide();w.library_dock=d


def make_variable_text_dock(w):
    import csv
    from text_tools import text_path
    d=QDockWidget("Texto variable",w);x=QWidget();f=QFormLayout(x)
    template=QLineEdit("Pieza {n:04d}");current=QSpinBox();current.setRange(0,999999999);current.setValue(1)
    source=QLineEdit();source.setReadOnly(True);rows=[]
    f.addRow("Plantilla",template);f.addRow("Número / fila CSV (desde 1)",current);f.addRow("CSV",source)
    browse=QPushButton("Cargar CSV UTF-8…");f.addRow(browse)
    def load():
        path,_=QFileDialog.getOpenFileName(w,"Texto variable","","CSV (*.csv)")
        if not path:return
        try:
            with open(path,encoding="utf-8-sig",newline="") as handle:
                sample=handle.read(4096);handle.seek(0)
                try:dialect=csv.Sniffer().sniff(sample,delimiters=",;\t")
                except csv.Error:dialect=csv.excel
                loaded=list(csv.DictReader(handle,dialect=dialect))
            if not loaded:raise ValueError("CSV sin filas de datos.")
            if any(None in row for row in loaded):raise ValueError("Hay filas con más columnas que el encabezado.")
        except (OSError,UnicodeError,csv.Error,ValueError) as exc:return QMessageBox.warning(w,"CSV",str(exc))
        rows[:]=loaded;source.setText(path);current.setValue(1)
    browse.clicked.connect(load)
    clear=QPushButton("Usar solo numeración");clear.clicked.connect(lambda:(rows.clear(),source.clear()));f.addRow(clear)
    info=QLabel("Usa {n} o {n:04d}. Con CSV, usa sus encabezados: {nombre}, {referencia}… Inserta una fila cada vez.");info.setWordWrap(True);f.addRow(info)
    create=QPushButton("Insertar texto y avanzar");f.addRow(create)
    def insert():
        from laser_studio import GItem
        number=current.value()
        try:
            if rows and not 1<=number<=len(rows):raise ValueError("Fila fuera del CSV.")
            values=dict(rows[number-1]) if rows else {};values['n']=number
            import string
            for _,field,_,conversion in string.Formatter().parse(template.text()):
                if field is not None and (field not in values or conversion):raise ValueError("Campo desconocido. Usa un encabezado del CSV o {n}.")
            content=template.text().format_map(values)
            if not content.strip():raise ValueError("El texto está vacío.")
        except (ValueError,KeyError,IndexError,TypeError) as exc:return QMessageBox.warning(w,"Texto variable",str(exc))
        settings=getattr(w,'_lb_text',{})
        family=settings['font'].currentText() if settings else 'Arial'
        size=settings['height'].value() if settings else 8
        bold=settings['bold'].isChecked() if settings else False
        italic=settings['italic'].isChecked() if settings else False
        item=GItem(text_path(content,family,size,bold,italic),'text')
        item.text_meta={'text':content,'font':family,'size_mm':size,'bold':bold,'italic':italic}
        w.scene.clearSelection();w.scene.addItem(item);w.apply_layer(item);item.setPos(20,20);item.setSelected(True)
        w.changed=True;w.schedule_preview();current.setValue(number+1)
    create.clicked.connect(insert)
    d.setWidget(x);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);d.hide();w.variable_dock=d


def make_optimization_action(w):
    tools=[a for a in w.menuBar().actions() if a.text().replace("&","")=="Tools"][0].menu()
    a=QAction("Orden de marcado por capas…",w)
    from editor_tools import optimization_dialog
    a.triggered.connect(lambda:optimization_dialog(w));tools.addAction(a)


def make_devices_action(w):
    laser_menu=w.menuBar().addMenu("&Laser")
    for title,dock in [("Shape Properties",w.shape_dock),("Move",w.move_dock),("Material Library",w.library_dock),("Variable Text",w.variable_dock)]:
        act=QAction(title,w);act.triggered.connect(lambda _,d=dock:(d.show(),d.raise_()));laser_menu.addAction(act)

def devices_dialog(w):
    d=QDialog(w);d.setWindowTitle("Devices");d.resize(560,320);v=QVBoxLayout(d)
    table=QTableWidget(1,6);table.setHorizontalHeaderLabels(["Device","Type","Workspace","Backend","USB","Status"])
    p=w.device_profile
    vals=[p["name"],p["type"],"110 × 110 mm",p["backend"],p["vid"]+":"+p["pid"],p["connection"]]
    for c,x in enumerate(vals):table.setItem(0,c,QTableWidgetItem(x))
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch);v.addWidget(table)
    info=QLabel("Profile is configured. Physical Frame/Start/Stop stay disabled until the exact device backend passes validation.")
    info.setWordWrap(True);v.addWidget(info)
    bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Close);bb.rejected.connect(d.reject);bb.clicked.connect(d.accept);v.addWidget(bb);d.exec()

def install_v4_tools(w):
    from laser_studio import GItem
    from geometry_pro import regular_polygon,star,path_from_points,intersect,subtract,xor
    from text_tools import text_path
    tools=[a for a in w.menuBar().actions() if a.text().replace("&","")=="Tools"][0].menu()

    def add_poly(star_mode=False):
        n,ok=QInputDialog.getInt(w,"Star" if star_mode else "Polygon","Points / sides",5,3,100)
        if not ok:return
        pts=star(55,55,15,7,n) if star_mode else regular_polygon(55,55,15,n)
        it=GItem(path_from_points(pts,True),"star" if star_mode else "polygon");w.scene.addItem(it);w.apply_layer(it);it.setSelected(True)

    def add_text():
        w.text_editor()

    def boolop(mode):
        s=w.selected()
        if len(s)<2:return
        if any(not isinstance(i,GItem) for i in s):
            return QMessageBox.information(w,"Operación vectorial","Selecciona vectores sin agrupar; vectoriza las imágenes primero.")
        mapped=[i.mapToScene(i.path()) for i in s]
        if mode=="intersect":p=intersect(mapped)
        elif mode=="subtract":p=subtract(mapped[0],mapped[1:])
        else:p=xor(mapped)
        for i in s:w.scene.removeItem(i)
        n=GItem(p,"boolean");w.scene.addItem(n);w.apply_layer(n);n.setSelected(True)

    for title,fn in [
      ("Create Polygon",lambda:add_poly(False)),("Create Star",lambda:add_poly(True)),("Create Text",add_text),
      ("Boolean Subtract",lambda:boolop("subtract")),("Boolean Intersection",lambda:boolop("intersect")),
      ("Boolean XOR",lambda:boolop("xor"))]:
        a=QAction(title,w);a.triggered.connect(fn);tools.addAction(a)

    # Window toggles for docks
    win=[a for a in w.menuBar().actions() if a.text().replace("&","")=="Window"][0].menu()
    for title,dock in [("Shape Properties",w.shape_dock),("Move",w.move_dock),("Material Library",w.library_dock),("Variable Text",w.variable_dock)]:
        a=QAction(title,w);a.triggered.connect(lambda checked=False,d=dock:(d.show(),d.raise_()));win.addAction(a)

def install_v5_image_vector(w):
    from laser_studio import RasterItem,GItem
    from raster_tools import load_rgba,adjust,trace_contours
    from geometry_pro import path_from_points
    tools=[a for a in w.menuBar().actions() if a.text().replace("&","")=="Tools"][0].menu()

    def selected_image():
        xs=[x for x in w.scene.selectedItems() if isinstance(x,RasterItem)]
        return xs[0] if xs else None

    def adjust_image():
        it=selected_image()
        if not it:return QMessageBox.information(w,"Adjust Image","Select an imported image first.")
        d=QDialog(w);d.setWindowTitle("Adjust Image");f=QFormLayout(d)
        vals={}
        for key,label,lo,hi,val in [("brightness","Brightness",.1,3,1),("contrast","Contrast",.1,3,1),("gamma","Gamma",.1,3,1),("sharpen","Sharpen",0,5,0)]:
            x=QDoubleSpinBox();x.setRange(lo,hi);x.setSingleStep(.1);x.setValue(val);vals[key]=x;f.addRow(label,x)
        inv=QCheckBox();f.addRow("Invert",inv)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);f.addRow(bb);bb.accepted.connect(d.accept);bb.rejected.connect(d.reject)
        if d.exec():
            img=adjust(load_rgba(it.source_path),**{k:v.value() for k,v in vals.items()},invert=inv.isChecked())
            out=pathlib.Path(it.source_path).with_name(pathlib.Path(it.source_path).stem+"_43adjusted.png");img.save(out)
            oldscale=it.scale();it.setPixmap(QPixmap(str(out)));it.source_path=str(out);it.setScale(oldscale)

    def trace_image():
        it=selected_image()
        if not it:return QMessageBox.information(w,"Trace Image","Select an imported image first.")
        d=QDialog(w);d.setWindowTitle("Trace Image");f=QFormLayout(d)
        th=QSpinBox();th.setRange(0,255);th.setValue(128);area=QSpinBox();area.setRange(0,100000);area.setValue(8)
        opt=QDoubleSpinBox();opt.setRange(0,0.1);opt.setDecimals(4);opt.setValue(.002);alpha=QCheckBox("Trace transparency")
        delete=QCheckBox("Delete image after trace")
        f.addRow("Threshold",th);f.addRow("Ignore area < px",area);f.addRow("Optimize",opt);f.addRow(alpha);f.addRow(delete)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);f.addRow(bb);bb.accepted.connect(d.accept);bb.rejected.connect(d.reject)
        if not d.exec():return
        img=load_rgba(it.source_path); contours=trace_contours(img,th.value(),area.value(),opt.value(),alpha.isChecked())
        pm=it.pixmap(); sx=(it.sceneBoundingRect().width()/max(1,pm.width())); sy=(it.sceneBoundingRect().height()/max(1,pm.height()))
        origin=it.sceneBoundingRect().topLeft()
        for pts in contours:
            pts=[(origin.x()+x*sx,origin.y()+y*sy) for x,y in pts]
            n=GItem(path_from_points(pts,True),"trace");w.scene.addItem(n);w.apply_layer(n)
        if delete.isChecked():w.scene.removeItem(it)

    def fill_selected():
        s=[x for x in w.selected() if isinstance(x,GItem)]
        if not s:return
        c=w.cuts[w.active_layer];c.mode="Fill"
        for x in s:w.apply_layer(x)
        w.edit_cut(w.active_layer)

    for title,fn,sc in [("Adjust Image",adjust_image,"Alt+I"),("Trace Image",trace_image,"Alt+T"),("Set Selected Vectors to Fill",fill_selected,None)]:
        a=QAction(title,w);a.triggered.connect(fn)
        if sc:a.setShortcut(QKeySequence(sc))
        tools.addAction(a)

def install_v6_scale_materials(w):
    import json, pathlib, tempfile
    from laser_studio import RasterItem,GItem
    from raster_tools import load_rgba,adjust,brightness_from_slider,darkness_from_slider

    # ---- Image controls dock: real-time darkness/brightness + exact scale ----
    d=QDockWidget("Image / Scale",w); box=QWidget();v=QVBoxLayout(box)
    dims=QGroupBox("Exact size");f=QFormLayout(dims)
    width=QDoubleSpinBox();height=QDoubleSpinBox()
    for q in (width,height):q.setRange(.01,10000);q.setDecimals(3);q.setSuffix(" mm")
    keep=QCheckBox("Keep aspect ratio");keep.setChecked(True)
    apply_size=QPushButton("Apply size")
    f.addRow("Width",width);f.addRow("Height",height);f.addRow(keep);f.addRow(apply_size);v.addWidget(dims)

    imgbox=QGroupBox("Photo adjustment");g=QFormLayout(imgbox)
    dark=QSlider(Qt.Orientation.Horizontal);dark.setRange(0,100);dark.setValue(0)
    bright=QSlider(Qt.Orientation.Horizontal);bright.setRange(-100,100);bright.setValue(0)
    darklab=QLabel("0");brightlab=QLabel("0")
    rw=QWidget();rh=QHBoxLayout(rw);rh.setContentsMargins(0,0,0,0);rh.addWidget(dark);rh.addWidget(darklab)
    bw=QWidget();bh=QHBoxLayout(bw);bh.setContentsMargins(0,0,0,0);bh.addWidget(bright);bh.addWidget(brightlab)
    reset=QPushButton("Reset image adjustments")
    g.addRow("Darkness",rw);g.addRow("Brightness",bw);g.addRow(reset);v.addWidget(imgbox)
    d.setWidget(box);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);w.image_scale_dock=d

    def refresh_dims():
        try:s=w.selected()
        except RuntimeError:return
        if not s:return
        r=s[0].sceneBoundingRect()
        for it in s[1:]:r=r.united(it.sceneBoundingRect())
        for q,val in ((width,r.width()),(height,r.height())):
            q.blockSignals(True);q.setValue(val);q.blockSignals(False)
    w.scene.selectionChanged.connect(refresh_dims)

    def resize():
        try:s=w.selected()
        except RuntimeError:return
        if not s:return
        r=s[0].sceneBoundingRect()
        for it in s[1:]:r=r.united(it.sceneBoundingRect())
        if r.width()<=0 or r.height()<=0:return
        sx=width.value()/r.width();sy=sx if keep.isChecked() else height.value()/r.height()
        w.begin_transform()
        try:
            for it in s:
                pos=it.scenePos()
                it.setPos(r.x()+(pos.x()-r.x())*sx,r.y()+(pos.y()-r.y())*sy)
                if isinstance(it,RasterItem) and keep.isChecked():it.setScale(it.scale()*sx)
                else:it.setTransform(it.transform().scale(sx,sy))
        finally:w.end_transform()
        refresh_dims()
    apply_size.clicked.connect(resize)

    def selected_raster():
        s=[i for i in w.scene.selectedItems() if isinstance(i,RasterItem)]
        return s[0] if s else None

    def preview_image():
        it=selected_raster()
        if not it:return
        if not hasattr(it,"_original_source"):it._original_source=it.source_path
        img=load_rgba(it._original_source)
        factor=brightness_from_slider(bright.value())*darkness_from_slider(dark.value())
        out=adjust(img,brightness=factor)
        tmp=pathlib.Path(tempfile.gettempdir())/"43aye3_image_preview.png";out.save(tmp)
        old=it.scale();it.setPixmap(QPixmap(str(tmp)));it.setScale(old)
        darklab.setText(str(dark.value()));brightlab.setText(str(bright.value()))
    dark.valueChanged.connect(preview_image);bright.valueChanged.connect(preview_image)
    reset.clicked.connect(lambda:(dark.setValue(0),bright.setValue(0),preview_image()))

    # ---- Material Test professional dock ----
    md=QDockWidget("Material Test Matrix",w); mb=QWidget();mf=QFormLayout(mb)
    presets=json.loads((pathlib.Path(__file__).parent/"material_presets.json").read_text(encoding="utf-8"))
    material=QComboBox();material.addItems(presets["materials"].keys())
    liquid=QComboBox();liquid.addItems(presets["marking_liquids"])
    rows=QSpinBox();rows.setRange(2,10);rows.setValue(5)
    cols=QSpinBox();cols.setRange(2,10);cols.setValue(5)
    smin=QDoubleSpinBox();smax=QDoubleSpinBox();pmin=QDoubleSpinBox();pmax=QDoubleSpinBox()
    for q in (smin,smax):q.setRange(1,100000);q.setSuffix(" mm/s")
    for q in (pmin,pmax):q.setRange(0,100);q.setSuffix(" %")
    fmin=QDoubleSpinBox();fmax=QDoubleSpinBox()
    for q in (fmin,fmax):q.setRange(1,5000);q.setSuffix(" kHz")
    interval=QDoubleSpinBox();interval.setRange(.001,10);interval.setDecimals(3);interval.setSingleStep(.005);interval.setSuffix(" mm")
    passes=QSpinBox();passes.setRange(1,100);passes.setValue(1)
    make=QPushButton("Generate test matrix")
    group_test=QPushButton("Agrupar matriz y ajustar tamaño")
    export_test=QPushButton("Exportar TEST → ORZX SDK")
    export_test_img=QPushButton("Exportar TEST → IMAGEN")
    note=QLabel("Presets are starting test ranges only. Verify on scrap material before production.");note.setWordWrap(True)
    for lab,q in [("Material",material),("Marking liquid (optional)",liquid),("Rows",rows),("Columns",cols),
                  ("Speed min",smin),("Speed max",smax),("Power min",pmin),("Power max",pmax),
                  ("Frequency min",fmin),("Frequency max",fmax),("Fill interval",interval),("Passes",passes)]:mf.addRow(lab,q)
    mf.addRow(make);mf.addRow(group_test);mf.addRow(export_test);mf.addRow(export_test_img);mf.addRow(note);md.setWidget(mb);w.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,md);w.material_test_dock=md

    def loadpreset():
        p=presets["materials"][material.currentText()]
        smin.setValue(p["speed"][0]);smax.setValue(p["speed"][1]);pmin.setValue(p["power"][0]);pmax.setValue(p["power"][1])
        fmin.setValue(p["freq"][0]);fmax.setValue(p["freq"][1])
        interval.setValue(p.get("interval",.03))
    material.currentTextChanged.connect(loadpreset);loadpreset()

    def generate():
        from material_test_matrix import generate_matrix
        generated=generate_matrix(w,rows.value(),cols.value(),(smin.value(),smax.value()),
                        (pmin.value(),pmax.value()),(fmin.value(),fmax.value()),
                        interval.value(),passes.value(),material.currentText(),liquid.currentText())
        first=min(item.layer for item in generated);last=max(item.layer for item in generated)
        QMessageBox.information(w,"Material Test",f"{rows.value()} × {cols.value()} muestras en C{first:02d}–C{last:02d}.\nCada cuadrado y su etiqueta están en su propia pluma Fill con velocidad, potencia, frecuencia, intervalo y pasadas.\nGuarda el proyecto .43laser para conservarlas.")
    make.clicked.connect(generate)
    group_test.clicked.connect(lambda:__import__("material_test_matrix").group_matrix(w))
    def export_material_test():
        from g2_native_orzx import export_job, NativeOrzxError
        fn,_=QFileDialog.getSaveFileName(w,"Exportar TEST a ORZX SDK","test_materiales.orzx","ORZX (*.orzx)")
        if not fn:return
        try:
            destination,job,log=export_job(w,fn)
        except NativeOrzxError as exc:
            QMessageBox.warning(w,"Exportar TEST ORZX SDK",str(exc));return
        except Exception as exc:
            QMessageBox.warning(w,"Exportar TEST ORZX SDK",str(exc));return
        QMessageBox.information(w,"TEST ORZX creado",f"Archivo creado mediante la DLL BSL seleccionada, sin GLaser:\n{destination}\n\nCada Cxx conserva Speed, Power, Frequency y Passes mediante BSL_SetPenParam. Los Fill se guardan con BSL_AddLinesToFile2.")

    export_test.clicked.connect(export_material_test)
    def export_material_test_image():
        from image_export_native import ImageExportDialog
        ImageExportDialog(w, default_area="TODO", default_preset="PREVIEW").exec()
    export_test_img.clicked.connect(export_material_test_image)
    w._material_test_controls={"rows":rows,"cols":cols,"smin":smin,"smax":smax,"pmin":pmin,"pmax":pmax,
                               "fmin":fmin,"fmax":fmax,"interval":interval,"passes":passes,"generate":make,"group":group_test,"export":export_test,"export_image":export_test_img}

    win=[a for a in w.menuBar().actions() if a.text().replace("&","")=="Window"][0].menu()
    for title,dock in [("Image / Scale",d),("Material Test Matrix",md)]:
        a=QAction(title,w);a.setCheckable(True);a.setChecked(True);a.triggered.connect(lambda checked,d=dock:d.setVisible(checked));win.addAction(a)
