
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction,QKeySequence,QColor,QBrush,QPen
from PySide6.QtWidgets import (QToolBar,QWidget,QLabel,QDoubleSpinBox,QCheckBox,QComboBox,
    QFontComboBox,QSpinBox,QMessageBox,QInputDialog,QDialog,QFormLayout,QDialogButtonBox)

def _act(tb,text,tip,fn,shortcut=None):
    a=QAction(text,tb);a.setToolTip(tip)
    if shortcut:a.setShortcut(QKeySequence(shortcut))
    a.triggered.connect(fn);tb.addAction(a);return a

def install_lightburn_workflow(w):
    # Hide legacy top/left toolbars: one authoritative UI, no duplicated dead controls.
    for tb in w.findChildren(QToolBar):
        tb.hide()

    main=QToolBar("Main",w);main.setObjectName("lb_main");main.setIconSize(__import__("PySide6.QtCore",fromlist=["QSize"]).QSize(20,20))
    w.addToolBar(Qt.ToolBarArea.TopToolBarArea,main)
    _act(main,"N","New",w.new,"Ctrl+N");_act(main,"O","Open project",w.open,"Ctrl+O");_act(main,"S","Save project",w.save,"Ctrl+S")
    main.addSeparator()
    a=_act(main,"↶","Undo",lambda:None,"Ctrl+Z");a.setEnabled(False);a.setToolTip("Undo disabled until command stack is implemented")
    a=_act(main,"↷","Redo",lambda:None,"Ctrl+Y");a.setEnabled(False);a.setToolTip("Redo disabled until command stack is implemented")
    _act(main,"⧉","Duplicate",w.duplicate,"Ctrl+D");_act(main,"⌫","Delete",w.delete,"Delete")
    main.addSeparator()
    _act(main,"✥","Pan / move view",lambda:w.tool("pan"))
    _act(main,"⊕","Zoom in",lambda:w.view.scale(1.2,1.2),"+")
    _act(main,"⊖","Zoom out",lambda:w.view.scale(1/1.2,1/1.2),"-")
    _act(main,"□","Zoom to page",w.fit)
    _act(main,"P","Preview",w.preview,"Alt+P")
    main.addSeparator()
    _act(main,"Agrupar selección","Agrupar los objetos seleccionados (Ctrl+G)",w.group)
    _act(main,"UG","Ungroup",w.ungroup,"Ctrl+U")
    group_state=QLabel("Selección: 0")
    main.addWidget(group_state)
    def update_group_state():
        try:
            selected=w.selected()
            if len(selected)==1 and hasattr(selected[0],"members"):
                group_state.setText(f"Grupo: {len(selected[0].members())} objetos")
            else:group_state.setText(f"Selección: {len(selected)}")
        except RuntimeError:pass
    w.scene.selectionChanged.connect(update_group_state)
    w._group_state_label=group_state
    _act(main,"↔","Flip horizontal",lambda:w.flip(True))
    _act(main,"↕","Flip vertical",lambda:w.flip(False))
    _act(main,"⟳","Rotate 90°",lambda:w.rotate(90))
    _act(main,"L","Align left",lambda:w.align("left"));_act(main,"C","Align centers",lambda:w.align("center"))
    _act(main,"T","Align top",lambda:w.align("top"))
    _act(main,"▦","Grid array",w.grid_array);_act(main,"◉","Circular array",w.circular_array)

    # Numeric edits row matching LightBurn workflow.
    num=QToolBar("Numeric Edits",w);num.setObjectName("lb_numeric");w.addToolBar(Qt.ToolBarArea.TopToolBarArea,num)
    controls={}
    def spin(label):
        num.addWidget(QLabel(label));q=QDoubleSpinBox();q.setRange(-100000,100000);q.setDecimals(3);q.setSuffix(" mm");q.setMaximumWidth(105);num.addWidget(q);return q
    controls["x"]=spin("XPos");controls["y"]=spin("YPos");controls["w"]=spin("Width");controls["h"]=spin("Height")
    lock=QCheckBox("Mantener proporción");lock.setChecked(True);lock.setToolTip("Desmarcar para ajustar anchura y altura por separado");num.addWidget(lock);controls["lock"]=lock
    num.addWidget(QLabel("Rotate"));rot=QDoubleSpinBox();rot.setRange(-36000,36000);rot.setDecimals(2);rot.setSuffix("°");rot.setMaximumWidth(90);num.addWidget(rot);controls["rot"]=rot
    num.addWidget(QLabel("mm"));controls["unit"]=QLabel("mm")

    busy={"v":False}
    def selection_rect():
        xs=w.selected()
        if not xs:return None
        r=xs[0].sceneBoundingRect()
        for it in xs[1:]:r=r.united(it.sceneBoundingRect())
        return r
    def load_numeric():
        try:
            r=selection_rect();busy["v"]=True
            for q in (controls["x"],controls["y"],controls["w"],controls["h"],rot):q.setEnabled(bool(r))
            if r:
                for q,v in ((controls["x"],r.x()),(controls["y"],r.y()),(controls["w"],r.width()),(controls["h"],r.height())):q.setValue(v)
                if len(w.selected())==1:rot.setValue(w.selected()[0].rotation())
        except RuntimeError:pass
        finally:busy["v"]=False
    def apply_numeric(kind):
        if busy["v"]:return
        xs=w.selected();r=selection_rect()
        if not xs or not r:return
        if kind=="x":
            dx=controls["x"].value()-r.x()
            for it in xs:it.moveBy(dx,0)
        elif kind=="y":
            dy=controls["y"].value()-r.y()
            for it in xs:it.moveBy(0,dy)
        elif kind in ("w","h") and r.width()>0 and r.height()>0:
            sx=controls["w"].value()/r.width() if kind=="w" else 1.0
            sy=controls["h"].value()/r.height() if kind=="h" else 1.0
            if lock.isChecked():
                if kind=="w":sy=sx
                else:sx=sy
            ox,oy=r.x(),r.y()
            w.begin_transform()
            try:
                for it in xs:
                    # Scale all selected objects as one matrix.
                    pos=it.scenePos();it.setPos(ox+(pos.x()-ox)*sx,oy+(pos.y()-oy)*sy)
                    it.setTransform(it.transform().scale(sx,sy))
            finally:w.end_transform()
        elif kind=="rot":
            delta=rot.value()-(xs[0].rotation() if len(xs)==1 else 0)
            for it in xs:it.setRotation(it.rotation()+delta)
        if hasattr(w,"hruler"):w.hruler.update();w.vruler.update()
        w.changed=True
        load_numeric()
    for k in ("x","y","w","h"):controls[k].editingFinished.connect(lambda k=k:apply_numeric(k))
    rot.editingFinished.connect(lambda:apply_numeric("rot"))
    w.scene.selectionChanged.connect(load_numeric);w._lb_numeric=controls

    # Text options row: installed Windows fonts + editable size/style.
    texttb=QToolBar("Text Options",w);texttb.setObjectName("lb_text");w.addToolBar(Qt.ToolBarArea.TopToolBarArea,texttb)
    texttb.addWidget(QLabel("Font"));font=QFontComboBox();font.setMaximumWidth(190)
    # Qt offscreen/minimal deployments can expose no font directory. Keep the
    # text control usable instead of leaving an empty, dead selector.
    if font.count() == 0:
        for family in ("Arial", "Segoe UI", "DejaVu Sans", "Sans Serif"):
            font.addItem(family)
    texttb.addWidget(font)
    texttb.addWidget(QLabel("Height"));height=QDoubleSpinBox();height.setRange(.5,200);height.setValue(8);height.setSuffix(" mm");texttb.addWidget(height)
    bold=QCheckBox("Bold");italic=QCheckBox("Italic");texttb.addWidget(bold);texttb.addWidget(italic)
    w._lb_text={"font":font,"height":height,"bold":bold,"italic":italic}

    # Left creation/modifier toolbar, ordered like the documented workflow.
    left=QToolBar("Creation / Modifiers",w);left.setObjectName("lb_left");left.setOrientation(Qt.Orientation.Vertical);w.addToolBar(Qt.ToolBarArea.LeftToolBarArea,left)
    _act(left,"↖","Select",lambda:w.tool("select"),"Esc")
    w._select_all_button=_act(left,"TODO","Seleccionar todos los objetos del lienzo",w.select_all)
    _act(left,"GRUPO","Agrupar la selección en un objeto escalable (Ctrl+G)",w.group)
    from editor_tools import edit_nodes
    _act(left,"N•","Editar nodos",lambda:edit_nodes(w))
    _act(left,"╱","Draw lines",lambda:w.tool("line"),"Ctrl+L")
    _act(left,"□","Rectangle",lambda:w.tool("rect"),"Ctrl+R")
    _act(left,"○","Ellipse",lambda:w.tool("ellipse"),"Ctrl+E")
    _act(left,"⬡","Polygon",lambda:w.tool("polygon"))
    _act(left,"★","Star",lambda:w.tool("star"))
    _act(left,"IMP","Import image/vector",w.import_any)
    _act(left,"Añadir texto","Create or edit text",w.text_editor)
    _act(left,"IMG","Adjust selected image",w.adjust_image)
    left.addSeparator()
    _act(left,"OFF","Contorno desplazado",w.offset,"Alt+O")
    _act(left,"U","Boolean union",w.boolean_union)
    _act(left,"▦","Grid array",w.grid_array);_act(left,"◉","Circular array",w.circular_array)
    _act(left,"↔","Measure",w.measure)

    # Bottom layer palette remains the fastest layer assignment workflow.
    palette=QToolBar("Color Palette",w);palette.setObjectName("lb_palette");w.addToolBar(Qt.ToolBarArea.BottomToolBarArea,palette)
    from laser_studio import COLORS
    for i,c in enumerate(COLORS):
        a=QAction(f"C{i:02}",palette);a.setToolTip(f"Assign selection to layer C{i:02}")
        a.triggered.connect(lambda checked=False,i=i:w.set_layer(i));palette.addAction(a)

    # Window menu allows restoring/hiding exact toolbars.
    wm=w.menuBar().addMenu("Window")
    for tb in (main,num,texttb,left,palette):wm.addAction(tb.toggleViewAction())
    wm.addSeparator();reset=wm.addAction("Reset to Default Layout");reset.triggered.connect(w.reset_layout)

    load_numeric()
