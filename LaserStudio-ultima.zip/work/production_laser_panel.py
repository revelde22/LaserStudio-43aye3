from pathlib import Path
import subprocess, os, ctypes, time, math

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QGroupBox,QGridLayout,QPushButton,QLabel,QMessageBox,QDialog,QFormLayout,
                               QDoubleSpinBox,QCheckBox,QSpinBox,QDialogButtonBox,QProgressDialog,QApplication,QProgressBar)

APP=Path(__file__).resolve().parent

def validate_mark_layer_mode(mode, has_vectors, has_images):
    if has_vectors and mode not in ('Line','Fill','Offset Fill'):
        raise ValueError('Selecciona Line, Fill u Offset Fill para los vectores.')
    if has_images and mode not in ('Image','Line','Fill','Offset Fill'):
        raise ValueError('El modo de la capa no admite imágenes.')

def _laser_menu(window):
    for action in window.menuBar().actions():
        menu=action.menu()
        if menu and action.text().replace('&','').strip().lower()=='laser': return menu
    return None

def _hide_test_panels(host):
    for box in host.findChildren(QGroupBox):
        if any(k in box.title().lower() for k in ('prueba','diagn','todas las pruebas')): box.hide()

class CalibrationDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('Calibración encuadre G2 nativo')
        from g2_native_frame import load_calibration
        c=load_calibration(); f=QFormLayout(self)
        self.sx=QDoubleSpinBox();self.sx.setRange(80,120);self.sx.setDecimals(3);self.sx.setSuffix(' %');self.sx.setValue(c.scale_x*100)
        self.sy=QDoubleSpinBox();self.sy.setRange(80,120);self.sy.setDecimals(3);self.sy.setSuffix(' %');self.sy.setValue(c.scale_y*100)
        self.ox=QDoubleSpinBox();self.ox.setRange(-20,20);self.ox.setDecimals(3);self.ox.setSuffix(' mm');self.ox.setValue(c.offset_x_mm)
        self.oy=QDoubleSpinBox();self.oy.setRange(-20,20);self.oy.setDecimals(3);self.oy.setSuffix(' mm');self.oy.setValue(c.offset_y_mm)
        self.ix=QCheckBox();self.ix.setChecked(c.invert_x);self.iy=QCheckBox();self.iy.setChecked(c.invert_y);self.sw=QCheckBox();self.sw.setChecked(c.swap_xy)
        self.pts=QSpinBox();self.pts.setRange(8,128);self.pts.setValue(c.edge_points)
        self.rep=QSpinBox();self.rep.setRange(1,50);self.rep.setValue(c.repeats)
        self.delay=QSpinBox();self.delay.setRange(1,1000);self.delay.setSuffix(' ms');self.delay.setValue(c.delay_ms)
        for n,w in [('Escala X',self.sx),('Escala Y',self.sy),('Offset X',self.ox),('Offset Y',self.oy),('Invertir X',self.ix),('Invertir Y',self.iy),('Intercambiar X/Y',self.sw),('Puntos por lado',self.pts),('Repeticiones',self.rep),('Retardo por punto',self.delay)]: f.addRow(n,w)
        note=QLabel('Base: campo 110×110 mm. El lienzo 43AYE3 se convierte directamente a coordenadas G2; no se importa ningún SVG ni se abre GLaser.');note.setWordWrap(True);f.addRow(note)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.RestoreDefaults)
        bb.accepted.connect(self.accept);bb.rejected.connect(self.reject);bb.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self.defaults);f.addRow(bb)
    def defaults(self):
        self.sx.setValue(100);self.sy.setValue(100);self.ox.setValue(0);self.oy.setValue(0);self.ix.setChecked(False);self.iy.setChecked(False);self.sw.setChecked(False);self.pts.setValue(8);self.rep.setValue(2);self.delay.setValue(80)
    def accept(self):
        from g2_native_frame import Calibration,save_calibration
        save_calibration(Calibration(scale_x=self.sx.value()/100,scale_y=self.sy.value()/100,offset_x_mm=self.ox.value(),offset_y_mm=self.oy.value(),invert_x=self.ix.isChecked(),invert_y=self.iy.isChecked(),swap_xy=self.sw.isChecked(),edge_points=self.pts.value(),repeats=self.rep.value(),delay_ms=self.delay.value()))
        super().accept()

def install_production_laser_panel(w):
    host=w.laser_dock.widget();layout=host.layout();_hide_test_panels(host)
    box=QGroupBox('G2 · control');g=QGridLayout(box);g.setAlignment(Qt.AlignmentFlag.AlignTop)
    state=QLabel('G2 nativa: sin comprobar · GLaser NO se usa');state.setWordWrap(True);state.setTextInteractionFlags(state.textInteractionFlags()|Qt.TextSelectableByMouse)
    connect_btn=QPushButton('CONECTAR');frame_btn=QPushButton('ENCUADRAR');stop_btn=QPushButton('STOP');mark_btn=QPushButton('MARCAR');vector_btn=QCheckBox('Seguir el trazado vectorial')
    for b in (connect_btn,frame_btn,stop_btn,mark_btn): b.setMinimumHeight(44)
    mark_btn.setToolTip('Marca vectores, Fill e imágenes tramadas por capa con los parámetros de su pluma.')
    mark_btn.setEnabled(False)
    frame_btn.setEnabled(False)
    vector_btn.setEnabled(False)
    vector_btn.setToolTip('Marcada: recorre todos los vectores visibles y subtrazos de SVG. Desmarcada: caja exterior.')
    frame_btn.setToolTip('Mantiene el encuadre rojo de caja o el trazado vectorial hasta pulsar STOP.')
    depth_btn=QPushButton('TALLADO EN PROFUNDIDAD…')
    image_depth_btn=QPushButton('CONFIGURAR TALLADO DE IMAGEN…')
    depth_btn.setToolTip('Configura gráficamente el relleno cruzado y las pasadas de una capa vectorial.')
    g.addWidget(state,0,0,1,3);g.addWidget(connect_btn,1,0);g.addWidget(frame_btn,1,1);g.addWidget(stop_btn,1,2);g.addWidget(mark_btn,2,0,1,3);g.addWidget(vector_btn,3,0,1,3);g.addWidget(depth_btn,4,0,1,3);g.addWidget(image_depth_btn,5,0,1,3);layout.addWidget(box)
    pass_label=QLabel('Pasadas: sin trabajo');pass_label.setWordWrap(True)
    pass_label.setToolTip('Se actualiza cuando termina un bloque del SDK. Las repeticiones internas de un bloque no tienen telemetría individual. STOP o un error no cuentan la pasada parcial.')
    g.addWidget(pass_label,6,0,1,3)
    eta_label=QLabel('Tiempo: sin trabajo');eta_label.setWordWrap(True)
    eta_label.setToolTip('Estimación por longitud y velocidad; se ajusta con bloques completados. No mide profundidad ni emisión física.')
    mark_progress=QProgressBar();mark_progress.setRange(0,100);mark_progress.setValue(0)
    mark_progress.setFormat('%p% · trayectorias confirmadas por SDK')
    g.addWidget(eta_label,7,0,1,3);g.addWidget(mark_progress,8,0,1,3)
    runtime={'ready':False,'frame_proc':None,'mark_proc':None,'pending_marks':[],'completed_marks':[],
             'frame_repeat':False,'frame_continuous':False,'frame_args':None,'frame_args_list':[],
             'frame_env':None,'frame_cycles':0,'frame_logs':[],'frame_start':0.0}
    poll=QTimer(w);poll.setInterval(250)
    def set_state(t):
        state.setText(t)
        try:w.pos.setText(t)
        except Exception:pass
    def vendor():
        from g2_runtime import discover
        return discover()
    def frame_executable(needs_design=False):
        exe=APP/'BSL_SDK'/'43AYE3_G2_SDK'/'43AYE3_SDK_SELFTEST.exe'
        source=APP/'BSL_SDK'/'43AYE3_G2_SDK'/'sdk_selftest_x86.cpp'
        compat=APP/'BSL_SDK'/'43AYE3_G2_SDK'/'43AYE3_BSL_COMPAT.cpp'
        dll=exe.with_name('43AYE3_BSL_COMPAT.dll')
        if (not exe.is_file() or not dll.is_file() or
                source.stat().st_mtime>exe.stat().st_mtime or
                compat.stat().st_mtime>dll.stat().st_mtime):
            set_state('Compilando el encuadre de contornos G2...')
            from PySide6.QtWidgets import QApplication
            QApplication.processEvents()
            result=subprocess.run(['cmd.exe','/d','/c',str(APP/'COMPILAR_SDK_43AYE3.bat')],
                cwd=str(APP),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            if result.returncode or not exe.is_file():
                raise RuntimeError('No se pudo compilar el encuadre de contornos.\n'+result.stdout[-3000:])
        if not exe.is_file():raise RuntimeError('Ejecuta COMPILAR_SDK_43AYE3.bat antes de abrir el programa.')
        return exe
    def check_state(show=True):
        from device_state_readonly_client import run_device_state_readonly_probe
        v=vendor()
        if v is None:
            runtime['ready']=False
            frame_btn.setEnabled(False);vector_btn.setEnabled(False);mark_btn.setEnabled(False)
            set_state('G2: falta G2_RUNTIME local');return False
        set_state('G2: comprobando conexión nativa...');connect_btn.setEnabled(False)
        try:
            r=run_device_state_readonly_probe(APP,vendor_dir=v,timeout=40);ready=bool(r.get('ok') and r.get('device_ready'));runtime['ready']=ready
            set_state('G2: LISTA · control nativo directo · GLaser NO usado' if ready else 'G2: NO DISPONIBLE · comprueba USB/alimentación')
            frame_btn.setEnabled(ready)
            vector_btn.setEnabled(ready)
            mark_btn.setEnabled(ready)
            if show and not ready: QMessageBox.warning(w,'G2', '\n'.join(r.get('lines',[])[-18:]))
            return ready
        finally:connect_btn.setEnabled(True)
    def stop_frame_process():
        runtime['frame_repeat']=False
        runtime['frame_continuous']=False
        p=runtime.get('frame_proc')
        if p is not None and p.poll() is None:
            api=ctypes.windll.kernel32
            api.OpenEventW.argtypes=(ctypes.c_uint32,ctypes.c_int,ctypes.c_wchar_p)
            api.OpenEventW.restype=ctypes.c_void_p
            api.SetEvent.argtypes=(ctypes.c_void_p,)
            api.CloseHandle.argtypes=(ctypes.c_void_p,)
            name=f'Local\\43AYE3_G2_RED_STOP_{p.pid}'
            until=time.monotonic()+0.6
            while time.monotonic()<until and p.poll() is None:
                event=api.OpenEventW(0x0002,False,name)
                if event:
                    api.SetEvent(event);api.CloseHandle(event);break
                time.sleep(0.05)
            try:p.wait(timeout=5)
            except Exception:
                try:p.kill()
                except Exception:pass
                try:p.wait(timeout=1)
                except Exception:pass
        if p is not None and p.poll() is not None:
            try:
                out=p.stdout.read() if p.stdout else ''
                runtime['frame_logs'].append(out)
                (APP/'RESULTADO_ENCUADRE_UI.txt').write_text('\n\n'.join(runtime['frame_logs'][-10:]),encoding='utf-8')
                if 'RED_CALL_BEGIN' in out and 'RED_CALL_END' not in out:
                    set_state('G2: llamada de encuadre bloqueada en SDK; revisa RESULTADO_ENCUADRE_UI.txt')
            except Exception:pass
        runtime['frame_proc']=None;runtime['ready']=False
        poll.stop();frame_btn.setEnabled(False);vector_btn.setEnabled(False);mark_btn.setEnabled(False)
    def stop_device():
        estimate=runtime.get('time_estimate')
        if estimate:estimate.stop();eta_label.setText(estimate.text())
        if runtime.get('pass_counter'):pass_label.setText(runtime['pass_counter'].text(stopped=True))
        runtime['pending_marks']=[]
        stop_frame_process()
        p=runtime.get('mark_proc')
        if p is not None and p.poll() is None:
            api=ctypes.windll.kernel32
            api.OpenEventW.argtypes=(ctypes.c_uint32,ctypes.c_int,ctypes.c_wchar_p)
            api.OpenEventW.restype=ctypes.c_void_p
            api.SetEvent.argtypes=(ctypes.c_void_p,)
            api.CloseHandle.argtypes=(ctypes.c_void_p,)
            until=time.monotonic()+1.0
            while time.monotonic()<until and p.poll() is None:
                event=api.OpenEventW(0x0002,False,f'Local\\43AYE3_G2_MARK_STOP_{p.pid}')
                if event:api.SetEvent(event);api.CloseHandle(event);break
                time.sleep(0.05)
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill();p.wait(timeout=2)
        if p is not None and p.poll() is not None and p.stdout is not None:
            try:(APP/'RESULTADO_MARCADO_VECTORIAL.txt').write_text(p.stdout.read(),encoding='utf-8')
            except Exception:pass
        log=runtime.pop('mark_log',None)
        if log:log.close()
        folder=runtime.pop('mark_queue_dir',None)
        if folder:
            import shutil
            shutil.rmtree(folder,ignore_errors=True)
        runtime['mark_proc']=None;runtime['ready']=False
        frame_btn.setEnabled(False);vector_btn.setEnabled(False);mark_btn.setEnabled(False)
        from device_active_safe_client import run_device_active_safe_probe
        v=vendor();set_state('G2: STOP nativo...')
        if v is None:return
        r=run_device_active_safe_probe(APP,vendor_dir=v,timeout=40)
        set_state('G2: STOP confirmado · pulsa CONECTAR' if r.get('ok') else 'G2: STOP no confirmado · usa diagnóstico')
    def finish_frame():
        estimate=runtime.get('time_estimate')
        if estimate:
            eta_label.setText(estimate.text());mark_progress.setValue(estimate.percent)
        mp=runtime.get('mark_proc')
        if mp is not None and mp.poll() is not None:
            log=runtime.pop('mark_log',None)
            if log:log.close()
            out=(APP/'RESULTADO_MARCADO_VECTORIAL.txt').read_text(encoding='utf-8',errors='replace') if log else (mp.stdout.read() if mp.stdout else '')
            out += f'\nPROCESS_EXIT_CODE={mp.returncode}\n'
            (APP/'RESULTADO_MARCADO_VECTORIAL.txt').write_text(out,encoding='utf-8')
            folder=runtime.pop('mark_queue_dir',None)
            if folder:
                import shutil
                shutil.rmtree(folder,ignore_errors=True)
            runtime['mark_proc']=None
            vector_btn.setEnabled(runtime['ready'])
            ok=mp.returncode==0 and 'VECTOR_MARK_RESULT=CALL_OK' in out
            runtime['completed_marks'].append((ok,out))
            counter=runtime.get('pass_counter')
            if counter:
                if ok:counter.confirm_block()
                pass_label.setText(counter.text(stopped=not ok))
            if estimate:
                if ok:estimate.confirm_block()
                else:estimate.stop()
                eta_label.setText(estimate.text());mark_progress.setValue(estimate.percent)
            if ok and runtime['pending_marks']:
                start_next_mark()
            else:
                runtime['pending_marks']=[];mark_btn.setEnabled(runtime['ready'])
                frame_btn.setEnabled(runtime['ready']);poll.stop()
                (APP/'RESULTADO_MARCADO_VECTORIAL.txt').write_text(
                    '\n\n'.join(x for _,x in runtime['completed_marks']),encoding='utf-8')
                set_state('MARCADO TERMINADO · comprueba la pieza' if ok else
                          f'MARCADO DETENIDO O FALLÓ · código {mp.returncode} · revisa resultado y pieza')
                if not ok:QMessageBox.warning(w,'Marcado',out[-3500:])
        p=runtime.get('frame_proc')
        if p is None:return
        if p.poll() is None:
            if (not runtime['frame_continuous'] and runtime['frame_start']
                    and time.monotonic()-runtime['frame_start']>15):
                stop_device()
                set_state('ENCUADRE BLOQUEADO · repetición desactivada')
                QMessageBox.warning(w,'Encuadre','El SDK no terminó la vuelta. Se ha enviado STOP y cancelado el encuadre. Guarda RESULTADO_ENCUADRE_UI.txt.')
            return
        try:out=p.stdout.read() if p.stdout else ''
        except Exception:out=''
        runtime['frame_logs'].append(out)
        try:(APP/'RESULTADO_ENCUADRE_UI.txt').write_text('\n\n'.join(runtime['frame_logs'][-10:]),encoding='utf-8')
        except Exception:pass
        runtime['frame_proc']=None
        one_shot_ok=(p.returncode==0 and ('FRAME_VECTOR_RESULT=PASS_CALL_VISUAL_PENDING' in out or
                                         'FRAME_BOX_RESULT=PASS_CALL_VISUAL_PENDING' in out))
        if runtime['frame_repeat'] and one_shot_ok:
            runtime['frame_cycles']+=1
            try:
                args_list=runtime['frame_args_list']
                next_args=args_list[runtime['frame_cycles']%len(args_list)]
                runtime['frame_proc']=subprocess.Popen(next_args,cwd=str(APP),
                    stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=runtime['frame_env'],
                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                set_state(f'ENCUADRE ROJO · vuelta {runtime["frame_cycles"]+1} · pulsa STOP')
                return
            except Exception as e:
                out+=f'\nREINICIO_ENCUADRE_ERROR={e}\n'
        was_continuous=runtime['frame_continuous']
        runtime['frame_repeat']=False;runtime['frame_continuous']=False;poll.stop()
        # The G2 can report Valid=0 after a successful red frame. A prior
        # read-only probe must never authorize the next active operation.
        runtime['ready']=False;frame_btn.setEnabled(False);vector_btn.setEnabled(False);mark_btn.setEnabled(False)
        if 'RED_LOOP_RESULT=STOPPED' in out:
            set_state('ENCUADRE ROJO DETENIDO')
        elif was_continuous:
            set_state('ENCUADRE CONTINUO TERMINÓ · revisa diagnóstico')
            QMessageBox.warning(w,'Encuadre continuo',out[-6000:] or 'El proceso terminó sin resultado.')
        elif one_shot_ok:
            set_state('ENCUADRE ROJO FINALIZADO · pulsa CONECTAR antes de marcar')
        else:
            set_state('ENCUADRE NATIVO: revisar diagnóstico')
            QMessageBox.warning(w,'Encuadre nativo · diagnóstico',out[-6000:] or 'El proceso terminó sin resultado.')
    poll.timeout.connect(finish_frame)
    def frame_job():
        if runtime.get('mark_proc') is not None and runtime['mark_proc'].poll() is None:
            QMessageBox.warning(w,'Encuadre','Hay un marcado en curso. Pulsa STOP.');return
        if runtime.get('frame_proc') is not None and runtime['frame_proc'].poll() is None:
            stop_device();return
        if vector_btn.isChecked():
            from laser_studio import RasterItem
            if not any(isinstance(it,RasterItem) and it.isVisible() for it in w.scene.items()):
                return vector_job()
        if not check_state(False): QMessageBox.warning(w,'Encuadrar','La G2 no está disponible.');return
        try:
            from g2_native_frame import frame_bounds,load_calibration,_map_logical
            rect,selected=frame_bounds(w);c=load_calibration()
            from laser_studio import RasterItem,GItem,GroupItem
            def visible_rasters(item):
                if isinstance(item,GroupItem):
                    for child in item.members():yield from visible_rasters(child)
                elif isinstance(item,RasterItem) and item.isVisible():yield item
            selected_items=list(w.selected()) if selected else []
            rasters=list({id(it):it for root in selected_items for it in visible_rasters(root)}.values())
            if not selected:
                rasters=[it for it in w.scene.items() if isinstance(it,RasterItem) and it.isVisible()]
            image_outline=None
            if len(rasters)==1 and (selected or len([it for it in w.scene.items() if it.isVisible() and isinstance(it,(RasterItem,GItem))])==1):
                image=rasters[0];r=image.boundingRect()
                corners=[r.topLeft(),r.topRight(),r.bottomRight(),r.bottomLeft(),r.topLeft()]
                image_outline=[_map_logical(image.mapToScene(p).x(),image.mapToScene(p).y(),c) for p in corners]
            pts=[_map_logical(x,y,c) for x in (rect.left(),rect.right()) for y in (rect.top(),rect.bottom())]
            xx=[x for x,_ in pts]; yy=[y for _,y in pts]
            box=(min(xx),min(yy),max(xx),max(yy))
            if min(box[2]-box[0],box[3]-box[1])<=0:
                raise ValueError('El diseño debe tener ancho y alto mayores que cero.')
            limit=min(float(c.field_mm)/2.0,55.0)
            if any(abs(v)>limit+1e-6 for v in box):
                raise ValueError(f'Coordenadas G2 X {box[0]:.2f}…{box[2]:.2f} mm, '
                                 f'Y {box[1]:.2f}…{box[3]:.2f} mm. '
                                 f'Campo configurado: ±{limit:g} mm. Revisa posición y calibración.')
        except Exception as e: QMessageBox.warning(w,'Encuadre',str(e));return
        answer=QMessageBox.question(w,'Encuadre rojo G2',
            'Apaga físicamente la energía de la fibra antes de continuar.\n\n'
            f'El marco rojo de {box[2]-box[0]:.1f} × {box[3]-box[1]:.1f} mm '+
            'intentará mantenerse hasta pulsar STOP. Comprueba visualmente la primera prueba sin pieza.'+
            '\nSTOP físico al alcance.\n\n¿Iniciar?',
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer!=QMessageBox.StandardButton.Yes:return
        v=vendor()
        try:
            exe=frame_executable()
            env=os.environ.copy();env['G2PRO_VENDOR_DIR']=str(v)
            if image_outline is not None:
                args=[str(exe),'--loop-red-vector',*(f'{value:.4f}' for point in image_outline for value in point),f'--parent={os.getpid()}']
            else:
                args=[str(exe),'--loop-red-box',*(f'{value:.4f}' for value in box),f'--parent={os.getpid()}']
            p=subprocess.Popen(args,cwd=str(APP),stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT,text=True,env=env,
                               creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            runtime['frame_proc']=p;runtime['frame_repeat']=False;runtime['frame_continuous']=True;runtime['frame_start']=time.monotonic()
            runtime['frame_args_list']=[args];runtime['frame_env']=env;runtime['frame_cycles']=0;runtime['frame_logs']=[]
            frame_btn.setEnabled(False);poll.start()
            set_state(f'ENCUADRE CONTINUO: {"selección" if selected else "diseño"} · {box[2]-box[0]:.1f} × {box[3]-box[1]:.1f} mm · pulsa STOP')
        except Exception as e: QMessageBox.warning(w,'Encuadrar nativo',str(e));set_state('Encuadre nativo: error')
    def vector_job():
        if runtime.get('mark_proc') is not None and runtime['mark_proc'].poll() is None:
            QMessageBox.warning(w,'Contorno vectorial','Hay un marcado en curso. Pulsa STOP.');return
        if runtime.get('frame_proc') is not None and runtime['frame_proc'].poll() is None:
            QMessageBox.warning(w,'Contorno vectorial','Hay un encuadre en curso.');return
        if not check_state(False):
            QMessageBox.warning(w,'Contorno vectorial','La G2 no está disponible.');return
        try:
            from g2_vector_frame import all_vector_paths,backend_batches
            contours,bounds=all_vector_paths(w)
            total=sum(map(len,contours))
            batches=list(backend_batches(contours))
            if len(batches)!=1:
                raise ValueError('El trazado necesita varios lotes. Usa el encuadre de caja exterior para verlo completo.')
        except Exception as e:
            QMessageBox.warning(w,'Contorno vectorial',str(e));return
        answer=QMessageBox.question(w,'Contorno vectorial',
            'Apaga físicamente la energía de la fibra. GLaser cerrado y STOP físico al alcance.\n\n'
            f'Se repetirán {len(contours)} contornos y {total} puntos hasta pulsar STOP.\n\n¿Iniciar?',
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer!=QMessageBox.StandardButton.Yes:return
        try:
            exe=frame_executable(needs_design=True)
            env=os.environ.copy();env['G2PRO_VENDOR_DIR']=str(vendor())
            args_list=[]
            for index,batch in enumerate(batches):
                source=APP/f'TRAZADO_ROJO_G2_{index:03d}.txt'
                source.write_text(str(len(batch))+'\n'+''.join(
                    str(len(path))+'\n'+''.join(f'{x:.4f} {y:.4f}\n' for x,y in path)
                    for path in batch),encoding='ascii')
                args_list.append([str(exe),'--loop-red-design',str(source),f'--parent={os.getpid()}'])
            p=subprocess.Popen(args_list[0],cwd=str(APP),stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT,text=True,env=env,
                               creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            runtime['frame_proc']=p;runtime['frame_repeat']=False;runtime['frame_continuous']=True;runtime['frame_start']=time.monotonic();runtime['frame_args_list']=args_list
            runtime['frame_env']=env;runtime['frame_cycles']=0;runtime['frame_logs']=[]
            frame_btn.setEnabled(False);vector_btn.setEnabled(False);poll.start()
            set_state(f'CONTORNO CONTINUO: {len(contours)} contornos, {total} puntos · {bounds[2]-bounds[0]:.1f} × {bounds[3]-bounds[1]:.1f} mm · pulsa STOP')
        except Exception as e: QMessageBox.warning(w,'Contorno vectorial',str(e))
    def start_mark_queue(groups):
        from mark_queue import write_mark_queue
        exe=APP/'BSL_SDK'/'43AYE3_G2_SDK'/'43AYE3_SDK_SELFTEST.exe'
        env=os.environ.copy();env['G2PRO_VENDOR_DIR']=str(vendor())
        version=subprocess.run([str(exe),'--queue-version'],cwd=str(APP),env=env,
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=15,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if version.returncode or 'MARK_QUEUE_VERSION=1' not in version.stdout:
            raise RuntimeError('Actualiza el ejecutable nativo con COMPILAR_SDK_43AYE3.bat y reinicia. No se ha enviado el trabajo.')
        manifest=write_mark_queue(groups,APP)
        log=open(APP/'RESULTADO_MARCADO_VECTORIAL.txt','w',encoding='utf-8')
        try:
            p=subprocess.Popen([str(exe),'--mark-vector-queue',str(manifest),f'--parent={os.getpid()}'],
                cwd=str(APP),stdout=log,stderr=subprocess.STDOUT,env=env,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except Exception:
            log.close()
            import shutil
            shutil.rmtree(manifest.parent,ignore_errors=True)
            raise
        runtime['mark_log']=log;runtime['mark_queue_dir']=manifest.parent
        runtime['mark_proc']=p;runtime['pending_marks']=[];runtime['completed_marks']=[]
        mark_btn.setEnabled(False);frame_btn.setEnabled(False);vector_btn.setEnabled(False)
        poll.start();set_state(f'MARCANDO: sesión única · {len(groups)} bloques · hasta terminar o STOP')

    def start_next_mark():
        if not runtime['pending_marks']:
            return
        layer,contours,passes,speed,power,khz=runtime['pending_marks'].pop(0)
        source=APP/'TRAZADO_MARCADO_G2.txt'
        source.write_text(f'{len(contours)} {passes} {speed:.4f} {power:.4f} {khz:.4f}\n'+''.join(
            str(len(path))+'\n'+''.join(f'{x:.4f} {y:.4f}\n' for x,y in path)
            for path in contours),encoding='ascii')
        exe=APP/'BSL_SDK'/'43AYE3_G2_SDK'/'43AYE3_SDK_SELFTEST.exe'
        env=os.environ.copy();env['G2PRO_VENDOR_DIR']=str(vendor())
        p=subprocess.Popen([str(exe),'--mark-vector-design',str(source),f'--parent={os.getpid()}'],
            cwd=str(APP),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        runtime['mark_proc']=p;mark_btn.setEnabled(False);frame_btn.setEnabled(False)
        try:
            import json
            (APP/'MARCADO_UI_DIAGNOSTICO.txt').write_text(json.dumps({
                'ui_revision':'RECUPERACION_SDXL_ESPANOL_CONTADOR_ETA',
                'work':str(APP),'native_exe':str(exe),'command':'--mark-vector-design',
                'block_started':len(runtime['completed_marks'])+1,
                'blocks_remaining':len(runtime['pending_marks']),
                'layer':layer,'paths':len(contours),'passes':passes,
                'speed':speed,'power':power,'frequency_khz':khz,
            },indent=2,ensure_ascii=False),encoding='utf-8')
        except OSError:pass
        if runtime.get('pass_counter'):pass_label.setText(runtime['pass_counter'].text())
        poll.start();set_state(f'MARCANDO C{layer:02d}: {len(contours)} contornos · {speed:g} mm/s · {power:g}% · {khz:g} kHz · {passes} pasada(s)')
    def mark_job():
        if runtime.get('frame_proc') is not None and runtime['frame_proc'].poll() is None:
            QMessageBox.warning(w,'Marcado','Pulsa STOP para detener el encuadre antes de marcar.');return
        if runtime.get('mark_proc') is not None and runtime['mark_proc'].poll() is None:return
        progress=None
        try:
            from g2_vector_frame import layer_mark_paths,raster_mark_paths,depth_map_paths,backend_batches
            from laser_studio import GItem,RasterItem
            from image_marking_mode import is_depth_image, validate_image_for_marking
            for image in w.scene.items():
                if isinstance(image,RasterItem) and image.isVisible() and w.cuts[image.layer].output:
                    route=validate_image_for_marking(image.image_settings)
                    if route=="raster":
                        spacing=float(w.cuts[image.layer].interval)
                        if not math.isfinite(spacing) or spacing<=0:raise ValueError("El intervalo debe ser mayor que cero.")
                        image.image_settings.update(interval=spacing,dpi=25.4/spacing)
            layers=sorted({item.layer for item in w.scene.items() if isinstance(item,(GItem,RasterItem))
                           and item.isVisible() and w.cuts[item.layer].output},
                          key=lambda n:w.cuts[n].priority)
            if not layers:raise ValueError('No hay imágenes o vectores visibles con salida activada.')
            preview=[]
            for layer in layers:
                cut=w.cuts[layer]
                preview.append(f'C{layer:02d}: {cut.mode} · {cut.speed:g} mm/s · {cut.power:g}% · {cut.frequency:g} kHz · {cut.passes} pasada(s) de pluma')
                for image in w.scene.items():
                    if isinstance(image,RasterItem) and image.layer==layer and image.isVisible() and not is_depth_image(image.image_settings):
                        preview.append(f'  Imagen: {image.image_settings.get("mode")} · intervalo {image.image_settings.get("interval",cut.interval):g} mm · reverso {"sí" if image.image_settings.get("invert",False) else "no"}')
                    if isinstance(image,RasterItem) and image.layer==layer and image.isVisible() and is_depth_image(image.image_settings):
                        settings=image.image_settings
                        preview.append(f'  Mapa: máximo {settings.get("depth_passes",1)} pasadas · intervalo {settings.get("depth_interval",.1):g} mm')
                        if settings.get('depth_mm_enabled',False):
                            preview.append(f'  Objetivo {settings.get("depth_target_mm",0):g} mm · estimación desde muestra')
            answer=QMessageBox.question(w,'Confirmar marcado',
                'Se preparará y marcará este trabajo con las plumas configuradas:\n\n'+
                '\n'.join(preview)+'\n\nCierra GLaser y coloca la pieza. ¿Preparar y marcar?',
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer!=QMessageBox.StandardButton.Yes:return
            progress=QProgressDialog('Comprobando conexión nativa...', 'Cancelar preparación', 0, 0, w)
            progress.setWindowTitle('Preparando marcado')
            progress.setWindowModality(Qt.WindowModality.ApplicationModal)
            progress.setMinimumDuration(0);progress.setAutoClose(False);progress.setAutoReset(False)
            progress.show();QApplication.processEvents()
            if progress.wasCanceled():return
            if not check_state(False):
                raise RuntimeError('La G2 no está lista. No se ha enviado el trabajo. Revisa USB/alimentación y conecta de nuevo.')
            def preparing(layer,level=None,maximum=None):
                if maximum:
                    progress.setRange(0,maximum);progress.setValue(level)
                    progress.setLabelText(f'C{layer:02d}: preparando nivel {level} / {maximum}')
                else:
                    progress.setRange(0,0);progress.setLabelText(f'C{layer:02d}: preparando trayectorias...')
                QApplication.processEvents()
                if progress.wasCanceled():raise InterruptedError('Preparación cancelada. No se ha enviado marcado.')
            groups=[];cleanup_groups=[];allx=[];ally=[];total=0;summary=[]
            segments=[];cleanup_segments=[]
            def add_segment(target,batches,layer,passes,speed,power,khz,description):
                entries=[(layer,batch,passes,speed,power,khz) for batch in batches]
                if entries:
                    target.extend(entries)
                    (cleanup_segments if target is cleanup_groups else segments).append((len(entries),passes,description))
            for layer in layers:
                preparing(layer)
                cut=w.cuts[layer]
                vectors=[it for it in w.scene.items() if isinstance(it,GItem) and it.isVisible() and it.layer==layer]
                rasters=[it for it in reversed(w.scene.items()) if isinstance(it,RasterItem) and it.isVisible() and it.layer==layer]
                try:
                    validate_mark_layer_mode(cut.mode,bool(vectors),bool(rasters))
                except ValueError as e:
                    raise ValueError(f'C{layer:02d}: {e}') from e
                speed,power,khz,passes=float(cut.speed),float(cut.power),float(cut.frequency),int(cut.passes)
                if not (0<speed<=100000 and 0<=power<=100 and 1<=khz<=4000 and 1<=passes<=999):
                    raise ValueError(f'C{layer:02d}: revisa velocidad, potencia, frecuencia y pasadas.')
                contours=[];depth_generated=False
                if vectors:
                    vector_paths,_=layer_mark_paths(w,layer)
                    contours.extend(vector_paths)
                for image in rasters:
                    if is_depth_image(image.image_settings):
                        max_passes=int(image.image_settings.get('depth_passes',1))
                        if image.image_settings.get('depth_mm_enabled',False):
                            from depth_map_tools import passes_from_mm
                            settings=image.image_settings
                            profile=settings.get('depth_calibration_profile')
                            if profile:
                                from depth_calibration import assert_matching,maximum_passes
                                assert_matching(profile,cut,settings.get('depth_interval',.05))
                                max_passes=maximum_passes(settings.get('depth_target_mm',0),profile)
                            else:
                                max_passes,rate=passes_from_mm(settings.get('depth_target_mm',0),settings.get('depth_measured_mm',0),settings.get('depth_calibration_passes',0))
                            calibration=settings.get('depth_calibration_pen',{})
                            current={'speed':speed,'power':power,'frequency':khz,'interval':float(settings.get('depth_interval',.05))}
                            differences=[f'{key}: muestra {calibration.get(key,"sin guardar")} / actual {value:g}'
                                         for key,value in current.items()
                                         if not math.isfinite(float(calibration.get(key,-1))) or abs(float(calibration.get(key,-1))-value)>1e-8]
                            if not calibration or differences:
                                raise ValueError(f'C{layer:02d}: la pluma o el intervalo no coinciden con la calibración en mm.\n'+
                                    '\n'.join(differences)+'\n\nRestaura los valores de la muestra o mide otra muestra con los ajustes actuales y aplícala en Tallado imagen. No se ha enviado marcado.')
                        interval=float(image.image_settings.get('depth_interval',.1))
                        footprint=None
                        for level, depth_paths in depth_map_paths(image,max_passes,interval,lambda level,maximum:preparing(layer,level,maximum)):
                            depth_generated=True
                            add_segment(groups,backend_batches(depth_paths),layer,1,speed,power,khz,f'C{layer:02d} · tallado nivel {level}/{max_passes}')
                            if footprint is None:footprint=depth_paths
                        if footprint is not None and image.image_settings.get('depth_cleanup',False):
                            cs=float(image.image_settings.get('depth_cleanup_speed',1000.))
                            cp=float(image.image_settings.get('depth_cleanup_power',10.))
                            cf=float(image.image_settings.get('depth_cleanup_frequency',30.))
                            if not (0<cs<=100000 and 0<=cp<=100 and 1<=cf<=4000):
                                raise ValueError(f'C{layer:02d}: revisa la limpieza del mapa de profundidad.')
                            add_segment(cleanup_groups,backend_batches(footprint),layer,1,cs,cp,cf,f'C{layer:02d} · limpieza final')
                        summary.append(f'C{layer:02d}: mapa de profundidad · máximo {max_passes} pasadas · intervalo {interval:g} mm'+(' · limpieza final' if image.image_settings.get('depth_cleanup',False) else ''))
                    else:
                        raster_paths,_=raster_mark_paths(image)
                        contours.extend(raster_paths)
                if not contours and not depth_generated:
                    continue
                if contours:
                    bounds=(min(p[0] for path in contours for p in path),
                            min(p[1] for path in contours for p in path),
                            max(p[0] for path in contours for p in path),
                            max(p[1] for path in contours for p in path))
                    add_segment(groups,backend_batches(contours),layer,passes,speed,power,khz,f'C{layer:02d} · grabado')
                    allx.extend((bounds[0],bounds[2]));ally.extend((bounds[1],bounds[3]))
                if bool(getattr(cut,'depth_cleanup',False)) and cut.mode in ('Fill','Offset Fill') and vectors:
                    clean_speed=float(getattr(cut,'cleanup_speed',1000.))
                    clean_power=float(getattr(cut,'cleanup_power',10.))
                    clean_khz=float(getattr(cut,'cleanup_frequency',30.))
                    if not (0<clean_speed<=100000 and 0<=clean_power<=100 and 1<=clean_khz<=4000):
                        raise ValueError(f'C{layer:02d}: revisa los parámetros de limpieza.')
                    add_segment(cleanup_groups,backend_batches(vector_paths),layer,1,clean_speed,clean_power,clean_khz,f'C{layer:02d} · limpieza final')
                total+=sum(map(len,contours))
                methods=', '.join(sorted({it.image_settings.get('mode','Grayscale') for it in rasters}))
                if contours:summary.append(f'C{layer:02d}: {cut.mode}'+(f' + imagen {methods}' if rasters else '')+
                               f' · {len(contours)} trazos · {speed:g} mm/s · {power:g}% · {khz:g} kHz · {passes} pasada(s)'+
                               (f' · limpieza final 1 pasada {clean_speed:g} mm/s, {clean_power:g}%, {clean_khz:g} kHz' if bool(getattr(cut,'depth_cleanup',False)) and cut.mode in ('Fill','Offset Fill') and vectors else ''))
            if not groups:
                raise ValueError('El diseño no produjo trayectorias de marcado.')
            exe=APP/'BSL_SDK'/'43AYE3_G2_SDK'/'43AYE3_SDK_SELFTEST.exe'
            if not exe.is_file():raise RuntimeError('Compila el SDK con COMPILAR_SDK_43AYE3.bat.')
            if progress.wasCanceled():return
            progress.close()
            from mark_pass_counter import PassCounter
            runtime['pass_counter']=PassCounter(segments+cleanup_segments)
            from mark_time_estimate import MarkTimeEstimate
            runtime['time_estimate']=MarkTimeEstimate(groups+cleanup_groups)
            eta_label.setText(runtime['time_estimate'].text());mark_progress.setValue(0)
            pass_label.setText(runtime['pass_counter'].text())
            runtime['pending_marks']=groups+cleanup_groups;runtime['completed_marks']=[];start_next_mark()
        except InterruptedError as e:set_state(str(e))
        except Exception as e:QMessageBox.warning(w,'Marcado',str(e))
        finally:
            if progress is not None:progress.close()
    def configure_depth():
        from laser_studio import GItem,GroupItem,COLORS
        from deep_engraving_dialog import DeepEngravingDialog
        from PySide6.QtGui import QBrush,QColor
        from PySide6.QtWidgets import QTableWidgetItem
        def vectors(item):
            if isinstance(item,GroupItem):
                for child in item.members():yield from vectors(child)
            elif isinstance(item,GItem):yield item
        chosen=list({id(it):it for selected in w.selected() for it in vectors(selected)}.values())
        if not chosen:
            QMessageBox.information(w,'Tallado en profundidad','Selecciona un vector cerrado en el lienzo para configurar su capa.')
            return
        layers={it.layer for it in chosen}
        if len(layers)!=1:
            QMessageBox.information(w,'Tallado en profundidad','Selecciona vectores de una sola capa.')
            return
        layer=layers.pop();cut=w.cuts[layer]
        dialog=DeepEngravingDialog(layer,cut,len(chosen),w)
        if not dialog.exec():return
        dialog.apply_to(cut)
        for it in w.scene.items():
            if isinstance(it,GItem) and it.layer==layer:
                it.setBrush(QBrush(QColor(COLORS[layer%len(COLORS)])))
        if hasattr(w,'layer_table'):
            for j,value in enumerate((cut.name,cut.mode,str(cut.speed),str(cut.power),'✓')):
                w.layer_table.setItem(layer,j,QTableWidgetItem(value))
        if hasattr(w,'_cuts_table'):
            for j,value in ((1,cut.mode),(2,str(cut.speed)),(3,str(cut.power))):
                item=w._cuts_table.item(layer,j)
                if item:item.setText(value)
        if hasattr(w,'_sync_cut_controls') and w.active_layer==layer:w._sync_cut_controls(layer)
        w.changed=True;w.refresh_status();w.schedule_preview()
        w.statusBar().showMessage(f'C{layer:02d}: tallado Fill cruzado={cut.cross} · {cut.passes} pasadas · {cut.interval:g} mm')
    def configure_image_depth():
        from laser_studio import RasterItem,GroupItem
        from deep_engraving_dialog import ImageDepthDialog
        def images(item):
            if isinstance(item,GroupItem):
                for child in item.members():yield from images(child)
            elif isinstance(item,RasterItem):yield item
        chosen=list({id(it):it for selected in w.selected() for it in images(selected)}.values())
        if len(chosen)!=1:
            QMessageBox.information(w,'Mapa de profundidad','Selecciona exactamente una imagen, incluso si está agrupada.');return
        item=chosen[0];dialog=ImageDepthDialog(item,w.cuts[item.layer],w);dialog.enabled.setChecked(True)
        if dialog.exec():
            dialog.apply_to(item);w.update_cut_row(item.layer)
            if hasattr(w,'_image_load_selection'):w._image_load_selection()
            if hasattr(w,'_sync_cut_controls'):w._sync_cut_controls(item.layer)
            w.changed=True;w.refresh_status();w.schedule_preview()
            w.statusBar().showMessage(f'C{item.layer:02d}: tallado y pluma guardados · {item.image_settings["depth_passes"]} pasadas máximas · intervalo {item.image_settings["depth_interval"]:g} mm')
    def calibrate():CalibrationDialog(w).exec()
    connect_btn.clicked.connect(lambda:check_state(True));frame_btn.clicked.connect(frame_job);stop_btn.clicked.connect(stop_device);mark_btn.clicked.connect(mark_job);depth_btn.clicked.connect(configure_depth);image_depth_btn.clicked.connect(configure_image_depth)
    menu=_laser_menu(w)
    if menu:
        menu.addSeparator();
        menu.addAction('Calibrar encuadre',calibrate)
        menu.addAction('Tallado en profundidad…',configure_depth)
        menu.addAction('Tallado imagen · mapa de profundidad…',configure_image_depth)
    w._production_laser={'box':box,'state':state,'connect':connect_btn,'frame':frame_btn,
                         'vector':vector_btn,'stop':stop_btn,'mark':mark_btn,'depth':depth_btn,'image_depth':image_depth_btn}
