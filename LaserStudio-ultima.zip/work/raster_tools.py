from pathlib import Path
import numpy as np
from PIL import Image,ImageEnhance,ImageFilter,ImageOps
def load_rgba(path):
    return Image.open(path).convert("RGBA")
def adjust(img,brightness=1.,contrast=1.,gamma=1.,sharpen=0.,invert=False):
    x=img.convert("RGB")
    x=ImageEnhance.Brightness(x).enhance(brightness)
    x=ImageEnhance.Contrast(x).enhance(contrast)
    if gamma!=1:
        lut=[int(255*((i/255.)**(1/max(.01,gamma)))) for i in range(256)]
        x=x.point(lut*3)
    if sharpen>0:x=ImageEnhance.Sharpness(x).enhance(1+sharpen)
    if invert:x=ImageOps.invert(x)
    return x.convert("RGBA")
def grayscale_array(img):
    return np.asarray(img.convert("L"),dtype=np.uint8)
def trace_contours(img,threshold=128,min_area=8,epsilon=.002,alpha=False):
    import cv2
    a=np.asarray(img)
    if alpha and a.shape[2]>=4: gray=a[:,:,3]
    else: gray=cv2.cvtColor(a[:,:,:3],cv2.COLOR_RGB2GRAY)
    mask=(gray<=threshold).astype(np.uint8)*255 if not alpha else (gray>threshold).astype(np.uint8)*255
    cs,_=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    out=[]
    for c in cs:
        if abs(cv2.contourArea(c))<min_area:continue
        eps=epsilon*cv2.arcLength(c,True)
        q=cv2.approxPolyDP(c,eps,True).reshape(-1,2)
        if len(q)>=3:out.append([(float(x),float(y)) for x,y in q])
    return out

def brightness_from_slider(value):
    # -100 darker ... 0 original ... +100 brighter
    value=max(-100,min(100,int(value)))
    return 2.0**(value/100.0)

def darkness_from_slider(value):
    # 0 original ... 100 darker
    value=max(0,min(100,int(value)))
    return 2.0**(-value/100.0)
