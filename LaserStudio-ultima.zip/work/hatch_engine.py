"""Rayado de contornos SVG con aristas activas por línea de barrido."""
import math
from PySide6.QtCore import QPointF
from PySide6.QtGui import QTransform
from PySide6.QtCore import Qt

def horizontal_hatch(path, interval=.1, angle=0.0):
    if path.isEmpty() or interval <= 0:
        return []
    transform=QTransform();transform.rotate(-angle)
    rotated=transform.map(path);inverse,_=transform.inverted()
    box=rotated.boundingRect()
    step=max(.001,float(interval))
    count=int(box.height()/step)+2
    starts={};ends={};edges=[]
    for polygon in rotated.toSubpathPolygons():
        pts=list(polygon)
        if len(pts)<3:continue
        for a,b in zip(pts,pts[1:]+pts[:1]):
            ay,by=a.y(),b.y()
            if abs(ay-by)<=1e-9:continue
            low,high=min(ay,by),max(ay,by)
            first=max(0,math.ceil((low-box.top())/step-.5))
            last=min(count,math.ceil((high-box.top())/step-.5))
            if last<=first:continue
            index=len(edges)
            # El signo conserva la regla WindingFill; OddEvenFill usa paridad.
            edges.append((a.x(),ay,(b.x()-a.x())/(by-ay),1 if by>ay else -1))
            starts.setdefault(first,[]).append(index)
            ends.setdefault(last,[]).append(index)
    if not edges:return []
    segments=[];active={}
    odd_even=rotated.fillRule()==Qt.FillRule.OddEvenFill
    for line in range(count):
        y=box.top()+(line+.5)*step
        if y>=box.bottom():break
        for index in ends.get(line,()):active.pop(index,None)
        for index in starts.get(line,()):active[index]=edges[index]
        if len(active)<2:continue
        hits=sorted((ax+(y-ay)*slope, direction) for ax,ay,slope,direction in active.values())
        depth=0;previous=None;index=0
        while index<len(hits):
            x=hits[index][0]
            if previous is not None and x-previous>1e-7 and (depth%2 if odd_even else depth!=0):
                segments.append((inverse.map(QPointF(previous,y)),inverse.map(QPointF(x,y))))
            crossings=0;direction_sum=0
            while index<len(hits) and abs(hits[index][0]-x)<=1e-7:
                crossings+=1;direction_sum+=hits[index][1];index+=1
            depth+=(crossings if odd_even else direction_sum)
            previous=x
    return segments
