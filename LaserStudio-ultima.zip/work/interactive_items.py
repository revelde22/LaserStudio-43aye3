
from PySide6.QtCore import Qt,QRectF,QPointF
from PySide6.QtGui import QPen,QBrush,QColor,QPainterPath,QPixmap,QImage,QTransform
from PySide6.QtWidgets import QGraphicsRectItem,QGraphicsItem,QMenu,QGraphicsPixmapItem,QGraphicsPathItem
from PIL import Image,ImageEnhance,ImageOps,ImageFilter
import tempfile,pathlib

HANDLE=6.0
class ResizeHandle(QGraphicsRectItem):
    def __init__(self,parent,corner):
        super().__init__(-HANDLE/2,-HANDLE/2,HANDLE,HANDLE,parent)
        self.owner=parent;self.corner=corner
        self.setBrush(QBrush(QColor("white")));self.setPen(QPen(QColor("black")))
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations,True)
        self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)
        self.setCursor({"tl":Qt.CursorShape.SizeFDiagCursor,"br":Qt.CursorShape.SizeFDiagCursor,
                        "tr":Qt.CursorShape.SizeBDiagCursor,"bl":Qt.CursorShape.SizeBDiagCursor,
                        "l":Qt.CursorShape.SizeHorCursor,"r":Qt.CursorShape.SizeHorCursor,
                        "t":Qt.CursorShape.SizeVerCursor,"b":Qt.CursorShape.SizeVerCursor}[corner])
    def mousePressEvent(self,e):
        owner=self.owner
        owner._resize_start=(owner.sceneTransform().inverted()[0],owner.scale(),owner.transform(),owner.pos(),owner.boundingRect())
        if owner.scene() and hasattr(owner.scene(),"app"):owner.scene().app.begin_transform()
        e.accept()
    def mouseMoveEvent(self,e):
        self.owner.resize_from_handle(self.corner,e.scenePos());e.accept()
    def mouseReleaseEvent(self,e):
        self.owner._resize_start=None
        if self.owner.scene() and hasattr(self.owner.scene(),"app"):self.owner.scene().app.end_transform()
        e.accept()

class InteractiveMixin:
    def setup_interactive(self):
        self.setFlags(self.flags()|QGraphicsItem.GraphicsItemFlag.ItemIsSelectable|QGraphicsItem.GraphicsItemFlag.ItemIsMovable|QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges)
        self.setAcceptHoverEvents(True);self._resize_start=None;self._handles={}
        for c in ("tl","tr","bl","br","l","r","t","b"):self._handles[c]=ResizeHandle(self,c)
        self.update_handles()
    def update_handles(self):
        r=self.boundingRect()
        pos={"tl":r.topLeft(),"tr":r.topRight(),"bl":r.bottomLeft(),"br":r.bottomRight(),
             "l":QPointF(r.left(),r.center().y()),"r":QPointF(r.right(),r.center().y()),
             "t":QPointF(r.center().x(),r.top()),"b":QPointF(r.center().x(),r.bottom())}
        views=self.scene().views() if self.scene() else []
        shown=views[0].transform().mapRect(self.sceneBoundingRect()) if views else self.sceneBoundingRect()
        # At tiny sizes the eight handles cover the entire object and steal drag events.
        enough=min(shown.width(),shown.height())>=18
        sides=min(shown.width(),shown.height())>=32
        for c,h in getattr(self,"_handles",{}).items():
            h.setPos(pos[c]);h.setVisible(self.isSelected() and enough and (c in ("tl","tr","bl","br") or sides))
    def itemChange(self,change,value):
        if change in (QGraphicsItem.GraphicsItemChange.ItemSelectedHasChanged,
                      QGraphicsItem.GraphicsItemChange.ItemScaleHasChanged,
                      QGraphicsItem.GraphicsItemChange.ItemTransformHasChanged):
            self.update_handles()
        return super().itemChange(change,value)
    def contextMenuEvent(self,e):
        m=QMenu();delete=m.addAction("Delete");dup=m.addAction("Duplicate")
        a=m.exec(e.screenPos())
        if a==delete:self.scene().removeItem(self)
        elif a==dup:
            # handled generically by scene keyboard duplicate if available; safe no-op here
            pass
        e.accept()
    def resize_from_handle(self,corner,p):
        if not self._resize_start:return
        inv,oldscale,oldt,oldpos,r=self._resize_start
        anchors={"tl":r.bottomRight(),"tr":r.bottomLeft(),"bl":r.topRight(),"br":r.topLeft(),
                 "l":QPointF(r.right(),r.center().y()),"r":QPointF(r.left(),r.center().y()),
                 "t":QPointF(r.center().x(),r.bottom()),"b":QPointF(r.center().x(),r.top())}
        startpoints={"tl":r.topLeft(),"tr":r.topRight(),"bl":r.bottomLeft(),"br":r.bottomRight(),
                     "l":QPointF(r.left(),r.center().y()),"r":QPointF(r.right(),r.center().y()),
                     "t":QPointF(r.center().x(),r.top()),"b":QPointF(r.center().x(),r.bottom())}
        anchor=anchors[corner];start=startpoints[corner];local=inv.map(p)
        kx=max(.01,(local.x()-anchor.x())/(start.x()-anchor.x())) if corner not in ("t","b") else 1.0
        ky=max(.01,(local.y()-anchor.y())/(start.y()-anchor.y())) if corner not in ("l","r") else 1.0
        if corner in ("tl","tr","bl","br"):
            k=min(kx,ky);kx=ky=k
        self.setPos(oldpos);self.setScale(oldscale);self.setTransform(oldt,False)
        before=self.mapToScene(anchor)
        transform=QTransform(oldt);transform.scale(kx,ky)
        self.setTransform(transform,False)
        after=self.mapToScene(anchor)
        self.moveBy(before.x()-after.x(),before.y()-after.y())
        self.update_handles()

def marking_preview_file(source,darkness=0,contrast=1.15,gamma=.95,sharpen=1.2):
    img=Image.open(source).convert("L")
    img=ImageEnhance.Contrast(img).enhance(contrast)
    if gamma!=1:
        lut=[int(255*((i/255.)**(1/max(.01,gamma)))) for i in range(256)]
        img=img.point(lut)
    if sharpen:img=ImageEnhance.Sharpness(img).enhance(sharpen)
    if darkness:
        img=ImageEnhance.Brightness(img).enhance(2**(-max(0,min(100,darkness))/100))
    # engraving-style monochrome preview, retains grayscale rather than destructive threshold
    out=pathlib.Path(tempfile.gettempdir())/("43aye3_marking_"+pathlib.Path(source).stem+".png")
    img.save(out);return str(out)
