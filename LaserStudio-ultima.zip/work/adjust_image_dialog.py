
from pathlib import Path
from PySide6.QtCore import Qt,QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import *
from laser_image_pipeline import prepare,MODES,interval_from_dpi,acceleration_name
from image_async import submit_prepare
from image_marking_mode import apply_image_settings, raster_grid
from image_display_utils import load_display_pixmap, replace_pixmap_keep_scene_bounds

class AdjustImageDialog(QDialog):
    def __init__(self,main,item):
        super().__init__(main);self.main=main;self.item=item
        self.setWindowTitle("Adjust Image");self.resize(1000,720)
        root=QHBoxLayout(self);left=QWidget();form=QFormLayout(left)
        self.mode=QComboBox();self.mode.addItems(MODES)
        def sl(lo,hi,val):
            q=QSlider(Qt.Orientation.Horizontal);q.setRange(lo,hi);q.setValue(val);return q
        st=dict(item.image_settings)
        self.mode.setCurrentText(st.get("mode","Grayscale"))
        self.b=sl(-100,100,st.get("brightness",0));self.d=sl(0,100,st.get("darkness",0))
        self.c=sl(-100,300,st.get("contrast",0));self.g=sl(20,300,int(st.get("gamma",1)*100))
        self.sh=sl(0,100,st.get("sharpen",0));self.th=sl(0,255,st.get("threshold",128))
        self.inv=QCheckBox();self.inv.setChecked(st.get("invert",False))
        self.interval=QDoubleSpinBox();self.interval.setRange(.005,1);self.interval.setDecimals(4);self.interval.setSuffix(" mm")
        self.interval.setValue(st.get("interval",.1))
        self.dpi=QDoubleSpinBox();self.dpi.setRange(25,5000);self.dpi.setDecimals(0);self.dpi.setSuffix(" DPI")
        self.dpi.setValue(st.get("dpi",254))
        self.labels={}
        def row(name,w,fmt=lambda v:str(v)):
            if isinstance(w,QSlider):
                box=QWidget();h=QHBoxLayout(box);h.setContentsMargins(0,0,0,0);h.addWidget(w);lab=QLabel(fmt(w.value()));lab.setMinimumWidth(48);h.addWidget(lab)
                w.valueChanged.connect(lambda v,lab=lab,fmt=fmt:lab.setText(fmt(v)));form.addRow(name,box)
            else:form.addRow(name,w)
        row("Image Mode",self.mode);row("Brightness",self.b);row("Darkness",self.d);row("Contrast",self.c)
        row("Gamma",self.g,lambda v:f"{v/100:.2f}");row("Sharpen",self.sh);row("Threshold",self.th);row("Reverso / negativo",self.inv)
        row("Line Interval",self.interval);row("DPI",self.dpi)
        reset=QPushButton("Reset");self.apply_btn=QPushButton("Apply");close=QPushButton("Close")
        hb=QHBoxLayout();hb.addWidget(reset);hb.addWidget(self.apply_btn);hb.addWidget(close);form.addRow(hb)
        root.addWidget(left,0)
        self.preview=QLabel();self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter);self.preview.setMinimumSize(650,600)
        self.preview.setStyleSheet("background:#202020");root.addWidget(self.preview,1)
        self.info=QLabel();form.addRow(self.info)
        self._busy=False;self._render_seq=0;self._render_tasks={};self._out=getattr(item,"preview_path",item.original_source);self._rendering=False;self._out_settings=None;self._requested_settings={}
        self._render_timer=QTimer(self);self._render_timer.setSingleShot(True);self._render_timer.setInterval(140);self._render_timer.timeout.connect(self.render)
        for q in (self.b,self.d,self.c,self.g,self.sh,self.th):q.valueChanged.connect(self.schedule_render)
        self.mode.currentTextChanged.connect(self.schedule_render);self.inv.toggled.connect(self.schedule_render)
        self.interval.valueChanged.connect(self.interval_changed);self.dpi.valueChanged.connect(self.dpi_changed)
        reset.clicked.connect(self.reset);self.apply_btn.clicked.connect(self.apply_to_canvas);close.clicked.connect(self.accept)
        self.render()
    def settings(self):
        return {"mode":self.mode.currentText(),"brightness":self.b.value(),"darkness":self.d.value(),"contrast":self.c.value(),
        "gamma":self.g.value()/100,"sharpen":self.sh.value(),"threshold":self.th.value(),"invert":self.inv.isChecked(),
        "interval":self.interval.value(),"dpi":self.dpi.value()}
    def interval_changed(self,*_):
        if self._busy:return
        self._busy=True;self.dpi.setValue(25.4/max(.0001,self.interval.value()));self._busy=False;self.schedule_render()
    def dpi_changed(self,*_):
        if self._busy:return
        self._busy=True;self.interval.setValue(interval_from_dpi(self.dpi.value()));self._busy=False;self.schedule_render()
    def schedule_render(self,*_):
        if not self._busy:self._render_timer.start()
    def _render_done(self,token,out,error):
        self._render_tasks.pop(token,None)
        if token!=self._render_seq:return
        if error:
            self._rendering=False;self.apply_btn.setEnabled(True);self.info.setText("ERROR: "+str(error));return
        self._out_settings=self._requested_settings.pop(token,None)
        self._out=out;pm=load_display_pixmap(out,1600)
        self.preview.setPixmap(pm.scaled(self.preview.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        self._rendering=False;self.apply_btn.setEnabled(True)
        st=self.settings();self.info.setText(f"{st['mode']} · {acceleration_name()} · {st['dpi']:.0f} DPI · {st['interval']:.4f} mm")
    def render(self,*_):
        st=self.settings();self._render_seq+=1;token=self._render_seq
        self._requested_settings.clear();self._requested_settings[token]=dict(st)
        self._rendering=True;self.apply_btn.setEnabled(False)
        self.info.setText(f"Procesando {st['mode']} en proceso separado… ({acceleration_name()})")
        kwargs={k:v for k,v in st.items() if k!="interval"}
        try:kwargs["size"]=raster_grid(self.item,st["interval"])
        except ValueError as exc:
            self._rendering=False;self.apply_btn.setEnabled(True);self.info.setText("ERROR: "+str(exc));return
        task=submit_prepare(token,self.item.original_source,kwargs,self._render_done)
        self._render_tasks[token]=task
    def apply_to_canvas(self):
        if self._render_timer.isActive() or self.settings()!=self._out_settings:
            self._render_timer.stop();self.render()
            self.info.setText("Procesando los ajustes actuales; pulsa Aplicar al terminar.")
            return
        if self._rendering:
            self.info.setText("Espera a que termine el procesado antes de aplicar.")
            return
        if not self._out or not Path(self._out).exists():
            self.info.setText("No hay una imagen procesada lista para aplicar.")
            return
        st=self.settings()
        before=self.item.sceneBoundingRect()
        try:
            if hasattr(self.main,"begin_transform"):self.main.begin_transform()
            apply_image_settings(self.item,st,self.main);self.item.preview_path=self._out
            pm=load_display_pixmap(self._out,2048)
            replace_pixmap_keep_scene_bounds(self.item,pm)
            after=self.item.sceneBoundingRect()
            self.main.scene.update();self.main.view.viewport().update()
            if hasattr(self.main,"_image_load_selection"):
                self.main._image_load_selection()
            self.main.changed=True
            self.info.setText(f"APLICADO · tamaño conservado {after.width():.3f} × {after.height():.3f} mm")
        finally:
            if hasattr(self.main,"end_transform"):self.main.end_transform()
    def reset(self):
        self.mode.setCurrentText("Grayscale");self.b.setValue(0);self.d.setValue(0);self.c.setValue(0);self.g.setValue(100)
        self.sh.setValue(0);self.th.setValue(128);self.inv.setChecked(False);self.interval.setValue(.1)
