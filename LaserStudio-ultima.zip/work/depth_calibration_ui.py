"""Editable measured response library; no automatic depth measurement."""
import uuid
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QHBoxLayout,QComboBox,QLineEdit,QDoubleSpinBox,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox,QCheckBox)
from PySide6.QtGui import QPainter,QPen,QColor
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget
from depth_calibration import load_profiles,save_profiles,validate_profile

class CurveView(QWidget):
    def __init__(self):super().__init__();self.points=[];self.setMinimumHeight(160)
    def paintEvent(self,event):
        painter=QPainter(self);painter.fillRect(self.rect(),QColor('#f4f7fa'));painter.setPen(QColor('#273947'))
        x,y,w,h=50,self.height()-32,self.width()-75,self.height()-55
        painter.drawLine(x,y,x+w,y);painter.drawLine(x,y,x,y-h)
        painter.drawText(x+5,self.height()-9,'Pasadas');painter.drawText(8,16,'mm')
        if not self.points:return
        maxn=self.points[-1][0];maxd=self.points[-1][1]
        painter.setPen(QPen(QColor('#126fa1'),2));last=(x,y)
        for n,d in self.points:
            now=(x+round(w*n/maxn),y-round(h*d/maxd));painter.drawLine(*last,*now);painter.drawEllipse(now[0]-3,now[1]-3,6,6);last=now
        painter.setPen(QColor('#273947'));painter.drawText(x+w-45,y+16,str(maxn));painter.drawText(7,35,f'{maxd:g}')

class CalibrationLibraryDialog(QDialog):
    def __init__(self,cut=None,interval=.05,parent=None):
        super().__init__(parent);self.setWindowTitle('Calibraciones de profundidad por material');self.resize(640,720);self.selected_profile=None;self.reference_origin=None
        self.profiles=load_profiles();layout=QVBoxLayout(self);form=QFormLayout();layout.addLayout(form)
        self.selector=QComboBox();self.selector.addItem('Nueva calibración',None)
        for p in self.profiles:self.selector.addItem(p['name']+' · '+p['material'],p['id'])
        form.addRow('Perfil guardado',self.selector)
        references=QPushButton('Mediciones publicadas de otros usuarios…');references.clicked.connect(self.external_references);form.addRow(references)
        self.local_measurements=QCheckBox('Mis puntos son mediciones realizadas en este equipo, material y pluma');self.local_measurements.hide();form.addRow(self.local_measurements)
        self.name=QLineEdit();self.material=QLineEdit(str(getattr(cut,'material','')));form.addRow('Nombre',self.name);form.addRow('Material / acabado',self.material)
        self.fields={}
        for k,label,value in [('speed','Velocidad (mm/s)',getattr(cut,'speed',1000)),('power','Potencia (%)',getattr(cut,'power',70)),('frequency','Frecuencia (kHz)',getattr(cut,'frequency',30)),('interval','Intervalo (mm)',interval),('focus_mm','Desenfoque anotado (mm)',0)]:
            control=QDoubleSpinBox();control.setDecimals(4);control.setRange(-100 if k=='focus_mm' else .0001,100000 if k=='speed' else 4000 if k=='frequency' else 100);control.setValue(value);self.fields[k]=control;form.addRow(label,control)
        note=QLabel('Introduce profundidades medidas de al menos dos muestras. Mismo material, foco y pluma; barrido de imagen en una dirección. El enfoque se anota manualmente, no se mide ni mueve desde esta ventana.');note.setWordWrap(True);layout.addWidget(note)
        self.table=QTableWidget(0,2);self.table.setHorizontalHeaderLabels(['Pasadas de muestra','Profundidad medida (mm)']);self.table.setColumnWidth(0,190);self.table.horizontalHeader().setStretchLastSection(True);layout.addWidget(self.table)
        row=QHBoxLayout();layout.addLayout(row)
        add=QPushButton('Añadir muestra');add.clicked.connect(lambda:self.add_row());row.addWidget(add)
        delete=QPushButton('Quitar muestra');delete.clicked.connect(lambda:self.table.removeRow(self.table.currentRow()) if self.table.currentRow()>=0 else None);row.addWidget(delete)
        self.curve=CurveView();layout.addWidget(self.curve);self.table.itemChanged.connect(self.refresh_curve)
        row=QHBoxLayout();layout.addLayout(row)
        save=QPushButton('Guardar perfil');save.clicked.connect(self.save);row.addWidget(save)
        remove=QPushButton('Eliminar perfil');remove.clicked.connect(self.remove);row.addWidget(remove)
        use=QPushButton('Usar perfil guardado');use.clicked.connect(self.use);row.addWidget(use)
        close=QPushButton('Cerrar');close.clicked.connect(self.reject);row.addWidget(close)
        self.selector.currentIndexChanged.connect(self.load)
    def external_references(self):
        from external_depth_ui import ExternalDepthDialog
        dialog=ExternalDepthDialog(self)
        if dialog.exec() and dialog.selected_report:self.prepare_external_draft(dialog.selected_report)
    def prepare_external_draft(self,report):
        self.selector.setCurrentIndex(0);self.table.setRowCount(0)
        self.name.setText('Mi calibración · '+report['title']);self.material.setText(report['material'])
        self.reference_origin={'source_kind':'external_reference','id':report['id'],'url':report['source_url'],'checked':report['checked'],'locally_measured':False}
        self.local_measurements.setChecked(False);self.local_measurements.show();self.refresh_curve()
    def add_row(self,values=('', '')):
        row=self.table.rowCount();self.table.insertRow(row)
        for i,v in enumerate(values):self.table.setItem(row,i,QTableWidgetItem(str(v)))
    def data(self):
        points=[]
        for row in range(self.table.rowCount()):
            points.append([float(self.table.item(row,c).text().replace(',','.')) if self.table.item(row,c) else 0 for c in range(2)])
        result=dict(id=self.selector.currentData() or uuid.uuid4().hex,name=self.name.text().strip(),material=self.material.text().strip(),points=points,pen={k:self.fields[k].value() for k in ('speed','power','frequency','interval')},focus_mm=self.fields['focus_mm'].value())
        if self.reference_origin:
            result['reference_origin']=dict(self.reference_origin,locally_measured=self.local_measurements.isChecked())
        return validate_profile(result)
    def refresh_curve(self):
        try:self.curve.points=self.data()['points']
        except (ValueError,TypeError):self.curve.points=[]
        self.curve.update()
    def load(self):
        pid=self.selector.currentData();p=next((p for p in self.profiles if p['id']==pid),None)
        self.table.setRowCount(0)
        self.reference_origin=p.get('reference_origin') if p else None
        self.local_measurements.setVisible(bool(self.reference_origin));self.local_measurements.setChecked(bool(self.reference_origin and self.reference_origin.get('locally_measured')))
        if not p:self.name.clear();self.refresh_curve();return
        self.name.setText(p['name']);self.material.setText(p['material'])
        for k,v in p['pen'].items():self.fields[k].setValue(v)
        self.fields['focus_mm'].setValue(p.get('focus_mm',0))
        for point in p['points']:self.add_row(point)
        self.refresh_curve()
    def save(self):
        try:
            p=self.data();rows=[x for x in self.profiles if x['id']!=p['id']]+[p];save_profiles(rows);self.profiles=rows
            index=self.selector.findData(p['id'])
            if index<0:self.selector.addItem(p['name']+' · '+p['material'],p['id']);index=self.selector.count()-1
            else:self.selector.setItemText(index,p['name']+' · '+p['material'])
            self.selector.setCurrentIndex(index);return p
        except (ValueError,OSError) as e:QMessageBox.warning(self,'Calibración',str(e));return None
    def remove(self):
        pid=self.selector.currentData()
        if not pid:return
        rows=[x for x in self.profiles if x['id']!=pid]
        try:save_profiles(rows)
        except (ValueError,OSError) as e:return QMessageBox.warning(self,'Calibración',str(e))
        self.profiles=rows;self.selector.removeItem(self.selector.currentIndex());self.selector.setCurrentIndex(0)
    def use(self):
        p=self.save()
        if p:self.selected_profile=p;self.accept()
