import json,sys
from pathlib import Path
from PySide6.QtCore import QObject,QProcess,QProcessEnvironment,Signal

class PreviewWorker(QObject):
    result=Signal(object);failed=Signal(str);finished=Signal()
    def __init__(self,options,parent=None):
        super().__init__(parent);self.options=options;self.active=False;self.done=False
        self.cancelled=False;self.buffer='';self.error_buffer='';self.delivered=False
        self.process=QProcess(self);self.process.started.connect(self.send)
        self.process.readyReadStandardOutput.connect(self.read)
        self.process.readyReadStandardError.connect(self.read_error)
        self.process.finished.connect(self.complete);self.process.errorOccurred.connect(self.error)
    def start(self):
        env=QProcessEnvironment.systemEnvironment();env.insert('PYTHONIOENCODING','utf-8')
        self.process.setProcessEnvironment(env);self.process.setWorkingDirectory(str(Path(__file__).resolve().parent))
        self.active=True;self.process.start(sys.executable,['-u',str(Path(__file__).with_name('depth_preview_cli.py'))])
    def send(self):
        if self.cancelled:self.process.kill();return
        self.process.write(json.dumps(self.options,ensure_ascii=False).encode('utf-8'));self.process.closeWriteChannel()
    def read(self):
        self.buffer+=bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace')
        while '\n' in self.buffer:
            line,self.buffer=self.buffer.split('\n',1)
            try:event=json.loads(line)
            except ValueError:continue
            if self.cancelled:continue
            if 'result' in event:self.delivered=True;self.result.emit(event['result'])
            if 'error' in event:self.delivered=True;self.failed.emit(event['error'])
    def read_error(self):
        self.error_buffer=(self.error_buffer+bytes(self.process.readAllStandardError()).decode('utf-8',errors='replace'))[-6000:]
    def finish(self):
        self.active=False
        if not self.done:self.done=True;self.finished.emit()
    def complete(self,code,*args):
        self.read();self.read_error()
        if not self.cancelled and not self.delivered:self.failed.emit('Falló el cálculo del mapa (código '+str(code)+'). '+self.error_buffer[-1500:])
        self.finish()
    def error(self,error):
        if error==QProcess.ProcessError.FailedToStart:
            if not self.cancelled:self.failed.emit('No se pudo iniciar el cálculo del mapa: '+self.process.errorString())
            self.finish()
    def isRunning(self):return self.active and not self.done
    def stop(self):
        self.cancelled=True
        if self.process.state()!=QProcess.ProcessState.NotRunning:self.process.kill()
    def wait(self,ms):return self.process.waitForFinished(ms)
