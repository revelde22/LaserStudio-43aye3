"""Editor de texto no modal. Los cambios se reflejan en el lienzo y Preview."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor,QPen,QBrush
from PySide6.QtWidgets import (QDialog,QFormLayout,QPlainTextEdit,QFontComboBox,QDoubleSpinBox,
    QCheckBox,QComboBox,QDialogButtonBox,QLabel)
from text_tools import text_path


def open_text_editor(main,item=None):
    from laser_studio import GItem,COLORS
    if getattr(main,"_text_dialog",None) is not None and main._text_dialog.isVisible():
        main._text_dialog.raise_();return main._text_dialog
    original=None
    if item is not None:
        original=(item.path(),item.rotation(),dict(getattr(item,"text_meta",{}) or {}),item.layer,item.brush(),item.transformOriginPoint())
    else:
        from PySide6.QtGui import QPainterPath
        item=GItem(QPainterPath(),"text");item.setPos(20,45)
        main.scene.addItem(item);main.apply_layer(item);item.setSelected(True)
    previous_mode=main.cuts[item.layer].mode
    meta=original[2] if original else {}
    dialog=QDialog(main);dialog.setWindowTitle("Texto — G2");dialog.setModal(False)
    form=QFormLayout(dialog)
    content=QPlainTextEdit(meta.get("text","Texto"));content.setFixedHeight(72)
    font=QFontComboBox();font.setCurrentFont(__import__('PySide6.QtGui',fromlist=['QFont']).QFont(meta.get("font","Arial")))
    def number(lo,hi,val,step=1,dec=2,suffix=""):
        q=QDoubleSpinBox();q.setRange(lo,hi);q.setDecimals(dec);q.setSingleStep(step);q.setValue(val);q.setSuffix(suffix);return q
    height=number(.5,110,meta.get("size_mm",8),.5,suffix=" mm")
    tracking=number(-5,20,meta.get("tracking_mm",0),.1,suffix=" mm")
    leading=number(.5,4,meta.get("line_spacing",1.2),.1)
    rotation=number(-360,360,meta.get("rotation",item.rotation()),1,suffix="°")
    bold=QCheckBox();bold.setChecked(meta.get("bold",False))
    italic=QCheckBox();italic.setChecked(meta.get("italic",False))
    mh=QCheckBox();mh.setChecked(meta.get("mirror_h",False))
    mv=QCheckBox();mv.setChecked(meta.get("mirror_v",False))
    alignment=QComboBox();alignment.addItems(["Left","Center","Right"]);alignment.setCurrentText(meta.get("align","Left"))
    mode=QComboBox();mode.addItems(["Line","Fill","Offset Fill","Image"]);mode.setCurrentText(main.cuts[item.layer].mode)
    for label,widget in (("Texto",content),("Fuente",font),("Altura",height),("Espacio entre letras",tracking),
        ("Espacio entre lineas",leading),("Alineacion",alignment),("Negrita",bold),("Cursiva",italic),
        ("Espejo horizontal",mh),("Espejo vertical",mv),("Giro",rotation),("Modo de capa",mode)):
        form.addRow(label,widget)
    note=QLabel("Los cambios aparecen al instante en el lienzo y en Preview.")
    form.addRow(note)
    buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
    form.addRow(buttons)

    def update(*_):
        text=content.toPlainText()
        settings={"text":text,"font":font.currentFont().family(),"size_mm":height.value(),
            "tracking_mm":tracking.value(),"line_spacing":leading.value(),"align":alignment.currentText(),
            "bold":bold.isChecked(),"italic":italic.isChecked(),"mirror_h":mh.isChecked(),
            "mirror_v":mv.isChecked(),"rotation":rotation.value()}
        item.setPath(text_path(text,settings["font"],settings["size_mm"],settings["bold"],settings["italic"],
            settings["tracking_mm"],settings["line_spacing"],settings["align"],settings["mirror_h"],settings["mirror_v"]))
        item.text_meta=settings;item.setTransformOriginPoint(item.path().boundingRect().center())
        item.setRotation(rotation.value());item.update_handles()
        cut=main.cuts[item.layer];cut.mode=mode.currentText()
        color=QColor(COLORS[item.layer%len(COLORS)]);item.setPen(QPen(color,0))
        item.setBrush(QBrush(color) if cut.mode in ("Fill","Offset Fill") else QBrush(Qt.BrushStyle.NoBrush))
        if hasattr(main,"_cuts_table"):main._cuts_table.item(item.layer,1).setText(cut.mode)
        if hasattr(main,"_sync_cut_controls"):main._sync_cut_controls(item.layer)
        main.changed=True;main.schedule_preview()
    content.textChanged.connect(update);font.currentFontChanged.connect(update)
    for spin in (height,tracking,leading,rotation):spin.valueChanged.connect(update)
    for checkbox in (bold,italic,mh,mv):checkbox.toggled.connect(update)
    alignment.currentTextChanged.connect(update);mode.currentTextChanged.connect(update)
    buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject)
    def finish(result):
        if result!=QDialog.DialogCode.Accepted:
            if original:
                path,angle,oldmeta,layer,brush,origin=original
                item.setPath(path);item.setRotation(angle);item.text_meta=oldmeta;item.layer=layer;item.setBrush(brush);item.setTransformOriginPoint(origin)
            elif item.scene():main.scene.removeItem(item)
            main.cuts[item.layer].mode=previous_mode
            if hasattr(main,"_cuts_table"):main._cuts_table.item(item.layer,1).setText(previous_mode)
            if hasattr(main,"_sync_cut_controls"):main._sync_cut_controls(item.layer)
        main._text_dialog=None;main.schedule_preview()
    dialog.finished.connect(finish)
    dialog.controls={"text":content,"font":font,"height":height,"tracking":tracking,"leading":leading,
                     "align":alignment,"mirror_h":mh,"mirror_v":mv,"rotation":rotation,"mode":mode}
    main._text_dialog=dialog
    update();dialog.show();main.view.ensureVisible(item,24,24)
    main.statusBar().showMessage("Texto añadido al lienzo; escribe en el editor y pulsa Aceptar")
    return dialog
