import math
import sys, json, math, copy, uuid, traceback, os, tempfile
from datetime import datetime
from pathlib import Path
from PySide6.QtCore import Qt, QRectF, QPointF, QTimer, QProcess, QSignalBlocker
from PySide6.QtGui import QAction, QColor, QPen, QBrush, QPainterPath, QKeySequence, QPixmap
from PySide6.QtWidgets import *
from interactive_items import InteractiveMixin, marking_preview_file

# La ejecución desde el BAT usa __main__; otros módulos importan laser_studio.
# Ambos nombres deben apuntar al mismo módulo para que isinstance reconozca
# los objetos de la matriz y los grupos creados desde el generador.
if __name__ == "__main__":
    sys.modules["laser_studio"] = sys.modules["__main__"]

COLORS=["#000000","#0066ff","#ff0000","#00aa44","#ffaa00","#aa00cc","#00aaaa","#777777",
        "#884400","#ff55aa","#55aaff","#88cc00","#cc6600","#6633cc","#009999","#999999"]

class Cut:
    def __init__(self,i):
        self.i=i; self.name=f"C{i:02d}"; self.mode="Line"; self.speed=1000.; self.power=20.; self.passes=1
        self.interval=.10; self.angle=0.; self.cross=False
        self.offset=.15
        self.frequency=30.0; self.output=True; self.show=True; self.locked=False; self.priority=i
        self.depth_cleanup=False; self.cleanup_speed=1000.; self.cleanup_power=10.; self.cleanup_frequency=30.
        self.sublayers=[]
    def dict(self): return vars(self).copy()

class GItem(InteractiveMixin,QGraphicsPathItem):
    def __init__(self,path,kind="path"):
        super().__init__(path); self.kind=kind; self.layer=0
        self.setFlags(self.GraphicsItemFlag.ItemIsSelectable|self.GraphicsItemFlag.ItemIsMovable|
                      self.GraphicsItemFlag.ItemSendsGeometryChanges)
        self.setPen(QPen(QColor(COLORS[0]),0))
        self.setBrush(Qt.BrushStyle.NoBrush)
        self.setup_interactive()
        self._path_revision=0
    def setPath(self,path):
        super().setPath(path)
        self._path_revision=getattr(self,"_path_revision",0)+1
    def shape(self):
        # Keep small vectors draggable from their interior after downsizing.
        p=super().shape();p.addRect(self.path().boundingRect());return p
    def mouseDoubleClickEvent(self,event):
        if self.kind=="text" and self.scene() and hasattr(self.scene().app,"text_editor"):
            self.scene().app.text_editor(self);event.accept();return
        super().mouseDoubleClickEvent(event)
    def data43(self):
        p=self.path(); pts=[]
        for i in range(p.elementCount()):
            e=p.elementAt(i); et=e.type; pts.append([e.x,e.y,int(et.value if hasattr(et,"value") else et)])
        return {"kind":self.kind,"layer":self.layer,"x":self.x(),"y":self.y(),
                "group_id":self.parentItem().group_id if isinstance(self.parentItem(),GroupItem) else None,
                "rot":self.rotation(),"sx":self.scale(),
                "transform":[self.transform().m11(),self.transform().m12(),self.transform().m21(),self.transform().m22(),self.transform().dx(),self.transform().dy()],
                "pts":pts,"text_meta":getattr(self,"text_meta",None),"source_svg":getattr(self,"source_svg",None),
                "test_settings":getattr(self,"test_settings",None),"label_width":getattr(self,"label_width",None)}

class RasterItem(InteractiveMixin,QGraphicsPixmapItem):
    def __init__(self,path):
        self.original_source=path; preview=marking_preview_file(path); super().__init__(QPixmap(preview));self.source_path=path;self.preview_path=preview;self.layer=0;self.kind="image"
        self.image_settings={"mode":"Grayscale","brightness":0,"darkness":0,"contrast":0,"gamma":1.0,"sharpen":0,"invert":False,"threshold":128,"interval":0.10,"dpi":254.0}
        self.setFlags(self.GraphicsItemFlag.ItemIsSelectable|self.GraphicsItemFlag.ItemIsMovable)
        self.setShapeMode(QGraphicsPixmapItem.ShapeMode.BoundingRectShape)
        self.setup_interactive()
        pm=self.pixmap()
        if pm.width(): self.setScale(40.0/pm.width())
    def data43(self):
        return {"kind":"image","layer":self.layer,"source":self.source_path,
                "group_id":self.parentItem().group_id if isinstance(self.parentItem(),GroupItem) else None,
                "x":self.x(),"y":self.y(),"rot":self.rotation(),"scale":self.scale(),
                "transform":[self.transform().m11(),self.transform().m12(),self.transform().m21(),self.transform().m22(),self.transform().dx(),self.transform().dy()],
                "image_settings":dict(self.image_settings)}

class GroupItem(InteractiveMixin,QGraphicsItemGroup):
    def __init__(self,group_id=None):
        super().__init__();self.group_id=group_id or uuid.uuid4().hex
        # Child artwork passes mouse input to the group; resize handles receive it directly.
        self.setHandlesChildEvents(False)
        self.setup_interactive()

    def members(self):
        return [item for item in self.childItems() if isinstance(item,(GItem,RasterItem,GroupItem))]

    def boundingRect(self):
        rect=QRectF()
        for item in self.members():
            part=item.mapRectToParent(item.boundingRect())
            rect=rect.united(part) if not rect.isNull() else part
        return rect

    def shape(self):
        path=QPainterPath();path.addRect(self.boundingRect());return path

    def data43(self):
        t=self.transform();parent=self.parentItem()
        return {"id":self.group_id,"parent_group_id":parent.group_id if isinstance(parent,GroupItem) else None,
                "x":self.x(),"y":self.y(),"rot":self.rotation(),"scale":self.scale(),
                "transform":[t.m11(),t.m12(),t.m21(),t.m22(),t.dx(),t.dy()]}

class Scene(QGraphicsScene):
    def __init__(self,app):
        super().__init__(0,0,110,110); self.app=app; self.start=None; self.preview=None; self.tool="select"
        self.setBackgroundBrush(QColor("#fafafa"))
    def drawBackground(self,p,r):
        super().drawBackground(p,r); p.save()
        p.setPen(QPen(QColor("#e5e5e5"),0))
        for x in range(0,111,5): p.drawLine(QPointF(x,0),QPointF(x,110))
        for y in range(0,111,5): p.drawLine(QPointF(0,y),QPointF(110,y))
        p.setPen(QPen(QColor("#bdbdbd"),0)); p.drawRect(QRectF(0,0,110,110)); p.restore()
    def mousePressEvent(self,e):
        if self.tool=="select": return super().mousePressEvent(e)
        self.start=e.scenePos()
        if self.tool in ("rect","ellipse","line","polygon","star"):
            path=QPainterPath()
            if self.tool=="line": path.moveTo(self.start); path.lineTo(self.start)
            else: path.addRect(QRectF(self.start,self.start))
            self.preview=GItem(path,self.tool); self.addItem(self.preview); self.app.apply_layer(self.preview)
        super().mousePressEvent(e)
    def mouseMoveEvent(self,e):
        if self.preview and self.start:
            q=e.scenePos(); path=QPainterPath()
            if self.tool=="rect": path.addRect(QRectF(self.start,q).normalized())
            elif self.tool=="ellipse": path.addEllipse(QRectF(self.start,q).normalized())
            elif self.tool in ("polygon","star"):
                c=self.start;dx=q.x()-c.x();dy=q.y()-c.y();rad=(dx*dx+dy*dy)**.5
                n=5; pts=[];count=n*(2 if self.tool=="star" else 1)
                for k in range(count):
                    rr=rad*(.45 if self.tool=="star" and k%2 else 1.0)
                    a=-math.pi/2+2*math.pi*k/count;pts.append(QPointF(c.x()+rr*math.cos(a),c.y()+rr*math.sin(a)))
                if pts:path.moveTo(pts[0]);[path.lineTo(v) for v in pts[1:]];path.closeSubpath()
            else: path.moveTo(self.start); path.lineTo(q)
            self.preview.setPath(path); return
        super().mouseMoveEvent(e)
    def mouseReleaseEvent(self,e):
        if self.preview:
            self.preview=None; self.start=None; self.app.changed=True; self.app.refresh_status()
            self.tool="select"; self.app.select_action.setChecked(True)
        super().mouseReleaseEvent(e)

class View(QGraphicsView):
    def __init__(self,s):
        super().__init__(s); self.setMouseTracking(True); self.setRenderHints(self.renderHints()|self.renderHints().Antialiasing)
        self.setDragMode(self.DragMode.RubberBandDrag); self.setTransformationAnchor(self.ViewportAnchor.AnchorUnderMouse)
        self._middle_pan=False; self._middle_last=None
    def wheelEvent(self,e):
        f=1.15 if e.angleDelta().y()>0 else 1/1.15; self.scale(f,f)
        for it in self.scene().selectedItems():
            if hasattr(it,"update_handles"):it.update_handles()
        if hasattr(self.scene().app,"refresh_status"):self.scene().app.refresh_status()
    def mouseMoveEvent(self,e):
        if self._middle_pan:
            p=e.position().toPoint(); last=self._middle_last or p
            dx=p.x()-last.x(); dy=p.y()-last.y()
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value()-dx)
            self.verticalScrollBar().setValue(self.verticalScrollBar().value()-dy)
            self._middle_last=p
            e.accept(); return
        q=self.mapToScene(e.position().toPoint())
        z=self.transform().m11()*100
        self.scene().app.statusBar().showMessage(f"X {q.x():.2f} mm · Y {q.y():.2f} mm · Zoom {z:.0f}% · Selected {len(self.scene().selectedItems())}")
        super().mouseMoveEvent(e)
    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.MiddleButton:
            self._middle_pan=True; self._middle_last=e.position().toPoint(); self.setCursor(Qt.CursorShape.ClosedHandCursor)
            e.accept(); return
        super().mousePressEvent(e)
    def mouseReleaseEvent(self,e):
        if e.button()==Qt.MouseButton.MiddleButton and self._middle_pan:
            self._middle_pan=False; self._middle_last=None; self.unsetCursor(); e.accept(); return
        super().mouseReleaseEvent(e); self.setDragMode(self.DragMode.RubberBandDrag)

class CutDialog(QDialog):
    def __init__(self,c,parent=None):
        super().__init__(parent); self.setWindowTitle("Cut Settings Editor"); self.c=c
        f=QFormLayout(self)
        self.mode=QComboBox(); self.mode.addItems(["Line","Fill","Offset Fill","Image"]); self.mode.setCurrentText(c.mode)
        self.speed=QDoubleSpinBox(); self.speed.setRange(.01,100000); self.speed.setValue(c.speed)
        self.power=QDoubleSpinBox(); self.power.setRange(0,100); self.power.setValue(c.power)
        self.frequency=QDoubleSpinBox(); self.frequency.setRange(1,4000); self.frequency.setDecimals(1); self.frequency.setSuffix(" kHz"); self.frequency.setValue(getattr(c,"frequency",30.0))
        self.passes=QSpinBox(); self.passes.setRange(1,999); self.passes.setValue(c.passes)
        self.interval=QDoubleSpinBox(); self.interval.setRange(.001,10); self.interval.setDecimals(3); self.interval.setValue(c.interval)
        self.offset=QDoubleSpinBox(); self.offset.setRange(0,10); self.offset.setDecimals(3); self.offset.setValue(c.offset)
        self.angle=QDoubleSpinBox(); self.angle.setRange(-360,360); self.angle.setValue(c.angle)
        self.cross=QCheckBox(); self.cross.setChecked(c.cross)
        for a,b in [("Mode",self.mode),("Speed mm/s",self.speed),("Power %",self.power),("Frequency (kHz)",self.frequency),("Passes",self.passes),
                    ("Line interval mm",self.interval),("Offset inset mm",self.offset),("Scan angle",self.angle),("Cross hatch",self.cross)]: f.addRow(a,b)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel); bb.accepted.connect(self.accept);bb.rejected.connect(self.reject);f.addRow(bb)
    def accept(self):
        c=self.c;c.mode=self.mode.currentText();c.speed=self.speed.value();c.power=self.power.value();c.frequency=self.frequency.value();c.passes=self.passes.value()
        c.interval=self.interval.value();c.offset=self.offset.value();c.angle=self.angle.value();c.cross=self.cross.isChecked();super().accept()

class Main(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("43AYE3 Laser Studio Pro"); self.resize(1450,900); self.changed=False
        self.cuts=[Cut(i) for i in range(16)]; self.active_layer=0
        self.scene=Scene(self); self.view=View(self.scene); self.setCentralWidget(self.view)
        self.make_actions(); self.make_menus(); self.make_tools(); self.make_layers(); self.make_laser(); self.make_palette()
        from professional_ui import install_professional_ui
        install_professional_ui(self)
        from professional_ui import install_v4_tools
        install_v4_tools(self)
        from professional_ui import install_v5_image_vector
        install_v5_image_vector(self)
        from professional_ui import install_v6_scale_materials
        install_v6_scale_materials(self)
        from classic_ui import install_classic_layout
        install_classic_layout(self)
        from functional_controls import install_functional_controls
        install_functional_controls(self)
        from rulers_live import install_rulers_live_image
        install_rulers_live_image(self)
        from image_controller import install_image_controller
        install_image_controller(self)
        self.normalize_layout()
        from lightburn_workflow import install_lightburn_workflow
        install_lightburn_workflow(self)
        from production_laser_panel import install_production_laser_panel
        install_production_laser_panel(self)
        for _n in ("start_btn","frame_btn","pause_btn","stop_btn"):
            _b=getattr(self,_n,None)
            if _b is not None:_b.hide()
        from comfy_design_ui import install_ai_design
        install_ai_design(self)
        from depth_map_ui import install_depth_map
        install_depth_map(self)
        from depth_material_tests_ui import install_depth_tests
        install_depth_tests(self)
        from right_accordion import install_right_accordion
        install_right_accordion(self)
        self._dedupe_shortcuts()

        self._preview_dialog=None
        self._preview_geometry_cache={}
        self._transform_depth=0
        self._preview_timer=QTimer(self);self._preview_timer.setSingleShot(True);self._preview_timer.setInterval(120)
        self._preview_timer.timeout.connect(self.refresh_preview)
        self.scene.changed.connect(lambda *_:self.schedule_preview())

        self.setWindowTitle("43AYE3 Laser Studio G2 · Editor Pro 2026.10.20 · Jarvis / Reverso")
        self.statusBar().showMessage("G2 V1 · 110 × 110 mm")
        from editor_history import EditorHistory
        self.editor_history=EditorHistory(self)
        self._dedupe_shortcuts()
    def act(self,text,slot,shortcut=None,check=False):
        a=QAction(text,self);a.triggered.connect(slot);a.setCheckable(check)
        if shortcut:a.setShortcut(QKeySequence(shortcut))
        return a
    def _dedupe_shortcuts(self):
        # The visible workflow is installed last. Qt ignores ambiguous shortcuts.
        seen={}
        for action in self.findChildren(QAction):
            shortcut=action.shortcut().toString()
            if not shortcut:continue
            if shortcut in seen:seen[shortcut].setShortcut(QKeySequence())
            seen[shortcut]=action
    def make_actions(self):
        self.select_action=self.act("Select",lambda:self.tool("select"),"Esc",True);self.select_action.setChecked(True)
        self.rect_action=self.act("Rectangle",lambda:self.tool("rect"),"R",True)
        self.ellipse_action=self.act("Ellipse",lambda:self.tool("ellipse"),"E",True)
        self.line_action=self.act("Line",lambda:self.tool("line"),"L",True)
    def make_menus(self):
        mb=self.menuBar()
        file=mb.addMenu("&File")
        for t,s,k in [("New",self.new,"Ctrl+N"),("Open Project",self.open,"Ctrl+O"),("Save",self.save,"Ctrl+S"),
                      ("Save As",self.saveas,"Ctrl+Shift+S"),("Import Image / Vector",self.import_any,"Ctrl+I"),("Import SVG",self.import_svg,None),("Importar STL como relieve",self.import_stl,None),("Export SVG",self.export_svg,"Alt+X"),("Exportar ORZX SDK",self.export_orzx,"Ctrl+Alt+X")]:
            file.addAction(self.act(t,s,k))
        edit=mb.addMenu("&Edit")
        edit.addAction(self.act("Seleccionar todo",self.select_all,"Ctrl+A"))
        edit.addAction(self.act("Delete",self.delete,"Del")); edit.addAction(self.act("Duplicate",self.duplicate,"Ctrl+D"))
        edit.addAction(self.act("Invertir colores de la imagen",lambda:self.invert_selected_image(),"Alt+Shift+N"))
        edit.addAction(self.act("Vectorizar imagen · Trace Bitmap",self.vectorize_image,"Alt+Shift+V"))
        arrange=mb.addMenu("&Arrange")
        self.group_action=self.act("Agrupar selección",self.group,"Ctrl+G")
        self.group_action.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
        arrange.addAction(self.group_action)
        for t,s in [("Ungroup",self.ungroup),("Flip Horizontal",lambda:self.flip(True)),
                    ("Flip Vertical",lambda:self.flip(False)),("Rotate 90° CW",lambda:self.rotate(90)),
                    ("Rotate 90° CCW",lambda:self.rotate(-90)),("Align Left",lambda:self.align("l")),
                    ("Align Right",lambda:self.align("r")),("Align Top",lambda:self.align("t")),
                    ("Align Bottom",lambda:self.align("b")),("Center Horizontal",lambda:self.align("h")),
                    ("Center Vertical",lambda:self.align("v")),("Distribute Horizontal",lambda:self.distribute(True)),
                    ("Distribute Vertical",lambda:self.distribute(False)),("Grid Array",self.grid_array),("Circular Array",self.circular_array)]:
            arrange.addAction(self.act(t,s))
        tools=mb.addMenu("&Tools")
        for t,s in [("Offset Shapes",self.offset),("Boolean Union",self.boolean_union),("Measure",self.measure),
                    ("Material Test",self.material_test),("Biblioteca materiales / liquidos",self.material_library),
                    ("Agregar parámetros a biblioteca",self.add_material_parameters),("Preview",self.preview)]:
            action=self.act(t,s)

            tools.addAction(action)
        insert=mb.addMenu("&Insert")
        insert.addAction(self.act("Add Text / Añadir texto",self.text_editor,"Ctrl+T"))
        win=mb.addMenu("&Window");win.addAction(self.act("Reset Layout",self.reset_layout))
        helpm=mb.addMenu("&Help")
        from documentation_help import install_help
        install_help(self, helpm)
        helpm.addAction(self.act("Acerca de",lambda:QMessageBox.information(self,"43AYE3 Laser Studio","43AYE3 Laser Studio G2 V1\nRelieve 5 + documentación integrada\nF1: manual completo")))
    def make_tools(self):
        tb=self.addToolBar("Main")
        for a in [self.select_action,self.rect_action,self.ellipse_action,self.line_action]:tb.addAction(a)
        tb.addSeparator()
        tb.addAction(self.act("Duplicate",self.duplicate,"Ctrl+D"));tb.addAction(self.act("Delete",self.delete,"Del"))
        tb.addAction(self.act("Preview",self.preview,"Alt+P"))
        self.fill_action=self.act("Fill selected",self.fill_selected,"Alt+Shift+F");tb.addAction(self.fill_action)
        tb.addAction(self.act("Añadir texto",self.text_editor))
        tb.addAction(self.act("Zoom Fit",self.fit,"F"))
        left=QToolBar("Create",self);self.addToolBar(Qt.ToolBarArea.LeftToolBarArea,left)
        for a in [self.select_action,self.rect_action,self.ellipse_action,self.line_action]:left.addAction(a)
    def make_layers(self):
        d=QDockWidget("Cuts / Layers",self);w=QWidget();v=QVBoxLayout(w);self.layer_table=QTableWidget(16,5)
        self.layer_table.setHorizontalHeaderLabels(["Layer","Mode","Speed","Power","Out"])
        for r,c in enumerate(self.cuts):
            self.layer_table.setItem(r,0,QTableWidgetItem(c.name));self.layer_table.setItem(r,1,QTableWidgetItem(c.mode))
            self.layer_table.setItem(r,2,QTableWidgetItem(str(c.speed)));self.layer_table.setItem(r,3,QTableWidgetItem(str(c.power)))
            it=QTableWidgetItem("✓");self.layer_table.setItem(r,4,it)
        self.layer_table.cellClicked.connect(lambda r,c:self.set_layer(r,assign_selection=False));self.layer_table.cellDoubleClicked.connect(lambda r,c:self.edit_cut(r))
        v.addWidget(self.layer_table); b=QPushButton("Edit Cut Settings");b.clicked.connect(lambda:self.edit_cut(self.active_layer));v.addWidget(b)
        d.setWidget(w);self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);self.layers_dock=d
    def make_laser(self):
        d=QDockWidget("Laser",self);w=QWidget();g=QGridLayout(w)
        self.device=QComboBox();self.device.addItems(["Gweike G2 Pro"])
        self.pos=QLabel("Gweike G2 Pro")
        self.usb_process=None
        d.setWidget(w);self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,d);self.laser_dock=d

    def check_g2_usb(self):
        if self.usb_process and self.usb_process.state()!=QProcess.ProcessState.NotRunning:
            return
        self.usb_check.setEnabled(False)
        self.pos.setText("Comprobando presencia USB en Windows...")
        self.usb_process=QProcess(self)
        self.usb_process.setWorkingDirectory(str(Path(__file__).resolve().parent))
        self.usb_process.finished.connect(self.usb_check_finished)
        self.usb_process.errorOccurred.connect(self.usb_check_error)
        self.usb_process.start(sys.executable,[str(Path(__file__).resolve().parent/"g2_usb_diagnostic.py")])

    def usb_check_finished(self,code,status):
        self.usb_check.setEnabled(True)
        output=bytes(self.usb_process.readAllStandardOutput()).decode("utf-8","replace")
        if code==0 and "RESULT=PNP_READY" in output:
            self.pos.setText("G2 detectado por Windows. FRAME/MARK fisicos pendientes de validar.")
        else:
            self.pos.setText("G2 USB sin validar. Ver G2_USB_DIAGNOSTICO.txt.")

    def usb_check_error(self,error):
        self.usb_check.setEnabled(True)
        self.pos.setText("No se pudo ejecutar el diagnostico USB. Verifica la instalacion.")
    def make_palette(self):
        tb=QToolBar("Palette",self);self.addToolBar(Qt.ToolBarArea.BottomToolBarArea,tb)
        for i,col in enumerate(COLORS):
            b=QPushButton(str(i));b.setFixedSize(32,24);b.setStyleSheet(f"background:{col};color:white");b.clicked.connect(lambda _,x=i:self.set_layer(x));tb.addWidget(b)
    def tool(self,t):
        supported={"select","rect","ellipse","line","polygon","star","pan","measure"}
        if t not in supported:
            self.statusBar().showMessage(f"{t}: not enabled until its editor is implemented")
            return
        self.scene.tool=t
        for a in [self.select_action,self.rect_action,self.ellipse_action,self.line_action]:a.setChecked(False)
        amap={"select":self.select_action,"rect":self.rect_action,"ellipse":self.ellipse_action,"line":self.line_action}
        if t in amap:amap[t].setChecked(True)
        if t=="pan":self.view.setDragMode(self.view.DragMode.ScrollHandDrag)
        elif t=="select":self.view.setDragMode(self.view.DragMode.RubberBandDrag)

    def keyPressEvent(self,e):
        if e.key()==Qt.Key.Key_Escape:
            self.tool('select');e.accept();return
        if e.key()==Qt.Key.Key_Delete:
            for i in list(self.scene.selectedItems()): self.scene.removeItem(i)
            e.accept();return
        super().keyPressEvent(e)

    def normalize_layout(self):
        # One right-side dock stack, no vertical pile-up.
        docks=[]
        for d in self.findChildren(QDockWidget):
            if d is getattr(self,"image_scale_dock",None) or d is getattr(self,"live_image_dock",None):
                d.hide();continue
            if d.objectName()=="":
                d.setObjectName("dock_"+d.windowTitle().replace(" ","_").replace("/","_"))
            docks.append(d)
        right=[d for d in docks if self.dockWidgetArea(d)==Qt.DockWidgetArea.RightDockWidgetArea]
        if right:
            base=getattr(self,"layers_dock",right[0])
            for d in right:
                if d is not base:self.tabifyDockWidget(base,d)
            base.raise_()
        self.resizeDocks(right,[320]*len(right),Qt.Orientation.Horizontal)
        self.setDockOptions(QMainWindow.DockOption.AllowTabbedDocks|QMainWindow.DockOption.AnimatedDocks)
        self.statusBar().showMessage("Ready · rulers 24 px · right panels tabbed")
    def selected(self):
        try:return [i for i in self.scene.selectedItems() if isinstance(i,(GItem,RasterItem,GroupItem))]
        except RuntimeError:return []
    def select_all(self):
        def record(message):
            try:
                with (Path(__file__).resolve().parent/"SELECCION_DIAGNOSTICO.txt").open("a",encoding="utf-8") as file:
                    file.write(f"{datetime.now().isoformat(timespec='seconds')} V26.3.38 · {message}\n")
            except OSError:pass
        record("TODO invocado")
        try:
            roots=[item for item in self.scene.items()
                   if isinstance(item,(GItem,RasterItem,GroupItem)) and not isinstance(item.parentItem(),GroupItem)]
            with QSignalBlocker(self.scene):
                self.scene.clearSelection()
                for item in roots:item.setSelected(True)
            self.scene.selectionChanged.emit()
            selected=len(self.selected())
            action=getattr(self,"_select_all_button",None)
            if action is not None:action.setText(f"TODO {selected}")
            record(f"objetos_raiz={len(roots)}; seleccionados={selected}")
            self.statusBar().showMessage(f"Seleccionados {selected} objetos; pulsa Ctrl+G para agruparlos")
        except Exception:
            record("ERROR: "+traceback.format_exc().replace("\n"," | "))
            message="No se pudo seleccionar. Adjunta SELECCION_DIAGNOSTICO.txt."
            self.statusBar().showMessage(message)
            dialog=QMessageBox(QMessageBox.Icon.Warning,"Seleccionar todo",message,QMessageBox.StandardButton.Ok,self)
            dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);dialog.show();self._select_feedback=dialog
    def closeEvent(self,e):
        self.editor_history.capture()
        if not self._confirm_replace_project():e.ignore();return
        depth=getattr(self,"_depth_map_dialog",None)
        if depth and not depth.shutdown():e.ignore();return
        ai=getattr(self,"_ai_design_dialog",None)
        if ai and not ai.shutdown():
            ai.show();ai.status.setText("Terminando la IA… Vuelve a cerrar en unos segundos.")
            e.ignore();return
        # Stop deferred UI work before Qt destroys Scene/QGraphicsItems.
        try:
            for t in self.findChildren(QTimer):t.stop()
            self.scene.selectionChanged.disconnect()
        except (RuntimeError,TypeError):
            pass
        e.accept()
    def apply_layer(self,it):
        it.layer=self.active_layer;c=self.cuts[self.active_layer]
        if isinstance(it,GItem):
            col=QColor(COLORS[self.active_layer%len(COLORS)]);it.setPen(QPen(col,0))
            if c.mode in ("Fill","Offset Fill"):
                it.setBrush(QBrush(col))
            else:
                it.setBrush(Qt.BrushStyle.NoBrush)
        self.refresh_status()

    def fill_selected(self):
        """Fill vectors; prepare selected rasters as threshold images for marking."""
        def leaves(item):
            if isinstance(item,GroupItem):
                for child in item.members():yield from leaves(child)
            else:yield item
        chosen=[leaf for item in self.selected() for leaf in leaves(item)]
        targets=[x for x in chosen if isinstance(x,GItem)]
        rasters=[x for x in chosen if isinstance(x,RasterItem)]
        if rasters:
            from laser_image_pipeline import prepare
            for it in rasters:
                it.image_settings["mode"]="Threshold"
                s=it.image_settings
                path=prepare(it.original_source,"Threshold",s.get("brightness",0),s.get("darkness",0),s.get("contrast",0),s.get("gamma",1),s.get("sharpen",0),s.get("invert",False),s.get("threshold",128),s.get("dpi",254))
                from image_display_utils import load_display_pixmap, replace_pixmap_keep_scene_bounds
                it.preview_path=path
                replace_pixmap_keep_scene_bounds(it,load_display_pixmap(path,2048))
                self.cuts[it.layer].mode="Image"
            if hasattr(self,"_image_controls"):
                mode=self._image_controls.get("mode")
                if mode:mode.setCurrentText("Threshold")
        if not targets:
            if rasters:self.changed=True;self.statusBar().showMessage("Imagen preparada en blanco y negro; Preview muestra el raster");self.schedule_preview()
            else:self.statusBar().showMessage("Fill: selecciona un vector o imagen")
            return
        layers=sorted({int(getattr(x,"layer",self.active_layer)) for x in targets})
        for layer in layers:
            self.cuts[layer].mode="Fill"
            for x in targets:
                if int(getattr(x,"layer",0))==layer:
                    col=QColor(COLORS[layer%len(COLORS)]);x.setPen(QPen(col,0));x.setBrush(QBrush(col))
            if hasattr(self,"layer_table"):
                c=self.cuts[layer]
                for j,val in enumerate([c.name,c.mode,str(c.speed),str(c.power),"✓"]): self.layer_table.setItem(layer,j,QTableWidgetItem(val))
            if hasattr(self,"_cuts_table"):
                self._cuts_table.item(layer,1).setText("Fill")
        self.changed=True;self.refresh_status();self.schedule_preview();self.statusBar().showMessage(f"Fill en {len(targets)} vector(es), {len(rasters)} imagen(es) en blanco y negro")

    def set_layer(self,i,assign_selection=True):
        self.active_layer=i
        if assign_selection:
            for x in self.selected(): self.apply_layer(x)
        if hasattr(self,"layer_table"):
            self.layer_table.blockSignals(True);self.layer_table.selectRow(i);self.layer_table.blockSignals(False)
        if hasattr(self,"_cuts_table"):
            self._cuts_table.blockSignals(True);self._cuts_table.selectRow(i);self._cuts_table.blockSignals(False)
        if hasattr(self,"_sync_cut_controls"):self._sync_cut_controls(i)
        self.refresh_status()
    def edit_cut(self,i):
        if CutDialog(self.cuts[i],self).exec():
            c=self.cuts[i]
            for image in self.scene.items():
                if isinstance(image,RasterItem) and image.layer==i:
                    image.image_settings.update(interval=c.interval,dpi=25.4/c.interval)
            if hasattr(self,"_image_load_selection"):self._image_load_selection()
            for j,x in enumerate([c.name,c.mode,str(c.speed),str(c.power),"✓"]):self.layer_table.setItem(i,j,QTableWidgetItem(x))
            if hasattr(self,"_cuts_table"):
                for j,value in ((1,c.mode),(2,str(c.speed)),(3,str(c.power))):self._cuts_table.item(i,j).setText(value)
            if hasattr(self,"_sync_cut_controls") and self.active_layer==i:self._sync_cut_controls(i)
            for it in self.scene.items():
                if isinstance(it,GItem) and it.layer==i:
                    it.setBrush(QBrush(QColor(COLORS[i%len(COLORS)])) if c.mode in ("Fill","Offset Fill") else QBrush(Qt.BrushStyle.NoBrush))
            from material_test_matrix import refresh_labels
            refresh_labels(self,i)
            self.changed=True
            self.schedule_preview()
    def delete(self):
        for i in self.selected():self.scene.removeItem(i)
    def duplicate(self):
        def clone(item,parent=None):
            if isinstance(item,GroupItem):
                result=GroupItem()
            elif isinstance(item,RasterItem):
                result=RasterItem(item.original_source);result.layer=item.layer
                result.image_settings=dict(item.image_settings)
            else:
                result=GItem(item.path(),item.kind);result.layer=item.layer
                result.setPen(item.pen());result.setBrush(item.brush())
                for name in ("text_meta","source_svg","test_settings","label_width"):
                    if hasattr(item,name):setattr(result,name,copy.deepcopy(getattr(item,name)))
            if parent is None:self.scene.addItem(result)
            else:result.setParentItem(parent);result.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
            result.setPos(item.pos());result.setRotation(item.rotation());result.setScale(item.scale())
            result.setTransform(item.transform(),False)
            if isinstance(item,GroupItem):
                for member in item.members():clone(member,result)
            result.update_handles()
            return result
        originals=list(self.selected());self.scene.clearSelection()
        for item in originals:
            result=clone(item);result.moveBy(2,2);result.setSelected(True);result.update_handles()
        if originals:self.changed=True;self.schedule_preview()
    def rotate(self,a):
        for i in self.selected():i.setRotation(i.rotation()+a)
    def flip(self,h):
        for i in self.selected():
            tr=i.transform();tr.scale(-1 if h else 1,1 if h else -1);i.setTransform(tr)
    def align(self,k):
        k={"left":"l","right":"r","top":"t","bottom":"b","center":"h"}.get(k,k)
        s=self.selected()
        if len(s)<2:return
        rs=[i.sceneBoundingRect() for i in s]; target=rs[-1]
        for i,r in zip(s[:-1],rs[:-1]):
            p=i.pos()
            if k=="l":p.setX(p.x()+target.left()-r.left())
            elif k=="r":p.setX(p.x()+target.right()-r.right())
            elif k=="t":p.setY(p.y()+target.top()-r.top())
            elif k=="b":p.setY(p.y()+target.bottom()-r.bottom())
            elif k=="h":p.setX(p.x()+target.center().x()-r.center().x())
            elif k=="v":p.setY(p.y()+target.center().y()-r.center().y())
            i.setPos(p)
    def distribute(self,h):
        s=sorted(self.selected(),key=lambda i:i.sceneBoundingRect().center().x() if h else i.sceneBoundingRect().center().y())
        if len(s)<3:return
        a=s[0].sceneBoundingRect().center();b=s[-1].sceneBoundingRect().center()
        for n,i in enumerate(s[1:-1],1):
            p=i.pos();v=(a.x()+(b.x()-a.x())*n/(len(s)-1)) if h else (a.y()+(b.y()-a.y())*n/(len(s)-1))
            c=i.sceneBoundingRect().center()
            if h:p.setX(p.x()+v-c.x())
            else:p.setY(p.y()+v-c.y())
            i.setPos(p)
    def group(self):
        selected=self.selected()
        roots=[i for i in selected if not isinstance(i.parentItem(),GroupItem)]
        def record(message):
            try:
                with (Path(__file__).resolve().parent/"AGRUPAR_DIAGNOSTICO.txt").open("a",encoding="utf-8") as file:
                    file.write(f"{datetime.now().isoformat(timespec='seconds')} V26.3.38 · {message}\n")
            except OSError:pass
        record(f"accion recibida; seleccion={len(selected)}; objetos_raiz={len(roots)}; grupos={sum(isinstance(i,GroupItem) for i in roots)}")
        if not roots:
            message="No hay objetos seleccionados. Pulsa TODO en la barra izquierda y luego GRUPO."
            self.statusBar().showMessage(message);record(message)
            dialog=QMessageBox(QMessageBox.Icon.Information,"Agrupar",message,QMessageBox.StandardButton.Ok,self)
            dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);dialog.show();self._group_feedback=dialog
            return None
        if len(roots)==1 and isinstance(roots[0],GroupItem):
            group=roots[0];message=f"Ya hay un grupo de {len(group.members())} objetos. Ajusta Width/Height."
            self.statusBar().showMessage(message);record(message)
            return group
        group=None
        try:
            self.scene.clearSelection()
            group=GroupItem();self.scene.addItem(group)
            for item in roots:
                group.addToGroup(item)
                item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
            group.setSelected(True)
            rect=group.sceneBoundingRect()
            if not rect.isEmpty():self.view.fitInView(rect.adjusted(-3,-3,3,3),Qt.AspectRatioMode.KeepAspectRatio)
            group.update_handles()
            self.changed=True;self.schedule_preview()
            message=f"Grupo creado: {len(roots)} objeto(s). Selección: 1 grupo; usa Width/Height."
            self.statusBar().showMessage(message);record(message)
            return group
        except Exception:
            record("ERROR: "+traceback.format_exc().replace("\n"," | "))
            if group is not None and group.scene() is self.scene:
                for item in group.members():
                    group.removeFromGroup(item);item.setAcceptedMouseButtons(Qt.MouseButton.LeftButton);item.setSelected(True)
                self.scene.removeItem(group)
            message="Error al agrupar. Adjunta AGRUPAR_DIAGNOSTICO.txt de la carpeta del programa."
            self.statusBar().showMessage(message)
            dialog=QMessageBox(QMessageBox.Icon.Warning,"Agrupar",message,QMessageBox.StandardButton.Ok,self)
            dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);dialog.show();self._group_feedback=dialog
            return None
    def ungroup(self):
        for group in [i for i in self.selected() if isinstance(i,GroupItem)]:
            members=group.members()
            group.setSelected(False)
            for item in members:
                group.removeFromGroup(item)
                item.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)
            for handle in group._handles.values():
                if handle.scene():self.scene.removeItem(handle)
            self.scene.removeItem(group)
            for item in members:item.setSelected(True)
            self.changed=True
        self.schedule_preview();self.refresh_status()
    def grid_array(self):
        originals=list(self.selected())
        if not originals:return
        rows,ok=QInputDialog.getInt(self,"Matriz rectangular","Filas",2,1,50)
        if not ok:return
        cols,ok=QInputDialog.getInt(self,"Matriz rectangular","Columnas",2,1,50)
        if not ok:return
        bounds=originals[0].sceneBoundingRect()
        for item in originals[1:]:bounds=bounds.united(item.sceneBoundingRect())
        gap,ok=QInputDialog.getDouble(self,"Matriz rectangular","Separación entre límites (mm)",2,0,1000,3)
        if not ok:return
        copies=[]
        for row in range(rows):
            for col in range(cols):
                if row==0 and col==0:continue
                self.scene.clearSelection()
                for item in originals:item.setSelected(True)
                self.duplicate()
                for item in self.selected():
                    item.moveBy(col*(bounds.width()+gap)-2,row*(bounds.height()+gap)-2)
                    copies.append(item)
        self.scene.clearSelection()
        for item in originals+copies:item.setSelected(True)
        self.changed=True;self.schedule_preview()

    def circular_array(self):
        originals=list(self.selected())
        if not originals:return
        count,ok=QInputDialog.getInt(self,"Matriz circular","Número total de posiciones",8,2,100)
        if not ok:return
        center=self.scene.sceneRect().center()
        from PySide6.QtGui import QTransform
        copies=[]
        for n in range(1,count):
            self.scene.clearSelection()
            for item in originals:item.setSelected(True)
            self.duplicate()
            turn=QTransform();turn.translate(center.x(),center.y());turn.rotate(360*n/count);turn.translate(-center.x(),-center.y())
            for item in self.selected():
                item.moveBy(-2,-2)
                matrix=item.sceneTransform()*turn
                item.setPos(0,0);item.setRotation(0);item.setScale(1);item.setTransformOriginPoint(0,0);item.setTransform(matrix)
                item.update_handles();copies.append(item)
        self.scene.clearSelection()
        for item in originals+copies:item.setSelected(True)
        self.changed=True;self.schedule_preview()

    def offset(self):
        from editor_tools import offset_selected
        offset_selected(self)
    def boolean_union(self):
        s=self.selected()
        if len(s)<2:return
        if any(not isinstance(i,GItem) for i in s):
            return QMessageBox.information(self,"Unión","Selecciona vectores sin agrupar; vectoriza las imágenes primero.")
        path=QPainterPath()
        for i in s:path=path.united(i.mapToScene(i.path()))
        for i in s:self.scene.removeItem(i)
        n=GItem(path,"boolean");self.scene.addItem(n);self.apply_layer(n)
    def measure(self):
        s=self.selected()
        if not s:return
        r=s[0].sceneBoundingRect();QMessageBox.information(self,"Measure",f"W {r.width():.3f} mm\nH {r.height():.3f} mm\nX {r.x():.3f}\nY {r.y():.3f}")
    def material_test(self):
        dock=getattr(self,"material_test_dock",None)
        if dock is not None:dock.show();dock.raise_()
    def material_library(self):
        from material_library import open_library
        open_library(self)
    def add_material_parameters(self):
        from material_library import open_library
        open_library(self,add_parameters=True)
    def vectorize_image(self):
        from vectorize_image import vectorize_selected
        vectorize_selected(self)

    def adjust_image(self):
        from adjust_image_dialog import AdjustImageDialog
        xs=[x for x in self.scene.selectedItems() if isinstance(x,RasterItem)]
        if not xs:
            xs=[x for x in self.scene.items() if isinstance(x,RasterItem)]
        if len(xs)!=1:
            QMessageBox.information(self,"Adjust Image","Select one image.")
            return
        d=AdjustImageDialog(self,xs[0]);d.exec()

    def preview(self):
        from visual_preview import PreviewDialog
        if self._preview_dialog is None:
            self._preview_dialog=PreviewDialog(self)
        else:self._preview_dialog.build()
        self._preview_dialog.show();self._preview_dialog.raise_();self._preview_dialog.activateWindow()

    def text_editor(self,item=None):
        from text_editor import open_text_editor
        return open_text_editor(self,item if isinstance(item,GItem) else None)

    def schedule_preview(self):
        if self._transform_depth:return
        if getattr(self,"_preview_dialog",None) is not None and self._preview_dialog.isVisible():
            self._preview_timer.start()

    def begin_transform(self):
        self._transform_depth+=1
        self._preview_timer.stop()

    def end_transform(self):
        self._transform_depth=max(0,self._transform_depth-1)
        if self._transform_depth==0:self.schedule_preview()

    def refresh_preview(self):
        if self._preview_dialog is not None and self._preview_dialog.isVisible():
            self._preview_dialog.build()

    def no_device(self):QMessageBox.information(self,"Design mode","No hardware backend selected. Design/plan functions remain available.")
    def fit(self):self.view.fitInView(self.scene.sceneRect(),Qt.AspectRatioMode.KeepAspectRatio)
    def refresh_status(self):self.statusBar().showMessage(f"Layer C{self.active_layer:02d} · Selected {len(self.scene.selectedItems())} · 110 × 110 mm")
    def ensure_cut_capacity(self,count):
        while len(self.cuts)<count:
            layer=len(self.cuts);self.cuts.append(Cut(layer))
            for table in (getattr(self,"layer_table",None),getattr(self,"_cuts_table",None)):
                if table is not None:table.setRowCount(len(self.cuts))
            self.update_cut_row(layer)

    def update_cut_row(self,layer):
        c=self.cuts[layer];color=QColor(COLORS[layer%len(COLORS)])
        old=getattr(self,"layer_table",None)
        if old is not None:
            old.blockSignals(True)
            for col,val in enumerate((c.name,c.mode,str(c.speed),str(c.power),"✓")):
                old.setItem(layer,col,QTableWidgetItem(val))
            old.blockSignals(False)
        table=getattr(self,"_cuts_table",None)
        if table is not None:
            table.blockSignals(True)
            for col,val in enumerate((c.name,c.mode,str(c.speed),str(c.power))):
                item=QTableWidgetItem(val)
                if col==0:item.setForeground(QBrush(color))
                table.setItem(layer,col,item)
            for col,checked in ((4,c.output),(5,c.show)):
                item=QTableWidgetItem();item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
                table.setItem(layer,col,item)
            table.blockSignals(False)
    def reset_layout(self):self.layers_dock.show();self.laser_dock.show();self.fit()
    def _confirm_replace_project(self):
        if hasattr(self,"editor_history"):self.editor_history.capture()
        if not self.changed:
            return True
        answer=QMessageBox.question(self,"Cambios sin guardar",
            "Hay cambios sin guardar. ¿Quieres guardar el proyecto antes de continuar?",
            QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Save)
        if answer==QMessageBox.StandardButton.Cancel:return False
        if answer==QMessageBox.StandardButton.Save:
            self.save()
            return not self.changed
        return True
    def new(self):
        if not self._confirm_replace_project():return
        self.scene.clear();self._preview_geometry_cache.clear()
        self.cuts=[Cut(i) for i in range(16)];self.active_layer=0
        for layer in range(len(self.cuts)):self.update_cut_row(layer)
        if hasattr(self,"filename"):del self.filename
        self.changed=False;self.refresh_status()
        if hasattr(self,"editor_history"):self.editor_history.reset()
    def save(self):
        if not hasattr(self,"filename"):return self.saveas()
        return self._save(self.filename)
    def saveas(self):
        fn,_=QFileDialog.getSaveFileName(self,"Save Project","","43AYE3 Project (*.43laser)")
        if not fn:return False
        fn=fn if fn.lower().endswith(".43laser") else fn+".43laser"
        if self._save(fn):self.filename=fn;return True
        return False
    def _save(self,fn):
        if hasattr(self,"editor_history"):self.editor_history.capture()
        data={"version":3,"field":[110,110],"cuts":[c.dict() for c in self.cuts],
              "groups":[i.data43() for i in self.scene.items() if isinstance(i,GroupItem)],
              "items":[i.data43() for i in self.scene.items() if isinstance(i,(GItem,RasterItem))]}
        temporary=None
        try:
            with tempfile.NamedTemporaryFile("w",encoding="utf-8",dir=Path(fn).parent,
                                             prefix=".43aye3-save-",suffix=".tmp",delete=False) as handle:
                temporary=Path(handle.name)
                json.dump(data,handle,indent=2,ensure_ascii=False)
                handle.flush();os.fsync(handle.fileno())
            os.replace(temporary,fn)
            self.changed=False
            return True
        except (OSError,TypeError,ValueError) as exc:
            QMessageBox.warning(self,"Guardar proyecto",f"No se pudo guardar el proyecto:\n{exc}")
            return False
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)
    def open(self):
        fn,_=QFileDialog.getOpenFileName(self,"Open Project","","43AYE3 Project (*.43laser)")
        if not fn:return
        try:
            d=json.loads(Path(fn).read_text(encoding="utf-8"))
            if not isinstance(d,dict) or not isinstance(d.get("cuts"),list) or not isinstance(d.get("groups"),list) or not isinstance(d.get("items"),list):
                raise ValueError("Formato de proyecto no válido")
            layer_count=len(d["cuts"])
            if not 1 <= layer_count <= 1024:
                raise ValueError('Número de capas no válido')
            for item in d["items"]:
                if not isinstance(item,dict) or not isinstance(item.get("layer",0),int) or not 0 <= item.get("layer",0) < layer_count:
                    raise ValueError("Objeto con capa no válida")
                if item.get("kind")!="image" and not isinstance(item.get("pts"),list):
                    raise ValueError("Vector sin puntos válidos")
            if not self._confirm_replace_project():return
            self.scene.clear();self._preview_geometry_cache.clear()
            def restore_transform(it,record):
                vals=record.get("transform")
                if isinstance(vals,list) and len(vals)==6:
                    from PySide6.QtGui import QTransform
                    it.setTransform(QTransform(*map(float,vals)),False)
                it.update_handles()
            self.ensure_cut_capacity(len(d.get("cuts",[])))
            for idx,cd in enumerate(d.get("cuts",[])[:len(self.cuts)]):
                c=self.cuts[idx]
                for k,v in cd.items():
                    if hasattr(c,k):setattr(c,k,v)
            groups={}
            for record in d.get("groups",[]):
                group=GroupItem(record.get("id"));self.scene.addItem(group)
                groups[group.group_id]=group
            for record in d.get("groups",[]):
                group=groups[record["id"]]
                parent=groups.get(record.get("parent_group_id"))
                if parent is not None:group.setParentItem(parent);group.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                group.setPos(float(record.get("x",0)),float(record.get("y",0)))
                group.setRotation(float(record.get("rot",0)));group.setScale(float(record.get("scale",1)))
                restore_transform(group,record)
            for x in d.get("items",[]):
                parent=groups.get(x.get("group_id"))
                if x.get("kind")=="image":
                    source=x.get("source","")
                    if not source or not Path(source).exists():
                        continue
                    it=RasterItem(source)
                    it.layer=int(x.get("layer",0));it.image_settings.update(x.get("image_settings",{}))
                    s=it.image_settings
                    from laser_image_pipeline import prepare
                    processed=prepare(source,s.get("mode","Grayscale"),s.get("brightness",0),s.get("darkness",0),s.get("contrast",0),s.get("gamma",1),s.get("sharpen",0),s.get("invert",False),s.get("threshold",128),s.get("dpi",254))
                    it.setPixmap(QPixmap(processed));it.preview_path=processed
                    it.setPos(float(x.get("x",0)),float(x.get("y",0)));it.setRotation(float(x.get("rot",0)));it.setScale(float(x.get("scale",it.scale())))
                    if parent is not None:it.setParentItem(parent);it.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                    restore_transform(it,x)
                    if it.scene() is None:self.scene.addItem(it)
                    continue
                p=QPainterPath()
                pts=x.get("pts",[])
                j=0
                while j<len(pts):
                    e=pts[j]; typ=int(e[2]) if len(e)>2 else (0 if j==0 else 1)
                    if typ==0:p.moveTo(e[0],e[1])
                    elif typ==2 and j+2<len(pts):
                        a,b=pts[j+1:j+3];p.cubicTo(e[0],e[1],a[0],a[1],b[0],b[1]);j+=2
                    elif typ!=3:p.lineTo(e[0],e[1])
                    j+=1
                it=GItem(p,x.get("kind","path"));it.layer=int(x.get("layer",0));it.setPen(QPen(QColor(COLORS[it.layer%len(COLORS)]),0))
                it.text_meta=x.get("text_meta");it.source_svg=x.get("source_svg")
                it.test_settings=x.get("test_settings");it.label_width=x.get("label_width")
                it.setPos(float(x.get("x",0)),float(x.get("y",0)));it.setRotation(float(x.get("rot",0)));it.setScale(float(x.get("sx",1)))
                it.setBrush(QBrush(QColor(COLORS[it.layer%len(COLORS)])) if self.cuts[it.layer].mode in ("Fill","Offset Fill") else QBrush(Qt.BrushStyle.NoBrush))
                if parent is not None:it.setParentItem(parent);it.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                restore_transform(it,x)
                if it.scene() is None:self.scene.addItem(it)
            for group in groups.values():group.update_handles()
            for layer in range(len(self.cuts)):self.update_cut_row(layer)
            self.filename=fn;self.changed=False;self.refresh_status()
            if hasattr(self,"editor_history"):self.editor_history.reset()
        except Exception as e:
            QMessageBox.critical(self,"Open Project",f"Could not open project:\n{e}")
    def import_any(self):
        fn,_=QFileDialog.getOpenFileName(self,"Import Image / Vector","",
            "Supported (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp *.svg);;Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp);;Vectors (*.svg)")
        if not fn:return
        if fn.lower().endswith(".svg"): return self.import_svg_file(fn)
        if any(isinstance(x,(GItem,RasterItem)) and x.layer==self.active_layer for x in self.scene.items()):
            free=next((n for n in range(len(self.cuts)) if not any(isinstance(x,(GItem,RasterItem)) and x.layer==n for x in self.scene.items())),self.active_layer)
            self.set_layer(free)
        self.cuts[self.active_layer].mode="Image"
        if hasattr(self,"_cuts_table"):self._cuts_table.item(self.active_layer,1).setText("Image")
        if hasattr(self,"_sync_cut_controls"):self._sync_cut_controls(self.active_layer)
        it=RasterItem(fn);it.layer=self.active_layer;self.scene.addItem(it);it.setPos(10,10);it.setSelected(True)
    def import_svg_file(self,fn):
        try:
            from svg_importer import load_svg_paths
            paths=load_svg_paths(fn)
            if not paths:
                QMessageBox.warning(self,"Import SVG","El archivo no contiene contornos vectoriales importables.")
                return
            compound=QPainterPath();compound.setFillRule(Qt.FillRule.WindingFill)
            for path in paths:compound.addPath(path)
            self.scene.clearSelection()
            it=GItem(compound,"svg");it.source_svg=str(fn)
            self.scene.addItem(it);self.apply_layer(it);it.setSelected(True)
            self.changed=True;self.view.ensureVisible(it,24,24)
            self.statusBar().showMessage(f"SVG importado como 1 objeto ({len(paths)} contornos). Arrastra el interior para moverlo; usa los tiradores para escalar.")
        except Exception as e:QMessageBox.warning(self,"Import SVG",str(e))
    def import_svg(self):
        fn,_=QFileDialog.getOpenFileName(self,"Import SVG","","SVG (*.svg)")
        if not fn:return
        self.import_svg_file(fn)
    def import_stl(self):
        from stl_relief_ui import importar_stl
        importar_stl(self)
    def export_orzx(self):
        from g2_native_orzx import export_job, NativeOrzxError
        from bsl_sdk_orzx import sdk_status
        sdk_state, sdk_detail = sdk_status()
        if sdk_state != 'API_PRESENT_UNVERIFIED':
            QMessageBox.warning(self,"Exportar ORZX", "El guardado ORZX todavía no está disponible.\n\n" + sdk_detail[-3500:])
            return
        fn,_=QFileDialog.getSaveFileName(self,"Exportar ORZX · 43AYE3 G2 SDK","trabajo.orzx","ORZX (*.orzx)")
        if not fn:return
        try:
            out,job,log=export_job(self,fn)
        except NativeOrzxError as exc:
            QMessageBox.warning(self,"Exportar ORZX · 43AYE3 SDK",str(exc));return
        except Exception as exc:
            QMessageBox.warning(self,"Exportar ORZX · 43AYE3 SDK",str(exc));return
        QMessageBox.information(self,"ORZX creado",f"Archivo creado mediante la DLL BSL seleccionada, sin GLaser:\n{out}\n\nCapas Cxx: Speed, Power, Frequency y Passes se escriben con BSL_SetPenParam. Vectores/Fill usan BSL_AddLinesToFile2 e imágenes BSL_AddBmpToFile.")

    def export_svg(self):
        fn,_=QFileDialog.getSaveFileName(self,"Export SVG","","SVG (*.svg)")
        if not fn:return
        lines=['<svg xmlns="http://www.w3.org/2000/svg" width="110mm" height="110mm" viewBox="0 0 110 110">']
        for i in self.scene.items():
            if isinstance(i,GItem):
                commands=[];p=i.path();j=0
                def xy(e):
                    pt=i.mapToScene(QPointF(e.x,e.y));return f"{pt.x():.3f} {pt.y():.3f}"
                while j<p.elementCount():
                    e=p.elementAt(j)
                    if e.type==QPainterPath.ElementType.MoveToElement:commands.append("M "+xy(e))
                    elif e.type==QPainterPath.ElementType.CurveToElement and j+2<p.elementCount():
                        commands.append("C "+" ".join(xy(p.elementAt(k)) for k in (j,j+1,j+2)));j+=2
                    elif e.type!=QPainterPath.ElementType.CurveToDataElement:commands.append("L "+xy(e))
                    j+=1
                if commands:
                    fill=COLORS[i.layer%len(COLORS)] if self.cuts[i.layer].mode in ("Fill","Offset Fill") else "none"
                    lines.append(f'<path d="{" ".join(commands)}" fill="{fill}" fill-rule="evenodd" stroke="{COLORS[i.layer%len(COLORS)]}" stroke-width="0.1"/>')
        lines.append("</svg>");Path(fn).write_text("\n".join(lines),encoding="utf-8")

if __name__=="__main__":
    app=QApplication(sys.argv);app.setApplicationName("43AYE3 Laser Studio Pro")
    w=Main();w.show();w.fit();sys.exit(app.exec())
