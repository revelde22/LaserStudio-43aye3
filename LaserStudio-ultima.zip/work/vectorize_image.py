from pathlib import Path
import cv2
import numpy as np
from PySide6.QtCore import Qt, QPointF
from PySide6.QtGui import QPainterPath
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QComboBox,QSlider,QSpinBox,QDoubleSpinBox,
                               QCheckBox,QDialogButtonBox,QLabel,QMessageBox)

class VectorizeDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('Vectorizar imagen · Trace Bitmap'); self.resize(430,360)
        v=QVBoxLayout(self); v.addWidget(QLabel('Convierte la imagen seleccionada en líneas vectoriales editables.'))
        f=QFormLayout(); v.addLayout(f)
        self.mode=QComboBox(); self.mode.addItems(['Contorno','Silueta / relleno','Línea central'])
        self.threshold=QSlider(Qt.Orientation.Horizontal); self.threshold.setRange(1,254); self.threshold.setValue(128)
        self.threshold_value=QSpinBox(); self.threshold_value.setRange(1,254); self.threshold_value.setValue(128)
        self.threshold.valueChanged.connect(self.threshold_value.setValue); self.threshold_value.valueChanged.connect(self.threshold.setValue)
        self.blur=QSpinBox(); self.blur.setRange(0,10); self.blur.setValue(1); self.blur.setSuffix(' px')
        self.min_area=QDoubleSpinBox(); self.min_area.setRange(0,10000); self.min_area.setValue(4); self.min_area.setSuffix(' px²')
        self.simplify=QDoubleSpinBox(); self.simplify.setRange(0,20); self.simplify.setDecimals(2); self.simplify.setValue(1.0); self.simplify.setSuffix(' px')
        self.invert=QCheckBox('Invertir blanco / negro'); self.replace=QCheckBox('Reemplazar imagen original'); self.replace.setChecked(False)
        self.fill=QCheckBox('Asignar capa como FILL');
        f.addRow('Modo',self.mode); f.addRow('Umbral',self.threshold); f.addRow('Valor',self.threshold_value); f.addRow('Suavizado',self.blur)
        f.addRow('Eliminar detalles menores de',self.min_area); f.addRow('Simplificar nodos',self.simplify); f.addRow('',self.invert); f.addRow('',self.replace); f.addRow('',self.fill)
        b=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel); b.button(QDialogButtonBox.StandardButton.Ok).setText('VECTORizar')
        b.accepted.connect(self.accept); b.rejected.connect(self.reject); v.addWidget(b)

def _load_gray(path):
    data=np.fromfile(str(path),dtype=np.uint8); img=cv2.imdecode(data,cv2.IMREAD_GRAYSCALE)
    if img is None: raise ValueError('No se pudo leer la imagen.')
    return img

def _binary(img, threshold, blur, invert):
    if blur:
        k=blur*2+1; img=cv2.GaussianBlur(img,(k,k),0)
    # Dark artwork becomes foreground by default.
    typ=cv2.THRESH_BINARY if invert else cv2.THRESH_BINARY_INV
    return cv2.threshold(img,threshold,255,typ)[1]

def _contour_path(binary, simplify, min_area):
    contours,h=cv2.findContours(binary,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_NONE)
    path=QPainterPath(); path.setFillRule(Qt.FillRule.OddEvenFill); kept=0
    for c in contours:
        if abs(cv2.contourArea(c)) < min_area: continue
        if simplify>0: c=cv2.approxPolyDP(c,simplify,True)
        pts=c.reshape(-1,2)
        if len(pts)<2: continue
        path.moveTo(float(pts[0,0]),float(pts[0,1]))
        for x,y in pts[1:]: path.lineTo(float(x),float(y))
        path.closeSubpath(); kept+=1
    return path,kept

def _centerline_path(binary, simplify, min_area):
    try:
        from skimage.morphology import skeletonize
    except Exception as e: raise RuntimeError('Línea central necesita scikit-image (incluido en requirements.txt).') from e
    sk=(skeletonize(binary>0).astype(np.uint8)*255)
    contours,_=cv2.findContours(sk,cv2.RETR_LIST,cv2.CHAIN_APPROX_NONE)
    path=QPainterPath(); kept=0
    for c in contours:
        if len(c)<3: continue
        if cv2.arcLength(c,False)<max(2.0,min_area): continue
        if simplify>0: c=cv2.approxPolyDP(c,simplify,False)
        pts=c.reshape(-1,2)
        if len(pts)<2: continue
        path.moveTo(float(pts[0,0]),float(pts[0,1]))
        for x,y in pts[1:]: path.lineTo(float(x),float(y))
        kept+=1
    return path,kept

def vectorize_selected(app):
    # Local import avoids circular import at application startup.
    from laser_studio import RasterItem, GItem
    selected=[x for x in app.scene.selectedItems() if isinstance(x,RasterItem)]
    if len(selected)!=1:
        QMessageBox.information(app,'Vectorizar imagen','Selecciona una sola imagen JPG/PNG/BMP para vectorizar.'); return
    src=selected[0]; dlg=VectorizeDialog(app)
    if dlg.exec()!=QDialog.DialogCode.Accepted:return
    try:
        img=_load_gray(src.source_path)
        binary=_binary(img,dlg.threshold.value(),dlg.blur.value(),dlg.invert.isChecked())
        if dlg.mode.currentIndex()==2: path,count=_centerline_path(binary,dlg.simplify.value(),dlg.min_area.value())
        else: path,count=_contour_path(binary,dlg.simplify.value(),dlg.min_area.value())
        if path.isEmpty(): raise ValueError('No se detectaron líneas. Prueba otro umbral.')
        kind='vector-centerline' if dlg.mode.currentIndex()==2 else ('vector-fill' if dlg.mode.currentIndex()==1 else 'vector-outline')
        out=GItem(path,kind); out.layer=src.layer
        # Same local pixel coordinate system as QGraphicsPixmapItem: preserves physical size and placement.
        out.setPos(src.pos()); out.setRotation(src.rotation()); out.setScale(src.scale()); out.setTransform(src.transform())
        out.setTransformOriginPoint(src.transformOriginPoint()); out.source_raster=str(src.source_path)
        app.scene.addItem(out); out.setSelected(True); src.setSelected(False)
        if dlg.fill.isChecked() or dlg.mode.currentIndex()==1:
            try: app.cuts[out.layer].mode='Fill'
            except Exception: pass
        if dlg.replace.isChecked(): app.scene.removeItem(src)
        app.changed=True
        if hasattr(app,'refresh_status'): app.refresh_status()
        if hasattr(app,'schedule_preview'): app.schedule_preview()
        app.statusBar().showMessage(f'Vectorización terminada · {count} trazados · {dlg.mode.currentText()}')
    except Exception as e:
        QMessageBox.warning(app,'Vectorizar imagen',str(e))
