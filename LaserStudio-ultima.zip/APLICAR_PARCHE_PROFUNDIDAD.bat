@echo off
REM Colocar esta .bat y la carpeta parche_profundidad en la RAIZ del proyecto
REM (donde esta ARRANCAR_43AYE3.bat). Haz doble clic o ejecutalo desde cmd.
REM   APLICAR_PARCHE_PROFUNDIDAD.bat             aplica y prueba
REM   APLICAR_PARCHE_PROFUNDIDAD.bat --revertir   deshace el parche
REM   APLICAR_PARCHE_PROFUNDIDAD.bat --solo-tests
chcp 65001 >nul
cd /d "%~dp0"

set "PY="
if exist "work\.venv\Scripts\python.exe" set "PY=work\.venv\Scripts\python.exe"
if not defined PY (
    where python >nul 2>nul
    if errorlevel 1 (
        echo No encuentro Python. Instala Python o usa el del proyecto.
        pause
        exit /b 1
    )
    set "PY=python"
)
echo Usando: %PY%
echo.

"%PY%" "%~dp0parche_profundidad\aplicar_parche.py" --proyecto "%~dp0." %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo TODO CORRECTO.) else (echo Terminado con codigo %RC%. Lee los mensajes de arriba.)
pause
exit /b %RC%
